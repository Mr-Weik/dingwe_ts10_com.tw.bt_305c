.class public Landroid/support/v7/app/p;
.super Landroid/support/v4/app/r;
.source ""

# interfaces
.implements Landroid/support/v7/app/q;
.implements Landroid/support/v4/app/ra;
.implements Landroid/support/v7/app/d;


# instance fields
.field private ba:Landroid/support/v7/app/r;

.field private hd:I

.field private mResources:Landroid/content/res/Resources;


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/support/v4/app/r;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, Landroid/support/v7/app/p;->hd:I

    return-void
.end method


# virtual methods
.method public B()Landroid/support/v7/app/r;
    .locals 2

    iget-object v0, p0, Landroid/support/v7/app/p;->ba:Landroid/support/v7/app/r;

    if-nez v0, :cond_0

    .line 1
    new-instance v0, Landroid/support/v7/app/I;

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    invoke-direct {v0, p0, v1, p0}, Landroid/support/v7/app/I;-><init>(Landroid/content/Context;Landroid/view/Window;Landroid/support/v7/app/q;)V

    .line 2
    iput-object v0, p0, Landroid/support/v7/app/p;->ba:Landroid/support/v7/app/r;

    :cond_0
    iget-object p0, p0, Landroid/support/v7/app/p;->ba:Landroid/support/v7/app/r;

    return-object p0
.end method

.method public X()V
    .locals 0

    invoke-virtual {p0}, Landroid/support/v7/app/p;->B()Landroid/support/v7/app/r;

    move-result-object p0

    invoke-virtual {p0}, Landroid/support/v7/app/r;->invalidateOptionsMenu()V

    return-void
.end method

.method public Y()Landroid/support/v7/app/c;
    .locals 0

    invoke-virtual {p0}, Landroid/support/v7/app/p;->B()Landroid/support/v7/app/r;

    move-result-object p0

    invoke-virtual {p0}, Landroid/support/v7/app/r;->Y()Landroid/support/v7/app/c;

    move-result-object p0

    return-object p0
.end method

.method public Z()V
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    return-void
.end method

.method public a(La/b/d/e/b;)La/b/d/e/c;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public a(La/b/d/e/c;)V
    .locals 0

    return-void
.end method

.method public a(Landroid/content/Intent;)V
    .locals 1

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-virtual {p0, p1}, Landroid/app/Activity;->navigateUpTo(Landroid/content/Intent;)Z

    return-void
.end method

.method public a(Landroid/support/v4/app/sa;)V
    .locals 0

    invoke-virtual {p1, p0}, Landroid/support/v4/app/sa;->addParentStack(Landroid/app/Activity;)Landroid/support/v4/app/sa;

    return-void
.end method

.method public aa()Z
    .locals 2

    invoke-virtual {p0}, Landroid/support/v7/app/p;->h()Landroid/content/Intent;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-virtual {p0, v0}, Landroid/support/v7/app/p;->b(Landroid/content/Intent;)Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-static {p0}, Landroid/support/v4/app/sa;->create(Landroid/content/Context;)Landroid/support/v4/app/sa;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroid/support/v7/app/p;->a(Landroid/support/v4/app/sa;)V

    invoke-virtual {p0, v0}, Landroid/support/v7/app/p;->b(Landroid/support/v4/app/sa;)V

    invoke-virtual {v0}, Landroid/support/v4/app/sa;->startActivities()V

    :try_start_0
    invoke-static {p0}, Landroid/support/v4/app/c;->c(Landroid/app/Activity;)V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    goto :goto_0

    :cond_0
    invoke-virtual {p0, v0}, Landroid/support/v7/app/p;->a(Landroid/content/Intent;)V

    :goto_0
    const/4 p0, 0x1

    return p0

    :cond_1
    const/4 p0, 0x0

    return p0
.end method

.method public addContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    .locals 0

    invoke-virtual {p0}, Landroid/support/v7/app/p;->B()Landroid/support/v7/app/r;

    move-result-object p0

    invoke-virtual {p0, p1, p2}, Landroid/support/v7/app/r;->addContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method public b(La/b/d/e/c;)V
    .locals 0

    return-void
.end method

.method public b(Landroid/support/v4/app/sa;)V
    .locals 0

    return-void
.end method

.method public b(Landroid/content/Intent;)Z
    .locals 1

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-virtual {p0, p1}, Landroid/app/Activity;->shouldUpRecreateTask(Landroid/content/Intent;)Z

    move-result p0

    return p0
.end method

.method public closeOptionsMenu()V
    .locals 3

    invoke-virtual {p0}, Landroid/support/v7/app/p;->Y()Landroid/support/v7/app/c;

    move-result-object v0

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/view/Window;->hasFeature(I)Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-super {p0}, Landroid/app/Activity;->closeOptionsMenu()V

    :cond_0
    return-void
.end method

.method public dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    .locals 3

    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result v0

    invoke-virtual {p0}, Landroid/support/v7/app/p;->Y()Landroid/support/v7/app/c;

    move-result-object v1

    const/16 v2, 0x52

    invoke-super {p0, p1}, Landroid/app/Activity;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z

    move-result p0

    return p0
.end method

.method public findViewById(I)Landroid/view/View;
    .locals 0

    invoke-virtual {p0}, Landroid/support/v7/app/p;->B()Landroid/support/v7/app/r;

    move-result-object p0

    invoke-virtual {p0, p1}, Landroid/support/v7/app/r;->findViewById(I)Landroid/view/View;

    move-result-object p0

    return-object p0
.end method

.method public getMenuInflater()Landroid/view/MenuInflater;
    .locals 0

    invoke-virtual {p0}, Landroid/support/v7/app/p;->B()Landroid/support/v7/app/r;

    move-result-object p0

    invoke-virtual {p0}, Landroid/support/v7/app/r;->getMenuInflater()Landroid/view/MenuInflater;

    move-result-object p0

    return-object p0
.end method

.method public getResources()Landroid/content/res/Resources;
    .locals 1

    iget-object v0, p0, Landroid/support/v7/app/p;->mResources:Landroid/content/res/Resources;

    if-nez v0, :cond_0

    invoke-static {}, Landroid/support/v7/widget/sc;->pa()Z

    :cond_0
    iget-object v0, p0, Landroid/support/v7/app/p;->mResources:Landroid/content/res/Resources;

    if-nez v0, :cond_1

    invoke-super {p0}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    :cond_1
    return-object v0
.end method

.method public h()Landroid/content/Intent;
    .locals 0

    invoke-static {p0}, La/b/a/a;->b(Landroid/app/Activity;)Landroid/content/Intent;

    move-result-object p0

    return-object p0
.end method

.method public invalidateOptionsMenu()V
    .locals 0

    invoke-virtual {p0}, Landroid/support/v7/app/p;->B()Landroid/support/v7/app/r;

    move-result-object p0

    invoke-virtual {p0}, Landroid/support/v7/app/r;->invalidateOptionsMenu()V

    return-void
.end method

.method public onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 1

    invoke-super {p0, p1}, Landroid/support/v4/app/r;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    invoke-virtual {p0}, Landroid/support/v7/app/p;->B()Landroid/support/v7/app/r;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/support/v7/app/r;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    iget-object v0, p0, Landroid/support/v7/app/p;->mResources:Landroid/content/res/Resources;

    if-eqz v0, :cond_0

    invoke-super {p0}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget-object p0, p0, Landroid/support/v7/app/p;->mResources:Landroid/content/res/Resources;

    invoke-virtual {p0, p1, v0}, Landroid/content/res/Resources;->updateConfiguration(Landroid/content/res/Configuration;Landroid/util/DisplayMetrics;)V

    :cond_0
    return-void
.end method

.method public onContentChanged()V
    .locals 0

    invoke-virtual {p0}, Landroid/support/v7/app/p;->Z()V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 3

    invoke-virtual {p0}, Landroid/support/v7/app/p;->B()Landroid/support/v7/app/r;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/v7/app/r;->Ia()V

    invoke-virtual {v0, p1}, Landroid/support/v7/app/r;->onCreate(Landroid/os/Bundle;)V

    invoke-virtual {v0}, Landroid/support/v7/app/r;->Ha()Z

    move-result v0

    if-eqz v0, :cond_0

    iget v0, p0, Landroid/support/v7/app/p;->hd:I

    if-eqz v0, :cond_0

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-virtual {p0}, Landroid/app/Activity;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v0

    iget v1, p0, Landroid/support/v7/app/p;->hd:I

    const/4 v2, 0x0

    invoke-virtual {p0, v0, v1, v2}, Landroid/app/Activity;->onApplyThemeResource(Landroid/content/res/Resources$Theme;IZ)V

    :cond_0
    invoke-super {p0, p1}, Landroid/support/v4/app/r;->onCreate(Landroid/os/Bundle;)V

    return-void
.end method

.method protected onDestroy()V
    .locals 0

    invoke-super {p0}, Landroid/support/v4/app/r;->onDestroy()V

    invoke-virtual {p0}, Landroid/support/v7/app/p;->B()Landroid/support/v7/app/r;

    move-result-object p0

    invoke-virtual {p0}, Landroid/support/v7/app/r;->onDestroy()V

    return-void
.end method

.method public onKeyDown(ILandroid/view/KeyEvent;)Z
    .locals 1

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2
    invoke-super {p0, p1, p2}, Landroid/app/Activity;->onKeyDown(ILandroid/view/KeyEvent;)Z

    move-result p0

    return p0
.end method

.method public final onMenuItemSelected(ILandroid/view/MenuItem;)Z
    .locals 1

    invoke-super {p0, p1, p2}, Landroid/support/v4/app/r;->onMenuItemSelected(ILandroid/view/MenuItem;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    invoke-virtual {p0}, Landroid/support/v7/app/p;->Y()Landroid/support/v7/app/c;

    move-result-object p1

    invoke-interface {p2}, Landroid/view/MenuItem;->getItemId()I

    move-result p2

    const v0, 0x102002c

    if-ne p2, v0, :cond_1

    if-eqz p1, :cond_1

    invoke-virtual {p1}, Landroid/support/v7/app/c;->getDisplayOptions()I

    move-result p1

    and-int/lit8 p1, p1, 0x4

    if-eqz p1, :cond_1

    invoke-virtual {p0}, Landroid/support/v7/app/p;->aa()Z

    move-result p0

    return p0

    :cond_1
    const/4 p0, 0x0

    return p0
.end method

.method public onMenuOpened(ILandroid/view/Menu;)Z
    .locals 0

    invoke-super {p0, p1, p2}, Landroid/app/Activity;->onMenuOpened(ILandroid/view/Menu;)Z

    move-result p0

    return p0
.end method

.method public onPanelClosed(ILandroid/view/Menu;)V
    .locals 0

    invoke-super {p0, p1, p2}, Landroid/support/v4/app/r;->onPanelClosed(ILandroid/view/Menu;)V

    return-void
.end method

.method protected onPostCreate(Landroid/os/Bundle;)V
    .locals 0

    invoke-super {p0, p1}, Landroid/app/Activity;->onPostCreate(Landroid/os/Bundle;)V

    invoke-virtual {p0}, Landroid/support/v7/app/p;->B()Landroid/support/v7/app/r;

    move-result-object p0

    invoke-virtual {p0, p1}, Landroid/support/v7/app/r;->onPostCreate(Landroid/os/Bundle;)V

    return-void
.end method

.method protected onPostResume()V
    .locals 0

    invoke-super {p0}, Landroid/support/v4/app/r;->onPostResume()V

    invoke-virtual {p0}, Landroid/support/v7/app/p;->B()Landroid/support/v7/app/r;

    move-result-object p0

    invoke-virtual {p0}, Landroid/support/v7/app/r;->onPostResume()V

    return-void
.end method

.method protected onSaveInstanceState(Landroid/os/Bundle;)V
    .locals 0

    invoke-super {p0, p1}, Landroid/support/v4/app/r;->onSaveInstanceState(Landroid/os/Bundle;)V

    invoke-virtual {p0}, Landroid/support/v7/app/p;->B()Landroid/support/v7/app/r;

    move-result-object p0

    invoke-virtual {p0, p1}, Landroid/support/v7/app/r;->onSaveInstanceState(Landroid/os/Bundle;)V

    return-void
.end method

.method protected onStart()V
    .locals 0

    invoke-super {p0}, Landroid/support/v4/app/r;->onStart()V

    invoke-virtual {p0}, Landroid/support/v7/app/p;->B()Landroid/support/v7/app/r;

    move-result-object p0

    invoke-virtual {p0}, Landroid/support/v7/app/r;->onStart()V

    return-void
.end method

.method protected onStop()V
    .locals 0

    invoke-super {p0}, Landroid/support/v4/app/r;->onStop()V

    invoke-virtual {p0}, Landroid/support/v7/app/p;->B()Landroid/support/v7/app/r;

    move-result-object p0

    invoke-virtual {p0}, Landroid/support/v7/app/r;->onStop()V

    return-void
.end method

.method protected onTitleChanged(Ljava/lang/CharSequence;I)V
    .locals 0

    invoke-super {p0, p1, p2}, Landroid/app/Activity;->onTitleChanged(Ljava/lang/CharSequence;I)V

    invoke-virtual {p0}, Landroid/support/v7/app/p;->B()Landroid/support/v7/app/r;

    move-result-object p0

    invoke-virtual {p0, p1}, Landroid/support/v7/app/r;->setTitle(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public openOptionsMenu()V
    .locals 3

    invoke-virtual {p0}, Landroid/support/v7/app/p;->Y()Landroid/support/v7/app/c;

    move-result-object v0

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/view/Window;->hasFeature(I)Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-super {p0}, Landroid/app/Activity;->openOptionsMenu()V

    :cond_0
    return-void
.end method

.method public setContentView(I)V
    .locals 0

    invoke-virtual {p0}, Landroid/support/v7/app/p;->B()Landroid/support/v7/app/r;

    move-result-object p0

    invoke-virtual {p0, p1}, Landroid/support/v7/app/r;->setContentView(I)V

    return-void
.end method

.method public setContentView(Landroid/view/View;)V
    .locals 0

    invoke-virtual {p0}, Landroid/support/v7/app/p;->B()Landroid/support/v7/app/r;

    move-result-object p0

    invoke-virtual {p0, p1}, Landroid/support/v7/app/r;->setContentView(Landroid/view/View;)V

    return-void
.end method

.method public setContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    .locals 0

    invoke-virtual {p0}, Landroid/support/v7/app/p;->B()Landroid/support/v7/app/r;

    move-result-object p0

    invoke-virtual {p0, p1, p2}, Landroid/support/v7/app/r;->setContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method public setTheme(I)V
    .locals 0

    invoke-super {p0, p1}, Landroid/app/Activity;->setTheme(I)V

    iput p1, p0, Landroid/support/v7/app/p;->hd:I

    return-void
.end method
