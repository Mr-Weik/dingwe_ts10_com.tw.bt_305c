.class public final Landroid/support/v7/app/G;
.super Ljava/lang/Object;
.source ""


# instance fields
.field Qj:Landroid/content/Context;

.field background:I

.field createdPanelView:Landroid/view/View;

.field decorView:Landroid/view/ViewGroup;

.field featureId:I

.field frozenActionViewState:Landroid/os/Bundle;

.field gravity:I

.field isHandled:Z

.field isOpen:Z

.field isPrepared:Z

.field listMenuPresenter:Landroid/support/v7/view/menu/n;

.field menu:Landroid/support/v7/view/menu/r;

.field public qwertyMode:Z

.field refreshDecorView:Z

.field refreshMenuContent:Z

.field shownPanelView:Landroid/view/View;

.field windowAnimations:I

.field x:I

.field y:I


# direct methods
.method constructor <init>(I)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Landroid/support/v7/app/G;->featureId:I

    const/4 p1, 0x0

    iput-boolean p1, p0, Landroid/support/v7/app/G;->refreshDecorView:Z

    return-void
.end method


# virtual methods
.method e(Landroid/support/v7/view/menu/r;)V
    .locals 2

    iget-object v0, p0, Landroid/support/v7/app/G;->menu:Landroid/support/v7/view/menu/r;

    if-ne p1, v0, :cond_0

    return-void

    :cond_0
    if-eqz v0, :cond_1

    iget-object v1, p0, Landroid/support/v7/app/G;->listMenuPresenter:Landroid/support/v7/view/menu/n;

    invoke-virtual {v0, v1}, Landroid/support/v7/view/menu/r;->b(Landroid/support/v7/view/menu/G;)V

    :cond_1
    iput-object p1, p0, Landroid/support/v7/app/G;->menu:Landroid/support/v7/view/menu/r;

    if-eqz p1, :cond_2

    iget-object p0, p0, Landroid/support/v7/app/G;->listMenuPresenter:Landroid/support/v7/view/menu/n;

    if-eqz p0, :cond_2

    invoke-virtual {p1, p0}, Landroid/support/v7/view/menu/r;->a(Landroid/support/v7/view/menu/G;)V

    :cond_2
    return-void
.end method

.method setStyle(Landroid/content/Context;)V
    .locals 4

    new-instance v0, Landroid/util/TypedValue;

    invoke-direct {v0}, Landroid/util/TypedValue;-><init>()V

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->newTheme()Landroid/content/res/Resources$Theme;

    move-result-object v1

    invoke-virtual {p1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/content/res/Resources$Theme;->setTo(Landroid/content/res/Resources$Theme;)V

    const/4 v2, 0x1

    const v3, 0x7f030002

    invoke-virtual {v1, v3, v0, v2}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    iget v3, v0, Landroid/util/TypedValue;->resourceId:I

    if-eqz v3, :cond_0

    invoke-virtual {v1, v3, v2}, Landroid/content/res/Resources$Theme;->applyStyle(IZ)V

    :cond_0
    const v3, 0x7f0300b9

    invoke-virtual {v1, v3, v0, v2}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    iget v0, v0, Landroid/util/TypedValue;->resourceId:I

    if-eqz v0, :cond_1

    goto :goto_0

    :cond_1
    const v0, 0x7f0f00fb

    :goto_0
    invoke-virtual {v1, v0, v2}, Landroid/content/res/Resources$Theme;->applyStyle(IZ)V

    new-instance v0, La/b/d/e/e;

    const/4 v3, 0x0

    invoke-direct {v0, p1, v3}, La/b/d/e/e;-><init>(Landroid/content/Context;I)V

    invoke-virtual {v0}, La/b/d/e/e;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object p1

    invoke-virtual {p1, v1}, Landroid/content/res/Resources$Theme;->setTo(Landroid/content/res/Resources$Theme;)V

    iput-object v0, p0, Landroid/support/v7/app/G;->Qj:Landroid/content/Context;

    sget-object p1, La/b/d/a/b;->nk:[I

    invoke-virtual {v0, p1}, Landroid/content/Context;->obtainStyledAttributes([I)Landroid/content/res/TypedArray;

    move-result-object p1

    const/16 v0, 0x50

    invoke-virtual {p1, v0, v3}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v0

    iput v0, p0, Landroid/support/v7/app/G;->background:I

    invoke-virtual {p1, v2, v3}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v0

    iput v0, p0, Landroid/support/v7/app/G;->windowAnimations:I

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    return-void
.end method
