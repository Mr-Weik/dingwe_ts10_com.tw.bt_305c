.class public Landroid/support/v7/app/S;
.super La/b/d/e/c;
.source ""

# interfaces
.implements Landroid/support/v7/view/menu/p;


# instance fields
.field private final kl:Landroid/content/Context;

.field private ll:Ljava/lang/ref/WeakReference;

.field private mCallback:La/b/d/e/b;

.field private final mMenu:Landroid/support/v7/view/menu/r;

.field final synthetic n:Landroid/support/v7/app/T;


# direct methods
.method public constructor <init>(Landroid/support/v7/app/T;Landroid/content/Context;La/b/d/e/b;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/app/S;->n:Landroid/support/v7/app/T;

    invoke-direct {p0}, La/b/d/e/c;-><init>()V

    iput-object p2, p0, Landroid/support/v7/app/S;->kl:Landroid/content/Context;

    iput-object p3, p0, Landroid/support/v7/app/S;->mCallback:La/b/d/e/b;

    new-instance p1, Landroid/support/v7/view/menu/r;

    invoke-direct {p1, p2}, Landroid/support/v7/view/menu/r;-><init>(Landroid/content/Context;)V

    const/4 p2, 0x1

    invoke-virtual {p1, p2}, Landroid/support/v7/view/menu/r;->setDefaultShowAsAction(I)Landroid/support/v7/view/menu/r;

    iput-object p1, p0, Landroid/support/v7/app/S;->mMenu:Landroid/support/v7/view/menu/r;

    iget-object p1, p0, Landroid/support/v7/app/S;->mMenu:Landroid/support/v7/view/menu/r;

    invoke-virtual {p1, p0}, Landroid/support/v7/view/menu/r;->a(Landroid/support/v7/view/menu/p;)V

    return-void
.end method


# virtual methods
.method public b(Landroid/support/v7/view/menu/r;)V
    .locals 0

    iget-object p1, p0, Landroid/support/v7/app/S;->mCallback:La/b/d/e/b;

    if-nez p1, :cond_0

    return-void

    :cond_0
    invoke-virtual {p0}, Landroid/support/v7/app/S;->invalidate()V

    iget-object p0, p0, Landroid/support/v7/app/S;->n:Landroid/support/v7/app/T;

    iget-object p0, p0, Landroid/support/v7/app/T;->hi:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {p0}, Landroid/support/v7/widget/ActionBarContextView;->showOverflowMenu()Z

    return-void
.end method

.method public c(Landroid/support/v7/view/menu/r;Landroid/view/MenuItem;)Z
    .locals 0

    iget-object p1, p0, Landroid/support/v7/app/S;->mCallback:La/b/d/e/b;

    if-eqz p1, :cond_0

    invoke-interface {p1, p0, p2}, La/b/d/e/b;->a(La/b/d/e/c;Landroid/view/MenuItem;)Z

    move-result p0

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public dispatchOnCreate()Z
    .locals 2

    iget-object v0, p0, Landroid/support/v7/app/S;->mMenu:Landroid/support/v7/view/menu/r;

    invoke-virtual {v0}, Landroid/support/v7/view/menu/r;->stopDispatchingItemsChanged()V

    :try_start_0
    iget-object v0, p0, Landroid/support/v7/app/S;->mCallback:La/b/d/e/b;

    iget-object v1, p0, Landroid/support/v7/app/S;->mMenu:Landroid/support/v7/view/menu/r;

    invoke-interface {v0, p0, v1}, La/b/d/e/b;->a(La/b/d/e/c;Landroid/view/Menu;)Z

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object p0, p0, Landroid/support/v7/app/S;->mMenu:Landroid/support/v7/view/menu/r;

    invoke-virtual {p0}, Landroid/support/v7/view/menu/r;->startDispatchingItemsChanged()V

    return v0

    :catchall_0
    move-exception v0

    iget-object p0, p0, Landroid/support/v7/app/S;->mMenu:Landroid/support/v7/view/menu/r;

    invoke-virtual {p0}, Landroid/support/v7/view/menu/r;->startDispatchingItemsChanged()V

    throw v0
.end method

.method public finish()V
    .locals 4

    iget-object v0, p0, Landroid/support/v7/app/S;->n:Landroid/support/v7/app/T;

    iget-object v1, v0, Landroid/support/v7/app/T;->mActionMode:Landroid/support/v7/app/S;

    if-eq v1, p0, :cond_0

    return-void

    :cond_0
    iget-boolean v1, v0, Landroid/support/v7/app/T;->oi:Z

    iget-boolean v0, v0, Landroid/support/v7/app/T;->qi:Z

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-nez v1, :cond_1

    if-eqz v0, :cond_2

    :cond_1
    move v2, v3

    :cond_2
    if-nez v2, :cond_3

    iget-object v0, p0, Landroid/support/v7/app/S;->n:Landroid/support/v7/app/T;

    iput-object p0, v0, Landroid/support/v7/app/T;->mDeferredDestroyActionMode:La/b/d/e/c;

    iget-object v1, p0, Landroid/support/v7/app/S;->mCallback:La/b/d/e/b;

    iput-object v1, v0, Landroid/support/v7/app/T;->mDeferredModeDestroyCallback:La/b/d/e/b;

    goto :goto_0

    :cond_3
    iget-object v0, p0, Landroid/support/v7/app/S;->mCallback:La/b/d/e/b;

    invoke-interface {v0, p0}, La/b/d/e/b;->c(La/b/d/e/c;)V

    :goto_0
    const/4 v0, 0x0

    iput-object v0, p0, Landroid/support/v7/app/S;->mCallback:La/b/d/e/b;

    iget-object v1, p0, Landroid/support/v7/app/S;->n:Landroid/support/v7/app/T;

    invoke-virtual {v1, v3}, Landroid/support/v7/app/T;->animateToMode(Z)V

    iget-object v1, p0, Landroid/support/v7/app/S;->n:Landroid/support/v7/app/T;

    iget-object v1, v1, Landroid/support/v7/app/T;->hi:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {v1}, Landroid/support/v7/widget/ActionBarContextView;->closeMode()V

    iget-object v1, p0, Landroid/support/v7/app/S;->n:Landroid/support/v7/app/T;

    iget-object v1, v1, Landroid/support/v7/app/T;->gi:Landroid/support/v7/widget/ha;

    check-cast v1, Landroid/support/v7/widget/qc;

    invoke-virtual {v1}, Landroid/support/v7/widget/qc;->getViewGroup()Landroid/view/ViewGroup;

    move-result-object v1

    const/16 v2, 0x20

    invoke-virtual {v1, v2}, Landroid/view/ViewGroup;->sendAccessibilityEvent(I)V

    iget-object v1, p0, Landroid/support/v7/app/S;->n:Landroid/support/v7/app/T;

    iget-object v2, v1, Landroid/support/v7/app/T;->ei:Landroid/support/v7/widget/ActionBarOverlayLayout;

    iget-boolean v1, v1, Landroid/support/v7/app/T;->mHideOnContentScroll:Z

    invoke-virtual {v2, v1}, Landroid/support/v7/widget/ActionBarOverlayLayout;->setHideOnContentScrollEnabled(Z)V

    iget-object p0, p0, Landroid/support/v7/app/S;->n:Landroid/support/v7/app/T;

    iput-object v0, p0, Landroid/support/v7/app/T;->mActionMode:Landroid/support/v7/app/S;

    return-void
.end method

.method public getCustomView()Landroid/view/View;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/app/S;->ll:Ljava/lang/ref/WeakReference;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/view/View;

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return-object p0
.end method

.method public getMenu()Landroid/view/Menu;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/app/S;->mMenu:Landroid/support/v7/view/menu/r;

    return-object p0
.end method

.method public getMenuInflater()Landroid/view/MenuInflater;
    .locals 1

    new-instance v0, La/b/d/e/k;

    iget-object p0, p0, Landroid/support/v7/app/S;->kl:Landroid/content/Context;

    invoke-direct {v0, p0}, La/b/d/e/k;-><init>(Landroid/content/Context;)V

    return-object v0
.end method

.method public getSubtitle()Ljava/lang/CharSequence;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/app/S;->n:Landroid/support/v7/app/T;

    iget-object p0, p0, Landroid/support/v7/app/T;->hi:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {p0}, Landroid/support/v7/widget/ActionBarContextView;->getSubtitle()Ljava/lang/CharSequence;

    move-result-object p0

    return-object p0
.end method

.method public getTitle()Ljava/lang/CharSequence;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/app/S;->n:Landroid/support/v7/app/T;

    iget-object p0, p0, Landroid/support/v7/app/T;->hi:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {p0}, Landroid/support/v7/widget/ActionBarContextView;->getTitle()Ljava/lang/CharSequence;

    move-result-object p0

    return-object p0
.end method

.method public invalidate()V
    .locals 2

    iget-object v0, p0, Landroid/support/v7/app/S;->n:Landroid/support/v7/app/T;

    iget-object v0, v0, Landroid/support/v7/app/T;->mActionMode:Landroid/support/v7/app/S;

    if-eq v0, p0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Landroid/support/v7/app/S;->mMenu:Landroid/support/v7/view/menu/r;

    invoke-virtual {v0}, Landroid/support/v7/view/menu/r;->stopDispatchingItemsChanged()V

    :try_start_0
    iget-object v0, p0, Landroid/support/v7/app/S;->mCallback:La/b/d/e/b;

    iget-object v1, p0, Landroid/support/v7/app/S;->mMenu:Landroid/support/v7/view/menu/r;

    invoke-interface {v0, p0, v1}, La/b/d/e/b;->b(La/b/d/e/c;Landroid/view/Menu;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object p0, p0, Landroid/support/v7/app/S;->mMenu:Landroid/support/v7/view/menu/r;

    invoke-virtual {p0}, Landroid/support/v7/view/menu/r;->startDispatchingItemsChanged()V

    return-void

    :catchall_0
    move-exception v0

    iget-object p0, p0, Landroid/support/v7/app/S;->mMenu:Landroid/support/v7/view/menu/r;

    invoke-virtual {p0}, Landroid/support/v7/view/menu/r;->startDispatchingItemsChanged()V

    throw v0
.end method

.method public isTitleOptional()Z
    .locals 0

    iget-object p0, p0, Landroid/support/v7/app/S;->n:Landroid/support/v7/app/T;

    iget-object p0, p0, Landroid/support/v7/app/T;->hi:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {p0}, Landroid/support/v7/widget/ActionBarContextView;->isTitleOptional()Z

    move-result p0

    return p0
.end method

.method public setCustomView(Landroid/view/View;)V
    .locals 1

    iget-object v0, p0, Landroid/support/v7/app/S;->n:Landroid/support/v7/app/T;

    iget-object v0, v0, Landroid/support/v7/app/T;->hi:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {v0, p1}, Landroid/support/v7/widget/ActionBarContextView;->setCustomView(Landroid/view/View;)V

    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Landroid/support/v7/app/S;->ll:Ljava/lang/ref/WeakReference;

    return-void
.end method

.method public setSubtitle(I)V
    .locals 1

    iget-object v0, p0, Landroid/support/v7/app/S;->n:Landroid/support/v7/app/T;

    iget-object v0, v0, Landroid/support/v7/app/T;->mContext:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p1

    .line 1
    iget-object p0, p0, Landroid/support/v7/app/S;->n:Landroid/support/v7/app/T;

    iget-object p0, p0, Landroid/support/v7/app/T;->hi:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/ActionBarContextView;->setSubtitle(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public setSubtitle(Ljava/lang/CharSequence;)V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/app/S;->n:Landroid/support/v7/app/T;

    iget-object p0, p0, Landroid/support/v7/app/T;->hi:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/ActionBarContextView;->setSubtitle(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public setTitle(I)V
    .locals 1

    iget-object v0, p0, Landroid/support/v7/app/S;->n:Landroid/support/v7/app/T;

    iget-object v0, v0, Landroid/support/v7/app/T;->mContext:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p1

    .line 1
    iget-object p0, p0, Landroid/support/v7/app/S;->n:Landroid/support/v7/app/T;

    iget-object p0, p0, Landroid/support/v7/app/T;->hi:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/ActionBarContextView;->setTitle(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public setTitle(Ljava/lang/CharSequence;)V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/app/S;->n:Landroid/support/v7/app/T;

    iget-object p0, p0, Landroid/support/v7/app/T;->hi:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/ActionBarContextView;->setTitle(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public setTitleOptionalHint(Z)V
    .locals 0

    invoke-super {p0, p1}, La/b/d/e/c;->setTitleOptionalHint(Z)V

    iget-object p0, p0, Landroid/support/v7/app/S;->n:Landroid/support/v7/app/T;

    iget-object p0, p0, Landroid/support/v7/app/T;->hi:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/ActionBarContextView;->setTitleOptional(Z)V

    return-void
.end method
