.class Landroid/support/v7/app/x;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic n:Landroid/support/v7/app/I;


# direct methods
.method constructor <init>(Landroid/support/v7/app/I;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/app/x;->n:Landroid/support/v7/app/I;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    iget-object v0, p0, Landroid/support/v7/app/x;->n:Landroid/support/v7/app/I;

    iget-object v1, v0, Landroid/support/v7/app/I;->hj:Landroid/widget/PopupWindow;

    iget-object v0, v0, Landroid/support/v7/app/I;->gj:Landroid/support/v7/widget/ActionBarContextView;

    const/4 v2, 0x0

    const/16 v3, 0x37

    invoke-virtual {v1, v0, v3, v2, v2}, Landroid/widget/PopupWindow;->showAtLocation(Landroid/view/View;III)V

    iget-object v0, p0, Landroid/support/v7/app/x;->n:Landroid/support/v7/app/I;

    invoke-virtual {v0}, Landroid/support/v7/app/I;->Ja()V

    iget-object v0, p0, Landroid/support/v7/app/x;->n:Landroid/support/v7/app/I;

    invoke-virtual {v0}, Landroid/support/v7/app/I;->Oa()Z

    move-result v0

    const/high16 v1, 0x3f800000    # 1.0f

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroid/support/v7/app/x;->n:Landroid/support/v7/app/I;

    iget-object v0, v0, Landroid/support/v7/app/I;->gj:Landroid/support/v7/widget/ActionBarContextView;

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Landroid/view/ViewGroup;->setAlpha(F)V

    iget-object v0, p0, Landroid/support/v7/app/x;->n:Landroid/support/v7/app/I;

    iget-object v2, v0, Landroid/support/v7/app/I;->gj:Landroid/support/v7/widget/ActionBarContextView;

    invoke-static {v2}, Landroid/support/v4/view/r;->j(Landroid/view/View;)Landroid/support/v4/view/w;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroid/support/v4/view/w;->alpha(F)Landroid/support/v4/view/w;

    iput-object v2, v0, Landroid/support/v7/app/I;->jj:Landroid/support/v4/view/w;

    iget-object v0, p0, Landroid/support/v7/app/x;->n:Landroid/support/v7/app/I;

    iget-object v0, v0, Landroid/support/v7/app/I;->jj:Landroid/support/v4/view/w;

    new-instance v1, Landroid/support/v7/app/w;

    invoke-direct {v1, p0}, Landroid/support/v7/app/w;-><init>(Landroid/support/v7/app/x;)V

    invoke-virtual {v0, v1}, Landroid/support/v4/view/w;->a(Landroid/support/v4/view/x;)Landroid/support/v4/view/w;

    goto :goto_0

    :cond_0
    iget-object v0, p0, Landroid/support/v7/app/x;->n:Landroid/support/v7/app/I;

    iget-object v0, v0, Landroid/support/v7/app/I;->gj:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->setAlpha(F)V

    iget-object p0, p0, Landroid/support/v7/app/x;->n:Landroid/support/v7/app/I;

    iget-object p0, p0, Landroid/support/v7/app/I;->gj:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {p0, v2}, Landroid/support/v7/widget/ActionBarContextView;->setVisibility(I)V

    :goto_0
    return-void
.end method
