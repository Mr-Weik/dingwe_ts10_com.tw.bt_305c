.class Landroid/support/v7/app/w;
.super Landroid/support/v4/view/y;
.source ""


# instance fields
.field final synthetic Hc:Landroid/support/v7/app/x;


# direct methods
.method constructor <init>(Landroid/support/v7/app/x;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/app/w;->Hc:Landroid/support/v7/app/x;

    invoke-direct {p0}, Landroid/support/v4/view/y;-><init>()V

    return-void
.end method


# virtual methods
.method public d(Landroid/view/View;)V
    .locals 1

    iget-object p1, p0, Landroid/support/v7/app/w;->Hc:Landroid/support/v7/app/x;

    iget-object p1, p1, Landroid/support/v7/app/x;->n:Landroid/support/v7/app/I;

    iget-object p1, p1, Landroid/support/v7/app/I;->gj:Landroid/support/v7/widget/ActionBarContextView;

    const/high16 v0, 0x3f800000    # 1.0f

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->setAlpha(F)V

    iget-object p1, p0, Landroid/support/v7/app/w;->Hc:Landroid/support/v7/app/x;

    iget-object p1, p1, Landroid/support/v7/app/x;->n:Landroid/support/v7/app/I;

    iget-object p1, p1, Landroid/support/v7/app/I;->jj:Landroid/support/v4/view/w;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/support/v4/view/w;->a(Landroid/support/v4/view/x;)Landroid/support/v4/view/w;

    iget-object p0, p0, Landroid/support/v7/app/w;->Hc:Landroid/support/v7/app/x;

    iget-object p0, p0, Landroid/support/v7/app/x;->n:Landroid/support/v7/app/I;

    iput-object v0, p0, Landroid/support/v7/app/I;->jj:Landroid/support/v4/view/w;

    return-void
.end method

.method public f(Landroid/view/View;)V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/app/w;->Hc:Landroid/support/v7/app/x;

    iget-object p0, p0, Landroid/support/v7/app/x;->n:Landroid/support/v7/app/I;

    iget-object p0, p0, Landroid/support/v7/app/I;->gj:Landroid/support/v7/widget/ActionBarContextView;

    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/ActionBarContextView;->setVisibility(I)V

    return-void
.end method
