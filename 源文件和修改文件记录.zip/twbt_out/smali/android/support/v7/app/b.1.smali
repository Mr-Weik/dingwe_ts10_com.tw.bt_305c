.class public interface abstract Landroid/support/v7/app/b;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract onMenuVisibilityChanged(Z)V
.end method
