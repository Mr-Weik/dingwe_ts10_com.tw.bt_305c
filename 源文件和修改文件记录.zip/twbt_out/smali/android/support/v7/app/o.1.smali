.class public Landroid/support/v7/app/o;
.super Landroid/support/v7/app/J;
.source ""

# interfaces
.implements Landroid/content/DialogInterface;


# instance fields
.field final mAlert:Landroid/support/v7/app/m;


# direct methods
.method protected constructor <init>(Landroid/content/Context;I)V
    .locals 1

    invoke-static {p1, p2}, Landroid/support/v7/app/o;->resolveDialogTheme(Landroid/content/Context;I)I

    move-result p2

    invoke-direct {p0, p1, p2}, Landroid/support/v7/app/J;-><init>(Landroid/content/Context;I)V

    new-instance p1, Landroid/support/v7/app/m;

    invoke-virtual {p0}, Landroid/app/Dialog;->getContext()Landroid/content/Context;

    move-result-object p2

    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-direct {p1, p2, p0, v0}, Landroid/support/v7/app/m;-><init>(Landroid/content/Context;Landroid/support/v7/app/J;Landroid/view/Window;)V

    iput-object p1, p0, Landroid/support/v7/app/o;->mAlert:Landroid/support/v7/app/m;

    return-void
.end method

.method static resolveDialogTheme(Landroid/content/Context;I)I
    .locals 2

    ushr-int/lit8 v0, p1, 0x18

    and-int/lit16 v0, v0, 0xff

    const/4 v1, 0x1

    if-lt v0, v1, :cond_0

    return p1

    :cond_0
    new-instance p1, Landroid/util/TypedValue;

    invoke-direct {p1}, Landroid/util/TypedValue;-><init>()V

    invoke-virtual {p0}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object p0

    const v0, 0x7f030025

    invoke-virtual {p0, v0, p1, v1}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    iget p0, p1, Landroid/util/TypedValue;->resourceId:I

    return p0
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 0

    invoke-super {p0, p1}, Landroid/support/v7/app/J;->onCreate(Landroid/os/Bundle;)V

    iget-object p0, p0, Landroid/support/v7/app/o;->mAlert:Landroid/support/v7/app/m;

    invoke-virtual {p0}, Landroid/support/v7/app/m;->installContent()V

    return-void
.end method

.method public onKeyDown(ILandroid/view/KeyEvent;)Z
    .locals 2

    iget-object v0, p0, Landroid/support/v7/app/o;->mAlert:Landroid/support/v7/app/m;

    .line 1
    iget-object v0, v0, Landroid/support/v7/app/m;->mScrollView:Landroid/support/v4/widget/NestedScrollView;

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    invoke-virtual {v0, p2}, Landroid/support/v4/widget/NestedScrollView;->executeKeyEvent(Landroid/view/KeyEvent;)Z

    move-result v0

    if-eqz v0, :cond_0

    move v0, v1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    if-eqz v0, :cond_1

    return v1

    .line 2
    :cond_1
    invoke-super {p0, p1, p2}, Landroid/app/Dialog;->onKeyDown(ILandroid/view/KeyEvent;)Z

    move-result p0

    return p0
.end method

.method public onKeyUp(ILandroid/view/KeyEvent;)Z
    .locals 2

    iget-object v0, p0, Landroid/support/v7/app/o;->mAlert:Landroid/support/v7/app/m;

    .line 1
    iget-object v0, v0, Landroid/support/v7/app/m;->mScrollView:Landroid/support/v4/widget/NestedScrollView;

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    invoke-virtual {v0, p2}, Landroid/support/v4/widget/NestedScrollView;->executeKeyEvent(Landroid/view/KeyEvent;)Z

    move-result v0

    if-eqz v0, :cond_0

    move v0, v1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    if-eqz v0, :cond_1

    return v1

    .line 2
    :cond_1
    invoke-super {p0, p1, p2}, Landroid/app/Dialog;->onKeyUp(ILandroid/view/KeyEvent;)Z

    move-result p0

    return p0
.end method

.method public setTitle(Ljava/lang/CharSequence;)V
    .locals 0

    invoke-super {p0, p1}, Landroid/support/v7/app/J;->setTitle(Ljava/lang/CharSequence;)V

    iget-object p0, p0, Landroid/support/v7/app/o;->mAlert:Landroid/support/v7/app/m;

    invoke-virtual {p0, p1}, Landroid/support/v7/app/m;->setTitle(Ljava/lang/CharSequence;)V

    return-void
.end method
