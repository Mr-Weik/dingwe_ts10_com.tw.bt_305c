.class Landroid/support/v7/app/u;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/support/v4/view/n;


# instance fields
.field final synthetic n:Landroid/support/v7/app/I;


# direct methods
.method constructor <init>(Landroid/support/v7/app/I;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/app/u;->n:Landroid/support/v7/app/I;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Landroid/view/View;Landroid/support/v4/view/A;)Landroid/support/v4/view/A;
    .locals 3

    invoke-virtual {p2}, Landroid/support/v4/view/A;->getSystemWindowInsetTop()I

    move-result v0

    iget-object p0, p0, Landroid/support/v7/app/u;->n:Landroid/support/v7/app/I;

    invoke-virtual {p0, v0}, Landroid/support/v7/app/I;->T(I)I

    move-result p0

    if-eq v0, p0, :cond_0

    invoke-virtual {p2}, Landroid/support/v4/view/A;->getSystemWindowInsetLeft()I

    move-result v0

    invoke-virtual {p2}, Landroid/support/v4/view/A;->getSystemWindowInsetRight()I

    move-result v1

    invoke-virtual {p2}, Landroid/support/v4/view/A;->getSystemWindowInsetBottom()I

    move-result v2

    invoke-virtual {p2, v0, p0, v1, v2}, Landroid/support/v4/view/A;->replaceSystemWindowInsets(IIII)Landroid/support/v4/view/A;

    move-result-object p2

    :cond_0
    invoke-static {p1, p2}, Landroid/support/v4/view/r;->a(Landroid/view/View;Landroid/support/v4/view/A;)Landroid/support/v4/view/A;

    move-result-object p0

    return-object p0
.end method
