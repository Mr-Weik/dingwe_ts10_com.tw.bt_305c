.class final Landroid/support/v7/app/H;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/support/v7/view/menu/F;


# instance fields
.field final synthetic n:Landroid/support/v7/app/I;


# direct methods
.method constructor <init>(Landroid/support/v7/app/I;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/app/H;->n:Landroid/support/v7/app/I;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Landroid/support/v7/view/menu/r;Z)V
    .locals 4

    invoke-virtual {p1}, Landroid/support/v7/view/menu/r;->getRootMenu()Landroid/support/v7/view/menu/r;

    move-result-object v0

    const/4 v1, 0x1

    if-eq v0, p1, :cond_0

    move v2, v1

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    :goto_0
    iget-object v3, p0, Landroid/support/v7/app/H;->n:Landroid/support/v7/app/I;

    if-eqz v2, :cond_1

    move-object p1, v0

    :cond_1
    invoke-virtual {v3, p1}, Landroid/support/v7/app/I;->findMenuPanel(Landroid/view/Menu;)Landroid/support/v7/app/G;

    move-result-object p1

    if-eqz p1, :cond_3

    if-eqz v2, :cond_2

    iget-object p2, p0, Landroid/support/v7/app/H;->n:Landroid/support/v7/app/I;

    iget v2, p1, Landroid/support/v7/app/G;->featureId:I

    invoke-virtual {p2, v2, p1, v0}, Landroid/support/v7/app/I;->a(ILandroid/support/v7/app/G;Landroid/view/Menu;)V

    iget-object p0, p0, Landroid/support/v7/app/H;->n:Landroid/support/v7/app/I;

    invoke-virtual {p0, p1, v1}, Landroid/support/v7/app/I;->a(Landroid/support/v7/app/G;Z)V

    goto :goto_1

    :cond_2
    iget-object p0, p0, Landroid/support/v7/app/H;->n:Landroid/support/v7/app/I;

    invoke-virtual {p0, p1, p2}, Landroid/support/v7/app/I;->a(Landroid/support/v7/app/G;Z)V

    :cond_3
    :goto_1
    return-void
.end method

.method public a(Landroid/support/v7/view/menu/r;)Z
    .locals 2

    if-nez p1, :cond_0

    iget-object v0, p0, Landroid/support/v7/app/H;->n:Landroid/support/v7/app/I;

    iget-boolean v1, v0, Landroid/support/v7/app/I;->qj:Z

    if-eqz v1, :cond_0

    invoke-virtual {v0}, Landroid/support/v7/app/I;->La()Landroid/view/Window$Callback;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-object p0, p0, Landroid/support/v7/app/H;->n:Landroid/support/v7/app/I;

    invoke-static {p0}, Landroid/support/v7/app/I;->a(Landroid/support/v7/app/I;)Z

    move-result p0

    if-nez p0, :cond_0

    const/16 p0, 0x6c

    invoke-interface {v0, p0, p1}, Landroid/view/Window$Callback;->onMenuOpened(ILandroid/view/Menu;)Z

    :cond_0
    const/4 p0, 0x1

    return p0
.end method
