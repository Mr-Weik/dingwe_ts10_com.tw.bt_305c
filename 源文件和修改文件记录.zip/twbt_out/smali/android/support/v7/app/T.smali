.class public Landroid/support/v7/app/T;
.super Landroid/support/v7/app/c;
.source ""

# interfaces
.implements Landroid/support/v7/widget/h;


# static fields
.field private static final wi:Landroid/view/animation/Interpolator;

.field private static final xi:Landroid/view/animation/Interpolator;


# instance fields
.field private di:Landroid/content/Context;

.field ei:Landroid/support/v7/widget/ActionBarOverlayLayout;

.field fi:Landroid/support/v7/widget/ActionBarContainer;

.field gi:Landroid/support/v7/widget/ha;

.field hi:Landroid/support/v7/widget/ActionBarContextView;

.field private ii:Z

.field private ji:Z

.field private ki:Ljava/util/ArrayList;

.field private li:Z

.field mActionMode:Landroid/support/v7/app/S;

.field mContentView:Landroid/view/View;

.field mContext:Landroid/content/Context;

.field mDeferredDestroyActionMode:La/b/d/e/c;

.field mDeferredModeDestroyCallback:La/b/d/e/b;

.field final mHideListener:Landroid/support/v4/view/x;

.field mHideOnContentScroll:Z

.field final mShowListener:Landroid/support/v4/view/x;

.field final mUpdateListener:Landroid/support/v4/view/z;

.field private mi:I

.field ni:Z

.field oi:Z

.field qi:Z

.field private ri:Z

.field private ti:Z

.field ui:La/b/d/e/m;

.field private vi:Z


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const-class v0, Landroid/support/v7/app/T;

    invoke-virtual {v0}, Ljava/lang/Class;->desiredAssertionStatus()Z

    new-instance v0, Landroid/view/animation/AccelerateInterpolator;

    invoke-direct {v0}, Landroid/view/animation/AccelerateInterpolator;-><init>()V

    sput-object v0, Landroid/support/v7/app/T;->wi:Landroid/view/animation/Interpolator;

    new-instance v0, Landroid/view/animation/DecelerateInterpolator;

    invoke-direct {v0}, Landroid/view/animation/DecelerateInterpolator;-><init>()V

    sput-object v0, Landroid/support/v7/app/T;->xi:Landroid/view/animation/Interpolator;

    return-void
.end method

.method public constructor <init>(Landroid/app/Activity;Z)V
    .locals 1

    invoke-direct {p0}, Landroid/support/v7/app/c;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroid/support/v7/app/T;->ki:Ljava/util/ArrayList;

    const/4 v0, 0x0

    iput v0, p0, Landroid/support/v7/app/T;->mi:I

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v7/app/T;->ni:Z

    iput-boolean v0, p0, Landroid/support/v7/app/T;->ti:Z

    new-instance v0, Landroid/support/v7/app/O;

    invoke-direct {v0, p0}, Landroid/support/v7/app/O;-><init>(Landroid/support/v7/app/T;)V

    iput-object v0, p0, Landroid/support/v7/app/T;->mHideListener:Landroid/support/v4/view/x;

    new-instance v0, Landroid/support/v7/app/P;

    invoke-direct {v0, p0}, Landroid/support/v7/app/P;-><init>(Landroid/support/v7/app/T;)V

    iput-object v0, p0, Landroid/support/v7/app/T;->mShowListener:Landroid/support/v4/view/x;

    new-instance v0, Landroid/support/v7/app/Q;

    invoke-direct {v0, p0}, Landroid/support/v7/app/Q;-><init>(Landroid/support/v7/app/T;)V

    iput-object v0, p0, Landroid/support/v7/app/T;->mUpdateListener:Landroid/support/v4/view/z;

    invoke-virtual {p1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p1

    invoke-direct {p0, p1}, Landroid/support/v7/app/T;->H(Landroid/view/View;)V

    if-nez p2, :cond_0

    const p2, 0x1020002

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    iput-object p1, p0, Landroid/support/v7/app/T;->mContentView:Landroid/view/View;

    :cond_0
    return-void
.end method

.method public constructor <init>(Landroid/app/Dialog;)V
    .locals 1

    invoke-direct {p0}, Landroid/support/v7/app/c;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroid/support/v7/app/T;->ki:Ljava/util/ArrayList;

    const/4 v0, 0x0

    iput v0, p0, Landroid/support/v7/app/T;->mi:I

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v7/app/T;->ni:Z

    iput-boolean v0, p0, Landroid/support/v7/app/T;->ti:Z

    new-instance v0, Landroid/support/v7/app/O;

    invoke-direct {v0, p0}, Landroid/support/v7/app/O;-><init>(Landroid/support/v7/app/T;)V

    iput-object v0, p0, Landroid/support/v7/app/T;->mHideListener:Landroid/support/v4/view/x;

    new-instance v0, Landroid/support/v7/app/P;

    invoke-direct {v0, p0}, Landroid/support/v7/app/P;-><init>(Landroid/support/v7/app/T;)V

    iput-object v0, p0, Landroid/support/v7/app/T;->mShowListener:Landroid/support/v4/view/x;

    new-instance v0, Landroid/support/v7/app/Q;

    invoke-direct {v0, p0}, Landroid/support/v7/app/Q;-><init>(Landroid/support/v7/app/T;)V

    iput-object v0, p0, Landroid/support/v7/app/T;->mUpdateListener:Landroid/support/v4/view/z;

    invoke-virtual {p1}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p1

    invoke-direct {p0, p1}, Landroid/support/v7/app/T;->H(Landroid/view/View;)V

    return-void
.end method

.method private H(Landroid/view/View;)V
    .locals 5

    const v0, 0x7f08003b

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/support/v7/widget/ActionBarOverlayLayout;

    iput-object v0, p0, Landroid/support/v7/app/T;->ei:Landroid/support/v7/widget/ActionBarOverlayLayout;

    iget-object v0, p0, Landroid/support/v7/app/T;->ei:Landroid/support/v7/widget/ActionBarOverlayLayout;

    if-eqz v0, :cond_0

    invoke-virtual {v0, p0}, Landroid/support/v7/widget/ActionBarOverlayLayout;->a(Landroid/support/v7/widget/h;)V

    :cond_0
    const v0, 0x7f080007

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    .line 1
    instance-of v1, v0, Landroid/support/v7/widget/ha;

    if-eqz v1, :cond_1

    check-cast v0, Landroid/support/v7/widget/ha;

    goto :goto_0

    :cond_1
    instance-of v1, v0, Landroid/support/v7/widget/Toolbar;

    if-eqz v1, :cond_a

    check-cast v0, Landroid/support/v7/widget/Toolbar;

    invoke-virtual {v0}, Landroid/support/v7/widget/Toolbar;->getWrapper()Landroid/support/v7/widget/ha;

    move-result-object v0

    .line 2
    :goto_0
    iput-object v0, p0, Landroid/support/v7/app/T;->gi:Landroid/support/v7/widget/ha;

    const v0, 0x7f08000f

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/support/v7/widget/ActionBarContextView;

    iput-object v0, p0, Landroid/support/v7/app/T;->hi:Landroid/support/v7/widget/ActionBarContextView;

    const v0, 0x7f080009

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/support/v7/widget/ActionBarContainer;

    iput-object p1, p0, Landroid/support/v7/app/T;->fi:Landroid/support/v7/widget/ActionBarContainer;

    iget-object p1, p0, Landroid/support/v7/app/T;->gi:Landroid/support/v7/widget/ha;

    if-eqz p1, :cond_9

    iget-object v0, p0, Landroid/support/v7/app/T;->hi:Landroid/support/v7/widget/ActionBarContextView;

    if-eqz v0, :cond_9

    iget-object v0, p0, Landroid/support/v7/app/T;->fi:Landroid/support/v7/widget/ActionBarContainer;

    if-eqz v0, :cond_9

    check-cast p1, Landroid/support/v7/widget/qc;

    invoke-virtual {p1}, Landroid/support/v7/widget/qc;->getContext()Landroid/content/Context;

    move-result-object p1

    iput-object p1, p0, Landroid/support/v7/app/T;->mContext:Landroid/content/Context;

    iget-object p1, p0, Landroid/support/v7/app/T;->gi:Landroid/support/v7/widget/ha;

    check-cast p1, Landroid/support/v7/widget/qc;

    invoke-virtual {p1}, Landroid/support/v7/widget/qc;->getDisplayOptions()I

    move-result p1

    and-int/lit8 p1, p1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    if-eqz p1, :cond_2

    move p1, v0

    goto :goto_1

    :cond_2
    move p1, v1

    :goto_1
    if-eqz p1, :cond_3

    iput-boolean v0, p0, Landroid/support/v7/app/T;->ii:Z

    :cond_3
    iget-object v2, p0, Landroid/support/v7/app/T;->mContext:Landroid/content/Context;

    invoke-static {v2}, La/b/d/e/a;->get(Landroid/content/Context;)La/b/d/e/a;

    move-result-object v2

    invoke-virtual {v2}, La/b/d/e/a;->enableHomeButtonByDefault()Z

    move-result v3

    if-nez v3, :cond_5

    if-eqz p1, :cond_4

    goto :goto_2

    :cond_4
    move p1, v1

    goto :goto_3

    :cond_5
    :goto_2
    move p1, v0

    .line 3
    :goto_3
    iget-object v3, p0, Landroid/support/v7/app/T;->gi:Landroid/support/v7/widget/ha;

    check-cast v3, Landroid/support/v7/widget/qc;

    invoke-virtual {v3, p1}, Landroid/support/v7/widget/qc;->setHomeButtonEnabled(Z)V

    .line 4
    invoke-virtual {v2}, La/b/d/e/a;->hasEmbeddedTabs()Z

    move-result p1

    invoke-direct {p0, p1}, Landroid/support/v7/app/T;->X(Z)V

    iget-object p1, p0, Landroid/support/v7/app/T;->mContext:Landroid/content/Context;

    const/4 v2, 0x0

    sget-object v3, La/b/d/a/b;->ActionBar:[I

    const v4, 0x7f030005

    invoke-virtual {p1, v2, v3, v4, v1}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    move-result-object p1

    const/16 v2, 0xe

    invoke-virtual {p1, v2, v1}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v2

    if-eqz v2, :cond_7

    .line 5
    iget-object v2, p0, Landroid/support/v7/app/T;->ei:Landroid/support/v7/widget/ActionBarOverlayLayout;

    invoke-virtual {v2}, Landroid/support/v7/widget/ActionBarOverlayLayout;->isInOverlayMode()Z

    move-result v2

    if-eqz v2, :cond_6

    iput-boolean v0, p0, Landroid/support/v7/app/T;->mHideOnContentScroll:Z

    iget-object v2, p0, Landroid/support/v7/app/T;->ei:Landroid/support/v7/widget/ActionBarOverlayLayout;

    invoke-virtual {v2, v0}, Landroid/support/v7/widget/ActionBarOverlayLayout;->setHideOnContentScrollEnabled(Z)V

    goto :goto_4

    :cond_6
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "Action bar must be in overlay mode (Window.FEATURE_OVERLAY_ACTION_BAR) to enable hide on content scroll"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_7
    :goto_4
    const/16 v0, 0xc

    .line 6
    invoke-virtual {p1, v0, v1}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v0

    if-eqz v0, :cond_8

    int-to-float v0, v0

    .line 7
    iget-object p0, p0, Landroid/support/v7/app/T;->fi:Landroid/support/v7/widget/ActionBarContainer;

    invoke-static {p0, v0}, Landroid/support/v4/view/r;->a(Landroid/view/View;F)V

    .line 8
    :cond_8
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    return-void

    :cond_9
    new-instance p0, Ljava/lang/IllegalStateException;

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-class v0, Landroid/support/v7/app/T;

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " can only be used "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "with a compatible window decor layout"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    .line 9
    :cond_a
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "Can\'t make a decor toolbar out of "

    invoke-static {p1}, Lb/a/a/a/a;->x(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    if-eqz v0, :cond_b

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    goto :goto_5

    :cond_b
    const-string v0, "null"

    :goto_5
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private X(Z)V
    .locals 4

    iput-boolean p1, p0, Landroid/support/v7/app/T;->li:Z

    iget-boolean p1, p0, Landroid/support/v7/app/T;->li:Z

    const/4 v0, 0x0

    if-nez p1, :cond_0

    iget-object p1, p0, Landroid/support/v7/app/T;->gi:Landroid/support/v7/widget/ha;

    check-cast p1, Landroid/support/v7/widget/qc;

    invoke-virtual {p1, v0}, Landroid/support/v7/widget/qc;->a(Landroid/support/v7/widget/Sb;)V

    iget-object p1, p0, Landroid/support/v7/app/T;->fi:Landroid/support/v7/widget/ActionBarContainer;

    invoke-virtual {p1, v0}, Landroid/support/v7/widget/ActionBarContainer;->b(Landroid/support/v7/widget/Sb;)V

    goto :goto_0

    :cond_0
    iget-object p1, p0, Landroid/support/v7/app/T;->fi:Landroid/support/v7/widget/ActionBarContainer;

    invoke-virtual {p1, v0}, Landroid/support/v7/widget/ActionBarContainer;->b(Landroid/support/v7/widget/Sb;)V

    iget-object p1, p0, Landroid/support/v7/app/T;->gi:Landroid/support/v7/widget/ha;

    check-cast p1, Landroid/support/v7/widget/qc;

    invoke-virtual {p1, v0}, Landroid/support/v7/widget/qc;->a(Landroid/support/v7/widget/Sb;)V

    .line 1
    :goto_0
    iget-object p1, p0, Landroid/support/v7/app/T;->gi:Landroid/support/v7/widget/ha;

    check-cast p1, Landroid/support/v7/widget/qc;

    invoke-virtual {p1}, Landroid/support/v7/widget/qc;->getNavigationMode()I

    move-result p1

    const/4 v0, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-ne p1, v0, :cond_1

    move p1, v1

    goto :goto_1

    :cond_1
    move p1, v2

    .line 2
    :goto_1
    iget-object v0, p0, Landroid/support/v7/app/T;->gi:Landroid/support/v7/widget/ha;

    iget-boolean v3, p0, Landroid/support/v7/app/T;->li:Z

    if-nez v3, :cond_2

    if-eqz p1, :cond_2

    move v3, v1

    goto :goto_2

    :cond_2
    move v3, v2

    :goto_2
    check-cast v0, Landroid/support/v7/widget/qc;

    invoke-virtual {v0, v3}, Landroid/support/v7/widget/qc;->setCollapsible(Z)V

    iget-object v0, p0, Landroid/support/v7/app/T;->ei:Landroid/support/v7/widget/ActionBarOverlayLayout;

    iget-boolean p0, p0, Landroid/support/v7/app/T;->li:Z

    if-nez p0, :cond_3

    if-eqz p1, :cond_3

    goto :goto_3

    :cond_3
    move v1, v2

    :goto_3
    invoke-virtual {v0, v1}, Landroid/support/v7/widget/ActionBarOverlayLayout;->setHasNonEmbeddedTabs(Z)V

    return-void
.end method

.method private Y(Z)V
    .locals 8

    iget-boolean v0, p0, Landroid/support/v7/app/T;->oi:Z

    iget-boolean v1, p0, Landroid/support/v7/app/T;->qi:Z

    iget-boolean v2, p0, Landroid/support/v7/app/T;->ri:Z

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v2, :cond_1

    :cond_0
    move v0, v4

    goto :goto_0

    :cond_1
    if-nez v0, :cond_2

    if-eqz v1, :cond_0

    :cond_2
    move v0, v3

    :goto_0
    const-wide/16 v1, 0xfa

    const/4 v5, 0x2

    const/high16 v6, 0x3f800000    # 1.0f

    const/4 v7, 0x0

    if-eqz v0, :cond_9

    iget-boolean v0, p0, Landroid/support/v7/app/T;->ti:Z

    if-nez v0, :cond_f

    iput-boolean v4, p0, Landroid/support/v7/app/T;->ti:Z

    .line 1
    iget-object v0, p0, Landroid/support/v7/app/T;->ui:La/b/d/e/m;

    if-eqz v0, :cond_3

    invoke-virtual {v0}, La/b/d/e/m;->cancel()V

    :cond_3
    iget-object v0, p0, Landroid/support/v7/app/T;->fi:Landroid/support/v7/widget/ActionBarContainer;

    invoke-virtual {v0, v3}, Landroid/support/v7/widget/ActionBarContainer;->setVisibility(I)V

    iget v0, p0, Landroid/support/v7/app/T;->mi:I

    const/4 v3, 0x0

    if-nez v0, :cond_7

    iget-boolean v0, p0, Landroid/support/v7/app/T;->vi:Z

    if-nez v0, :cond_4

    if-eqz p1, :cond_7

    :cond_4
    iget-object v0, p0, Landroid/support/v7/app/T;->fi:Landroid/support/v7/widget/ActionBarContainer;

    invoke-virtual {v0, v3}, Landroid/widget/FrameLayout;->setTranslationY(F)V

    iget-object v0, p0, Landroid/support/v7/app/T;->fi:Landroid/support/v7/widget/ActionBarContainer;

    invoke-virtual {v0}, Landroid/widget/FrameLayout;->getHeight()I

    move-result v0

    neg-int v0, v0

    int-to-float v0, v0

    if-eqz p1, :cond_5

    new-array p1, v5, [I

    fill-array-data p1, :array_0

    iget-object v5, p0, Landroid/support/v7/app/T;->fi:Landroid/support/v7/widget/ActionBarContainer;

    invoke-virtual {v5, p1}, Landroid/widget/FrameLayout;->getLocationInWindow([I)V

    aget p1, p1, v4

    int-to-float p1, p1

    sub-float/2addr v0, p1

    :cond_5
    iget-object p1, p0, Landroid/support/v7/app/T;->fi:Landroid/support/v7/widget/ActionBarContainer;

    invoke-virtual {p1, v0}, Landroid/widget/FrameLayout;->setTranslationY(F)V

    new-instance p1, La/b/d/e/m;

    invoke-direct {p1}, La/b/d/e/m;-><init>()V

    iget-object v4, p0, Landroid/support/v7/app/T;->fi:Landroid/support/v7/widget/ActionBarContainer;

    invoke-static {v4}, Landroid/support/v4/view/r;->j(Landroid/view/View;)Landroid/support/v4/view/w;

    move-result-object v4

    invoke-virtual {v4, v3}, Landroid/support/v4/view/w;->translationY(F)Landroid/support/v4/view/w;

    iget-object v5, p0, Landroid/support/v7/app/T;->mUpdateListener:Landroid/support/v4/view/z;

    invoke-virtual {v4, v5}, Landroid/support/v4/view/w;->a(Landroid/support/v4/view/z;)Landroid/support/v4/view/w;

    invoke-virtual {p1, v4}, La/b/d/e/m;->a(Landroid/support/v4/view/w;)La/b/d/e/m;

    iget-boolean v4, p0, Landroid/support/v7/app/T;->ni:Z

    if-eqz v4, :cond_6

    iget-object v4, p0, Landroid/support/v7/app/T;->mContentView:Landroid/view/View;

    if-eqz v4, :cond_6

    invoke-virtual {v4, v0}, Landroid/view/View;->setTranslationY(F)V

    iget-object v0, p0, Landroid/support/v7/app/T;->mContentView:Landroid/view/View;

    invoke-static {v0}, Landroid/support/v4/view/r;->j(Landroid/view/View;)Landroid/support/v4/view/w;

    move-result-object v0

    invoke-virtual {v0, v3}, Landroid/support/v4/view/w;->translationY(F)Landroid/support/v4/view/w;

    invoke-virtual {p1, v0}, La/b/d/e/m;->a(Landroid/support/v4/view/w;)La/b/d/e/m;

    :cond_6
    sget-object v0, Landroid/support/v7/app/T;->xi:Landroid/view/animation/Interpolator;

    invoke-virtual {p1, v0}, La/b/d/e/m;->setInterpolator(Landroid/view/animation/Interpolator;)La/b/d/e/m;

    invoke-virtual {p1, v1, v2}, La/b/d/e/m;->setDuration(J)La/b/d/e/m;

    iget-object v0, p0, Landroid/support/v7/app/T;->mShowListener:Landroid/support/v4/view/x;

    invoke-virtual {p1, v0}, La/b/d/e/m;->a(Landroid/support/v4/view/x;)La/b/d/e/m;

    iput-object p1, p0, Landroid/support/v7/app/T;->ui:La/b/d/e/m;

    invoke-virtual {p1}, La/b/d/e/m;->start()V

    goto :goto_1

    :cond_7
    iget-object p1, p0, Landroid/support/v7/app/T;->fi:Landroid/support/v7/widget/ActionBarContainer;

    invoke-virtual {p1, v6}, Landroid/widget/FrameLayout;->setAlpha(F)V

    iget-object p1, p0, Landroid/support/v7/app/T;->fi:Landroid/support/v7/widget/ActionBarContainer;

    invoke-virtual {p1, v3}, Landroid/widget/FrameLayout;->setTranslationY(F)V

    iget-boolean p1, p0, Landroid/support/v7/app/T;->ni:Z

    if-eqz p1, :cond_8

    iget-object p1, p0, Landroid/support/v7/app/T;->mContentView:Landroid/view/View;

    if-eqz p1, :cond_8

    invoke-virtual {p1, v3}, Landroid/view/View;->setTranslationY(F)V

    :cond_8
    iget-object p1, p0, Landroid/support/v7/app/T;->mShowListener:Landroid/support/v4/view/x;

    invoke-interface {p1, v7}, Landroid/support/v4/view/x;->d(Landroid/view/View;)V

    :goto_1
    iget-object p0, p0, Landroid/support/v7/app/T;->ei:Landroid/support/v7/widget/ActionBarOverlayLayout;

    if-eqz p0, :cond_f

    invoke-static {p0}, Landroid/support/v4/view/r;->A(Landroid/view/View;)V

    goto/16 :goto_2

    .line 2
    :cond_9
    iget-boolean v0, p0, Landroid/support/v7/app/T;->ti:Z

    if-eqz v0, :cond_f

    iput-boolean v3, p0, Landroid/support/v7/app/T;->ti:Z

    .line 3
    iget-object v0, p0, Landroid/support/v7/app/T;->ui:La/b/d/e/m;

    if-eqz v0, :cond_a

    invoke-virtual {v0}, La/b/d/e/m;->cancel()V

    :cond_a
    iget v0, p0, Landroid/support/v7/app/T;->mi:I

    if-nez v0, :cond_e

    iget-boolean v0, p0, Landroid/support/v7/app/T;->vi:Z

    if-nez v0, :cond_b

    if-eqz p1, :cond_e

    :cond_b
    iget-object v0, p0, Landroid/support/v7/app/T;->fi:Landroid/support/v7/widget/ActionBarContainer;

    invoke-virtual {v0, v6}, Landroid/widget/FrameLayout;->setAlpha(F)V

    iget-object v0, p0, Landroid/support/v7/app/T;->fi:Landroid/support/v7/widget/ActionBarContainer;

    invoke-virtual {v0, v4}, Landroid/support/v7/widget/ActionBarContainer;->setTransitioning(Z)V

    new-instance v0, La/b/d/e/m;

    invoke-direct {v0}, La/b/d/e/m;-><init>()V

    iget-object v3, p0, Landroid/support/v7/app/T;->fi:Landroid/support/v7/widget/ActionBarContainer;

    invoke-virtual {v3}, Landroid/widget/FrameLayout;->getHeight()I

    move-result v3

    neg-int v3, v3

    int-to-float v3, v3

    if-eqz p1, :cond_c

    new-array p1, v5, [I

    fill-array-data p1, :array_1

    iget-object v5, p0, Landroid/support/v7/app/T;->fi:Landroid/support/v7/widget/ActionBarContainer;

    invoke-virtual {v5, p1}, Landroid/widget/FrameLayout;->getLocationInWindow([I)V

    aget p1, p1, v4

    int-to-float p1, p1

    sub-float/2addr v3, p1

    :cond_c
    iget-object p1, p0, Landroid/support/v7/app/T;->fi:Landroid/support/v7/widget/ActionBarContainer;

    invoke-static {p1}, Landroid/support/v4/view/r;->j(Landroid/view/View;)Landroid/support/v4/view/w;

    move-result-object p1

    invoke-virtual {p1, v3}, Landroid/support/v4/view/w;->translationY(F)Landroid/support/v4/view/w;

    iget-object v4, p0, Landroid/support/v7/app/T;->mUpdateListener:Landroid/support/v4/view/z;

    invoke-virtual {p1, v4}, Landroid/support/v4/view/w;->a(Landroid/support/v4/view/z;)Landroid/support/v4/view/w;

    invoke-virtual {v0, p1}, La/b/d/e/m;->a(Landroid/support/v4/view/w;)La/b/d/e/m;

    iget-boolean p1, p0, Landroid/support/v7/app/T;->ni:Z

    if-eqz p1, :cond_d

    iget-object p1, p0, Landroid/support/v7/app/T;->mContentView:Landroid/view/View;

    if-eqz p1, :cond_d

    invoke-static {p1}, Landroid/support/v4/view/r;->j(Landroid/view/View;)Landroid/support/v4/view/w;

    move-result-object p1

    invoke-virtual {p1, v3}, Landroid/support/v4/view/w;->translationY(F)Landroid/support/v4/view/w;

    invoke-virtual {v0, p1}, La/b/d/e/m;->a(Landroid/support/v4/view/w;)La/b/d/e/m;

    :cond_d
    sget-object p1, Landroid/support/v7/app/T;->wi:Landroid/view/animation/Interpolator;

    invoke-virtual {v0, p1}, La/b/d/e/m;->setInterpolator(Landroid/view/animation/Interpolator;)La/b/d/e/m;

    invoke-virtual {v0, v1, v2}, La/b/d/e/m;->setDuration(J)La/b/d/e/m;

    iget-object p1, p0, Landroid/support/v7/app/T;->mHideListener:Landroid/support/v4/view/x;

    invoke-virtual {v0, p1}, La/b/d/e/m;->a(Landroid/support/v4/view/x;)La/b/d/e/m;

    iput-object v0, p0, Landroid/support/v7/app/T;->ui:La/b/d/e/m;

    invoke-virtual {v0}, La/b/d/e/m;->start()V

    goto :goto_2

    :cond_e
    iget-object p0, p0, Landroid/support/v7/app/T;->mHideListener:Landroid/support/v4/view/x;

    invoke-interface {p0, v7}, Landroid/support/v4/view/x;->d(Landroid/view/View;)V

    :cond_f
    :goto_2
    return-void

    nop

    :array_0
    .array-data 4
        0x0
        0x0
    .end array-data

    :array_1
    .array-data 4
        0x0
        0x0
    .end array-data
.end method


# virtual methods
.method public animateToMode(Z)V
    .locals 9

    const/4 v0, 0x0

    if-eqz p1, :cond_1

    .line 1
    iget-boolean v1, p0, Landroid/support/v7/app/T;->ri:Z

    if-nez v1, :cond_3

    const/4 v1, 0x1

    iput-boolean v1, p0, Landroid/support/v7/app/T;->ri:Z

    iget-object v2, p0, Landroid/support/v7/app/T;->ei:Landroid/support/v7/widget/ActionBarOverlayLayout;

    if-eqz v2, :cond_0

    invoke-virtual {v2, v1}, Landroid/support/v7/widget/ActionBarOverlayLayout;->setShowingForActionMode(Z)V

    :cond_0
    invoke-direct {p0, v0}, Landroid/support/v7/app/T;->Y(Z)V

    goto :goto_0

    .line 2
    :cond_1
    iget-boolean v1, p0, Landroid/support/v7/app/T;->ri:Z

    if-eqz v1, :cond_3

    iput-boolean v0, p0, Landroid/support/v7/app/T;->ri:Z

    iget-object v1, p0, Landroid/support/v7/app/T;->ei:Landroid/support/v7/widget/ActionBarOverlayLayout;

    if-eqz v1, :cond_2

    invoke-virtual {v1, v0}, Landroid/support/v7/widget/ActionBarOverlayLayout;->setShowingForActionMode(Z)V

    :cond_2
    invoke-direct {p0, v0}, Landroid/support/v7/app/T;->Y(Z)V

    .line 3
    :cond_3
    :goto_0
    iget-object v1, p0, Landroid/support/v7/app/T;->fi:Landroid/support/v7/widget/ActionBarContainer;

    invoke-static {v1}, Landroid/support/v4/view/r;->y(Landroid/view/View;)Z

    move-result v1

    const/4 v2, 0x4

    const/16 v3, 0x8

    if-eqz v1, :cond_5

    const-wide/16 v4, 0x64

    const-wide/16 v6, 0xc8

    if-eqz p1, :cond_4

    .line 4
    iget-object p1, p0, Landroid/support/v7/app/T;->gi:Landroid/support/v7/widget/ha;

    check-cast p1, Landroid/support/v7/widget/qc;

    invoke-virtual {p1, v2, v4, v5}, Landroid/support/v7/widget/qc;->setupAnimatorToVisibility(IJ)Landroid/support/v4/view/w;

    move-result-object p1

    iget-object p0, p0, Landroid/support/v7/app/T;->hi:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {p0, v0, v6, v7}, Landroid/support/v7/widget/ActionBarContextView;->setupAnimatorToVisibility(IJ)Landroid/support/v4/view/w;

    move-result-object p0

    move-object v8, p1

    move-object p1, p0

    move-object p0, v8

    goto :goto_1

    :cond_4
    iget-object p1, p0, Landroid/support/v7/app/T;->gi:Landroid/support/v7/widget/ha;

    check-cast p1, Landroid/support/v7/widget/qc;

    invoke-virtual {p1, v0, v6, v7}, Landroid/support/v7/widget/qc;->setupAnimatorToVisibility(IJ)Landroid/support/v4/view/w;

    move-result-object p1

    iget-object p0, p0, Landroid/support/v7/app/T;->hi:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {p0, v3, v4, v5}, Landroid/support/v7/widget/ActionBarContextView;->setupAnimatorToVisibility(IJ)Landroid/support/v4/view/w;

    move-result-object p0

    :goto_1
    new-instance v0, La/b/d/e/m;

    invoke-direct {v0}, La/b/d/e/m;-><init>()V

    invoke-virtual {v0, p0, p1}, La/b/d/e/m;->a(Landroid/support/v4/view/w;Landroid/support/v4/view/w;)La/b/d/e/m;

    invoke-virtual {v0}, La/b/d/e/m;->start()V

    goto :goto_2

    :cond_5
    if-eqz p1, :cond_6

    iget-object p1, p0, Landroid/support/v7/app/T;->gi:Landroid/support/v7/widget/ha;

    check-cast p1, Landroid/support/v7/widget/qc;

    invoke-virtual {p1, v2}, Landroid/support/v7/widget/qc;->setVisibility(I)V

    iget-object p0, p0, Landroid/support/v7/app/T;->hi:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {p0, v0}, Landroid/support/v7/widget/ActionBarContextView;->setVisibility(I)V

    goto :goto_2

    :cond_6
    iget-object p1, p0, Landroid/support/v7/app/T;->gi:Landroid/support/v7/widget/ha;

    check-cast p1, Landroid/support/v7/widget/qc;

    invoke-virtual {p1, v0}, Landroid/support/v7/widget/qc;->setVisibility(I)V

    iget-object p0, p0, Landroid/support/v7/app/T;->hi:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {p0, v3}, Landroid/support/v7/widget/ActionBarContextView;->setVisibility(I)V

    :goto_2
    return-void
.end method

.method public b(La/b/d/e/b;)La/b/d/e/c;
    .locals 2

    iget-object v0, p0, Landroid/support/v7/app/T;->mActionMode:Landroid/support/v7/app/S;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/support/v7/app/S;->finish()V

    :cond_0
    iget-object v0, p0, Landroid/support/v7/app/T;->ei:Landroid/support/v7/widget/ActionBarOverlayLayout;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/support/v7/widget/ActionBarOverlayLayout;->setHideOnContentScrollEnabled(Z)V

    iget-object v0, p0, Landroid/support/v7/app/T;->hi:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {v0}, Landroid/support/v7/widget/ActionBarContextView;->killMode()V

    new-instance v0, Landroid/support/v7/app/S;

    iget-object v1, p0, Landroid/support/v7/app/T;->hi:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {v1}, Landroid/view/ViewGroup;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, p0, v1, p1}, Landroid/support/v7/app/S;-><init>(Landroid/support/v7/app/T;Landroid/content/Context;La/b/d/e/b;)V

    invoke-virtual {v0}, Landroid/support/v7/app/S;->dispatchOnCreate()Z

    move-result p1

    if-eqz p1, :cond_1

    iput-object v0, p0, Landroid/support/v7/app/T;->mActionMode:Landroid/support/v7/app/S;

    invoke-virtual {v0}, Landroid/support/v7/app/S;->invalidate()V

    iget-object p1, p0, Landroid/support/v7/app/T;->hi:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {p1, v0}, Landroid/support/v7/widget/ActionBarContextView;->e(La/b/d/e/c;)V

    const/4 p1, 0x1

    invoke-virtual {p0, p1}, Landroid/support/v7/app/T;->animateToMode(Z)V

    iget-object p0, p0, Landroid/support/v7/app/T;->hi:Landroid/support/v7/widget/ActionBarContextView;

    const/16 p1, 0x20

    invoke-virtual {p0, p1}, Landroid/view/ViewGroup;->sendAccessibilityEvent(I)V

    return-object v0

    :cond_1
    const/4 p0, 0x0

    return-object p0
.end method

.method public collapseActionView()Z
    .locals 1

    iget-object v0, p0, Landroid/support/v7/app/T;->gi:Landroid/support/v7/widget/ha;

    if-eqz v0, :cond_0

    check-cast v0, Landroid/support/v7/widget/qc;

    invoke-virtual {v0}, Landroid/support/v7/widget/qc;->hasExpandedActionView()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object p0, p0, Landroid/support/v7/app/T;->gi:Landroid/support/v7/widget/ha;

    check-cast p0, Landroid/support/v7/widget/qc;

    invoke-virtual {p0}, Landroid/support/v7/widget/qc;->collapseActionView()V

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public dispatchMenuVisibilityChanged(Z)V
    .locals 3

    iget-boolean v0, p0, Landroid/support/v7/app/T;->ji:Z

    if-ne p1, v0, :cond_0

    return-void

    :cond_0
    iput-boolean p1, p0, Landroid/support/v7/app/T;->ji:Z

    iget-object v0, p0, Landroid/support/v7/app/T;->ki:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_1

    iget-object v2, p0, Landroid/support/v7/app/T;->ki:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/support/v7/app/b;

    invoke-interface {v2, p1}, Landroid/support/v7/app/b;->onMenuVisibilityChanged(Z)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method public enableContentAnimations(Z)V
    .locals 0

    iput-boolean p1, p0, Landroid/support/v7/app/T;->ni:Z

    return-void
.end method

.method public getDisplayOptions()I
    .locals 0

    iget-object p0, p0, Landroid/support/v7/app/T;->gi:Landroid/support/v7/widget/ha;

    check-cast p0, Landroid/support/v7/widget/qc;

    invoke-virtual {p0}, Landroid/support/v7/widget/qc;->getDisplayOptions()I

    move-result p0

    return p0
.end method

.method public getThemedContext()Landroid/content/Context;
    .locals 4

    iget-object v0, p0, Landroid/support/v7/app/T;->di:Landroid/content/Context;

    if-nez v0, :cond_1

    new-instance v0, Landroid/util/TypedValue;

    invoke-direct {v0}, Landroid/util/TypedValue;-><init>()V

    iget-object v1, p0, Landroid/support/v7/app/T;->mContext:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v1

    const v2, 0x7f03000a

    const/4 v3, 0x1

    invoke-virtual {v1, v2, v0, v3}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    iget v0, v0, Landroid/util/TypedValue;->resourceId:I

    if-eqz v0, :cond_0

    new-instance v1, Landroid/view/ContextThemeWrapper;

    iget-object v2, p0, Landroid/support/v7/app/T;->mContext:Landroid/content/Context;

    invoke-direct {v1, v2, v0}, Landroid/view/ContextThemeWrapper;-><init>(Landroid/content/Context;I)V

    iput-object v1, p0, Landroid/support/v7/app/T;->di:Landroid/content/Context;

    goto :goto_0

    :cond_0
    iget-object v0, p0, Landroid/support/v7/app/T;->mContext:Landroid/content/Context;

    iput-object v0, p0, Landroid/support/v7/app/T;->di:Landroid/content/Context;

    :cond_1
    :goto_0
    iget-object p0, p0, Landroid/support/v7/app/T;->di:Landroid/content/Context;

    return-object p0
.end method

.method public hideForSystem()V
    .locals 1

    iget-boolean v0, p0, Landroid/support/v7/app/T;->qi:Z

    if-nez v0, :cond_0

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v7/app/T;->qi:Z

    invoke-direct {p0, v0}, Landroid/support/v7/app/T;->Y(Z)V

    :cond_0
    return-void
.end method

.method public onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 0

    iget-object p1, p0, Landroid/support/v7/app/T;->mContext:Landroid/content/Context;

    invoke-static {p1}, La/b/d/e/a;->get(Landroid/content/Context;)La/b/d/e/a;

    move-result-object p1

    invoke-virtual {p1}, La/b/d/e/a;->hasEmbeddedTabs()Z

    move-result p1

    invoke-direct {p0, p1}, Landroid/support/v7/app/T;->X(Z)V

    return-void
.end method

.method public onContentScrollStarted()V
    .locals 1

    iget-object v0, p0, Landroid/support/v7/app/T;->ui:La/b/d/e/m;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, La/b/d/e/m;->cancel()V

    const/4 v0, 0x0

    iput-object v0, p0, Landroid/support/v7/app/T;->ui:La/b/d/e/m;

    :cond_0
    return-void
.end method

.method public onContentScrollStopped()V
    .locals 0

    return-void
.end method

.method public onKeyShortcut(ILandroid/view/KeyEvent;)Z
    .locals 3

    iget-object p0, p0, Landroid/support/v7/app/T;->mActionMode:Landroid/support/v7/app/S;

    const/4 v0, 0x0

    if-nez p0, :cond_0

    return v0

    :cond_0
    invoke-virtual {p0}, Landroid/support/v7/app/S;->getMenu()Landroid/view/Menu;

    move-result-object p0

    if-eqz p0, :cond_3

    if-eqz p2, :cond_1

    invoke-virtual {p2}, Landroid/view/KeyEvent;->getDeviceId()I

    move-result v1

    goto :goto_0

    :cond_1
    const/4 v1, -0x1

    :goto_0
    invoke-static {v1}, Landroid/view/KeyCharacterMap;->load(I)Landroid/view/KeyCharacterMap;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/KeyCharacterMap;->getKeyboardType()I

    move-result v1

    const/4 v2, 0x1

    if-eq v1, v2, :cond_2

    goto :goto_1

    :cond_2
    move v2, v0

    :goto_1
    invoke-interface {p0, v2}, Landroid/view/Menu;->setQwertyMode(Z)V

    invoke-interface {p0, p1, p2, v0}, Landroid/view/Menu;->performShortcut(ILandroid/view/KeyEvent;I)Z

    move-result p0

    return p0

    :cond_3
    return v0
.end method

.method public onWindowVisibilityChanged(I)V
    .locals 0

    iput p1, p0, Landroid/support/v7/app/T;->mi:I

    return-void
.end method

.method public setDefaultDisplayHomeAsUpEnabled(Z)V
    .locals 3

    iget-boolean v0, p0, Landroid/support/v7/app/T;->ii:Z

    if-nez v0, :cond_1

    const/4 v0, 0x4

    if-eqz p1, :cond_0

    move p1, v0

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    .line 1
    :goto_0
    iget-object v1, p0, Landroid/support/v7/app/T;->gi:Landroid/support/v7/widget/ha;

    check-cast v1, Landroid/support/v7/widget/qc;

    invoke-virtual {v1}, Landroid/support/v7/widget/qc;->getDisplayOptions()I

    move-result v1

    const/4 v2, 0x1

    iput-boolean v2, p0, Landroid/support/v7/app/T;->ii:Z

    iget-object p0, p0, Landroid/support/v7/app/T;->gi:Landroid/support/v7/widget/ha;

    and-int/2addr p1, v0

    and-int/lit8 v0, v1, -0x5

    or-int/2addr p1, v0

    check-cast p0, Landroid/support/v7/widget/qc;

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/qc;->setDisplayOptions(I)V

    :cond_1
    return-void
.end method

.method public setShowHideAnimationEnabled(Z)V
    .locals 0

    iput-boolean p1, p0, Landroid/support/v7/app/T;->vi:Z

    if-nez p1, :cond_0

    iget-object p0, p0, Landroid/support/v7/app/T;->ui:La/b/d/e/m;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, La/b/d/e/m;->cancel()V

    :cond_0
    return-void
.end method

.method public setWindowTitle(Ljava/lang/CharSequence;)V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/app/T;->gi:Landroid/support/v7/widget/ha;

    check-cast p0, Landroid/support/v7/widget/qc;

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/qc;->setWindowTitle(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public showForSystem()V
    .locals 1

    iget-boolean v0, p0, Landroid/support/v7/app/T;->qi:Z

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/support/v7/app/T;->qi:Z

    const/4 v0, 0x1

    invoke-direct {p0, v0}, Landroid/support/v7/app/T;->Y(Z)V

    :cond_0
    return-void
.end method
