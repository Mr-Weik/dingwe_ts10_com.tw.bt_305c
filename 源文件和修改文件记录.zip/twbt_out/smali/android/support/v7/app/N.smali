.class Landroid/support/v7/app/N;
.super Ljava/lang/Object;
.source ""


# static fields
.field private static sInstance:Landroid/support/v7/app/N;


# instance fields
.field private final bk:Landroid/location/LocationManager;

.field private final ck:Landroid/support/v7/app/M;

.field private final mContext:Landroid/content/Context;


# direct methods
.method constructor <init>(Landroid/content/Context;Landroid/location/LocationManager;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Landroid/support/v7/app/M;

    invoke-direct {v0}, Landroid/support/v7/app/M;-><init>()V

    iput-object v0, p0, Landroid/support/v7/app/N;->ck:Landroid/support/v7/app/M;

    iput-object p1, p0, Landroid/support/v7/app/N;->mContext:Landroid/content/Context;

    iput-object p2, p0, Landroid/support/v7/app/N;->bk:Landroid/location/LocationManager;

    return-void
.end method

.method private fa(Ljava/lang/String;)Landroid/location/Location;
    .locals 1

    :try_start_0
    iget-object v0, p0, Landroid/support/v7/app/N;->bk:Landroid/location/LocationManager;

    invoke-virtual {v0, p1}, Landroid/location/LocationManager;->isProviderEnabled(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object p0, p0, Landroid/support/v7/app/N;->bk:Landroid/location/LocationManager;

    invoke-virtual {p0, p1}, Landroid/location/LocationManager;->getLastKnownLocation(Ljava/lang/String;)Landroid/location/Location;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    move-exception p0

    const-string p1, "TwilightManager"

    const-string v0, "Failed to get last known location"

    invoke-static {p1, v0, p0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method static getInstance(Landroid/content/Context;)Landroid/support/v7/app/N;
    .locals 2

    sget-object v0, Landroid/support/v7/app/N;->sInstance:Landroid/support/v7/app/N;

    if-nez v0, :cond_0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    new-instance v0, Landroid/support/v7/app/N;

    const-string v1, "location"

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/location/LocationManager;

    invoke-direct {v0, p0, v1}, Landroid/support/v7/app/N;-><init>(Landroid/content/Context;Landroid/location/LocationManager;)V

    sput-object v0, Landroid/support/v7/app/N;->sInstance:Landroid/support/v7/app/N;

    :cond_0
    sget-object p0, Landroid/support/v7/app/N;->sInstance:Landroid/support/v7/app/N;

    return-object p0
.end method

.method static setInstance(Landroid/support/v7/app/N;)V
    .locals 0

    sput-object p0, Landroid/support/v7/app/N;->sInstance:Landroid/support/v7/app/N;

    return-void
.end method


# virtual methods
.method Ra()Z
    .locals 21

    move-object/from16 v0, p0

    iget-object v1, v0, Landroid/support/v7/app/N;->ck:Landroid/support/v7/app/M;

    .line 1
    iget-wide v2, v1, Landroid/support/v7/app/M;->ak:J

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    cmp-long v2, v2, v4

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-lez v2, :cond_0

    move v2, v3

    goto :goto_0

    :cond_0
    move v2, v4

    :goto_0
    if-eqz v2, :cond_1

    .line 2
    iget-boolean v0, v1, Landroid/support/v7/app/M;->_j:Z

    return v0

    .line 3
    :cond_1
    iget-object v2, v0, Landroid/support/v7/app/N;->mContext:Landroid/content/Context;

    const-string v5, "android.permission.ACCESS_COARSE_LOCATION"

    invoke-static {v2, v5}, La/b/a/a;->a(Landroid/content/Context;Ljava/lang/String;)I

    move-result v2

    const/4 v5, 0x0

    if-nez v2, :cond_2

    const-string v2, "network"

    invoke-direct {v0, v2}, Landroid/support/v7/app/N;->fa(Ljava/lang/String;)Landroid/location/Location;

    move-result-object v2

    goto :goto_1

    :cond_2
    move-object v2, v5

    :goto_1
    iget-object v6, v0, Landroid/support/v7/app/N;->mContext:Landroid/content/Context;

    const-string v7, "android.permission.ACCESS_FINE_LOCATION"

    invoke-static {v6, v7}, La/b/a/a;->a(Landroid/content/Context;Ljava/lang/String;)I

    move-result v6

    if-nez v6, :cond_3

    const-string v5, "gps"

    invoke-direct {v0, v5}, Landroid/support/v7/app/N;->fa(Ljava/lang/String;)Landroid/location/Location;

    move-result-object v5

    :cond_3
    if-eqz v5, :cond_4

    if-eqz v2, :cond_4

    invoke-virtual {v5}, Landroid/location/Location;->getTime()J

    move-result-wide v6

    invoke-virtual {v2}, Landroid/location/Location;->getTime()J

    move-result-wide v8

    cmp-long v6, v6, v8

    if-lez v6, :cond_5

    :goto_2
    move-object v2, v5

    goto :goto_3

    :cond_4
    if-eqz v5, :cond_5

    goto :goto_2

    :cond_5
    :goto_3
    if-eqz v2, :cond_b

    .line 4
    iget-object v0, v0, Landroid/support/v7/app/N;->ck:Landroid/support/v7/app/M;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v12

    invoke-static {}, Landroid/support/v7/app/L;->getInstance()Landroid/support/v7/app/L;

    move-result-object v14

    const-wide/32 v15, 0x5265c00

    sub-long v6, v12, v15

    invoke-virtual {v2}, Landroid/location/Location;->getLatitude()D

    move-result-wide v8

    invoke-virtual {v2}, Landroid/location/Location;->getLongitude()D

    move-result-wide v10

    move-object v5, v14

    invoke-virtual/range {v5 .. v11}, Landroid/support/v7/app/L;->a(JDD)V

    iget-wide v5, v14, Landroid/support/v7/app/L;->Yj:J

    invoke-virtual {v2}, Landroid/location/Location;->getLatitude()D

    move-result-wide v8

    invoke-virtual {v2}, Landroid/location/Location;->getLongitude()D

    move-result-wide v10

    move-object v5, v14

    move-wide v6, v12

    invoke-virtual/range {v5 .. v11}, Landroid/support/v7/app/L;->a(JDD)V

    iget v5, v14, Landroid/support/v7/app/L;->state:I

    if-ne v5, v3, :cond_6

    goto :goto_4

    :cond_6
    move v3, v4

    :goto_4
    iget-wide v10, v14, Landroid/support/v7/app/L;->Zj:J

    iget-wide v8, v14, Landroid/support/v7/app/L;->Yj:J

    add-long v6, v12, v15

    invoke-virtual {v2}, Landroid/location/Location;->getLatitude()D

    move-result-wide v15

    invoke-virtual {v2}, Landroid/location/Location;->getLongitude()D

    move-result-wide v17

    move-object v5, v14

    move-wide/from16 v19, v8

    move-wide v8, v15

    move-wide v15, v10

    move-wide/from16 v10, v17

    invoke-virtual/range {v5 .. v11}, Landroid/support/v7/app/L;->a(JDD)V

    iget-wide v4, v14, Landroid/support/v7/app/L;->Zj:J

    const-wide/16 v6, 0x0

    const-wide/16 v8, -0x1

    cmp-long v2, v15, v8

    if-eqz v2, :cond_a

    cmp-long v2, v19, v8

    if-nez v2, :cond_7

    goto :goto_6

    :cond_7
    cmp-long v2, v12, v19

    if-lez v2, :cond_8

    add-long/2addr v4, v6

    goto :goto_5

    :cond_8
    cmp-long v2, v12, v15

    if-lez v2, :cond_9

    add-long v4, v19, v6

    goto :goto_5

    :cond_9
    add-long v4, v15, v6

    :goto_5
    const-wide/32 v6, 0xea60

    add-long/2addr v4, v6

    goto :goto_7

    :cond_a
    :goto_6
    const-wide/32 v4, 0x2932e00

    add-long/2addr v4, v12

    :goto_7
    iput-boolean v3, v0, Landroid/support/v7/app/M;->_j:Z

    iput-wide v4, v0, Landroid/support/v7/app/M;->ak:J

    .line 5
    iget-boolean v0, v1, Landroid/support/v7/app/M;->_j:Z

    return v0

    :cond_b
    const-string v0, "TwilightManager"

    const-string v1, "Could not get last known location. This is probably because the app does not have any location permissions. Falling back to hardcoded sunrise/sunset values."

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v0

    const/16 v1, 0xb

    invoke-virtual {v0, v1}, Ljava/util/Calendar;->get(I)I

    move-result v0

    const/4 v1, 0x6

    if-lt v0, v1, :cond_d

    const/16 v1, 0x16

    if-lt v0, v1, :cond_c

    goto :goto_8

    :cond_c
    move v3, v4

    :cond_d
    :goto_8
    return v3
.end method
