.class Landroid/support/v7/app/h;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/widget/AdapterView$OnItemClickListener;


# instance fields
.field final synthetic n:Landroid/support/v7/app/j;

.field final synthetic yi:Landroid/support/v7/app/m;


# direct methods
.method constructor <init>(Landroid/support/v7/app/j;Landroid/support/v7/app/m;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/app/h;->n:Landroid/support/v7/app/j;

    iput-object p2, p0, Landroid/support/v7/app/h;->yi:Landroid/support/v7/app/m;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 0

    iget-object p1, p0, Landroid/support/v7/app/h;->n:Landroid/support/v7/app/j;

    iget-object p1, p1, Landroid/support/v7/app/j;->mOnClickListener:Landroid/content/DialogInterface$OnClickListener;

    iget-object p2, p0, Landroid/support/v7/app/h;->yi:Landroid/support/v7/app/m;

    iget-object p2, p2, Landroid/support/v7/app/m;->mDialog:Landroid/support/v7/app/J;

    invoke-interface {p1, p2, p3}, Landroid/content/DialogInterface$OnClickListener;->onClick(Landroid/content/DialogInterface;I)V

    iget-object p1, p0, Landroid/support/v7/app/h;->n:Landroid/support/v7/app/j;

    iget-boolean p1, p1, Landroid/support/v7/app/j;->mIsSingleChoice:Z

    if-nez p1, :cond_0

    iget-object p0, p0, Landroid/support/v7/app/h;->yi:Landroid/support/v7/app/m;

    iget-object p0, p0, Landroid/support/v7/app/m;->mDialog:Landroid/support/v7/app/J;

    invoke-virtual {p0}, Landroid/app/Dialog;->dismiss()V

    :cond_0
    return-void
.end method
