.class Landroid/support/v7/app/Q;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/support/v4/view/z;


# instance fields
.field final synthetic n:Landroid/support/v7/app/T;


# direct methods
.method constructor <init>(Landroid/support/v7/app/T;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/app/Q;->n:Landroid/support/v7/app/T;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public c(Landroid/view/View;)V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/app/Q;->n:Landroid/support/v7/app/T;

    iget-object p0, p0, Landroid/support/v7/app/T;->fi:Landroid/support/v7/widget/ActionBarContainer;

    invoke-virtual {p0}, Landroid/widget/FrameLayout;->getParent()Landroid/view/ViewParent;

    move-result-object p0

    check-cast p0, Landroid/view/View;

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return-void
.end method
