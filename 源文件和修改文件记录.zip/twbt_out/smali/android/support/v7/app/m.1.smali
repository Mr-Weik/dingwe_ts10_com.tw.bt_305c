.class Landroid/support/v7/app/m;
.super Ljava/lang/Object;
.source ""


# instance fields
.field private final Di:I

.field Ei:Landroid/widget/Button;

.field private Fi:Ljava/lang/CharSequence;

.field Gi:Landroid/os/Message;

.field private Hi:Landroid/graphics/drawable/Drawable;

.field Ii:Landroid/widget/Button;

.field private Ji:Ljava/lang/CharSequence;

.field Ki:Landroid/os/Message;

.field private Li:Landroid/graphics/drawable/Drawable;

.field Mi:Landroid/widget/Button;

.field private Ni:Ljava/lang/CharSequence;

.field Oi:Landroid/os/Message;

.field private Pi:Landroid/graphics/drawable/Drawable;

.field private Qi:Landroid/widget/ImageView;

.field private Ri:Landroid/widget/TextView;

.field private Si:I

.field private Ti:I

.field Ui:I

.field Vi:I

.field Wi:I

.field Xi:I

.field private Yi:Z

.field private Zi:I

.field private final _i:Landroid/view/View$OnClickListener;

.field mAdapter:Landroid/widget/ListAdapter;

.field mCheckedItem:I

.field private final mContext:Landroid/content/Context;

.field private mCustomTitleView:Landroid/view/View;

.field final mDialog:Landroid/support/v7/app/J;

.field mHandler:Landroid/os/Handler;

.field private mIcon:Landroid/graphics/drawable/Drawable;

.field private mIconId:I

.field mListView:Landroid/widget/ListView;

.field private mMessage:Ljava/lang/CharSequence;

.field private mMessageView:Landroid/widget/TextView;

.field mScrollView:Landroid/support/v4/widget/NestedScrollView;

.field private mTitle:Ljava/lang/CharSequence;

.field private mView:Landroid/view/View;

.field private mViewLayoutResId:I

.field private mViewSpacingBottom:I

.field private mViewSpacingLeft:I

.field private mViewSpacingRight:I

.field private mViewSpacingSpecified:Z

.field private mViewSpacingTop:I

.field private final mWindow:Landroid/view/Window;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/support/v7/app/J;Landroid/view/Window;)V
    .locals 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/support/v7/app/m;->mViewSpacingSpecified:Z

    iput v0, p0, Landroid/support/v7/app/m;->mIconId:I

    const/4 v1, -0x1

    iput v1, p0, Landroid/support/v7/app/m;->mCheckedItem:I

    iput v0, p0, Landroid/support/v7/app/m;->Zi:I

    new-instance v1, Landroid/support/v7/app/e;

    invoke-direct {v1, p0}, Landroid/support/v7/app/e;-><init>(Landroid/support/v7/app/m;)V

    iput-object v1, p0, Landroid/support/v7/app/m;->_i:Landroid/view/View$OnClickListener;

    iput-object p1, p0, Landroid/support/v7/app/m;->mContext:Landroid/content/Context;

    iput-object p2, p0, Landroid/support/v7/app/m;->mDialog:Landroid/support/v7/app/J;

    iput-object p3, p0, Landroid/support/v7/app/m;->mWindow:Landroid/view/Window;

    new-instance p3, Landroid/support/v7/app/k;

    invoke-direct {p3, p2}, Landroid/support/v7/app/k;-><init>(Landroid/content/DialogInterface;)V

    iput-object p3, p0, Landroid/support/v7/app/m;->mHandler:Landroid/os/Handler;

    sget-object p3, La/b/d/a/b;->AlertDialog:[I

    const/4 v1, 0x0

    const v2, 0x7f030024

    invoke-virtual {p1, v1, p3, v2, v0}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    move-result-object p1

    sget p3, La/b/d/a/b;->gk:I

    invoke-virtual {p1, p3, v0}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result p3

    iput p3, p0, Landroid/support/v7/app/m;->Si:I

    const/4 p3, 0x2

    invoke-virtual {p1, p3, v0}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result p3

    iput p3, p0, Landroid/support/v7/app/m;->Ti:I

    const/4 p3, 0x4

    invoke-virtual {p1, p3, v0}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result p3

    iput p3, p0, Landroid/support/v7/app/m;->Ui:I

    const/4 p3, 0x5

    invoke-virtual {p1, p3, v0}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result p3

    iput p3, p0, Landroid/support/v7/app/m;->Vi:I

    const/4 p3, 0x7

    invoke-virtual {p1, p3, v0}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result p3

    iput p3, p0, Landroid/support/v7/app/m;->Wi:I

    const/4 p3, 0x3

    invoke-virtual {p1, p3, v0}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result p3

    iput p3, p0, Landroid/support/v7/app/m;->Xi:I

    const/4 p3, 0x1

    const/4 v1, 0x6

    invoke-virtual {p1, v1, p3}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v1

    iput-boolean v1, p0, Landroid/support/v7/app/m;->Yi:Z

    invoke-virtual {p1, p3, v0}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v0

    iput v0, p0, Landroid/support/v7/app/m;->Di:I

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    .line 1
    invoke-virtual {p2}, Landroid/support/v7/app/J;->B()Landroid/support/v7/app/r;

    move-result-object p0

    invoke-virtual {p0, p3}, Landroid/support/v7/app/r;->requestWindowFeature(I)Z

    return-void
.end method

.method private a(Landroid/view/View;Landroid/view/View;)Landroid/view/ViewGroup;
    .locals 1

    if-nez p1, :cond_1

    instance-of p0, p2, Landroid/view/ViewStub;

    if-eqz p0, :cond_0

    check-cast p2, Landroid/view/ViewStub;

    invoke-virtual {p2}, Landroid/view/ViewStub;->inflate()Landroid/view/View;

    move-result-object p2

    :cond_0
    check-cast p2, Landroid/view/ViewGroup;

    return-object p2

    :cond_1
    if-eqz p2, :cond_2

    invoke-virtual {p2}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p0

    instance-of v0, p0, Landroid/view/ViewGroup;

    if-eqz v0, :cond_2

    check-cast p0, Landroid/view/ViewGroup;

    invoke-virtual {p0, p2}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_2
    instance-of p0, p1, Landroid/view/ViewStub;

    if-eqz p0, :cond_3

    check-cast p1, Landroid/view/ViewStub;

    invoke-virtual {p1}, Landroid/view/ViewStub;->inflate()Landroid/view/View;

    move-result-object p1

    :cond_3
    check-cast p1, Landroid/view/ViewGroup;

    return-object p1
.end method

.method private a(Landroid/widget/Button;)V
    .locals 1

    invoke-virtual {p1}, Landroid/widget/Button;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p0

    check-cast p0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v0, 0x1

    iput v0, p0, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    const/high16 v0, 0x3f000000    # 0.5f

    iput v0, p0, Landroid/widget/LinearLayout$LayoutParams;->weight:F

    invoke-virtual {p1, p0}, Landroid/widget/Button;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method static canTextInput(Landroid/view/View;)Z
    .locals 4

    invoke-virtual {p0}, Landroid/view/View;->onCheckIsTextEditor()Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    return v1

    :cond_0
    instance-of v0, p0, Landroid/view/ViewGroup;

    const/4 v2, 0x0

    if-nez v0, :cond_1

    return v2

    :cond_1
    check-cast p0, Landroid/view/ViewGroup;

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    :cond_2
    if-lez v0, :cond_3

    add-int/lit8 v0, v0, -0x1

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    invoke-static {v3}, Landroid/support/v7/app/m;->canTextInput(Landroid/view/View;)Z

    move-result v3

    if-eqz v3, :cond_2

    return v1

    :cond_3
    return v2
.end method


# virtual methods
.method public a(ILjava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;Landroid/os/Message;Landroid/graphics/drawable/Drawable;)V
    .locals 0

    if-nez p4, :cond_0

    if-eqz p3, :cond_0

    iget-object p4, p0, Landroid/support/v7/app/m;->mHandler:Landroid/os/Handler;

    invoke-virtual {p4, p1, p3}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p4

    :cond_0
    const/4 p3, -0x3

    if-eq p1, p3, :cond_3

    const/4 p3, -0x2

    if-eq p1, p3, :cond_2

    const/4 p3, -0x1

    if-ne p1, p3, :cond_1

    iput-object p2, p0, Landroid/support/v7/app/m;->Fi:Ljava/lang/CharSequence;

    iput-object p4, p0, Landroid/support/v7/app/m;->Gi:Landroid/os/Message;

    iput-object p5, p0, Landroid/support/v7/app/m;->Hi:Landroid/graphics/drawable/Drawable;

    goto :goto_0

    :cond_1
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "Button does not exist"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_2
    iput-object p2, p0, Landroid/support/v7/app/m;->Ji:Ljava/lang/CharSequence;

    iput-object p4, p0, Landroid/support/v7/app/m;->Ki:Landroid/os/Message;

    iput-object p5, p0, Landroid/support/v7/app/m;->Li:Landroid/graphics/drawable/Drawable;

    goto :goto_0

    :cond_3
    iput-object p2, p0, Landroid/support/v7/app/m;->Ni:Ljava/lang/CharSequence;

    iput-object p4, p0, Landroid/support/v7/app/m;->Oi:Landroid/os/Message;

    iput-object p5, p0, Landroid/support/v7/app/m;->Pi:Landroid/graphics/drawable/Drawable;

    :goto_0
    return-void
.end method

.method public getIconAttributeResId(I)I
    .locals 2

    new-instance v0, Landroid/util/TypedValue;

    invoke-direct {v0}, Landroid/util/TypedValue;-><init>()V

    iget-object p0, p0, Landroid/support/v7/app/m;->mContext:Landroid/content/Context;

    invoke-virtual {p0}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object p0

    const/4 v1, 0x1

    invoke-virtual {p0, p1, v0, v1}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    iget p0, v0, Landroid/util/TypedValue;->resourceId:I

    return p0
.end method

.method public installContent()V
    .locals 16

    move-object/from16 v0, p0

    .line 1
    iget v1, v0, Landroid/support/v7/app/m;->Ti:I

    const/4 v2, 0x1

    if-nez v1, :cond_1

    :cond_0
    iget v1, v0, Landroid/support/v7/app/m;->Si:I

    goto :goto_0

    :cond_1
    iget v3, v0, Landroid/support/v7/app/m;->Zi:I

    if-ne v3, v2, :cond_0

    .line 2
    :goto_0
    iget-object v3, v0, Landroid/support/v7/app/m;->mDialog:Landroid/support/v7/app/J;

    .line 3
    invoke-virtual {v3}, Landroid/support/v7/app/J;->B()Landroid/support/v7/app/r;

    move-result-object v3

    invoke-virtual {v3, v1}, Landroid/support/v7/app/r;->setContentView(I)V

    .line 4
    iget-object v1, v0, Landroid/support/v7/app/m;->mWindow:Landroid/view/Window;

    const v3, 0x7f0800c1

    invoke-virtual {v1, v3}, Landroid/view/Window;->findViewById(I)Landroid/view/View;

    move-result-object v1

    const v3, 0x7f080104

    invoke-virtual {v1, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v4

    const v5, 0x7f080038

    invoke-virtual {v1, v5}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v6

    const v7, 0x7f080028

    invoke-virtual {v1, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v8

    const v9, 0x7f08003a

    invoke-virtual {v1, v9}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/view/ViewGroup;

    .line 5
    iget-object v9, v0, Landroid/support/v7/app/m;->mView:Landroid/view/View;

    const/4 v10, 0x0

    if-eqz v9, :cond_2

    goto :goto_1

    :cond_2
    iget v9, v0, Landroid/support/v7/app/m;->mViewLayoutResId:I

    if-eqz v9, :cond_3

    iget-object v9, v0, Landroid/support/v7/app/m;->mContext:Landroid/content/Context;

    invoke-static {v9}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v9

    iget v12, v0, Landroid/support/v7/app/m;->mViewLayoutResId:I

    invoke-virtual {v9, v12, v1, v10}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v9

    goto :goto_1

    :cond_3
    const/4 v9, 0x0

    :goto_1
    if-eqz v9, :cond_4

    move v12, v2

    goto :goto_2

    :cond_4
    move v12, v10

    :goto_2
    if-eqz v12, :cond_5

    invoke-static {v9}, Landroid/support/v7/app/m;->canTextInput(Landroid/view/View;)Z

    move-result v13

    if-nez v13, :cond_6

    :cond_5
    iget-object v13, v0, Landroid/support/v7/app/m;->mWindow:Landroid/view/Window;

    const/high16 v14, 0x20000

    invoke-virtual {v13, v14, v14}, Landroid/view/Window;->setFlags(II)V

    :cond_6
    const/4 v13, -0x1

    const/16 v14, 0x8

    if-eqz v12, :cond_8

    iget-object v12, v0, Landroid/support/v7/app/m;->mWindow:Landroid/view/Window;

    const v15, 0x7f080039

    invoke-virtual {v12, v15}, Landroid/view/Window;->findViewById(I)Landroid/view/View;

    move-result-object v12

    check-cast v12, Landroid/widget/FrameLayout;

    new-instance v15, Landroid/view/ViewGroup$LayoutParams;

    invoke-direct {v15, v13, v13}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    invoke-virtual {v12, v9, v15}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-boolean v9, v0, Landroid/support/v7/app/m;->mViewSpacingSpecified:Z

    if-eqz v9, :cond_7

    iget v9, v0, Landroid/support/v7/app/m;->mViewSpacingLeft:I

    iget v15, v0, Landroid/support/v7/app/m;->mViewSpacingTop:I

    iget v2, v0, Landroid/support/v7/app/m;->mViewSpacingRight:I

    iget v11, v0, Landroid/support/v7/app/m;->mViewSpacingBottom:I

    invoke-virtual {v12, v9, v15, v2, v11}, Landroid/widget/FrameLayout;->setPadding(IIII)V

    :cond_7
    iget-object v2, v0, Landroid/support/v7/app/m;->mListView:Landroid/widget/ListView;

    if-eqz v2, :cond_9

    invoke-virtual {v1}, Landroid/view/ViewGroup;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    check-cast v2, Landroid/support/v7/widget/Oa;

    const/4 v9, 0x0

    iput v9, v2, Landroid/support/v7/widget/Oa;->weight:F

    goto :goto_3

    :cond_8
    invoke-virtual {v1, v14}, Landroid/view/ViewGroup;->setVisibility(I)V

    .line 6
    :cond_9
    :goto_3
    invoke-virtual {v1, v3}, Landroid/view/ViewGroup;->findViewById(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v1, v5}, Landroid/view/ViewGroup;->findViewById(I)Landroid/view/View;

    move-result-object v3

    invoke-virtual {v1, v7}, Landroid/view/ViewGroup;->findViewById(I)Landroid/view/View;

    move-result-object v5

    invoke-direct {v0, v2, v4}, Landroid/support/v7/app/m;->a(Landroid/view/View;Landroid/view/View;)Landroid/view/ViewGroup;

    move-result-object v2

    invoke-direct {v0, v3, v6}, Landroid/support/v7/app/m;->a(Landroid/view/View;Landroid/view/View;)Landroid/view/ViewGroup;

    move-result-object v3

    invoke-direct {v0, v5, v8}, Landroid/support/v7/app/m;->a(Landroid/view/View;Landroid/view/View;)Landroid/view/ViewGroup;

    move-result-object v4

    .line 7
    iget-object v5, v0, Landroid/support/v7/app/m;->mWindow:Landroid/view/Window;

    const v6, 0x7f0800dc

    invoke-virtual {v5, v6}, Landroid/view/Window;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/support/v4/widget/NestedScrollView;

    iput-object v5, v0, Landroid/support/v7/app/m;->mScrollView:Landroid/support/v4/widget/NestedScrollView;

    iget-object v5, v0, Landroid/support/v7/app/m;->mScrollView:Landroid/support/v4/widget/NestedScrollView;

    invoke-virtual {v5, v10}, Landroid/widget/FrameLayout;->setFocusable(Z)V

    iget-object v5, v0, Landroid/support/v7/app/m;->mScrollView:Landroid/support/v4/widget/NestedScrollView;

    invoke-virtual {v5, v10}, Landroid/support/v4/widget/NestedScrollView;->setNestedScrollingEnabled(Z)V

    const v5, 0x102000b

    invoke-virtual {v3, v5}, Landroid/view/ViewGroup;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/TextView;

    iput-object v5, v0, Landroid/support/v7/app/m;->mMessageView:Landroid/widget/TextView;

    iget-object v5, v0, Landroid/support/v7/app/m;->mMessageView:Landroid/widget/TextView;

    if-nez v5, :cond_a

    goto :goto_4

    :cond_a
    iget-object v6, v0, Landroid/support/v7/app/m;->mMessage:Ljava/lang/CharSequence;

    if-eqz v6, :cond_b

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_4

    :cond_b
    invoke-virtual {v5, v14}, Landroid/widget/TextView;->setVisibility(I)V

    iget-object v5, v0, Landroid/support/v7/app/m;->mScrollView:Landroid/support/v4/widget/NestedScrollView;

    iget-object v6, v0, Landroid/support/v7/app/m;->mMessageView:Landroid/widget/TextView;

    invoke-virtual {v5, v6}, Landroid/widget/FrameLayout;->removeView(Landroid/view/View;)V

    iget-object v5, v0, Landroid/support/v7/app/m;->mListView:Landroid/widget/ListView;

    if-eqz v5, :cond_c

    iget-object v5, v0, Landroid/support/v7/app/m;->mScrollView:Landroid/support/v4/widget/NestedScrollView;

    invoke-virtual {v5}, Landroid/widget/FrameLayout;->getParent()Landroid/view/ViewParent;

    move-result-object v5

    check-cast v5, Landroid/view/ViewGroup;

    iget-object v6, v0, Landroid/support/v7/app/m;->mScrollView:Landroid/support/v4/widget/NestedScrollView;

    invoke-virtual {v5, v6}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    move-result v6

    invoke-virtual {v5, v6}, Landroid/view/ViewGroup;->removeViewAt(I)V

    iget-object v7, v0, Landroid/support/v7/app/m;->mListView:Landroid/widget/ListView;

    new-instance v8, Landroid/view/ViewGroup$LayoutParams;

    invoke-direct {v8, v13, v13}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    invoke-virtual {v5, v7, v6, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    goto :goto_4

    :cond_c
    invoke-virtual {v3, v14}, Landroid/view/ViewGroup;->setVisibility(I)V

    :goto_4
    const v5, 0x1020019

    .line 8
    invoke-virtual {v4, v5}, Landroid/view/ViewGroup;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/Button;

    iput-object v5, v0, Landroid/support/v7/app/m;->Ei:Landroid/widget/Button;

    iget-object v5, v0, Landroid/support/v7/app/m;->Ei:Landroid/widget/Button;

    iget-object v6, v0, Landroid/support/v7/app/m;->_i:Landroid/view/View$OnClickListener;

    invoke-virtual {v5, v6}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object v5, v0, Landroid/support/v7/app/m;->Fi:Ljava/lang/CharSequence;

    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_d

    iget-object v5, v0, Landroid/support/v7/app/m;->Hi:Landroid/graphics/drawable/Drawable;

    if-nez v5, :cond_d

    iget-object v5, v0, Landroid/support/v7/app/m;->Ei:Landroid/widget/Button;

    invoke-virtual {v5, v14}, Landroid/widget/Button;->setVisibility(I)V

    move v5, v10

    goto :goto_5

    :cond_d
    iget-object v5, v0, Landroid/support/v7/app/m;->Ei:Landroid/widget/Button;

    iget-object v6, v0, Landroid/support/v7/app/m;->Fi:Ljava/lang/CharSequence;

    invoke-virtual {v5, v6}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    iget-object v5, v0, Landroid/support/v7/app/m;->Hi:Landroid/graphics/drawable/Drawable;

    if-eqz v5, :cond_e

    iget v6, v0, Landroid/support/v7/app/m;->Di:I

    invoke-virtual {v5, v10, v10, v6, v6}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    iget-object v5, v0, Landroid/support/v7/app/m;->Ei:Landroid/widget/Button;

    iget-object v6, v0, Landroid/support/v7/app/m;->Hi:Landroid/graphics/drawable/Drawable;

    const/4 v7, 0x0

    invoke-virtual {v5, v6, v7, v7, v7}, Landroid/widget/Button;->setCompoundDrawables(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    :cond_e
    iget-object v5, v0, Landroid/support/v7/app/m;->Ei:Landroid/widget/Button;

    invoke-virtual {v5, v10}, Landroid/widget/Button;->setVisibility(I)V

    const/4 v5, 0x1

    :goto_5
    const v6, 0x102001a

    invoke-virtual {v4, v6}, Landroid/view/ViewGroup;->findViewById(I)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/Button;

    iput-object v6, v0, Landroid/support/v7/app/m;->Ii:Landroid/widget/Button;

    iget-object v6, v0, Landroid/support/v7/app/m;->Ii:Landroid/widget/Button;

    iget-object v7, v0, Landroid/support/v7/app/m;->_i:Landroid/view/View$OnClickListener;

    invoke-virtual {v6, v7}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object v6, v0, Landroid/support/v7/app/m;->Ji:Ljava/lang/CharSequence;

    invoke-static {v6}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v6

    if-eqz v6, :cond_f

    iget-object v6, v0, Landroid/support/v7/app/m;->Li:Landroid/graphics/drawable/Drawable;

    if-nez v6, :cond_f

    iget-object v6, v0, Landroid/support/v7/app/m;->Ii:Landroid/widget/Button;

    invoke-virtual {v6, v14}, Landroid/widget/Button;->setVisibility(I)V

    goto :goto_6

    :cond_f
    iget-object v6, v0, Landroid/support/v7/app/m;->Ii:Landroid/widget/Button;

    iget-object v7, v0, Landroid/support/v7/app/m;->Ji:Ljava/lang/CharSequence;

    invoke-virtual {v6, v7}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    iget-object v6, v0, Landroid/support/v7/app/m;->Li:Landroid/graphics/drawable/Drawable;

    if-eqz v6, :cond_10

    iget v7, v0, Landroid/support/v7/app/m;->Di:I

    invoke-virtual {v6, v10, v10, v7, v7}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    iget-object v6, v0, Landroid/support/v7/app/m;->Ii:Landroid/widget/Button;

    iget-object v7, v0, Landroid/support/v7/app/m;->Li:Landroid/graphics/drawable/Drawable;

    const/4 v8, 0x0

    invoke-virtual {v6, v7, v8, v8, v8}, Landroid/widget/Button;->setCompoundDrawables(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    :cond_10
    iget-object v6, v0, Landroid/support/v7/app/m;->Ii:Landroid/widget/Button;

    invoke-virtual {v6, v10}, Landroid/widget/Button;->setVisibility(I)V

    or-int/lit8 v5, v5, 0x2

    :goto_6
    const v6, 0x102001b

    invoke-virtual {v4, v6}, Landroid/view/ViewGroup;->findViewById(I)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/Button;

    iput-object v6, v0, Landroid/support/v7/app/m;->Mi:Landroid/widget/Button;

    iget-object v6, v0, Landroid/support/v7/app/m;->Mi:Landroid/widget/Button;

    iget-object v7, v0, Landroid/support/v7/app/m;->_i:Landroid/view/View$OnClickListener;

    invoke-virtual {v6, v7}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object v6, v0, Landroid/support/v7/app/m;->Ni:Ljava/lang/CharSequence;

    invoke-static {v6}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v6

    if-eqz v6, :cond_11

    iget-object v6, v0, Landroid/support/v7/app/m;->Pi:Landroid/graphics/drawable/Drawable;

    if-nez v6, :cond_11

    iget-object v6, v0, Landroid/support/v7/app/m;->Mi:Landroid/widget/Button;

    invoke-virtual {v6, v14}, Landroid/widget/Button;->setVisibility(I)V

    const/4 v8, 0x0

    goto :goto_8

    :cond_11
    iget-object v6, v0, Landroid/support/v7/app/m;->Mi:Landroid/widget/Button;

    iget-object v7, v0, Landroid/support/v7/app/m;->Ni:Ljava/lang/CharSequence;

    invoke-virtual {v6, v7}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    iget-object v6, v0, Landroid/support/v7/app/m;->Hi:Landroid/graphics/drawable/Drawable;

    if-eqz v6, :cond_12

    iget v7, v0, Landroid/support/v7/app/m;->Di:I

    invoke-virtual {v6, v10, v10, v7, v7}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    iget-object v6, v0, Landroid/support/v7/app/m;->Ei:Landroid/widget/Button;

    iget-object v7, v0, Landroid/support/v7/app/m;->Hi:Landroid/graphics/drawable/Drawable;

    const/4 v8, 0x0

    invoke-virtual {v6, v7, v8, v8, v8}, Landroid/widget/Button;->setCompoundDrawables(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    goto :goto_7

    :cond_12
    const/4 v8, 0x0

    :goto_7
    iget-object v6, v0, Landroid/support/v7/app/m;->Mi:Landroid/widget/Button;

    invoke-virtual {v6, v10}, Landroid/widget/Button;->setVisibility(I)V

    or-int/lit8 v5, v5, 0x4

    :goto_8
    iget-object v6, v0, Landroid/support/v7/app/m;->mContext:Landroid/content/Context;

    .line 9
    new-instance v7, Landroid/util/TypedValue;

    invoke-direct {v7}, Landroid/util/TypedValue;-><init>()V

    invoke-virtual {v6}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v6

    const v9, 0x7f030023

    const/4 v11, 0x1

    invoke-virtual {v6, v9, v7, v11}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    iget v6, v7, Landroid/util/TypedValue;->data:I

    if-eqz v6, :cond_13

    move v6, v11

    goto :goto_9

    :cond_13
    move v6, v10

    :goto_9
    const/4 v7, 0x2

    if-eqz v6, :cond_16

    if-ne v5, v11, :cond_14

    .line 10
    iget-object v6, v0, Landroid/support/v7/app/m;->Ei:Landroid/widget/Button;

    goto :goto_a

    :cond_14
    if-ne v5, v7, :cond_15

    iget-object v6, v0, Landroid/support/v7/app/m;->Ii:Landroid/widget/Button;

    goto :goto_a

    :cond_15
    const/4 v6, 0x4

    if-ne v5, v6, :cond_16

    iget-object v6, v0, Landroid/support/v7/app/m;->Mi:Landroid/widget/Button;

    :goto_a
    invoke-direct {v0, v6}, Landroid/support/v7/app/m;->a(Landroid/widget/Button;)V

    :cond_16
    if-eqz v5, :cond_17

    const/4 v5, 0x1

    goto :goto_b

    :cond_17
    move v5, v10

    :goto_b
    if-nez v5, :cond_18

    invoke-virtual {v4, v14}, Landroid/view/ViewGroup;->setVisibility(I)V

    .line 11
    :cond_18
    iget-object v5, v0, Landroid/support/v7/app/m;->mCustomTitleView:Landroid/view/View;

    const v6, 0x7f080101

    if-eqz v5, :cond_19

    new-instance v5, Landroid/view/ViewGroup$LayoutParams;

    const/4 v9, -0x2

    invoke-direct {v5, v13, v9}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    iget-object v9, v0, Landroid/support/v7/app/m;->mCustomTitleView:Landroid/view/View;

    invoke-virtual {v2, v9, v10, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    iget-object v5, v0, Landroid/support/v7/app/m;->mWindow:Landroid/view/Window;

    invoke-virtual {v5, v6}, Landroid/view/Window;->findViewById(I)Landroid/view/View;

    move-result-object v5

    invoke-virtual {v5, v14}, Landroid/view/View;->setVisibility(I)V

    goto/16 :goto_c

    :cond_19
    iget-object v5, v0, Landroid/support/v7/app/m;->mWindow:Landroid/view/Window;

    const v9, 0x1020006

    invoke-virtual {v5, v9}, Landroid/view/Window;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/ImageView;

    iput-object v5, v0, Landroid/support/v7/app/m;->Qi:Landroid/widget/ImageView;

    iget-object v5, v0, Landroid/support/v7/app/m;->mTitle:Ljava/lang/CharSequence;

    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v5

    const/4 v9, 0x1

    xor-int/2addr v5, v9

    if-eqz v5, :cond_1c

    iget-boolean v5, v0, Landroid/support/v7/app/m;->Yi:Z

    if-eqz v5, :cond_1c

    iget-object v5, v0, Landroid/support/v7/app/m;->mWindow:Landroid/view/Window;

    const v6, 0x7f08001c

    invoke-virtual {v5, v6}, Landroid/view/Window;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/TextView;

    iput-object v5, v0, Landroid/support/v7/app/m;->Ri:Landroid/widget/TextView;

    iget-object v5, v0, Landroid/support/v7/app/m;->Ri:Landroid/widget/TextView;

    iget-object v6, v0, Landroid/support/v7/app/m;->mTitle:Ljava/lang/CharSequence;

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget v5, v0, Landroid/support/v7/app/m;->mIconId:I

    if-eqz v5, :cond_1a

    iget-object v6, v0, Landroid/support/v7/app/m;->Qi:Landroid/widget/ImageView;

    invoke-virtual {v6, v5}, Landroid/widget/ImageView;->setImageResource(I)V

    goto :goto_c

    :cond_1a
    iget-object v5, v0, Landroid/support/v7/app/m;->mIcon:Landroid/graphics/drawable/Drawable;

    if-eqz v5, :cond_1b

    iget-object v6, v0, Landroid/support/v7/app/m;->Qi:Landroid/widget/ImageView;

    invoke-virtual {v6, v5}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    goto :goto_c

    :cond_1b
    iget-object v5, v0, Landroid/support/v7/app/m;->Ri:Landroid/widget/TextView;

    iget-object v6, v0, Landroid/support/v7/app/m;->Qi:Landroid/widget/ImageView;

    invoke-virtual {v6}, Landroid/widget/ImageView;->getPaddingLeft()I

    move-result v6

    iget-object v9, v0, Landroid/support/v7/app/m;->Qi:Landroid/widget/ImageView;

    invoke-virtual {v9}, Landroid/widget/ImageView;->getPaddingTop()I

    move-result v9

    iget-object v11, v0, Landroid/support/v7/app/m;->Qi:Landroid/widget/ImageView;

    invoke-virtual {v11}, Landroid/widget/ImageView;->getPaddingRight()I

    move-result v11

    iget-object v12, v0, Landroid/support/v7/app/m;->Qi:Landroid/widget/ImageView;

    invoke-virtual {v12}, Landroid/widget/ImageView;->getPaddingBottom()I

    move-result v12

    invoke-virtual {v5, v6, v9, v11, v12}, Landroid/widget/TextView;->setPadding(IIII)V

    iget-object v5, v0, Landroid/support/v7/app/m;->Qi:Landroid/widget/ImageView;

    invoke-virtual {v5, v14}, Landroid/widget/ImageView;->setVisibility(I)V

    goto :goto_c

    :cond_1c
    iget-object v5, v0, Landroid/support/v7/app/m;->mWindow:Landroid/view/Window;

    invoke-virtual {v5, v6}, Landroid/view/Window;->findViewById(I)Landroid/view/View;

    move-result-object v5

    invoke-virtual {v5, v14}, Landroid/view/View;->setVisibility(I)V

    iget-object v5, v0, Landroid/support/v7/app/m;->Qi:Landroid/widget/ImageView;

    invoke-virtual {v5, v14}, Landroid/widget/ImageView;->setVisibility(I)V

    invoke-virtual {v2, v14}, Landroid/view/ViewGroup;->setVisibility(I)V

    .line 12
    :goto_c
    invoke-virtual {v1}, Landroid/view/ViewGroup;->getVisibility()I

    move-result v1

    if-eq v1, v14, :cond_1d

    const/4 v1, 0x1

    goto :goto_d

    :cond_1d
    move v1, v10

    :goto_d
    if-eqz v2, :cond_1e

    invoke-virtual {v2}, Landroid/view/ViewGroup;->getVisibility()I

    move-result v5

    if-eq v5, v14, :cond_1e

    const/4 v5, 0x1

    goto :goto_e

    :cond_1e
    move v5, v10

    :goto_e
    invoke-virtual {v4}, Landroid/view/ViewGroup;->getVisibility()I

    move-result v4

    if-eq v4, v14, :cond_1f

    const/4 v4, 0x1

    goto :goto_f

    :cond_1f
    move v4, v10

    :goto_f
    if-nez v4, :cond_20

    const v6, 0x7f0800fc

    invoke-virtual {v3, v6}, Landroid/view/ViewGroup;->findViewById(I)Landroid/view/View;

    move-result-object v6

    if-eqz v6, :cond_20

    invoke-virtual {v6, v10}, Landroid/view/View;->setVisibility(I)V

    :cond_20
    if-eqz v5, :cond_24

    iget-object v6, v0, Landroid/support/v7/app/m;->mScrollView:Landroid/support/v4/widget/NestedScrollView;

    if-eqz v6, :cond_21

    const/4 v9, 0x1

    invoke-virtual {v6, v9}, Landroid/widget/FrameLayout;->setClipToPadding(Z)V

    :cond_21
    iget-object v6, v0, Landroid/support/v7/app/m;->mMessage:Ljava/lang/CharSequence;

    if-nez v6, :cond_22

    iget-object v6, v0, Landroid/support/v7/app/m;->mListView:Landroid/widget/ListView;

    if-eqz v6, :cond_23

    :cond_22
    const v6, 0x7f080100

    invoke-virtual {v2, v6}, Landroid/view/ViewGroup;->findViewById(I)Landroid/view/View;

    move-result-object v11

    move-object v8, v11

    :cond_23
    if-eqz v8, :cond_25

    invoke-virtual {v8, v10}, Landroid/view/View;->setVisibility(I)V

    goto :goto_10

    :cond_24
    const v2, 0x7f0800fd

    invoke-virtual {v3, v2}, Landroid/view/ViewGroup;->findViewById(I)Landroid/view/View;

    move-result-object v2

    if-eqz v2, :cond_25

    invoke-virtual {v2, v10}, Landroid/view/View;->setVisibility(I)V

    :cond_25
    :goto_10
    iget-object v2, v0, Landroid/support/v7/app/m;->mListView:Landroid/widget/ListView;

    instance-of v6, v2, Landroid/support/v7/app/AlertController$RecycleListView;

    if-eqz v6, :cond_26

    check-cast v2, Landroid/support/v7/app/AlertController$RecycleListView;

    invoke-virtual {v2, v5, v4}, Landroid/support/v7/app/AlertController$RecycleListView;->setHasDecor(ZZ)V

    :cond_26
    if-nez v1, :cond_2a

    iget-object v1, v0, Landroid/support/v7/app/m;->mListView:Landroid/widget/ListView;

    if-eqz v1, :cond_27

    goto :goto_11

    :cond_27
    iget-object v1, v0, Landroid/support/v7/app/m;->mScrollView:Landroid/support/v4/widget/NestedScrollView;

    :goto_11
    if-eqz v1, :cond_2a

    if-eqz v4, :cond_28

    goto :goto_12

    :cond_28
    move v7, v10

    :goto_12
    or-int v2, v5, v7

    const/4 v4, 0x3

    .line 13
    iget-object v5, v0, Landroid/support/v7/app/m;->mWindow:Landroid/view/Window;

    const v6, 0x7f0800db

    invoke-virtual {v5, v6}, Landroid/view/Window;->findViewById(I)Landroid/view/View;

    move-result-object v5

    iget-object v6, v0, Landroid/support/v7/app/m;->mWindow:Landroid/view/Window;

    const v7, 0x7f0800da

    invoke-virtual {v6, v7}, Landroid/view/Window;->findViewById(I)Landroid/view/View;

    move-result-object v6

    sget v7, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-static {v1, v2, v4}, Landroid/support/v4/view/r;->a(Landroid/view/View;II)V

    if-eqz v5, :cond_29

    invoke-virtual {v3, v5}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_29
    if-eqz v6, :cond_2a

    invoke-virtual {v3, v6}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 14
    :cond_2a
    iget-object v1, v0, Landroid/support/v7/app/m;->mListView:Landroid/widget/ListView;

    if-eqz v1, :cond_2b

    iget-object v2, v0, Landroid/support/v7/app/m;->mAdapter:Landroid/widget/ListAdapter;

    if-eqz v2, :cond_2b

    invoke-virtual {v1, v2}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    iget v0, v0, Landroid/support/v7/app/m;->mCheckedItem:I

    if-le v0, v13, :cond_2b

    const/4 v2, 0x1

    invoke-virtual {v1, v0, v2}, Landroid/widget/ListView;->setItemChecked(IZ)V

    invoke-virtual {v1, v0}, Landroid/widget/ListView;->setSelection(I)V

    :cond_2b
    return-void
.end method

.method public setCustomTitle(Landroid/view/View;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/app/m;->mCustomTitleView:Landroid/view/View;

    return-void
.end method

.method public setIcon(I)V
    .locals 1

    const/4 v0, 0x0

    iput-object v0, p0, Landroid/support/v7/app/m;->mIcon:Landroid/graphics/drawable/Drawable;

    iput p1, p0, Landroid/support/v7/app/m;->mIconId:I

    iget-object v0, p0, Landroid/support/v7/app/m;->Qi:Landroid/widget/ImageView;

    if-eqz v0, :cond_1

    if-eqz p1, :cond_0

    const/4 p1, 0x0

    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setVisibility(I)V

    iget-object p1, p0, Landroid/support/v7/app/m;->Qi:Landroid/widget/ImageView;

    iget p0, p0, Landroid/support/v7/app/m;->mIconId:I

    invoke-virtual {p1, p0}, Landroid/widget/ImageView;->setImageResource(I)V

    goto :goto_0

    :cond_0
    const/16 p0, 0x8

    invoke-virtual {v0, p0}, Landroid/widget/ImageView;->setVisibility(I)V

    :cond_1
    :goto_0
    return-void
.end method

.method public setIcon(Landroid/graphics/drawable/Drawable;)V
    .locals 2

    iput-object p1, p0, Landroid/support/v7/app/m;->mIcon:Landroid/graphics/drawable/Drawable;

    const/4 v0, 0x0

    iput v0, p0, Landroid/support/v7/app/m;->mIconId:I

    iget-object v1, p0, Landroid/support/v7/app/m;->Qi:Landroid/widget/ImageView;

    if-eqz v1, :cond_1

    if-eqz p1, :cond_0

    invoke-virtual {v1, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    iget-object p0, p0, Landroid/support/v7/app/m;->Qi:Landroid/widget/ImageView;

    invoke-virtual {p0, p1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    goto :goto_0

    :cond_0
    const/16 p0, 0x8

    invoke-virtual {v1, p0}, Landroid/widget/ImageView;->setVisibility(I)V

    :cond_1
    :goto_0
    return-void
.end method

.method public setMessage(Ljava/lang/CharSequence;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/app/m;->mMessage:Ljava/lang/CharSequence;

    iget-object p0, p0, Landroid/support/v7/app/m;->mMessageView:Landroid/widget/TextView;

    if-eqz p0, :cond_0

    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_0
    return-void
.end method

.method public setTitle(Ljava/lang/CharSequence;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/app/m;->mTitle:Ljava/lang/CharSequence;

    iget-object p0, p0, Landroid/support/v7/app/m;->Ri:Landroid/widget/TextView;

    if-eqz p0, :cond_0

    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_0
    return-void
.end method

.method public setView(I)V
    .locals 1

    const/4 v0, 0x0

    iput-object v0, p0, Landroid/support/v7/app/m;->mView:Landroid/view/View;

    iput p1, p0, Landroid/support/v7/app/m;->mViewLayoutResId:I

    const/4 p1, 0x0

    iput-boolean p1, p0, Landroid/support/v7/app/m;->mViewSpacingSpecified:Z

    return-void
.end method

.method public setView(Landroid/view/View;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/app/m;->mView:Landroid/view/View;

    const/4 p1, 0x0

    iput p1, p0, Landroid/support/v7/app/m;->mViewLayoutResId:I

    iput-boolean p1, p0, Landroid/support/v7/app/m;->mViewSpacingSpecified:Z

    return-void
.end method

.method public setView(Landroid/view/View;IIII)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/app/m;->mView:Landroid/view/View;

    const/4 p1, 0x0

    iput p1, p0, Landroid/support/v7/app/m;->mViewLayoutResId:I

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroid/support/v7/app/m;->mViewSpacingSpecified:Z

    iput p2, p0, Landroid/support/v7/app/m;->mViewSpacingLeft:I

    iput p3, p0, Landroid/support/v7/app/m;->mViewSpacingTop:I

    iput p4, p0, Landroid/support/v7/app/m;->mViewSpacingRight:I

    iput p5, p0, Landroid/support/v7/app/m;->mViewSpacingBottom:I

    return-void
.end method
