.class Landroid/support/v7/app/A;
.super Landroid/support/v4/view/y;
.source ""


# instance fields
.field final synthetic Hc:Landroid/support/v7/app/B;


# direct methods
.method constructor <init>(Landroid/support/v7/app/B;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/app/A;->Hc:Landroid/support/v7/app/B;

    invoke-direct {p0}, Landroid/support/v4/view/y;-><init>()V

    return-void
.end method


# virtual methods
.method public d(Landroid/view/View;)V
    .locals 1

    iget-object p1, p0, Landroid/support/v7/app/A;->Hc:Landroid/support/v7/app/B;

    iget-object p1, p1, Landroid/support/v7/app/B;->n:Landroid/support/v7/app/I;

    iget-object p1, p1, Landroid/support/v7/app/I;->gj:Landroid/support/v7/widget/ActionBarContextView;

    const/16 v0, 0x8

    invoke-virtual {p1, v0}, Landroid/support/v7/widget/ActionBarContextView;->setVisibility(I)V

    iget-object p1, p0, Landroid/support/v7/app/A;->Hc:Landroid/support/v7/app/B;

    iget-object p1, p1, Landroid/support/v7/app/B;->n:Landroid/support/v7/app/I;

    iget-object v0, p1, Landroid/support/v7/app/I;->hj:Landroid/widget/PopupWindow;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/widget/PopupWindow;->dismiss()V

    goto :goto_0

    :cond_0
    iget-object p1, p1, Landroid/support/v7/app/I;->gj:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {p1}, Landroid/view/ViewGroup;->getParent()Landroid/view/ViewParent;

    move-result-object p1

    instance-of p1, p1, Landroid/view/View;

    if-eqz p1, :cond_1

    iget-object p1, p0, Landroid/support/v7/app/A;->Hc:Landroid/support/v7/app/B;

    iget-object p1, p1, Landroid/support/v7/app/B;->n:Landroid/support/v7/app/I;

    iget-object p1, p1, Landroid/support/v7/app/I;->gj:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {p1}, Landroid/view/ViewGroup;->getParent()Landroid/view/ViewParent;

    move-result-object p1

    check-cast p1, Landroid/view/View;

    invoke-static {p1}, Landroid/support/v4/view/r;->A(Landroid/view/View;)V

    :cond_1
    :goto_0
    iget-object p1, p0, Landroid/support/v7/app/A;->Hc:Landroid/support/v7/app/B;

    iget-object p1, p1, Landroid/support/v7/app/B;->n:Landroid/support/v7/app/I;

    iget-object p1, p1, Landroid/support/v7/app/I;->gj:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {p1}, Landroid/view/ViewGroup;->removeAllViews()V

    iget-object p1, p0, Landroid/support/v7/app/A;->Hc:Landroid/support/v7/app/B;

    iget-object p1, p1, Landroid/support/v7/app/B;->n:Landroid/support/v7/app/I;

    iget-object p1, p1, Landroid/support/v7/app/I;->jj:Landroid/support/v4/view/w;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/support/v4/view/w;->a(Landroid/support/v4/view/x;)Landroid/support/v4/view/w;

    iget-object p0, p0, Landroid/support/v7/app/A;->Hc:Landroid/support/v7/app/B;

    iget-object p0, p0, Landroid/support/v7/app/B;->n:Landroid/support/v7/app/I;

    iput-object v0, p0, Landroid/support/v7/app/I;->jj:Landroid/support/v4/view/w;

    return-void
.end method
