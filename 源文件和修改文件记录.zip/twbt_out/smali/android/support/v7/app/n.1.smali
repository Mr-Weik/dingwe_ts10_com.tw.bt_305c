.class public Landroid/support/v7/app/n;
.super Ljava/lang/Object;
.source ""


# instance fields
.field private final P:Landroid/support/v7/app/j;

.field private final mTheme:I


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 4

    const/4 v0, 0x0

    invoke-static {p1, v0}, Landroid/support/v7/app/o;->resolveDialogTheme(Landroid/content/Context;I)I

    move-result v0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v1, Landroid/support/v7/app/j;

    new-instance v2, Landroid/view/ContextThemeWrapper;

    invoke-static {p1, v0}, Landroid/support/v7/app/o;->resolveDialogTheme(Landroid/content/Context;I)I

    move-result v3

    invoke-direct {v2, p1, v3}, Landroid/view/ContextThemeWrapper;-><init>(Landroid/content/Context;I)V

    invoke-direct {v1, v2}, Landroid/support/v7/app/j;-><init>(Landroid/content/Context;)V

    iput-object v1, p0, Landroid/support/v7/app/n;->P:Landroid/support/v7/app/j;

    iput v0, p0, Landroid/support/v7/app/n;->mTheme:I

    return-void
.end method


# virtual methods
.method public create()Landroid/support/v7/app/o;
    .locals 14

    new-instance v0, Landroid/support/v7/app/o;

    iget-object v1, p0, Landroid/support/v7/app/n;->P:Landroid/support/v7/app/j;

    iget-object v1, v1, Landroid/support/v7/app/j;->mContext:Landroid/content/Context;

    iget v2, p0, Landroid/support/v7/app/n;->mTheme:I

    invoke-direct {v0, v1, v2}, Landroid/support/v7/app/o;-><init>(Landroid/content/Context;I)V

    iget-object v1, p0, Landroid/support/v7/app/n;->P:Landroid/support/v7/app/j;

    iget-object v10, v0, Landroid/support/v7/app/o;->mAlert:Landroid/support/v7/app/m;

    .line 1
    iget-object v2, v1, Landroid/support/v7/app/j;->mCustomTitleView:Landroid/view/View;

    if-eqz v2, :cond_0

    invoke-virtual {v10, v2}, Landroid/support/v7/app/m;->setCustomTitle(Landroid/view/View;)V

    goto :goto_0

    :cond_0
    iget-object v2, v1, Landroid/support/v7/app/j;->mTitle:Ljava/lang/CharSequence;

    if-eqz v2, :cond_1

    invoke-virtual {v10, v2}, Landroid/support/v7/app/m;->setTitle(Ljava/lang/CharSequence;)V

    :cond_1
    iget-object v2, v1, Landroid/support/v7/app/j;->mIcon:Landroid/graphics/drawable/Drawable;

    if-eqz v2, :cond_2

    invoke-virtual {v10, v2}, Landroid/support/v7/app/m;->setIcon(Landroid/graphics/drawable/Drawable;)V

    :cond_2
    iget v2, v1, Landroid/support/v7/app/j;->mIconId:I

    if-eqz v2, :cond_3

    invoke-virtual {v10, v2}, Landroid/support/v7/app/m;->setIcon(I)V

    :cond_3
    iget v2, v1, Landroid/support/v7/app/j;->mIconAttrId:I

    if-eqz v2, :cond_4

    invoke-virtual {v10, v2}, Landroid/support/v7/app/m;->getIconAttributeResId(I)I

    move-result v2

    invoke-virtual {v10, v2}, Landroid/support/v7/app/m;->setIcon(I)V

    :cond_4
    :goto_0
    iget-object v2, v1, Landroid/support/v7/app/j;->mMessage:Ljava/lang/CharSequence;

    if-eqz v2, :cond_5

    invoke-virtual {v10, v2}, Landroid/support/v7/app/m;->setMessage(Ljava/lang/CharSequence;)V

    :cond_5
    iget-object v2, v1, Landroid/support/v7/app/j;->mPositiveButtonText:Ljava/lang/CharSequence;

    if-nez v2, :cond_6

    iget-object v2, v1, Landroid/support/v7/app/j;->Ai:Landroid/graphics/drawable/Drawable;

    if-eqz v2, :cond_7

    :cond_6
    const/4 v3, -0x1

    iget-object v4, v1, Landroid/support/v7/app/j;->mPositiveButtonText:Ljava/lang/CharSequence;

    iget-object v5, v1, Landroid/support/v7/app/j;->mPositiveButtonListener:Landroid/content/DialogInterface$OnClickListener;

    const/4 v6, 0x0

    iget-object v7, v1, Landroid/support/v7/app/j;->Ai:Landroid/graphics/drawable/Drawable;

    move-object v2, v10

    invoke-virtual/range {v2 .. v7}, Landroid/support/v7/app/m;->a(ILjava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;Landroid/os/Message;Landroid/graphics/drawable/Drawable;)V

    :cond_7
    iget-object v2, v1, Landroid/support/v7/app/j;->mNegativeButtonText:Ljava/lang/CharSequence;

    if-nez v2, :cond_8

    iget-object v2, v1, Landroid/support/v7/app/j;->Bi:Landroid/graphics/drawable/Drawable;

    if-eqz v2, :cond_9

    :cond_8
    const/4 v3, -0x2

    iget-object v4, v1, Landroid/support/v7/app/j;->mNegativeButtonText:Ljava/lang/CharSequence;

    iget-object v5, v1, Landroid/support/v7/app/j;->mNegativeButtonListener:Landroid/content/DialogInterface$OnClickListener;

    const/4 v6, 0x0

    iget-object v7, v1, Landroid/support/v7/app/j;->Bi:Landroid/graphics/drawable/Drawable;

    move-object v2, v10

    invoke-virtual/range {v2 .. v7}, Landroid/support/v7/app/m;->a(ILjava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;Landroid/os/Message;Landroid/graphics/drawable/Drawable;)V

    :cond_9
    iget-object v2, v1, Landroid/support/v7/app/j;->mNeutralButtonText:Ljava/lang/CharSequence;

    if-nez v2, :cond_a

    iget-object v2, v1, Landroid/support/v7/app/j;->Ci:Landroid/graphics/drawable/Drawable;

    if-eqz v2, :cond_b

    :cond_a
    const/4 v3, -0x3

    iget-object v4, v1, Landroid/support/v7/app/j;->mNeutralButtonText:Ljava/lang/CharSequence;

    iget-object v5, v1, Landroid/support/v7/app/j;->mNeutralButtonListener:Landroid/content/DialogInterface$OnClickListener;

    const/4 v6, 0x0

    iget-object v7, v1, Landroid/support/v7/app/j;->Ci:Landroid/graphics/drawable/Drawable;

    move-object v2, v10

    invoke-virtual/range {v2 .. v7}, Landroid/support/v7/app/m;->a(ILjava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;Landroid/os/Message;Landroid/graphics/drawable/Drawable;)V

    :cond_b
    iget-object v2, v1, Landroid/support/v7/app/j;->mItems:[Ljava/lang/CharSequence;

    const/4 v11, 0x1

    if-nez v2, :cond_c

    iget-object v2, v1, Landroid/support/v7/app/j;->mCursor:Landroid/database/Cursor;

    if-nez v2, :cond_c

    iget-object v2, v1, Landroid/support/v7/app/j;->mAdapter:Landroid/widget/ListAdapter;

    if-eqz v2, :cond_17

    .line 2
    :cond_c
    iget-object v2, v1, Landroid/support/v7/app/j;->mInflater:Landroid/view/LayoutInflater;

    iget v3, v10, Landroid/support/v7/app/m;->Ui:I

    const/4 v4, 0x0

    invoke-virtual {v2, v3, v4}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/support/v7/app/AlertController$RecycleListView;

    iget-boolean v3, v1, Landroid/support/v7/app/j;->mIsMultiChoice:Z

    if-eqz v3, :cond_e

    iget-object v6, v1, Landroid/support/v7/app/j;->mCursor:Landroid/database/Cursor;

    if-nez v6, :cond_d

    new-instance v12, Landroid/support/v7/app/f;

    iget-object v5, v1, Landroid/support/v7/app/j;->mContext:Landroid/content/Context;

    iget v6, v10, Landroid/support/v7/app/m;->Vi:I

    const v7, 0x1020014

    iget-object v8, v1, Landroid/support/v7/app/j;->mItems:[Ljava/lang/CharSequence;

    move-object v3, v12

    move-object v4, v1

    move-object v9, v2

    invoke-direct/range {v3 .. v9}, Landroid/support/v7/app/f;-><init>(Landroid/support/v7/app/j;Landroid/content/Context;II[Ljava/lang/CharSequence;Landroid/support/v7/app/AlertController$RecycleListView;)V

    goto :goto_2

    :cond_d
    new-instance v12, Landroid/support/v7/app/g;

    iget-object v5, v1, Landroid/support/v7/app/j;->mContext:Landroid/content/Context;

    const/4 v7, 0x0

    move-object v3, v12

    move-object v4, v1

    move-object v8, v2

    move-object v9, v10

    invoke-direct/range {v3 .. v9}, Landroid/support/v7/app/g;-><init>(Landroid/support/v7/app/j;Landroid/content/Context;Landroid/database/Cursor;ZLandroid/support/v7/app/AlertController$RecycleListView;Landroid/support/v7/app/m;)V

    goto :goto_2

    :cond_e
    iget-boolean v3, v1, Landroid/support/v7/app/j;->mIsSingleChoice:Z

    if-eqz v3, :cond_f

    iget v3, v10, Landroid/support/v7/app/m;->Wi:I

    goto :goto_1

    :cond_f
    iget v3, v10, Landroid/support/v7/app/m;->Xi:I

    :goto_1
    move v6, v3

    iget-object v7, v1, Landroid/support/v7/app/j;->mCursor:Landroid/database/Cursor;

    const v3, 0x1020014

    if-eqz v7, :cond_10

    new-instance v12, Landroid/widget/SimpleCursorAdapter;

    iget-object v5, v1, Landroid/support/v7/app/j;->mContext:Landroid/content/Context;

    new-array v8, v11, [Ljava/lang/String;

    iget-object v4, v1, Landroid/support/v7/app/j;->mLabelColumn:Ljava/lang/String;

    const/4 v9, 0x0

    aput-object v4, v8, v9

    new-array v13, v11, [I

    aput v3, v13, v9

    move-object v4, v12

    move-object v9, v13

    invoke-direct/range {v4 .. v9}, Landroid/widget/SimpleCursorAdapter;-><init>(Landroid/content/Context;ILandroid/database/Cursor;[Ljava/lang/String;[I)V

    goto :goto_2

    :cond_10
    iget-object v12, v1, Landroid/support/v7/app/j;->mAdapter:Landroid/widget/ListAdapter;

    if-eqz v12, :cond_11

    goto :goto_2

    :cond_11
    new-instance v12, Landroid/support/v7/app/l;

    iget-object v4, v1, Landroid/support/v7/app/j;->mContext:Landroid/content/Context;

    iget-object v5, v1, Landroid/support/v7/app/j;->mItems:[Ljava/lang/CharSequence;

    invoke-direct {v12, v4, v6, v3, v5}, Landroid/support/v7/app/l;-><init>(Landroid/content/Context;II[Ljava/lang/CharSequence;)V

    :goto_2
    iput-object v12, v10, Landroid/support/v7/app/m;->mAdapter:Landroid/widget/ListAdapter;

    iget v3, v1, Landroid/support/v7/app/j;->mCheckedItem:I

    iput v3, v10, Landroid/support/v7/app/m;->mCheckedItem:I

    iget-object v3, v1, Landroid/support/v7/app/j;->mOnClickListener:Landroid/content/DialogInterface$OnClickListener;

    if-eqz v3, :cond_12

    new-instance v3, Landroid/support/v7/app/h;

    invoke-direct {v3, v1, v10}, Landroid/support/v7/app/h;-><init>(Landroid/support/v7/app/j;Landroid/support/v7/app/m;)V

    goto :goto_3

    :cond_12
    iget-object v3, v1, Landroid/support/v7/app/j;->mOnCheckboxClickListener:Landroid/content/DialogInterface$OnMultiChoiceClickListener;

    if-eqz v3, :cond_13

    new-instance v3, Landroid/support/v7/app/i;

    invoke-direct {v3, v1, v2, v10}, Landroid/support/v7/app/i;-><init>(Landroid/support/v7/app/j;Landroid/support/v7/app/AlertController$RecycleListView;Landroid/support/v7/app/m;)V

    :goto_3
    invoke-virtual {v2, v3}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    :cond_13
    iget-object v3, v1, Landroid/support/v7/app/j;->mOnItemSelectedListener:Landroid/widget/AdapterView$OnItemSelectedListener;

    if-eqz v3, :cond_14

    invoke-virtual {v2, v3}, Landroid/widget/ListView;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    :cond_14
    iget-boolean v3, v1, Landroid/support/v7/app/j;->mIsSingleChoice:Z

    if-eqz v3, :cond_15

    invoke-virtual {v2, v11}, Landroid/widget/ListView;->setChoiceMode(I)V

    goto :goto_4

    :cond_15
    iget-boolean v3, v1, Landroid/support/v7/app/j;->mIsMultiChoice:Z

    if-eqz v3, :cond_16

    const/4 v3, 0x2

    invoke-virtual {v2, v3}, Landroid/widget/ListView;->setChoiceMode(I)V

    :cond_16
    :goto_4
    iput-object v2, v10, Landroid/support/v7/app/m;->mListView:Landroid/widget/ListView;

    .line 3
    :cond_17
    iget-object v3, v1, Landroid/support/v7/app/j;->mView:Landroid/view/View;

    if-eqz v3, :cond_19

    iget-boolean v2, v1, Landroid/support/v7/app/j;->mViewSpacingSpecified:Z

    if-eqz v2, :cond_18

    iget v4, v1, Landroid/support/v7/app/j;->mViewSpacingLeft:I

    iget v5, v1, Landroid/support/v7/app/j;->mViewSpacingTop:I

    iget v6, v1, Landroid/support/v7/app/j;->mViewSpacingRight:I

    iget v7, v1, Landroid/support/v7/app/j;->mViewSpacingBottom:I

    move-object v2, v10

    invoke-virtual/range {v2 .. v7}, Landroid/support/v7/app/m;->setView(Landroid/view/View;IIII)V

    goto :goto_5

    :cond_18
    invoke-virtual {v10, v3}, Landroid/support/v7/app/m;->setView(Landroid/view/View;)V

    goto :goto_5

    :cond_19
    iget v1, v1, Landroid/support/v7/app/j;->mViewLayoutResId:I

    if-eqz v1, :cond_1a

    invoke-virtual {v10, v1}, Landroid/support/v7/app/m;->setView(I)V

    .line 4
    :cond_1a
    :goto_5
    iget-object v1, p0, Landroid/support/v7/app/n;->P:Landroid/support/v7/app/j;

    iget-boolean v1, v1, Landroid/support/v7/app/j;->mCancelable:Z

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->setCancelable(Z)V

    iget-object v1, p0, Landroid/support/v7/app/n;->P:Landroid/support/v7/app/j;

    iget-boolean v1, v1, Landroid/support/v7/app/j;->mCancelable:Z

    if-eqz v1, :cond_1b

    invoke-virtual {v0, v11}, Landroid/app/Dialog;->setCanceledOnTouchOutside(Z)V

    :cond_1b
    iget-object v1, p0, Landroid/support/v7/app/n;->P:Landroid/support/v7/app/j;

    iget-object v1, v1, Landroid/support/v7/app/j;->mOnCancelListener:Landroid/content/DialogInterface$OnCancelListener;

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->setOnCancelListener(Landroid/content/DialogInterface$OnCancelListener;)V

    iget-object v1, p0, Landroid/support/v7/app/n;->P:Landroid/support/v7/app/j;

    iget-object v1, v1, Landroid/support/v7/app/j;->mOnDismissListener:Landroid/content/DialogInterface$OnDismissListener;

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)V

    iget-object p0, p0, Landroid/support/v7/app/n;->P:Landroid/support/v7/app/j;

    iget-object p0, p0, Landroid/support/v7/app/j;->mOnKeyListener:Landroid/content/DialogInterface$OnKeyListener;

    if-eqz p0, :cond_1c

    invoke-virtual {v0, p0}, Landroid/app/Dialog;->setOnKeyListener(Landroid/content/DialogInterface$OnKeyListener;)V

    :cond_1c
    return-object v0
.end method

.method public getContext()Landroid/content/Context;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/app/n;->P:Landroid/support/v7/app/j;

    iget-object p0, p0, Landroid/support/v7/app/j;->mContext:Landroid/content/Context;

    return-object p0
.end method

.method public setAdapter(Landroid/widget/ListAdapter;Landroid/content/DialogInterface$OnClickListener;)Landroid/support/v7/app/n;
    .locals 1

    iget-object v0, p0, Landroid/support/v7/app/n;->P:Landroid/support/v7/app/j;

    iput-object p1, v0, Landroid/support/v7/app/j;->mAdapter:Landroid/widget/ListAdapter;

    iput-object p2, v0, Landroid/support/v7/app/j;->mOnClickListener:Landroid/content/DialogInterface$OnClickListener;

    return-object p0
.end method

.method public setCustomTitle(Landroid/view/View;)Landroid/support/v7/app/n;
    .locals 1

    iget-object v0, p0, Landroid/support/v7/app/n;->P:Landroid/support/v7/app/j;

    iput-object p1, v0, Landroid/support/v7/app/j;->mCustomTitleView:Landroid/view/View;

    return-object p0
.end method

.method public setIcon(Landroid/graphics/drawable/Drawable;)Landroid/support/v7/app/n;
    .locals 1

    iget-object v0, p0, Landroid/support/v7/app/n;->P:Landroid/support/v7/app/j;

    iput-object p1, v0, Landroid/support/v7/app/j;->mIcon:Landroid/graphics/drawable/Drawable;

    return-object p0
.end method

.method public setOnKeyListener(Landroid/content/DialogInterface$OnKeyListener;)Landroid/support/v7/app/n;
    .locals 1

    iget-object v0, p0, Landroid/support/v7/app/n;->P:Landroid/support/v7/app/j;

    iput-object p1, v0, Landroid/support/v7/app/j;->mOnKeyListener:Landroid/content/DialogInterface$OnKeyListener;

    return-object p0
.end method

.method public setTitle(Ljava/lang/CharSequence;)Landroid/support/v7/app/n;
    .locals 1

    iget-object v0, p0, Landroid/support/v7/app/n;->P:Landroid/support/v7/app/j;

    iput-object p1, v0, Landroid/support/v7/app/j;->mTitle:Ljava/lang/CharSequence;

    return-object p0
.end method
