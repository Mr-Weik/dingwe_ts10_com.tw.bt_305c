.class Landroid/support/v7/app/i;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/widget/AdapterView$OnItemClickListener;


# instance fields
.field final synthetic n:Landroid/support/v7/app/j;

.field final synthetic yi:Landroid/support/v7/app/m;

.field final synthetic zi:Landroid/support/v7/app/AlertController$RecycleListView;


# direct methods
.method constructor <init>(Landroid/support/v7/app/j;Landroid/support/v7/app/AlertController$RecycleListView;Landroid/support/v7/app/m;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/app/i;->n:Landroid/support/v7/app/j;

    iput-object p2, p0, Landroid/support/v7/app/i;->zi:Landroid/support/v7/app/AlertController$RecycleListView;

    iput-object p3, p0, Landroid/support/v7/app/i;->yi:Landroid/support/v7/app/m;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 0

    iget-object p1, p0, Landroid/support/v7/app/i;->n:Landroid/support/v7/app/j;

    iget-object p1, p1, Landroid/support/v7/app/j;->mCheckedItems:[Z

    if-eqz p1, :cond_0

    iget-object p2, p0, Landroid/support/v7/app/i;->zi:Landroid/support/v7/app/AlertController$RecycleListView;

    invoke-virtual {p2, p3}, Landroid/widget/ListView;->isItemChecked(I)Z

    move-result p2

    aput-boolean p2, p1, p3

    :cond_0
    iget-object p1, p0, Landroid/support/v7/app/i;->n:Landroid/support/v7/app/j;

    iget-object p1, p1, Landroid/support/v7/app/j;->mOnCheckboxClickListener:Landroid/content/DialogInterface$OnMultiChoiceClickListener;

    iget-object p2, p0, Landroid/support/v7/app/i;->yi:Landroid/support/v7/app/m;

    iget-object p2, p2, Landroid/support/v7/app/m;->mDialog:Landroid/support/v7/app/J;

    iget-object p0, p0, Landroid/support/v7/app/i;->zi:Landroid/support/v7/app/AlertController$RecycleListView;

    invoke-virtual {p0, p3}, Landroid/widget/ListView;->isItemChecked(I)Z

    move-result p0

    invoke-interface {p1, p2, p3, p0}, Landroid/content/DialogInterface$OnMultiChoiceClickListener;->onClick(Landroid/content/DialogInterface;IZ)V

    return-void
.end method
