.class Landroid/support/v7/app/t;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic n:Landroid/support/v7/app/I;


# direct methods
.method constructor <init>(Landroid/support/v7/app/I;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/app/t;->n:Landroid/support/v7/app/I;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    iget-object v0, p0, Landroid/support/v7/app/t;->n:Landroid/support/v7/app/I;

    iget v1, v0, Landroid/support/v7/app/I;->Cj:I

    and-int/lit8 v1, v1, 0x1

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    invoke-virtual {v0, v2}, Landroid/support/v7/app/I;->doInvalidatePanelMenu(I)V

    :cond_0
    iget-object v0, p0, Landroid/support/v7/app/t;->n:Landroid/support/v7/app/I;

    iget v1, v0, Landroid/support/v7/app/I;->Cj:I

    and-int/lit16 v1, v1, 0x1000

    if-eqz v1, :cond_1

    const/16 v1, 0x6c

    invoke-virtual {v0, v1}, Landroid/support/v7/app/I;->doInvalidatePanelMenu(I)V

    :cond_1
    iget-object p0, p0, Landroid/support/v7/app/t;->n:Landroid/support/v7/app/I;

    iput-boolean v2, p0, Landroid/support/v7/app/I;->Bj:Z

    iput v2, p0, Landroid/support/v7/app/I;->Cj:I

    return-void
.end method
