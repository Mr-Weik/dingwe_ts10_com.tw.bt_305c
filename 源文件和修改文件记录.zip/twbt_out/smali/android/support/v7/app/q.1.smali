.class public interface abstract Landroid/support/v7/app/q;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract a(La/b/d/e/b;)La/b/d/e/c;
.end method

.method public abstract a(La/b/d/e/c;)V
.end method

.method public abstract b(La/b/d/e/c;)V
.end method
