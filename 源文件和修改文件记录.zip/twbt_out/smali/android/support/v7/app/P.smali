.class Landroid/support/v7/app/P;
.super Landroid/support/v4/view/y;
.source ""


# instance fields
.field final synthetic n:Landroid/support/v7/app/T;


# direct methods
.method constructor <init>(Landroid/support/v7/app/T;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/app/P;->n:Landroid/support/v7/app/T;

    invoke-direct {p0}, Landroid/support/v4/view/y;-><init>()V

    return-void
.end method


# virtual methods
.method public d(Landroid/view/View;)V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/app/P;->n:Landroid/support/v7/app/T;

    const/4 p1, 0x0

    iput-object p1, p0, Landroid/support/v7/app/T;->ui:La/b/d/e/m;

    iget-object p0, p0, Landroid/support/v7/app/T;->fi:Landroid/support/v7/widget/ActionBarContainer;

    invoke-virtual {p0}, Landroid/widget/FrameLayout;->requestLayout()V

    return-void
.end method
