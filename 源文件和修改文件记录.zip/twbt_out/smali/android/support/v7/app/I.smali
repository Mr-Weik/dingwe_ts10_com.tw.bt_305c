.class Landroid/support/v7/app/I;
.super Landroid/support/v7/app/r;
.source ""

# interfaces
.implements Landroid/support/v7/view/menu/p;
.implements Landroid/view/LayoutInflater$Factory2;


# static fields
.field private static final Ij:Z

.field private static final Jj:[I

.field private static Kj:Z


# instance fields
.field private Aj:Landroid/support/v7/app/AppCompatDelegateImpl$AutoNightModeManager;

.field Bj:Z

.field Cj:I

.field private final Dj:Ljava/lang/Runnable;

.field private Ej:Z

.field private Fj:Landroid/graphics/Rect;

.field private Gj:Landroid/graphics/Rect;

.field private Hj:Landroid/support/v7/app/AppCompatViewInflater;

.field private Ri:Landroid/widget/TextView;

.field final aj:Landroid/view/Window$Callback;

.field final bj:Landroid/view/Window$Callback;

.field final cj:Landroid/support/v7/app/q;

.field dj:Landroid/view/MenuInflater;

.field private ej:Landroid/support/v7/app/z;

.field private fj:Landroid/support/v7/app/H;

.field gj:Landroid/support/v7/widget/ActionBarContextView;

.field hj:Landroid/widget/PopupWindow;

.field ij:Ljava/lang/Runnable;

.field jj:Landroid/support/v4/view/w;

.field private kj:Z

.field private lj:Z

.field mActionBar:Landroid/support/v7/app/c;

.field mActionMode:La/b/d/e/c;

.field final mContext:Landroid/content/Context;

.field private mDecorContentParent:Landroid/support/v7/widget/ga;

.field mIsFloating:Z

.field private mPreparedPanel:Landroid/support/v7/app/G;

.field private mTitle:Ljava/lang/CharSequence;

.field final mWindow:Landroid/view/Window;

.field private mj:Landroid/view/ViewGroup;

.field private nj:Landroid/view/View;

.field private oj:Z

.field private pj:Z

.field qj:Z

.field rj:Z

.field sj:Z

.field tj:Z

.field private uj:Z

.field private vj:[Landroid/support/v7/app/G;

.field private wj:Z

.field private xj:Z

.field private yj:I

.field private zj:Z


# direct methods
.method static constructor <clinit>()V
    .locals 4

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v0, 0x0

    sput-boolean v0, Landroid/support/v7/app/I;->Ij:Z

    const/4 v1, 0x1

    new-array v2, v1, [I

    const v3, 0x1010054

    aput v3, v2, v0

    sput-object v2, Landroid/support/v7/app/I;->Jj:[I

    sget-boolean v0, Landroid/support/v7/app/I;->Ij:Z

    if-eqz v0, :cond_0

    sget-boolean v0, Landroid/support/v7/app/I;->Kj:Z

    if-nez v0, :cond_0

    invoke-static {}, Ljava/lang/Thread;->getDefaultUncaughtExceptionHandler()Ljava/lang/Thread$UncaughtExceptionHandler;

    move-result-object v0

    new-instance v2, Landroid/support/v7/app/s;

    invoke-direct {v2, v0}, Landroid/support/v7/app/s;-><init>(Ljava/lang/Thread$UncaughtExceptionHandler;)V

    invoke-static {v2}, Ljava/lang/Thread;->setDefaultUncaughtExceptionHandler(Ljava/lang/Thread$UncaughtExceptionHandler;)V

    sput-boolean v1, Landroid/support/v7/app/I;->Kj:Z

    :cond_0
    return-void
.end method

.method constructor <init>(Landroid/content/Context;Landroid/view/Window;Landroid/support/v7/app/q;)V
    .locals 2

    invoke-direct {p0}, Landroid/support/v7/app/r;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, Landroid/support/v7/app/I;->jj:Landroid/support/v4/view/w;

    const/4 v1, 0x1

    iput-boolean v1, p0, Landroid/support/v7/app/I;->kj:Z

    const/16 v1, -0x64

    iput v1, p0, Landroid/support/v7/app/I;->yj:I

    new-instance v1, Landroid/support/v7/app/t;

    invoke-direct {v1, p0}, Landroid/support/v7/app/t;-><init>(Landroid/support/v7/app/I;)V

    iput-object v1, p0, Landroid/support/v7/app/I;->Dj:Ljava/lang/Runnable;

    iput-object p1, p0, Landroid/support/v7/app/I;->mContext:Landroid/content/Context;

    iput-object p2, p0, Landroid/support/v7/app/I;->mWindow:Landroid/view/Window;

    iput-object p3, p0, Landroid/support/v7/app/I;->cj:Landroid/support/v7/app/q;

    iget-object p2, p0, Landroid/support/v7/app/I;->mWindow:Landroid/view/Window;

    invoke-virtual {p2}, Landroid/view/Window;->getCallback()Landroid/view/Window$Callback;

    move-result-object p2

    iput-object p2, p0, Landroid/support/v7/app/I;->aj:Landroid/view/Window$Callback;

    iget-object p2, p0, Landroid/support/v7/app/I;->aj:Landroid/view/Window$Callback;

    instance-of p3, p2, Landroid/support/v7/app/C;

    if-nez p3, :cond_1

    new-instance p3, Landroid/support/v7/app/C;

    invoke-direct {p3, p0, p2}, Landroid/support/v7/app/C;-><init>(Landroid/support/v7/app/I;Landroid/view/Window$Callback;)V

    iput-object p3, p0, Landroid/support/v7/app/I;->bj:Landroid/view/Window$Callback;

    iget-object p2, p0, Landroid/support/v7/app/I;->mWindow:Landroid/view/Window;

    iget-object p3, p0, Landroid/support/v7/app/I;->bj:Landroid/view/Window$Callback;

    invoke-virtual {p2, p3}, Landroid/view/Window;->setCallback(Landroid/view/Window$Callback;)V

    sget-object p2, Landroid/support/v7/app/I;->Jj:[I

    invoke-static {p1, v0, p2}, Landroid/support/v7/widget/hc;->a(Landroid/content/Context;Landroid/util/AttributeSet;[I)Landroid/support/v7/widget/hc;

    move-result-object p1

    const/4 p2, 0x0

    invoke-virtual {p1, p2}, Landroid/support/v7/widget/hc;->ia(I)Landroid/graphics/drawable/Drawable;

    move-result-object p2

    if-eqz p2, :cond_0

    iget-object p0, p0, Landroid/support/v7/app/I;->mWindow:Landroid/view/Window;

    invoke-virtual {p0, p2}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    invoke-virtual {p1}, Landroid/support/v7/widget/hc;->recycle()V

    return-void

    :cond_1
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "AppCompat has already installed itself into the Window"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private Xf()V
    .locals 2

    iget-object v0, p0, Landroid/support/v7/app/I;->Aj:Landroid/support/v7/app/AppCompatDelegateImpl$AutoNightModeManager;

    if-nez v0, :cond_0

    new-instance v0, Landroid/support/v7/app/AppCompatDelegateImpl$AutoNightModeManager;

    iget-object v1, p0, Landroid/support/v7/app/I;->mContext:Landroid/content/Context;

    invoke-static {v1}, Landroid/support/v7/app/N;->getInstance(Landroid/content/Context;)Landroid/support/v7/app/N;

    move-result-object v1

    invoke-direct {v0, p0, v1}, Landroid/support/v7/app/AppCompatDelegateImpl$AutoNightModeManager;-><init>(Landroid/support/v7/app/I;Landroid/support/v7/app/N;)V

    iput-object v0, p0, Landroid/support/v7/app/I;->Aj:Landroid/support/v7/app/AppCompatDelegateImpl$AutoNightModeManager;

    :cond_0
    return-void
.end method

.method private Yf()V
    .locals 9

    iget-boolean v0, p0, Landroid/support/v7/app/I;->lj:Z

    if-nez v0, :cond_19

    .line 1
    iget-object v0, p0, Landroid/support/v7/app/I;->mContext:Landroid/content/Context;

    sget-object v1, La/b/d/a/b;->nk:[I

    invoke-virtual {v0, v1}, Landroid/content/Context;->obtainStyledAttributes([I)Landroid/content/res/TypedArray;

    move-result-object v0

    const/16 v1, 0x6f

    invoke-virtual {v0, v1}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v2

    if-eqz v2, :cond_18

    const/16 v2, 0x78

    const/4 v3, 0x0

    invoke-virtual {v0, v2, v3}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v2

    const/16 v4, 0x6c

    const/4 v5, 0x1

    if-eqz v2, :cond_0

    invoke-virtual {p0, v5}, Landroid/support/v7/app/I;->requestWindowFeature(I)Z

    goto :goto_0

    :cond_0
    invoke-virtual {v0, v1, v3}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-virtual {p0, v4}, Landroid/support/v7/app/I;->requestWindowFeature(I)Z

    :cond_1
    :goto_0
    const/16 v1, 0x70

    invoke-virtual {v0, v1, v3}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v1

    const/16 v2, 0x6d

    if-eqz v1, :cond_2

    invoke-virtual {p0, v2}, Landroid/support/v7/app/I;->requestWindowFeature(I)Z

    :cond_2
    const/16 v1, 0x71

    invoke-virtual {v0, v1, v3}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v1

    if-eqz v1, :cond_3

    const/16 v1, 0xa

    invoke-virtual {p0, v1}, Landroid/support/v7/app/I;->requestWindowFeature(I)Z

    :cond_3
    sget v1, La/b/d/a/b;->pk:I

    invoke-virtual {v0, v1, v3}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v1

    iput-boolean v1, p0, Landroid/support/v7/app/I;->mIsFloating:Z

    invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V

    iget-object v0, p0, Landroid/support/v7/app/I;->mWindow:Landroid/view/Window;

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    iget-object v0, p0, Landroid/support/v7/app/I;->mContext:Landroid/content/Context;

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    iget-boolean v1, p0, Landroid/support/v7/app/I;->tj:Z

    const/4 v6, 0x0

    if-nez v1, :cond_9

    iget-boolean v1, p0, Landroid/support/v7/app/I;->mIsFloating:Z

    if-eqz v1, :cond_4

    const v1, 0x7f0a000c

    invoke-virtual {v0, v1, v6}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/view/ViewGroup;

    iput-boolean v3, p0, Landroid/support/v7/app/I;->rj:Z

    iput-boolean v3, p0, Landroid/support/v7/app/I;->qj:Z

    goto/16 :goto_3

    :cond_4
    iget-boolean v0, p0, Landroid/support/v7/app/I;->qj:Z

    if-eqz v0, :cond_8

    new-instance v0, Landroid/util/TypedValue;

    invoke-direct {v0}, Landroid/util/TypedValue;-><init>()V

    iget-object v1, p0, Landroid/support/v7/app/I;->mContext:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v1

    const v7, 0x7f030009

    invoke-virtual {v1, v7, v0, v5}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    iget v0, v0, Landroid/util/TypedValue;->resourceId:I

    if-eqz v0, :cond_5

    new-instance v1, La/b/d/e/e;

    iget-object v7, p0, Landroid/support/v7/app/I;->mContext:Landroid/content/Context;

    invoke-direct {v1, v7, v0}, La/b/d/e/e;-><init>(Landroid/content/Context;I)V

    goto :goto_1

    :cond_5
    iget-object v1, p0, Landroid/support/v7/app/I;->mContext:Landroid/content/Context;

    :goto_1
    invoke-static {v1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    const v1, 0x7f0a0017

    invoke-virtual {v0, v1, v6}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/view/ViewGroup;

    const v1, 0x7f08003b

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/support/v7/widget/ga;

    iput-object v1, p0, Landroid/support/v7/app/I;->mDecorContentParent:Landroid/support/v7/widget/ga;

    iget-object v1, p0, Landroid/support/v7/app/I;->mDecorContentParent:Landroid/support/v7/widget/ga;

    invoke-virtual {p0}, Landroid/support/v7/app/I;->La()Landroid/view/Window$Callback;

    move-result-object v7

    invoke-interface {v1, v7}, Landroid/support/v7/widget/ga;->setWindowCallback(Landroid/view/Window$Callback;)V

    iget-boolean v1, p0, Landroid/support/v7/app/I;->rj:Z

    if-eqz v1, :cond_6

    iget-object v1, p0, Landroid/support/v7/app/I;->mDecorContentParent:Landroid/support/v7/widget/ga;

    invoke-interface {v1, v2}, Landroid/support/v7/widget/ga;->initFeature(I)V

    :cond_6
    iget-boolean v1, p0, Landroid/support/v7/app/I;->oj:Z

    if-eqz v1, :cond_7

    iget-object v1, p0, Landroid/support/v7/app/I;->mDecorContentParent:Landroid/support/v7/widget/ga;

    const/4 v2, 0x2

    invoke-interface {v1, v2}, Landroid/support/v7/widget/ga;->initFeature(I)V

    :cond_7
    iget-boolean v1, p0, Landroid/support/v7/app/I;->pj:Z

    if-eqz v1, :cond_b

    iget-object v1, p0, Landroid/support/v7/app/I;->mDecorContentParent:Landroid/support/v7/widget/ga;

    const/4 v2, 0x5

    invoke-interface {v1, v2}, Landroid/support/v7/widget/ga;->initFeature(I)V

    goto :goto_3

    :cond_8
    move-object v0, v6

    goto :goto_3

    :cond_9
    iget-boolean v1, p0, Landroid/support/v7/app/I;->sj:Z

    if-eqz v1, :cond_a

    const v1, 0x7f0a0016

    goto :goto_2

    :cond_a
    const v1, 0x7f0a0015

    :goto_2
    invoke-virtual {v0, v1, v6}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/view/ViewGroup;

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    new-instance v1, Landroid/support/v7/app/u;

    invoke-direct {v1, p0}, Landroid/support/v7/app/u;-><init>(Landroid/support/v7/app/I;)V

    invoke-static {v0, v1}, Landroid/support/v4/view/r;->a(Landroid/view/View;Landroid/support/v4/view/n;)V

    :cond_b
    :goto_3
    if-eqz v0, :cond_17

    iget-object v1, p0, Landroid/support/v7/app/I;->mDecorContentParent:Landroid/support/v7/widget/ga;

    if-nez v1, :cond_c

    const v1, 0x7f0800ff

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Landroid/support/v7/app/I;->Ri:Landroid/widget/TextView;

    :cond_c
    invoke-static {v0}, Landroid/support/v7/widget/yc;->G(Landroid/view/View;)V

    const v1, 0x7f080008

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/support/v7/widget/ContentFrameLayout;

    iget-object v2, p0, Landroid/support/v7/app/I;->mWindow:Landroid/view/Window;

    const v7, 0x1020002

    invoke-virtual {v2, v7}, Landroid/view/Window;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/view/ViewGroup;

    if-eqz v2, :cond_e

    :goto_4
    invoke-virtual {v2}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v8

    if-lez v8, :cond_d

    invoke-virtual {v2, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v8

    invoke-virtual {v2, v3}, Landroid/view/ViewGroup;->removeViewAt(I)V

    invoke-virtual {v1, v8}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;)V

    goto :goto_4

    :cond_d
    const/4 v8, -0x1

    invoke-virtual {v2, v8}, Landroid/view/ViewGroup;->setId(I)V

    invoke-virtual {v1, v7}, Landroid/widget/FrameLayout;->setId(I)V

    instance-of v8, v2, Landroid/widget/FrameLayout;

    if-eqz v8, :cond_e

    check-cast v2, Landroid/widget/FrameLayout;

    invoke-virtual {v2, v6}, Landroid/widget/FrameLayout;->setForeground(Landroid/graphics/drawable/Drawable;)V

    :cond_e
    iget-object v2, p0, Landroid/support/v7/app/I;->mWindow:Landroid/view/Window;

    invoke-virtual {v2, v0}, Landroid/view/Window;->setContentView(Landroid/view/View;)V

    new-instance v2, Landroid/support/v7/app/v;

    invoke-direct {v2, p0}, Landroid/support/v7/app/v;-><init>(Landroid/support/v7/app/I;)V

    invoke-virtual {v1, v2}, Landroid/support/v7/widget/ContentFrameLayout;->a(Landroid/support/v7/widget/fa;)V

    .line 2
    iput-object v0, p0, Landroid/support/v7/app/I;->mj:Landroid/view/ViewGroup;

    invoke-virtual {p0}, Landroid/support/v7/app/I;->getTitle()Ljava/lang/CharSequence;

    move-result-object v0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_11

    iget-object v1, p0, Landroid/support/v7/app/I;->mDecorContentParent:Landroid/support/v7/widget/ga;

    if-eqz v1, :cond_f

    invoke-interface {v1, v0}, Landroid/support/v7/widget/ga;->setWindowTitle(Ljava/lang/CharSequence;)V

    goto :goto_5

    :cond_f
    invoke-virtual {p0}, Landroid/support/v7/app/I;->Na()Landroid/support/v7/app/c;

    move-result-object v1

    if-eqz v1, :cond_10

    invoke-virtual {p0}, Landroid/support/v7/app/I;->Na()Landroid/support/v7/app/c;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/support/v7/app/c;->setWindowTitle(Ljava/lang/CharSequence;)V

    goto :goto_5

    :cond_10
    iget-object v1, p0, Landroid/support/v7/app/I;->Ri:Landroid/widget/TextView;

    if-eqz v1, :cond_11

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3
    :cond_11
    :goto_5
    iget-object v0, p0, Landroid/support/v7/app/I;->mj:Landroid/view/ViewGroup;

    invoke-virtual {v0, v7}, Landroid/view/ViewGroup;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/support/v7/widget/ContentFrameLayout;

    iget-object v1, p0, Landroid/support/v7/app/I;->mWindow:Landroid/view/Window;

    invoke-virtual {v1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/View;->getPaddingLeft()I

    move-result v2

    invoke-virtual {v1}, Landroid/view/View;->getPaddingTop()I

    move-result v6

    invoke-virtual {v1}, Landroid/view/View;->getPaddingRight()I

    move-result v7

    invoke-virtual {v1}, Landroid/view/View;->getPaddingBottom()I

    move-result v1

    invoke-virtual {v0, v2, v6, v7, v1}, Landroid/support/v7/widget/ContentFrameLayout;->b(IIII)V

    iget-object v1, p0, Landroid/support/v7/app/I;->mContext:Landroid/content/Context;

    sget-object v2, La/b/d/a/b;->nk:[I

    invoke-virtual {v1, v2}, Landroid/content/Context;->obtainStyledAttributes([I)Landroid/content/res/TypedArray;

    move-result-object v1

    invoke-virtual {v0}, Landroid/support/v7/widget/ContentFrameLayout;->Jb()Landroid/util/TypedValue;

    move-result-object v2

    const/16 v6, 0x76

    invoke-virtual {v1, v6, v2}, Landroid/content/res/TypedArray;->getValue(ILandroid/util/TypedValue;)Z

    invoke-virtual {v0}, Landroid/support/v7/widget/ContentFrameLayout;->Kb()Landroid/util/TypedValue;

    move-result-object v2

    const/16 v6, 0x77

    invoke-virtual {v1, v6, v2}, Landroid/content/res/TypedArray;->getValue(ILandroid/util/TypedValue;)Z

    const/16 v2, 0x74

    invoke-virtual {v1, v2}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v6

    if-eqz v6, :cond_12

    invoke-virtual {v0}, Landroid/support/v7/widget/ContentFrameLayout;->Hb()Landroid/util/TypedValue;

    move-result-object v6

    invoke-virtual {v1, v2, v6}, Landroid/content/res/TypedArray;->getValue(ILandroid/util/TypedValue;)Z

    :cond_12
    const/16 v2, 0x75

    invoke-virtual {v1, v2}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v6

    if-eqz v6, :cond_13

    invoke-virtual {v0}, Landroid/support/v7/widget/ContentFrameLayout;->Ib()Landroid/util/TypedValue;

    move-result-object v6

    invoke-virtual {v1, v2, v6}, Landroid/content/res/TypedArray;->getValue(ILandroid/util/TypedValue;)Z

    :cond_13
    const/16 v2, 0x72

    invoke-virtual {v1, v2}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v6

    if-eqz v6, :cond_14

    invoke-virtual {v0}, Landroid/support/v7/widget/ContentFrameLayout;->Fb()Landroid/util/TypedValue;

    move-result-object v6

    invoke-virtual {v1, v2, v6}, Landroid/content/res/TypedArray;->getValue(ILandroid/util/TypedValue;)Z

    :cond_14
    const/16 v2, 0x73

    invoke-virtual {v1, v2}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v6

    if-eqz v6, :cond_15

    invoke-virtual {v0}, Landroid/support/v7/widget/ContentFrameLayout;->Gb()Landroid/util/TypedValue;

    move-result-object v6

    invoke-virtual {v1, v2, v6}, Landroid/content/res/TypedArray;->getValue(ILandroid/util/TypedValue;)Z

    :cond_15
    invoke-virtual {v1}, Landroid/content/res/TypedArray;->recycle()V

    invoke-virtual {v0}, Landroid/widget/FrameLayout;->requestLayout()V

    .line 4
    iget-object v0, p0, Landroid/support/v7/app/I;->mj:Landroid/view/ViewGroup;

    invoke-virtual {p0, v0}, Landroid/support/v7/app/I;->a(Landroid/view/ViewGroup;)V

    iput-boolean v5, p0, Landroid/support/v7/app/I;->lj:Z

    invoke-virtual {p0, v3, v3}, Landroid/support/v7/app/I;->getPanelState(IZ)Landroid/support/v7/app/G;

    move-result-object v0

    iget-boolean v1, p0, Landroid/support/v7/app/I;->xj:Z

    if-nez v1, :cond_19

    if-eqz v0, :cond_16

    iget-object v0, v0, Landroid/support/v7/app/G;->menu:Landroid/support/v7/view/menu/r;

    if-nez v0, :cond_19

    :cond_16
    invoke-direct {p0, v4}, Landroid/support/v7/app/I;->invalidatePanelMenu(I)V

    goto :goto_6

    .line 5
    :cond_17
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "AppCompat does not support the current theme features: { windowActionBar: "

    invoke-static {v1}, Lb/a/a/a/a;->x(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-boolean v2, p0, Landroid/support/v7/app/I;->qj:Z

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v2, ", windowActionBarOverlay: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v2, p0, Landroid/support/v7/app/I;->rj:Z

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v2, ", android:windowIsFloating: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v2, p0, Landroid/support/v7/app/I;->mIsFloating:Z

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v2, ", windowActionModeOverlay: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v2, p0, Landroid/support/v7/app/I;->sj:Z

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v2, ", windowNoTitle: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean p0, p0, Landroid/support/v7/app/I;->tj:Z

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string p0, " }"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_18
    invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V

    new-instance p0, Ljava/lang/IllegalStateException;

    const-string v0, "You need to use a Theme.AppCompat theme (or descendant) with this activity."

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_19
    :goto_6
    return-void
.end method

.method private Zf()V
    .locals 3

    invoke-direct {p0}, Landroid/support/v7/app/I;->Yf()V

    iget-boolean v0, p0, Landroid/support/v7/app/I;->qj:Z

    if-eqz v0, :cond_3

    iget-object v0, p0, Landroid/support/v7/app/I;->mActionBar:Landroid/support/v7/app/c;

    if-eqz v0, :cond_0

    goto :goto_2

    :cond_0
    iget-object v0, p0, Landroid/support/v7/app/I;->aj:Landroid/view/Window$Callback;

    instance-of v1, v0, Landroid/app/Activity;

    if-eqz v1, :cond_1

    new-instance v1, Landroid/support/v7/app/T;

    check-cast v0, Landroid/app/Activity;

    iget-boolean v2, p0, Landroid/support/v7/app/I;->rj:Z

    invoke-direct {v1, v0, v2}, Landroid/support/v7/app/T;-><init>(Landroid/app/Activity;Z)V

    :goto_0
    iput-object v1, p0, Landroid/support/v7/app/I;->mActionBar:Landroid/support/v7/app/c;

    goto :goto_1

    :cond_1
    instance-of v1, v0, Landroid/app/Dialog;

    if-eqz v1, :cond_2

    new-instance v1, Landroid/support/v7/app/T;

    check-cast v0, Landroid/app/Dialog;

    invoke-direct {v1, v0}, Landroid/support/v7/app/T;-><init>(Landroid/app/Dialog;)V

    goto :goto_0

    :cond_2
    :goto_1
    iget-object v0, p0, Landroid/support/v7/app/I;->mActionBar:Landroid/support/v7/app/c;

    if-eqz v0, :cond_3

    iget-boolean p0, p0, Landroid/support/v7/app/I;->Ej:Z

    invoke-virtual {v0, p0}, Landroid/support/v7/app/c;->setDefaultDisplayHomeAsUpEnabled(Z)V

    :cond_3
    :goto_2
    return-void
.end method

.method private _f()V
    .locals 1

    iget-boolean p0, p0, Landroid/support/v7/app/I;->lj:Z

    if-nez p0, :cond_0

    return-void

    :cond_0
    new-instance p0, Landroid/util/AndroidRuntimeException;

    const-string v0, "Window feature must be requested before adding content"

    invoke-direct {p0, v0}, Landroid/util/AndroidRuntimeException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private a(Landroid/support/v7/app/G;Landroid/view/KeyEvent;)V
    .locals 13

    iget-boolean v0, p1, Landroid/support/v7/app/G;->isOpen:Z

    if-nez v0, :cond_17

    iget-boolean v0, p0, Landroid/support/v7/app/I;->xj:Z

    if-eqz v0, :cond_0

    goto/16 :goto_a

    :cond_0
    iget v0, p1, Landroid/support/v7/app/G;->featureId:I

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-nez v0, :cond_2

    iget-object v0, p0, Landroid/support/v7/app/I;->mContext:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v0

    iget v0, v0, Landroid/content/res/Configuration;->screenLayout:I

    and-int/lit8 v0, v0, 0xf

    const/4 v3, 0x4

    if-ne v0, v3, :cond_1

    move v0, v2

    goto :goto_0

    :cond_1
    move v0, v1

    :goto_0
    if-eqz v0, :cond_2

    return-void

    :cond_2
    invoke-virtual {p0}, Landroid/support/v7/app/I;->La()Landroid/view/Window$Callback;

    move-result-object v0

    if-eqz v0, :cond_3

    iget v3, p1, Landroid/support/v7/app/G;->featureId:I

    iget-object v4, p1, Landroid/support/v7/app/G;->menu:Landroid/support/v7/view/menu/r;

    invoke-interface {v0, v3, v4}, Landroid/view/Window$Callback;->onMenuOpened(ILandroid/view/Menu;)Z

    move-result v0

    if-nez v0, :cond_3

    invoke-virtual {p0, p1, v2}, Landroid/support/v7/app/I;->a(Landroid/support/v7/app/G;Z)V

    return-void

    :cond_3
    iget-object v0, p0, Landroid/support/v7/app/I;->mContext:Landroid/content/Context;

    const-string v3, "window"

    invoke-virtual {v0, v3}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/WindowManager;

    if-nez v0, :cond_4

    return-void

    :cond_4
    invoke-direct {p0, p1, p2}, Landroid/support/v7/app/I;->b(Landroid/support/v7/app/G;Landroid/view/KeyEvent;)Z

    move-result p2

    if-nez p2, :cond_5

    return-void

    :cond_5
    iget-object p2, p1, Landroid/support/v7/app/G;->decorView:Landroid/view/ViewGroup;

    const/4 v3, -0x1

    const/4 v4, -0x2

    if-eqz p2, :cond_7

    iget-boolean p2, p1, Landroid/support/v7/app/G;->refreshDecorView:Z

    if-eqz p2, :cond_6

    goto :goto_1

    :cond_6
    iget-object p0, p1, Landroid/support/v7/app/G;->createdPanelView:Landroid/view/View;

    if-eqz p0, :cond_16

    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p0

    if-eqz p0, :cond_16

    iget p0, p0, Landroid/view/ViewGroup$LayoutParams;->width:I

    if-ne p0, v3, :cond_16

    move v6, v3

    goto/16 :goto_9

    :cond_7
    :goto_1
    iget-object p2, p1, Landroid/support/v7/app/G;->decorView:Landroid/view/ViewGroup;

    if-nez p2, :cond_8

    .line 1
    invoke-virtual {p0}, Landroid/support/v7/app/I;->Ka()Landroid/content/Context;

    move-result-object p2

    invoke-virtual {p1, p2}, Landroid/support/v7/app/G;->setStyle(Landroid/content/Context;)V

    new-instance p2, Landroid/support/v7/app/E;

    iget-object v3, p1, Landroid/support/v7/app/G;->Qj:Landroid/content/Context;

    invoke-direct {p2, p0, v3}, Landroid/support/v7/app/E;-><init>(Landroid/support/v7/app/I;Landroid/content/Context;)V

    iput-object p2, p1, Landroid/support/v7/app/G;->decorView:Landroid/view/ViewGroup;

    const/16 p2, 0x51

    iput p2, p1, Landroid/support/v7/app/G;->gravity:I

    .line 2
    iget-object p2, p1, Landroid/support/v7/app/G;->decorView:Landroid/view/ViewGroup;

    if-nez p2, :cond_9

    return-void

    :cond_8
    iget-boolean v3, p1, Landroid/support/v7/app/G;->refreshDecorView:Z

    if-eqz v3, :cond_9

    invoke-virtual {p2}, Landroid/view/ViewGroup;->getChildCount()I

    move-result p2

    if-lez p2, :cond_9

    iget-object p2, p1, Landroid/support/v7/app/G;->decorView:Landroid/view/ViewGroup;

    invoke-virtual {p2}, Landroid/view/ViewGroup;->removeAllViews()V

    .line 3
    :cond_9
    iget-object p2, p1, Landroid/support/v7/app/G;->createdPanelView:Landroid/view/View;

    if-eqz p2, :cond_a

    iput-object p2, p1, Landroid/support/v7/app/G;->shownPanelView:Landroid/view/View;

    goto :goto_3

    :cond_a
    iget-object p2, p1, Landroid/support/v7/app/G;->menu:Landroid/support/v7/view/menu/r;

    if-nez p2, :cond_b

    goto :goto_4

    :cond_b
    iget-object p2, p0, Landroid/support/v7/app/I;->fj:Landroid/support/v7/app/H;

    if-nez p2, :cond_c

    new-instance p2, Landroid/support/v7/app/H;

    invoke-direct {p2, p0}, Landroid/support/v7/app/H;-><init>(Landroid/support/v7/app/I;)V

    iput-object p2, p0, Landroid/support/v7/app/I;->fj:Landroid/support/v7/app/H;

    :cond_c
    iget-object p0, p0, Landroid/support/v7/app/I;->fj:Landroid/support/v7/app/H;

    .line 4
    iget-object p2, p1, Landroid/support/v7/app/G;->menu:Landroid/support/v7/view/menu/r;

    if-nez p2, :cond_d

    const/4 p0, 0x0

    goto :goto_2

    :cond_d
    iget-object p2, p1, Landroid/support/v7/app/G;->listMenuPresenter:Landroid/support/v7/view/menu/n;

    if-nez p2, :cond_e

    new-instance p2, Landroid/support/v7/view/menu/n;

    iget-object v3, p1, Landroid/support/v7/app/G;->Qj:Landroid/content/Context;

    const v5, 0x7f0a0010

    invoke-direct {p2, v3, v5}, Landroid/support/v7/view/menu/n;-><init>(Landroid/content/Context;I)V

    iput-object p2, p1, Landroid/support/v7/app/G;->listMenuPresenter:Landroid/support/v7/view/menu/n;

    iget-object p2, p1, Landroid/support/v7/app/G;->listMenuPresenter:Landroid/support/v7/view/menu/n;

    invoke-virtual {p2, p0}, Landroid/support/v7/view/menu/n;->a(Landroid/support/v7/view/menu/F;)V

    iget-object p0, p1, Landroid/support/v7/app/G;->menu:Landroid/support/v7/view/menu/r;

    iget-object p2, p1, Landroid/support/v7/app/G;->listMenuPresenter:Landroid/support/v7/view/menu/n;

    invoke-virtual {p0, p2}, Landroid/support/v7/view/menu/r;->a(Landroid/support/v7/view/menu/G;)V

    :cond_e
    iget-object p0, p1, Landroid/support/v7/app/G;->listMenuPresenter:Landroid/support/v7/view/menu/n;

    iget-object p2, p1, Landroid/support/v7/app/G;->decorView:Landroid/view/ViewGroup;

    invoke-virtual {p0, p2}, Landroid/support/v7/view/menu/n;->getMenuView(Landroid/view/ViewGroup;)Landroid/support/v7/view/menu/I;

    move-result-object p0

    .line 5
    :goto_2
    check-cast p0, Landroid/view/View;

    iput-object p0, p1, Landroid/support/v7/app/G;->shownPanelView:Landroid/view/View;

    iget-object p0, p1, Landroid/support/v7/app/G;->shownPanelView:Landroid/view/View;

    if-eqz p0, :cond_f

    :goto_3
    move p0, v2

    goto :goto_5

    :cond_f
    :goto_4
    move p0, v1

    :goto_5
    if-eqz p0, :cond_17

    .line 6
    iget-object p0, p1, Landroid/support/v7/app/G;->shownPanelView:Landroid/view/View;

    if-nez p0, :cond_10

    goto :goto_7

    :cond_10
    iget-object p0, p1, Landroid/support/v7/app/G;->createdPanelView:Landroid/view/View;

    if-eqz p0, :cond_11

    goto :goto_6

    :cond_11
    iget-object p0, p1, Landroid/support/v7/app/G;->listMenuPresenter:Landroid/support/v7/view/menu/n;

    invoke-virtual {p0}, Landroid/support/v7/view/menu/n;->getAdapter()Landroid/widget/ListAdapter;

    move-result-object p0

    invoke-interface {p0}, Landroid/widget/ListAdapter;->getCount()I

    move-result p0

    if-lez p0, :cond_12

    :goto_6
    move p0, v2

    goto :goto_8

    :cond_12
    :goto_7
    move p0, v1

    :goto_8
    if-nez p0, :cond_13

    goto :goto_a

    .line 7
    :cond_13
    iget-object p0, p1, Landroid/support/v7/app/G;->shownPanelView:Landroid/view/View;

    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p0

    if-nez p0, :cond_14

    new-instance p0, Landroid/view/ViewGroup$LayoutParams;

    invoke-direct {p0, v4, v4}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    :cond_14
    iget p2, p1, Landroid/support/v7/app/G;->background:I

    iget-object v3, p1, Landroid/support/v7/app/G;->decorView:Landroid/view/ViewGroup;

    invoke-virtual {v3, p2}, Landroid/view/ViewGroup;->setBackgroundResource(I)V

    iget-object p2, p1, Landroid/support/v7/app/G;->shownPanelView:Landroid/view/View;

    invoke-virtual {p2}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p2

    if-eqz p2, :cond_15

    instance-of v3, p2, Landroid/view/ViewGroup;

    if-eqz v3, :cond_15

    check-cast p2, Landroid/view/ViewGroup;

    iget-object v3, p1, Landroid/support/v7/app/G;->shownPanelView:Landroid/view/View;

    invoke-virtual {p2, v3}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_15
    iget-object p2, p1, Landroid/support/v7/app/G;->decorView:Landroid/view/ViewGroup;

    iget-object v3, p1, Landroid/support/v7/app/G;->shownPanelView:Landroid/view/View;

    invoke-virtual {p2, v3, p0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object p0, p1, Landroid/support/v7/app/G;->shownPanelView:Landroid/view/View;

    invoke-virtual {p0}, Landroid/view/View;->hasFocus()Z

    move-result p0

    if-nez p0, :cond_16

    iget-object p0, p1, Landroid/support/v7/app/G;->shownPanelView:Landroid/view/View;

    invoke-virtual {p0}, Landroid/view/View;->requestFocus()Z

    :cond_16
    move v6, v4

    :goto_9
    iput-boolean v1, p1, Landroid/support/v7/app/G;->isHandled:Z

    new-instance p0, Landroid/view/WindowManager$LayoutParams;

    const/4 v7, -0x2

    iget v8, p1, Landroid/support/v7/app/G;->x:I

    iget v9, p1, Landroid/support/v7/app/G;->y:I

    const/16 v10, 0x3ea

    const/high16 v11, 0x820000

    const/4 v12, -0x3

    move-object v5, p0

    invoke-direct/range {v5 .. v12}, Landroid/view/WindowManager$LayoutParams;-><init>(IIIIIII)V

    iget p2, p1, Landroid/support/v7/app/G;->gravity:I

    iput p2, p0, Landroid/view/WindowManager$LayoutParams;->gravity:I

    iget p2, p1, Landroid/support/v7/app/G;->windowAnimations:I

    iput p2, p0, Landroid/view/WindowManager$LayoutParams;->windowAnimations:I

    iget-object p2, p1, Landroid/support/v7/app/G;->decorView:Landroid/view/ViewGroup;

    invoke-interface {v0, p2, p0}, Landroid/view/WindowManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iput-boolean v2, p1, Landroid/support/v7/app/G;->isOpen:Z

    :cond_17
    :goto_a
    return-void
.end method

.method private a(Landroid/support/v7/app/G;ILandroid/view/KeyEvent;I)Z
    .locals 2

    invoke-virtual {p3}, Landroid/view/KeyEvent;->isSystem()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    return v1

    :cond_0
    iget-boolean v0, p1, Landroid/support/v7/app/G;->isPrepared:Z

    if-nez v0, :cond_1

    invoke-direct {p0, p1, p3}, Landroid/support/v7/app/I;->b(Landroid/support/v7/app/G;Landroid/view/KeyEvent;)Z

    move-result v0

    if-eqz v0, :cond_2

    :cond_1
    iget-object v0, p1, Landroid/support/v7/app/G;->menu:Landroid/support/v7/view/menu/r;

    if-eqz v0, :cond_2

    invoke-virtual {v0, p2, p3, p4}, Landroid/support/v7/view/menu/r;->performShortcut(ILandroid/view/KeyEvent;I)Z

    move-result v1

    :cond_2
    if-eqz v1, :cond_3

    const/4 p2, 0x1

    and-int/lit8 p3, p4, 0x1

    if-nez p3, :cond_3

    iget-object p3, p0, Landroid/support/v7/app/I;->mDecorContentParent:Landroid/support/v7/widget/ga;

    if-nez p3, :cond_3

    invoke-virtual {p0, p1, p2}, Landroid/support/v7/app/I;->a(Landroid/support/v7/app/G;Z)V

    :cond_3
    return v1
.end method

.method static synthetic a(Landroid/support/v7/app/I;)Z
    .locals 0

    iget-boolean p0, p0, Landroid/support/v7/app/I;->xj:Z

    return p0
.end method

.method private b(Landroid/support/v7/app/G;Landroid/view/KeyEvent;)Z
    .locals 11

    iget-boolean v0, p0, Landroid/support/v7/app/I;->xj:Z

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    return v1

    :cond_0
    iget-boolean v0, p1, Landroid/support/v7/app/G;->isPrepared:Z

    const/4 v2, 0x1

    if-eqz v0, :cond_1

    return v2

    :cond_1
    iget-object v0, p0, Landroid/support/v7/app/I;->mPreparedPanel:Landroid/support/v7/app/G;

    if-eqz v0, :cond_2

    if-eq v0, p1, :cond_2

    invoke-virtual {p0, v0, v1}, Landroid/support/v7/app/I;->a(Landroid/support/v7/app/G;Z)V

    :cond_2
    invoke-virtual {p0}, Landroid/support/v7/app/I;->La()Landroid/view/Window$Callback;

    move-result-object v0

    if-eqz v0, :cond_3

    iget v3, p1, Landroid/support/v7/app/G;->featureId:I

    invoke-interface {v0, v3}, Landroid/view/Window$Callback;->onCreatePanelView(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, p1, Landroid/support/v7/app/G;->createdPanelView:Landroid/view/View;

    :cond_3
    iget v3, p1, Landroid/support/v7/app/G;->featureId:I

    const/16 v4, 0x6c

    if-eqz v3, :cond_5

    if-ne v3, v4, :cond_4

    goto :goto_0

    :cond_4
    move v3, v1

    goto :goto_1

    :cond_5
    :goto_0
    move v3, v2

    :goto_1
    if-eqz v3, :cond_6

    iget-object v5, p0, Landroid/support/v7/app/I;->mDecorContentParent:Landroid/support/v7/widget/ga;

    if-eqz v5, :cond_6

    invoke-interface {v5}, Landroid/support/v7/widget/ga;->setMenuPrepared()V

    :cond_6
    iget-object v5, p1, Landroid/support/v7/app/G;->createdPanelView:Landroid/view/View;

    if-nez v5, :cond_19

    if-eqz v3, :cond_7

    invoke-virtual {p0}, Landroid/support/v7/app/I;->Na()Landroid/support/v7/app/c;

    :cond_7
    iget-object v5, p1, Landroid/support/v7/app/G;->menu:Landroid/support/v7/view/menu/r;

    const/4 v6, 0x0

    if-eqz v5, :cond_8

    iget-boolean v5, p1, Landroid/support/v7/app/G;->refreshMenuContent:Z

    if-eqz v5, :cond_13

    :cond_8
    iget-object v5, p1, Landroid/support/v7/app/G;->menu:Landroid/support/v7/view/menu/r;

    if-nez v5, :cond_e

    .line 4
    iget-object v5, p0, Landroid/support/v7/app/I;->mContext:Landroid/content/Context;

    iget v7, p1, Landroid/support/v7/app/G;->featureId:I

    if-eqz v7, :cond_9

    if-ne v7, v4, :cond_d

    :cond_9
    iget-object v4, p0, Landroid/support/v7/app/I;->mDecorContentParent:Landroid/support/v7/widget/ga;

    if-eqz v4, :cond_d

    new-instance v4, Landroid/util/TypedValue;

    invoke-direct {v4}, Landroid/util/TypedValue;-><init>()V

    invoke-virtual {v5}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v7

    const v8, 0x7f030009

    invoke-virtual {v7, v8, v4, v2}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    iget v8, v4, Landroid/util/TypedValue;->resourceId:I

    const v9, 0x7f03000a

    if-eqz v8, :cond_a

    invoke-virtual {v5}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v8

    invoke-virtual {v8}, Landroid/content/res/Resources;->newTheme()Landroid/content/res/Resources$Theme;

    move-result-object v8

    invoke-virtual {v8, v7}, Landroid/content/res/Resources$Theme;->setTo(Landroid/content/res/Resources$Theme;)V

    iget v10, v4, Landroid/util/TypedValue;->resourceId:I

    invoke-virtual {v8, v10, v2}, Landroid/content/res/Resources$Theme;->applyStyle(IZ)V

    invoke-virtual {v8, v9, v4, v2}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    goto :goto_2

    :cond_a
    invoke-virtual {v7, v9, v4, v2}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    move-object v8, v6

    :goto_2
    iget v9, v4, Landroid/util/TypedValue;->resourceId:I

    if-eqz v9, :cond_c

    if-nez v8, :cond_b

    invoke-virtual {v5}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v8

    invoke-virtual {v8}, Landroid/content/res/Resources;->newTheme()Landroid/content/res/Resources$Theme;

    move-result-object v8

    invoke-virtual {v8, v7}, Landroid/content/res/Resources$Theme;->setTo(Landroid/content/res/Resources$Theme;)V

    :cond_b
    iget v4, v4, Landroid/util/TypedValue;->resourceId:I

    invoke-virtual {v8, v4, v2}, Landroid/content/res/Resources$Theme;->applyStyle(IZ)V

    :cond_c
    if-eqz v8, :cond_d

    new-instance v4, La/b/d/e/e;

    invoke-direct {v4, v5, v1}, La/b/d/e/e;-><init>(Landroid/content/Context;I)V

    invoke-virtual {v4}, La/b/d/e/e;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v5

    invoke-virtual {v5, v8}, Landroid/content/res/Resources$Theme;->setTo(Landroid/content/res/Resources$Theme;)V

    goto :goto_3

    :cond_d
    move-object v4, v5

    :goto_3
    new-instance v5, Landroid/support/v7/view/menu/r;

    invoke-direct {v5, v4}, Landroid/support/v7/view/menu/r;-><init>(Landroid/content/Context;)V

    invoke-virtual {v5, p0}, Landroid/support/v7/view/menu/r;->a(Landroid/support/v7/view/menu/p;)V

    invoke-virtual {p1, v5}, Landroid/support/v7/app/G;->e(Landroid/support/v7/view/menu/r;)V

    .line 5
    iget-object v4, p1, Landroid/support/v7/app/G;->menu:Landroid/support/v7/view/menu/r;

    if-nez v4, :cond_e

    return v1

    :cond_e
    if-eqz v3, :cond_10

    iget-object v4, p0, Landroid/support/v7/app/I;->mDecorContentParent:Landroid/support/v7/widget/ga;

    if-eqz v4, :cond_10

    iget-object v4, p0, Landroid/support/v7/app/I;->ej:Landroid/support/v7/app/z;

    if-nez v4, :cond_f

    new-instance v4, Landroid/support/v7/app/z;

    invoke-direct {v4, p0}, Landroid/support/v7/app/z;-><init>(Landroid/support/v7/app/I;)V

    iput-object v4, p0, Landroid/support/v7/app/I;->ej:Landroid/support/v7/app/z;

    :cond_f
    iget-object v4, p0, Landroid/support/v7/app/I;->mDecorContentParent:Landroid/support/v7/widget/ga;

    iget-object v5, p1, Landroid/support/v7/app/G;->menu:Landroid/support/v7/view/menu/r;

    iget-object v7, p0, Landroid/support/v7/app/I;->ej:Landroid/support/v7/app/z;

    invoke-interface {v4, v5, v7}, Landroid/support/v7/widget/ga;->a(Landroid/view/Menu;Landroid/support/v7/view/menu/F;)V

    :cond_10
    iget-object v4, p1, Landroid/support/v7/app/G;->menu:Landroid/support/v7/view/menu/r;

    invoke-virtual {v4}, Landroid/support/v7/view/menu/r;->stopDispatchingItemsChanged()V

    iget v4, p1, Landroid/support/v7/app/G;->featureId:I

    iget-object v5, p1, Landroid/support/v7/app/G;->menu:Landroid/support/v7/view/menu/r;

    invoke-interface {v0, v4, v5}, Landroid/view/Window$Callback;->onCreatePanelMenu(ILandroid/view/Menu;)Z

    move-result v4

    if-nez v4, :cond_12

    invoke-virtual {p1, v6}, Landroid/support/v7/app/G;->e(Landroid/support/v7/view/menu/r;)V

    if-eqz v3, :cond_11

    iget-object p1, p0, Landroid/support/v7/app/I;->mDecorContentParent:Landroid/support/v7/widget/ga;

    if-eqz p1, :cond_11

    iget-object p0, p0, Landroid/support/v7/app/I;->ej:Landroid/support/v7/app/z;

    invoke-interface {p1, v6, p0}, Landroid/support/v7/widget/ga;->a(Landroid/view/Menu;Landroid/support/v7/view/menu/F;)V

    :cond_11
    return v1

    :cond_12
    iput-boolean v1, p1, Landroid/support/v7/app/G;->refreshMenuContent:Z

    :cond_13
    iget-object v4, p1, Landroid/support/v7/app/G;->menu:Landroid/support/v7/view/menu/r;

    invoke-virtual {v4}, Landroid/support/v7/view/menu/r;->stopDispatchingItemsChanged()V

    iget-object v4, p1, Landroid/support/v7/app/G;->frozenActionViewState:Landroid/os/Bundle;

    if-eqz v4, :cond_14

    iget-object v5, p1, Landroid/support/v7/app/G;->menu:Landroid/support/v7/view/menu/r;

    invoke-virtual {v5, v4}, Landroid/support/v7/view/menu/r;->restoreActionViewStates(Landroid/os/Bundle;)V

    iput-object v6, p1, Landroid/support/v7/app/G;->frozenActionViewState:Landroid/os/Bundle;

    :cond_14
    iget-object v4, p1, Landroid/support/v7/app/G;->createdPanelView:Landroid/view/View;

    iget-object v5, p1, Landroid/support/v7/app/G;->menu:Landroid/support/v7/view/menu/r;

    invoke-interface {v0, v1, v4, v5}, Landroid/view/Window$Callback;->onPreparePanel(ILandroid/view/View;Landroid/view/Menu;)Z

    move-result v0

    if-nez v0, :cond_16

    if-eqz v3, :cond_15

    iget-object p2, p0, Landroid/support/v7/app/I;->mDecorContentParent:Landroid/support/v7/widget/ga;

    if-eqz p2, :cond_15

    iget-object p0, p0, Landroid/support/v7/app/I;->ej:Landroid/support/v7/app/z;

    invoke-interface {p2, v6, p0}, Landroid/support/v7/widget/ga;->a(Landroid/view/Menu;Landroid/support/v7/view/menu/F;)V

    :cond_15
    iget-object p0, p1, Landroid/support/v7/app/G;->menu:Landroid/support/v7/view/menu/r;

    invoke-virtual {p0}, Landroid/support/v7/view/menu/r;->startDispatchingItemsChanged()V

    return v1

    :cond_16
    if-eqz p2, :cond_17

    invoke-virtual {p2}, Landroid/view/KeyEvent;->getDeviceId()I

    move-result p2

    goto :goto_4

    :cond_17
    const/4 p2, -0x1

    :goto_4
    invoke-static {p2}, Landroid/view/KeyCharacterMap;->load(I)Landroid/view/KeyCharacterMap;

    move-result-object p2

    invoke-virtual {p2}, Landroid/view/KeyCharacterMap;->getKeyboardType()I

    move-result p2

    if-eq p2, v2, :cond_18

    move p2, v2

    goto :goto_5

    :cond_18
    move p2, v1

    :goto_5
    iput-boolean p2, p1, Landroid/support/v7/app/G;->qwertyMode:Z

    iget-object p2, p1, Landroid/support/v7/app/G;->menu:Landroid/support/v7/view/menu/r;

    iget-boolean v0, p1, Landroid/support/v7/app/G;->qwertyMode:Z

    invoke-virtual {p2, v0}, Landroid/support/v7/view/menu/r;->setQwertyMode(Z)V

    iget-object p2, p1, Landroid/support/v7/app/G;->menu:Landroid/support/v7/view/menu/r;

    invoke-virtual {p2}, Landroid/support/v7/view/menu/r;->startDispatchingItemsChanged()V

    :cond_19
    iput-boolean v2, p1, Landroid/support/v7/app/G;->isPrepared:Z

    iput-boolean v1, p1, Landroid/support/v7/app/G;->isHandled:Z

    iput-object p1, p0, Landroid/support/v7/app/I;->mPreparedPanel:Landroid/support/v7/app/G;

    return v2
.end method

.method private invalidatePanelMenu(I)V
    .locals 2

    iget v0, p0, Landroid/support/v7/app/I;->Cj:I

    const/4 v1, 0x1

    shl-int p1, v1, p1

    or-int/2addr p1, v0

    iput p1, p0, Landroid/support/v7/app/I;->Cj:I

    iget-boolean p1, p0, Landroid/support/v7/app/I;->Bj:Z

    if-nez p1, :cond_0

    iget-object p1, p0, Landroid/support/v7/app/I;->mWindow:Landroid/view/Window;

    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p1

    iget-object v0, p0, Landroid/support/v7/app/I;->Dj:Ljava/lang/Runnable;

    invoke-static {p1, v0}, Landroid/support/v4/view/r;->a(Landroid/view/View;Ljava/lang/Runnable;)V

    iput-boolean v1, p0, Landroid/support/v7/app/I;->Bj:Z

    :cond_0
    return-void
.end method


# virtual methods
.method public Ha()Z
    .locals 10

    .line 1
    iget v0, p0, Landroid/support/v7/app/I;->yj:I

    const/16 v1, -0x64

    const/4 v2, -0x1

    if-eq v0, v1, :cond_0

    goto :goto_0

    :cond_0
    move v0, v2

    .line 2
    :goto_0
    invoke-virtual {p0, v0}, Landroid/support/v7/app/I;->Q(I)I

    move-result v1

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eq v1, v2, :cond_4

    .line 3
    iget-object v2, p0, Landroid/support/v7/app/I;->mContext:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v5

    iget v6, v5, Landroid/content/res/Configuration;->uiMode:I

    and-int/lit8 v6, v6, 0x30

    const/4 v7, 0x2

    if-ne v1, v7, :cond_1

    const/16 v1, 0x20

    goto :goto_1

    :cond_1
    const/16 v1, 0x10

    :goto_1
    if-eq v6, v1, :cond_4

    .line 4
    iget-boolean v6, p0, Landroid/support/v7/app/I;->zj:Z

    if-eqz v6, :cond_2

    iget-object v6, p0, Landroid/support/v7/app/I;->mContext:Landroid/content/Context;

    instance-of v7, v6, Landroid/app/Activity;

    if-eqz v7, :cond_2

    invoke-virtual {v6}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v6

    :try_start_0
    new-instance v7, Landroid/content/ComponentName;

    iget-object v8, p0, Landroid/support/v7/app/I;->mContext:Landroid/content/Context;

    iget-object v9, p0, Landroid/support/v7/app/I;->mContext:Landroid/content/Context;

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v9

    invoke-direct {v7, v8, v9}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {v6, v7, v4}, Landroid/content/pm/PackageManager;->getActivityInfo(Landroid/content/ComponentName;I)Landroid/content/pm/ActivityInfo;

    move-result-object v6

    iget v6, v6, Landroid/content/pm/ActivityInfo;->configChanges:I
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    and-int/lit16 v6, v6, 0x200

    if-nez v6, :cond_2

    goto :goto_2

    :catch_0
    move-exception v4

    const-string v6, "AppCompatDelegate"

    const-string v7, "Exception while getting ActivityInfo"

    invoke-static {v6, v7, v4}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_2
    move v4, v3

    :cond_2
    if-eqz v4, :cond_3

    .line 5
    iget-object v1, p0, Landroid/support/v7/app/I;->mContext:Landroid/content/Context;

    check-cast v1, Landroid/app/Activity;

    invoke-virtual {v1}, Landroid/app/Activity;->recreate()V

    goto :goto_3

    :cond_3
    new-instance v4, Landroid/content/res/Configuration;

    invoke-direct {v4, v5}, Landroid/content/res/Configuration;-><init>(Landroid/content/res/Configuration;)V

    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v5

    iget v6, v4, Landroid/content/res/Configuration;->uiMode:I

    and-int/lit8 v6, v6, -0x31

    or-int/2addr v1, v6

    iput v1, v4, Landroid/content/res/Configuration;->uiMode:I

    invoke-virtual {v2, v4, v5}, Landroid/content/res/Resources;->updateConfiguration(Landroid/content/res/Configuration;Landroid/util/DisplayMetrics;)V

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    :goto_3
    move v4, v3

    :cond_4
    if-nez v0, :cond_5

    .line 6
    invoke-direct {p0}, Landroid/support/v7/app/I;->Xf()V

    iget-object v0, p0, Landroid/support/v7/app/I;->Aj:Landroid/support/v7/app/AppCompatDelegateImpl$AutoNightModeManager;

    invoke-virtual {v0}, Landroid/support/v7/app/AppCompatDelegateImpl$AutoNightModeManager;->setup()V

    :cond_5
    iput-boolean v3, p0, Landroid/support/v7/app/I;->zj:Z

    return v4
.end method

.method public Ia()V
    .locals 2

    iget-object v0, p0, Landroid/support/v7/app/I;->mContext:Landroid/content/Context;

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/LayoutInflater;->getFactory()Landroid/view/LayoutInflater$Factory;

    move-result-object v1

    if-nez v1, :cond_0

    .line 1
    invoke-virtual {v0, p0}, Landroid/view/LayoutInflater;->setFactory2(Landroid/view/LayoutInflater$Factory2;)V

    sget p0, Landroid/os/Build$VERSION;->SDK_INT:I

    goto :goto_0

    .line 2
    :cond_0
    invoke-virtual {v0}, Landroid/view/LayoutInflater;->getFactory2()Landroid/view/LayoutInflater$Factory2;

    move-result-object p0

    instance-of p0, p0, Landroid/support/v7/app/I;

    if-nez p0, :cond_1

    const-string p0, "AppCompatDelegate"

    const-string v0, "The Activity\'s LayoutInflater already has a Factory installed so we can not install AppCompat\'s"

    invoke-static {p0, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    :cond_1
    :goto_0
    return-void
.end method

.method Ja()V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/app/I;->jj:Landroid/support/v4/view/w;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroid/support/v4/view/w;->cancel()V

    :cond_0
    return-void
.end method

.method final Ka()Landroid/content/Context;
    .locals 1

    invoke-virtual {p0}, Landroid/support/v7/app/I;->Y()Landroid/support/v7/app/c;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/support/v7/app/c;->getThemedContext()Landroid/content/Context;

    move-result-object v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    if-nez v0, :cond_1

    iget-object v0, p0, Landroid/support/v7/app/I;->mContext:Landroid/content/Context;

    :cond_1
    return-object v0
.end method

.method final La()Landroid/view/Window$Callback;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/app/I;->mWindow:Landroid/view/Window;

    invoke-virtual {p0}, Landroid/view/Window;->getCallback()Landroid/view/Window$Callback;

    move-result-object p0

    return-object p0
.end method

.method public Ma()Z
    .locals 0

    iget-boolean p0, p0, Landroid/support/v7/app/I;->kj:Z

    return p0
.end method

.method final Na()Landroid/support/v7/app/c;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/app/I;->mActionBar:Landroid/support/v7/app/c;

    return-object p0
.end method

.method final Oa()Z
    .locals 1

    iget-boolean v0, p0, Landroid/support/v7/app/I;->lj:Z

    if-eqz v0, :cond_0

    iget-object p0, p0, Landroid/support/v7/app/I;->mj:Landroid/view/ViewGroup;

    if-eqz p0, :cond_0

    invoke-static {p0}, Landroid/support/v4/view/r;->y(Landroid/view/View;)Z

    move-result p0

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method Q(I)I
    .locals 2

    const/16 v0, -0x64

    const/4 v1, -0x1

    if-eq p1, v0, :cond_2

    if-eqz p1, :cond_0

    return p1

    :cond_0
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    iget-object p1, p0, Landroid/support/v7/app/I;->mContext:Landroid/content/Context;

    const-class v0, Landroid/app/UiModeManager;

    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/app/UiModeManager;

    invoke-virtual {p1}, Landroid/app/UiModeManager;->getNightMode()I

    move-result p1

    if-nez p1, :cond_1

    return v1

    :cond_1
    invoke-direct {p0}, Landroid/support/v7/app/I;->Xf()V

    iget-object p0, p0, Landroid/support/v7/app/I;->Aj:Landroid/support/v7/app/AppCompatDelegateImpl$AutoNightModeManager;

    invoke-virtual {p0}, Landroid/support/v7/app/AppCompatDelegateImpl$AutoNightModeManager;->Qa()I

    move-result p0

    return p0

    :cond_2
    return v1
.end method

.method R(I)V
    .locals 1

    const/16 v0, 0x6c

    if-ne p1, v0, :cond_0

    invoke-virtual {p0}, Landroid/support/v7/app/I;->Y()Landroid/support/v7/app/c;

    move-result-object p0

    if-eqz p0, :cond_0

    const/4 p1, 0x1

    invoke-virtual {p0, p1}, Landroid/support/v7/app/c;->dispatchMenuVisibilityChanged(Z)V

    :cond_0
    return-void
.end method

.method S(I)V
    .locals 2

    const/4 v0, 0x0

    const/16 v1, 0x6c

    if-ne p1, v1, :cond_0

    invoke-virtual {p0}, Landroid/support/v7/app/I;->Y()Landroid/support/v7/app/c;

    move-result-object p0

    if-eqz p0, :cond_1

    invoke-virtual {p0, v0}, Landroid/support/v7/app/c;->dispatchMenuVisibilityChanged(Z)V

    goto :goto_0

    :cond_0
    if-nez p1, :cond_1

    const/4 v1, 0x1

    invoke-virtual {p0, p1, v1}, Landroid/support/v7/app/I;->getPanelState(IZ)Landroid/support/v7/app/G;

    move-result-object p1

    iget-boolean v1, p1, Landroid/support/v7/app/G;->isOpen:Z

    if-eqz v1, :cond_1

    invoke-virtual {p0, p1, v0}, Landroid/support/v7/app/I;->a(Landroid/support/v7/app/G;Z)V

    :cond_1
    :goto_0
    return-void
.end method

.method T(I)I
    .locals 7

    iget-object v0, p0, Landroid/support/v7/app/I;->gj:Landroid/support/v7/widget/ActionBarContextView;

    const/4 v1, 0x0

    if-eqz v0, :cond_9

    invoke-virtual {v0}, Landroid/view/ViewGroup;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    instance-of v0, v0, Landroid/view/ViewGroup$MarginLayoutParams;

    if-eqz v0, :cond_9

    iget-object v0, p0, Landroid/support/v7/app/I;->gj:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {v0}, Landroid/view/ViewGroup;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroid/view/ViewGroup$MarginLayoutParams;

    iget-object v2, p0, Landroid/support/v7/app/I;->gj:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {v2}, Landroid/view/ViewGroup;->isShown()Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_6

    iget-object v2, p0, Landroid/support/v7/app/I;->Fj:Landroid/graphics/Rect;

    if-nez v2, :cond_0

    new-instance v2, Landroid/graphics/Rect;

    invoke-direct {v2}, Landroid/graphics/Rect;-><init>()V

    iput-object v2, p0, Landroid/support/v7/app/I;->Fj:Landroid/graphics/Rect;

    new-instance v2, Landroid/graphics/Rect;

    invoke-direct {v2}, Landroid/graphics/Rect;-><init>()V

    iput-object v2, p0, Landroid/support/v7/app/I;->Gj:Landroid/graphics/Rect;

    :cond_0
    iget-object v2, p0, Landroid/support/v7/app/I;->Fj:Landroid/graphics/Rect;

    iget-object v4, p0, Landroid/support/v7/app/I;->Gj:Landroid/graphics/Rect;

    invoke-virtual {v2, v1, p1, v1, v1}, Landroid/graphics/Rect;->set(IIII)V

    iget-object v5, p0, Landroid/support/v7/app/I;->mj:Landroid/view/ViewGroup;

    invoke-static {v5, v2, v4}, Landroid/support/v7/widget/yc;->a(Landroid/view/View;Landroid/graphics/Rect;Landroid/graphics/Rect;)V

    iget v2, v4, Landroid/graphics/Rect;->top:I

    if-nez v2, :cond_1

    move v2, p1

    goto :goto_0

    :cond_1
    move v2, v1

    :goto_0
    iget v4, v0, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    if-eq v4, v2, :cond_4

    iput p1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    iget-object v2, p0, Landroid/support/v7/app/I;->nj:Landroid/view/View;

    if-nez v2, :cond_2

    new-instance v2, Landroid/view/View;

    iget-object v4, p0, Landroid/support/v7/app/I;->mContext:Landroid/content/Context;

    invoke-direct {v2, v4}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    iput-object v2, p0, Landroid/support/v7/app/I;->nj:Landroid/view/View;

    iget-object v2, p0, Landroid/support/v7/app/I;->nj:Landroid/view/View;

    iget-object v4, p0, Landroid/support/v7/app/I;->mContext:Landroid/content/Context;

    invoke-virtual {v4}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    const v5, 0x7f050007

    invoke-virtual {v4, v5}, Landroid/content/res/Resources;->getColor(I)I

    move-result v4

    invoke-virtual {v2, v4}, Landroid/view/View;->setBackgroundColor(I)V

    iget-object v2, p0, Landroid/support/v7/app/I;->mj:Landroid/view/ViewGroup;

    iget-object v4, p0, Landroid/support/v7/app/I;->nj:Landroid/view/View;

    new-instance v5, Landroid/view/ViewGroup$LayoutParams;

    const/4 v6, -0x1

    invoke-direct {v5, v6, p1}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v4, v6, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    goto :goto_1

    :cond_2
    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    iget v4, v2, Landroid/view/ViewGroup$LayoutParams;->height:I

    if-eq v4, p1, :cond_3

    iput p1, v2, Landroid/view/ViewGroup$LayoutParams;->height:I

    iget-object v4, p0, Landroid/support/v7/app/I;->nj:Landroid/view/View;

    invoke-virtual {v4, v2}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_3
    :goto_1
    move v2, v3

    goto :goto_2

    :cond_4
    move v2, v1

    :goto_2
    iget-object v4, p0, Landroid/support/v7/app/I;->nj:Landroid/view/View;

    if-eqz v4, :cond_5

    goto :goto_3

    :cond_5
    move v3, v1

    :goto_3
    iget-boolean v4, p0, Landroid/support/v7/app/I;->sj:Z

    if-nez v4, :cond_8

    if-eqz v3, :cond_8

    move p1, v1

    goto :goto_4

    :cond_6
    iget v2, v0, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    if-eqz v2, :cond_7

    iput v1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    move v2, v3

    move v3, v1

    goto :goto_4

    :cond_7
    move v2, v1

    move v3, v2

    :cond_8
    :goto_4
    if-eqz v2, :cond_a

    iget-object v2, p0, Landroid/support/v7/app/I;->gj:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {v2, v0}, Landroid/view/ViewGroup;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    goto :goto_5

    :cond_9
    move v3, v1

    :cond_a
    :goto_5
    iget-object p0, p0, Landroid/support/v7/app/I;->nj:Landroid/view/View;

    if-eqz p0, :cond_c

    if-eqz v3, :cond_b

    goto :goto_6

    :cond_b
    const/16 v1, 0x8

    :goto_6
    invoke-virtual {p0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_c
    return p1
.end method

.method public Y()Landroid/support/v7/app/c;
    .locals 0

    invoke-direct {p0}, Landroid/support/v7/app/I;->Zf()V

    iget-object p0, p0, Landroid/support/v7/app/I;->mActionBar:Landroid/support/v7/app/c;

    return-object p0
.end method

.method a(ILandroid/support/v7/app/G;Landroid/view/Menu;)V
    .locals 2

    if-nez p3, :cond_1

    if-nez p2, :cond_0

    if-ltz p1, :cond_0

    iget-object v0, p0, Landroid/support/v7/app/I;->vj:[Landroid/support/v7/app/G;

    array-length v1, v0

    if-ge p1, v1, :cond_0

    aget-object p2, v0, p1

    :cond_0
    if-eqz p2, :cond_1

    iget-object p3, p2, Landroid/support/v7/app/G;->menu:Landroid/support/v7/view/menu/r;

    :cond_1
    if-eqz p2, :cond_2

    iget-boolean p2, p2, Landroid/support/v7/app/G;->isOpen:Z

    if-nez p2, :cond_2

    return-void

    :cond_2
    iget-boolean p2, p0, Landroid/support/v7/app/I;->xj:Z

    if-nez p2, :cond_3

    iget-object p0, p0, Landroid/support/v7/app/I;->aj:Landroid/view/Window$Callback;

    invoke-interface {p0, p1, p3}, Landroid/view/Window$Callback;->onPanelClosed(ILandroid/view/Menu;)V

    :cond_3
    return-void
.end method

.method a(Landroid/support/v7/app/G;Z)V
    .locals 3

    if-eqz p2, :cond_0

    iget v0, p1, Landroid/support/v7/app/G;->featureId:I

    if-nez v0, :cond_0

    iget-object v0, p0, Landroid/support/v7/app/I;->mDecorContentParent:Landroid/support/v7/widget/ga;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Landroid/support/v7/widget/ga;->isOverflowMenuShowing()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object p1, p1, Landroid/support/v7/app/G;->menu:Landroid/support/v7/view/menu/r;

    invoke-virtual {p0, p1}, Landroid/support/v7/app/I;->d(Landroid/support/v7/view/menu/r;)V

    return-void

    :cond_0
    iget-object v0, p0, Landroid/support/v7/app/I;->mContext:Landroid/content/Context;

    const-string v1, "window"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/WindowManager;

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    iget-boolean v2, p1, Landroid/support/v7/app/G;->isOpen:Z

    if-eqz v2, :cond_1

    iget-object v2, p1, Landroid/support/v7/app/G;->decorView:Landroid/view/ViewGroup;

    if-eqz v2, :cond_1

    invoke-interface {v0, v2}, Landroid/view/WindowManager;->removeView(Landroid/view/View;)V

    if-eqz p2, :cond_1

    iget p2, p1, Landroid/support/v7/app/G;->featureId:I

    invoke-virtual {p0, p2, p1, v1}, Landroid/support/v7/app/I;->a(ILandroid/support/v7/app/G;Landroid/view/Menu;)V

    :cond_1
    const/4 p2, 0x0

    iput-boolean p2, p1, Landroid/support/v7/app/G;->isPrepared:Z

    iput-boolean p2, p1, Landroid/support/v7/app/G;->isHandled:Z

    iput-boolean p2, p1, Landroid/support/v7/app/G;->isOpen:Z

    iput-object v1, p1, Landroid/support/v7/app/G;->shownPanelView:Landroid/view/View;

    const/4 p2, 0x1

    iput-boolean p2, p1, Landroid/support/v7/app/G;->refreshDecorView:Z

    iget-object p2, p0, Landroid/support/v7/app/I;->mPreparedPanel:Landroid/support/v7/app/G;

    if-ne p2, p1, :cond_2

    iput-object v1, p0, Landroid/support/v7/app/I;->mPreparedPanel:Landroid/support/v7/app/G;

    :cond_2
    return-void
.end method

.method a(Landroid/view/ViewGroup;)V
    .locals 0

    return-void
.end method

.method public addContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    .locals 2

    invoke-direct {p0}, Landroid/support/v7/app/I;->Yf()V

    iget-object v0, p0, Landroid/support/v7/app/I;->mj:Landroid/view/ViewGroup;

    const v1, 0x1020002

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/view/ViewGroup;

    invoke-virtual {v0, p1, p2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object p0, p0, Landroid/support/v7/app/I;->aj:Landroid/view/Window$Callback;

    invoke-interface {p0}, Landroid/view/Window$Callback;->onContentChanged()V

    return-void
.end method

.method public b(Landroid/view/View;Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;
    .locals 11

    iget-object v0, p0, Landroid/support/v7/app/I;->Hj:Landroid/support/v7/app/AppCompatViewInflater;

    const/4 v1, 0x0

    if-nez v0, :cond_2

    iget-object v0, p0, Landroid/support/v7/app/I;->mContext:Landroid/content/Context;

    sget-object v2, La/b/d/a/b;->nk:[I

    invoke-virtual {v0, v2}, Landroid/content/Context;->obtainStyledAttributes([I)Landroid/content/res/TypedArray;

    move-result-object v0

    const/16 v2, 0x6e

    invoke-virtual {v0, v2}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_1

    const-class v2, Landroid/support/v7/app/AppCompatViewInflater;

    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    goto :goto_0

    :cond_0
    :try_start_0
    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v2

    new-array v3, v1, [Ljava/lang/Class;

    invoke-virtual {v2, v3}, Ljava/lang/Class;->getDeclaredConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object v2

    new-array v3, v1, [Ljava/lang/Object;

    invoke-virtual {v2, v3}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/support/v7/app/AppCompatViewInflater;

    iput-object v2, p0, Landroid/support/v7/app/I;->Hj:Landroid/support/v7/app/AppCompatViewInflater;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_2

    :catchall_0
    move-exception v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Failed to instantiate custom view inflater "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ". Falling back to default."

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v3, "AppCompatDelegate"

    invoke-static {v3, v0, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    new-instance v0, Landroid/support/v7/app/AppCompatViewInflater;

    invoke-direct {v0}, Landroid/support/v7/app/AppCompatViewInflater;-><init>()V

    goto :goto_1

    :cond_1
    :goto_0
    new-instance v0, Landroid/support/v7/app/AppCompatViewInflater;

    invoke-direct {v0}, Landroid/support/v7/app/AppCompatViewInflater;-><init>()V

    :goto_1
    iput-object v0, p0, Landroid/support/v7/app/I;->Hj:Landroid/support/v7/app/AppCompatViewInflater;

    :cond_2
    :goto_2
    sget-boolean v0, Landroid/support/v7/app/I;->Ij:Z

    if-eqz v0, :cond_7

    instance-of v0, p4, Lorg/xmlpull/v1/XmlPullParser;

    const/4 v2, 0x1

    if-eqz v0, :cond_3

    move-object v0, p4

    check-cast v0, Lorg/xmlpull/v1/XmlPullParser;

    invoke-interface {v0}, Lorg/xmlpull/v1/XmlPullParser;->getDepth()I

    move-result v0

    if-le v0, v2, :cond_7

    :goto_3
    move v1, v2

    goto :goto_5

    :cond_3
    move-object v0, p1

    check-cast v0, Landroid/view/ViewParent;

    if-nez v0, :cond_4

    goto :goto_5

    .line 1
    :cond_4
    iget-object v3, p0, Landroid/support/v7/app/I;->mWindow:Landroid/view/Window;

    invoke-virtual {v3}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v3

    :goto_4
    if-nez v0, :cond_5

    goto :goto_3

    :cond_5
    if-eq v0, v3, :cond_7

    instance-of v4, v0, Landroid/view/View;

    if-eqz v4, :cond_7

    move-object v4, v0

    check-cast v4, Landroid/view/View;

    invoke-static {v4}, Landroid/support/v4/view/r;->x(Landroid/view/View;)Z

    move-result v4

    if-eqz v4, :cond_6

    goto :goto_5

    :cond_6
    invoke-interface {v0}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    goto :goto_4

    :cond_7
    :goto_5
    move v7, v1

    .line 2
    iget-object v2, p0, Landroid/support/v7/app/I;->Hj:Landroid/support/v7/app/AppCompatViewInflater;

    sget-boolean v8, Landroid/support/v7/app/I;->Ij:Z

    const/4 v9, 0x1

    invoke-static {}, Landroid/support/v7/widget/sc;->pa()Z

    const/4 v10, 0x0

    move-object v3, p1

    move-object v4, p2

    move-object v5, p3

    move-object v6, p4

    invoke-virtual/range {v2 .. v10}, Landroid/support/v7/app/AppCompatViewInflater;->a(Landroid/view/View;Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;ZZZZ)Landroid/view/View;

    move-result-object p0

    return-object p0
.end method

.method public b(Landroid/support/v7/view/menu/r;)V
    .locals 5

    .line 3
    iget-object p1, p0, Landroid/support/v7/app/I;->mDecorContentParent:Landroid/support/v7/widget/ga;

    const/4 v0, 0x1

    const/4 v1, 0x0

    if-eqz p1, :cond_3

    invoke-interface {p1}, Landroid/support/v7/widget/ga;->canShowOverflowMenu()Z

    move-result p1

    if-eqz p1, :cond_3

    iget-object p1, p0, Landroid/support/v7/app/I;->mContext:Landroid/content/Context;

    invoke-static {p1}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/ViewConfiguration;->hasPermanentMenuKey()Z

    move-result p1

    if-eqz p1, :cond_0

    iget-object p1, p0, Landroid/support/v7/app/I;->mDecorContentParent:Landroid/support/v7/widget/ga;

    invoke-interface {p1}, Landroid/support/v7/widget/ga;->isOverflowMenuShowPending()Z

    move-result p1

    if-eqz p1, :cond_3

    :cond_0
    invoke-virtual {p0}, Landroid/support/v7/app/I;->La()Landroid/view/Window$Callback;

    move-result-object p1

    iget-object v2, p0, Landroid/support/v7/app/I;->mDecorContentParent:Landroid/support/v7/widget/ga;

    invoke-interface {v2}, Landroid/support/v7/widget/ga;->isOverflowMenuShowing()Z

    move-result v2

    const/16 v3, 0x6c

    if-eqz v2, :cond_1

    iget-object v2, p0, Landroid/support/v7/app/I;->mDecorContentParent:Landroid/support/v7/widget/ga;

    invoke-interface {v2}, Landroid/support/v7/widget/ga;->hideOverflowMenu()Z

    iget-boolean v2, p0, Landroid/support/v7/app/I;->xj:Z

    if-nez v2, :cond_4

    invoke-virtual {p0, v1, v0}, Landroid/support/v7/app/I;->getPanelState(IZ)Landroid/support/v7/app/G;

    move-result-object p0

    iget-object p0, p0, Landroid/support/v7/app/G;->menu:Landroid/support/v7/view/menu/r;

    invoke-interface {p1, v3, p0}, Landroid/view/Window$Callback;->onPanelClosed(ILandroid/view/Menu;)V

    goto :goto_0

    :cond_1
    if-eqz p1, :cond_4

    iget-boolean v2, p0, Landroid/support/v7/app/I;->xj:Z

    if-nez v2, :cond_4

    iget-boolean v2, p0, Landroid/support/v7/app/I;->Bj:Z

    if-eqz v2, :cond_2

    iget v2, p0, Landroid/support/v7/app/I;->Cj:I

    and-int/2addr v2, v0

    if-eqz v2, :cond_2

    iget-object v2, p0, Landroid/support/v7/app/I;->mWindow:Landroid/view/Window;

    invoke-virtual {v2}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v2

    iget-object v4, p0, Landroid/support/v7/app/I;->Dj:Ljava/lang/Runnable;

    invoke-virtual {v2, v4}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    iget-object v2, p0, Landroid/support/v7/app/I;->Dj:Ljava/lang/Runnable;

    invoke-interface {v2}, Ljava/lang/Runnable;->run()V

    :cond_2
    invoke-virtual {p0, v1, v0}, Landroid/support/v7/app/I;->getPanelState(IZ)Landroid/support/v7/app/G;

    move-result-object v0

    iget-object v2, v0, Landroid/support/v7/app/G;->menu:Landroid/support/v7/view/menu/r;

    if-eqz v2, :cond_4

    iget-boolean v4, v0, Landroid/support/v7/app/G;->refreshMenuContent:Z

    if-nez v4, :cond_4

    iget-object v4, v0, Landroid/support/v7/app/G;->createdPanelView:Landroid/view/View;

    invoke-interface {p1, v1, v4, v2}, Landroid/view/Window$Callback;->onPreparePanel(ILandroid/view/View;Landroid/view/Menu;)Z

    move-result v1

    if-eqz v1, :cond_4

    iget-object v0, v0, Landroid/support/v7/app/G;->menu:Landroid/support/v7/view/menu/r;

    invoke-interface {p1, v3, v0}, Landroid/view/Window$Callback;->onMenuOpened(ILandroid/view/Menu;)Z

    iget-object p0, p0, Landroid/support/v7/app/I;->mDecorContentParent:Landroid/support/v7/widget/ga;

    invoke-interface {p0}, Landroid/support/v7/widget/ga;->showOverflowMenu()Z

    goto :goto_0

    :cond_3
    invoke-virtual {p0, v1, v0}, Landroid/support/v7/app/I;->getPanelState(IZ)Landroid/support/v7/app/G;

    move-result-object p1

    iput-boolean v0, p1, Landroid/support/v7/app/G;->refreshDecorView:Z

    invoke-virtual {p0, p1, v1}, Landroid/support/v7/app/I;->a(Landroid/support/v7/app/G;Z)V

    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, Landroid/support/v7/app/I;->a(Landroid/support/v7/app/G;Landroid/view/KeyEvent;)V

    :cond_4
    :goto_0
    return-void
.end method

.method public c(La/b/d/e/b;)La/b/d/e/c;
    .locals 2

    if-eqz p1, :cond_3

    iget-object v0, p0, Landroid/support/v7/app/I;->mActionMode:La/b/d/e/c;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, La/b/d/e/c;->finish()V

    :cond_0
    new-instance v0, Landroid/support/v7/app/B;

    invoke-direct {v0, p0, p1}, Landroid/support/v7/app/B;-><init>(Landroid/support/v7/app/I;La/b/d/e/b;)V

    invoke-virtual {p0}, Landroid/support/v7/app/I;->Y()Landroid/support/v7/app/c;

    move-result-object p1

    if-eqz p1, :cond_1

    invoke-virtual {p1, v0}, Landroid/support/v7/app/c;->b(La/b/d/e/b;)La/b/d/e/c;

    move-result-object p1

    iput-object p1, p0, Landroid/support/v7/app/I;->mActionMode:La/b/d/e/c;

    iget-object p1, p0, Landroid/support/v7/app/I;->mActionMode:La/b/d/e/c;

    if-eqz p1, :cond_1

    iget-object v1, p0, Landroid/support/v7/app/I;->cj:Landroid/support/v7/app/q;

    if-eqz v1, :cond_1

    invoke-interface {v1, p1}, Landroid/support/v7/app/q;->b(La/b/d/e/c;)V

    :cond_1
    iget-object p1, p0, Landroid/support/v7/app/I;->mActionMode:La/b/d/e/c;

    if-nez p1, :cond_2

    invoke-virtual {p0, v0}, Landroid/support/v7/app/I;->d(La/b/d/e/b;)La/b/d/e/c;

    move-result-object p1

    iput-object p1, p0, Landroid/support/v7/app/I;->mActionMode:La/b/d/e/c;

    :cond_2
    iget-object p0, p0, Landroid/support/v7/app/I;->mActionMode:La/b/d/e/c;

    return-object p0

    :cond_3
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "ActionMode callback can not be null."

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public c(Landroid/support/v7/view/menu/r;Landroid/view/MenuItem;)Z
    .locals 2

    invoke-virtual {p0}, Landroid/support/v7/app/I;->La()Landroid/view/Window$Callback;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-boolean v1, p0, Landroid/support/v7/app/I;->xj:Z

    if-nez v1, :cond_0

    invoke-virtual {p1}, Landroid/support/v7/view/menu/r;->getRootMenu()Landroid/support/v7/view/menu/r;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/support/v7/app/I;->findMenuPanel(Landroid/view/Menu;)Landroid/support/v7/app/G;

    move-result-object p0

    if-eqz p0, :cond_0

    iget p0, p0, Landroid/support/v7/app/G;->featureId:I

    invoke-interface {v0, p0, p2}, Landroid/view/Window$Callback;->onMenuItemSelected(ILandroid/view/MenuItem;)Z

    move-result p0

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method closePanel(I)V
    .locals 1

    const/4 v0, 0x1

    invoke-virtual {p0, p1, v0}, Landroid/support/v7/app/I;->getPanelState(IZ)Landroid/support/v7/app/G;

    move-result-object p1

    invoke-virtual {p0, p1, v0}, Landroid/support/v7/app/I;->a(Landroid/support/v7/app/G;Z)V

    return-void
.end method

.method d(La/b/d/e/b;)La/b/d/e/c;
    .locals 8

    invoke-virtual {p0}, Landroid/support/v7/app/I;->Ja()V

    iget-object v0, p0, Landroid/support/v7/app/I;->mActionMode:La/b/d/e/c;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, La/b/d/e/c;->finish()V

    :cond_0
    instance-of v0, p1, Landroid/support/v7/app/B;

    if-nez v0, :cond_1

    new-instance v0, Landroid/support/v7/app/B;

    invoke-direct {v0, p0, p1}, Landroid/support/v7/app/B;-><init>(Landroid/support/v7/app/I;La/b/d/e/b;)V

    move-object p1, v0

    :cond_1
    iget-object v0, p0, Landroid/support/v7/app/I;->cj:Landroid/support/v7/app/q;

    const/4 v1, 0x0

    if-eqz v0, :cond_2

    iget-boolean v2, p0, Landroid/support/v7/app/I;->xj:Z

    if-nez v2, :cond_2

    :try_start_0
    invoke-interface {v0, p1}, Landroid/support/v7/app/q;->a(La/b/d/e/b;)La/b/d/e/c;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/AbstractMethodError; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    :cond_2
    move-object v0, v1

    :goto_0
    if-eqz v0, :cond_3

    iput-object v0, p0, Landroid/support/v7/app/I;->mActionMode:La/b/d/e/c;

    goto/16 :goto_5

    :cond_3
    iget-object v0, p0, Landroid/support/v7/app/I;->gj:Landroid/support/v7/widget/ActionBarContextView;

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-nez v0, :cond_6

    iget-boolean v0, p0, Landroid/support/v7/app/I;->mIsFloating:Z

    if-eqz v0, :cond_5

    new-instance v0, Landroid/util/TypedValue;

    invoke-direct {v0}, Landroid/util/TypedValue;-><init>()V

    iget-object v4, p0, Landroid/support/v7/app/I;->mContext:Landroid/content/Context;

    invoke-virtual {v4}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v4

    const v5, 0x7f030009

    invoke-virtual {v4, v5, v0, v3}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    iget v5, v0, Landroid/util/TypedValue;->resourceId:I

    if-eqz v5, :cond_4

    iget-object v5, p0, Landroid/support/v7/app/I;->mContext:Landroid/content/Context;

    invoke-virtual {v5}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {v5}, Landroid/content/res/Resources;->newTheme()Landroid/content/res/Resources$Theme;

    move-result-object v5

    invoke-virtual {v5, v4}, Landroid/content/res/Resources$Theme;->setTo(Landroid/content/res/Resources$Theme;)V

    iget v4, v0, Landroid/util/TypedValue;->resourceId:I

    invoke-virtual {v5, v4, v3}, Landroid/content/res/Resources$Theme;->applyStyle(IZ)V

    new-instance v4, La/b/d/e/e;

    iget-object v6, p0, Landroid/support/v7/app/I;->mContext:Landroid/content/Context;

    invoke-direct {v4, v6, v2}, La/b/d/e/e;-><init>(Landroid/content/Context;I)V

    invoke-virtual {v4}, La/b/d/e/e;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v6

    invoke-virtual {v6, v5}, Landroid/content/res/Resources$Theme;->setTo(Landroid/content/res/Resources$Theme;)V

    goto :goto_1

    :cond_4
    iget-object v4, p0, Landroid/support/v7/app/I;->mContext:Landroid/content/Context;

    :goto_1
    new-instance v5, Landroid/support/v7/widget/ActionBarContextView;

    invoke-direct {v5, v4}, Landroid/support/v7/widget/ActionBarContextView;-><init>(Landroid/content/Context;)V

    iput-object v5, p0, Landroid/support/v7/app/I;->gj:Landroid/support/v7/widget/ActionBarContextView;

    new-instance v5, Landroid/widget/PopupWindow;

    const v6, 0x7f030017

    invoke-direct {v5, v4, v1, v6}, Landroid/widget/PopupWindow;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    iput-object v5, p0, Landroid/support/v7/app/I;->hj:Landroid/widget/PopupWindow;

    iget-object v5, p0, Landroid/support/v7/app/I;->hj:Landroid/widget/PopupWindow;

    const/4 v6, 0x2

    .line 1
    sget v7, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-virtual {v5, v6}, Landroid/widget/PopupWindow;->setWindowLayoutType(I)V

    .line 2
    iget-object v5, p0, Landroid/support/v7/app/I;->hj:Landroid/widget/PopupWindow;

    iget-object v6, p0, Landroid/support/v7/app/I;->gj:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {v5, v6}, Landroid/widget/PopupWindow;->setContentView(Landroid/view/View;)V

    iget-object v5, p0, Landroid/support/v7/app/I;->hj:Landroid/widget/PopupWindow;

    const/4 v6, -0x1

    invoke-virtual {v5, v6}, Landroid/widget/PopupWindow;->setWidth(I)V

    invoke-virtual {v4}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v5

    const v6, 0x7f030003

    invoke-virtual {v5, v6, v0, v3}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    iget v0, v0, Landroid/util/TypedValue;->data:I

    invoke-virtual {v4}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    invoke-virtual {v4}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v4

    invoke-static {v0, v4}, Landroid/util/TypedValue;->complexToDimensionPixelSize(ILandroid/util/DisplayMetrics;)I

    move-result v0

    iget-object v4, p0, Landroid/support/v7/app/I;->gj:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {v4, v0}, Landroid/support/v7/widget/ActionBarContextView;->setContentHeight(I)V

    iget-object v0, p0, Landroid/support/v7/app/I;->hj:Landroid/widget/PopupWindow;

    const/4 v4, -0x2

    invoke-virtual {v0, v4}, Landroid/widget/PopupWindow;->setHeight(I)V

    new-instance v0, Landroid/support/v7/app/x;

    invoke-direct {v0, p0}, Landroid/support/v7/app/x;-><init>(Landroid/support/v7/app/I;)V

    iput-object v0, p0, Landroid/support/v7/app/I;->ij:Ljava/lang/Runnable;

    goto :goto_2

    :cond_5
    iget-object v0, p0, Landroid/support/v7/app/I;->mj:Landroid/view/ViewGroup;

    const v4, 0x7f080015

    invoke-virtual {v0, v4}, Landroid/view/ViewGroup;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/support/v7/widget/ViewStubCompat;

    if-eqz v0, :cond_6

    invoke-virtual {p0}, Landroid/support/v7/app/I;->Ka()Landroid/content/Context;

    move-result-object v4

    invoke-static {v4}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v4

    invoke-virtual {v0, v4}, Landroid/support/v7/widget/ViewStubCompat;->setLayoutInflater(Landroid/view/LayoutInflater;)V

    invoke-virtual {v0}, Landroid/support/v7/widget/ViewStubCompat;->inflate()Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/support/v7/widget/ActionBarContextView;

    iput-object v0, p0, Landroid/support/v7/app/I;->gj:Landroid/support/v7/widget/ActionBarContextView;

    :cond_6
    :goto_2
    iget-object v0, p0, Landroid/support/v7/app/I;->gj:Landroid/support/v7/widget/ActionBarContextView;

    if-eqz v0, :cond_b

    invoke-virtual {p0}, Landroid/support/v7/app/I;->Ja()V

    iget-object v0, p0, Landroid/support/v7/app/I;->gj:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {v0}, Landroid/support/v7/widget/ActionBarContextView;->killMode()V

    new-instance v0, La/b/d/e/f;

    iget-object v4, p0, Landroid/support/v7/app/I;->gj:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {v4}, Landroid/view/ViewGroup;->getContext()Landroid/content/Context;

    move-result-object v4

    iget-object v5, p0, Landroid/support/v7/app/I;->gj:Landroid/support/v7/widget/ActionBarContextView;

    iget-object v6, p0, Landroid/support/v7/app/I;->hj:Landroid/widget/PopupWindow;

    if-nez v6, :cond_7

    goto :goto_3

    :cond_7
    move v3, v2

    :goto_3
    invoke-direct {v0, v4, v5, p1, v3}, La/b/d/e/f;-><init>(Landroid/content/Context;Landroid/support/v7/widget/ActionBarContextView;La/b/d/e/b;Z)V

    invoke-virtual {v0}, La/b/d/e/f;->getMenu()Landroid/view/Menu;

    move-result-object v3

    invoke-interface {p1, v0, v3}, La/b/d/e/b;->a(La/b/d/e/c;Landroid/view/Menu;)Z

    move-result p1

    if-eqz p1, :cond_a

    invoke-virtual {v0}, La/b/d/e/f;->invalidate()V

    iget-object p1, p0, Landroid/support/v7/app/I;->gj:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {p1, v0}, Landroid/support/v7/widget/ActionBarContextView;->e(La/b/d/e/c;)V

    iput-object v0, p0, Landroid/support/v7/app/I;->mActionMode:La/b/d/e/c;

    invoke-virtual {p0}, Landroid/support/v7/app/I;->Oa()Z

    move-result p1

    const/high16 v0, 0x3f800000    # 1.0f

    if-eqz p1, :cond_8

    iget-object p1, p0, Landroid/support/v7/app/I;->gj:Landroid/support/v7/widget/ActionBarContextView;

    const/4 v1, 0x0

    invoke-virtual {p1, v1}, Landroid/view/ViewGroup;->setAlpha(F)V

    iget-object p1, p0, Landroid/support/v7/app/I;->gj:Landroid/support/v7/widget/ActionBarContextView;

    invoke-static {p1}, Landroid/support/v4/view/r;->j(Landroid/view/View;)Landroid/support/v4/view/w;

    move-result-object p1

    invoke-virtual {p1, v0}, Landroid/support/v4/view/w;->alpha(F)Landroid/support/v4/view/w;

    iput-object p1, p0, Landroid/support/v7/app/I;->jj:Landroid/support/v4/view/w;

    iget-object p1, p0, Landroid/support/v7/app/I;->jj:Landroid/support/v4/view/w;

    new-instance v0, Landroid/support/v7/app/y;

    invoke-direct {v0, p0}, Landroid/support/v7/app/y;-><init>(Landroid/support/v7/app/I;)V

    invoke-virtual {p1, v0}, Landroid/support/v4/view/w;->a(Landroid/support/v4/view/x;)Landroid/support/v4/view/w;

    goto :goto_4

    :cond_8
    iget-object p1, p0, Landroid/support/v7/app/I;->gj:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->setAlpha(F)V

    iget-object p1, p0, Landroid/support/v7/app/I;->gj:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {p1, v2}, Landroid/support/v7/widget/ActionBarContextView;->setVisibility(I)V

    iget-object p1, p0, Landroid/support/v7/app/I;->gj:Landroid/support/v7/widget/ActionBarContextView;

    const/16 v0, 0x20

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->sendAccessibilityEvent(I)V

    iget-object p1, p0, Landroid/support/v7/app/I;->gj:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {p1}, Landroid/view/ViewGroup;->getParent()Landroid/view/ViewParent;

    move-result-object p1

    instance-of p1, p1, Landroid/view/View;

    if-eqz p1, :cond_9

    iget-object p1, p0, Landroid/support/v7/app/I;->gj:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {p1}, Landroid/view/ViewGroup;->getParent()Landroid/view/ViewParent;

    move-result-object p1

    check-cast p1, Landroid/view/View;

    invoke-static {p1}, Landroid/support/v4/view/r;->A(Landroid/view/View;)V

    :cond_9
    :goto_4
    iget-object p1, p0, Landroid/support/v7/app/I;->hj:Landroid/widget/PopupWindow;

    if-eqz p1, :cond_b

    iget-object p1, p0, Landroid/support/v7/app/I;->mWindow:Landroid/view/Window;

    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p1

    iget-object v0, p0, Landroid/support/v7/app/I;->ij:Ljava/lang/Runnable;

    invoke-virtual {p1, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    goto :goto_5

    :cond_a
    iput-object v1, p0, Landroid/support/v7/app/I;->mActionMode:La/b/d/e/c;

    :cond_b
    :goto_5
    iget-object p1, p0, Landroid/support/v7/app/I;->mActionMode:La/b/d/e/c;

    if-eqz p1, :cond_c

    iget-object v0, p0, Landroid/support/v7/app/I;->cj:Landroid/support/v7/app/q;

    if-eqz v0, :cond_c

    invoke-interface {v0, p1}, Landroid/support/v7/app/q;->b(La/b/d/e/c;)V

    :cond_c
    iget-object p0, p0, Landroid/support/v7/app/I;->mActionMode:La/b/d/e/c;

    return-object p0
.end method

.method d(Landroid/support/v7/view/menu/r;)V
    .locals 2

    iget-boolean v0, p0, Landroid/support/v7/app/I;->uj:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v7/app/I;->uj:Z

    iget-object v0, p0, Landroid/support/v7/app/I;->mDecorContentParent:Landroid/support/v7/widget/ga;

    invoke-interface {v0}, Landroid/support/v7/widget/ga;->dismissPopups()V

    invoke-virtual {p0}, Landroid/support/v7/app/I;->La()Landroid/view/Window$Callback;

    move-result-object v0

    if-eqz v0, :cond_1

    iget-boolean v1, p0, Landroid/support/v7/app/I;->xj:Z

    if-nez v1, :cond_1

    const/16 v1, 0x6c

    invoke-interface {v0, v1, p1}, Landroid/view/Window$Callback;->onPanelClosed(ILandroid/view/Menu;)V

    :cond_1
    const/4 p1, 0x0

    iput-boolean p1, p0, Landroid/support/v7/app/I;->uj:Z

    return-void
.end method

.method dismissPopups()V
    .locals 2

    iget-object v0, p0, Landroid/support/v7/app/I;->mDecorContentParent:Landroid/support/v7/widget/ga;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Landroid/support/v7/widget/ga;->dismissPopups()V

    :cond_0
    iget-object v0, p0, Landroid/support/v7/app/I;->hj:Landroid/widget/PopupWindow;

    if-eqz v0, :cond_2

    iget-object v0, p0, Landroid/support/v7/app/I;->mWindow:Landroid/view/Window;

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    iget-object v1, p0, Landroid/support/v7/app/I;->ij:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    iget-object v0, p0, Landroid/support/v7/app/I;->hj:Landroid/widget/PopupWindow;

    invoke-virtual {v0}, Landroid/widget/PopupWindow;->isShowing()Z

    move-result v0

    if-eqz v0, :cond_1

    :try_start_0
    iget-object v0, p0, Landroid/support/v7/app/I;->hj:Landroid/widget/PopupWindow;

    invoke-virtual {v0}, Landroid/widget/PopupWindow;->dismiss()V
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_1
    const/4 v0, 0x0

    iput-object v0, p0, Landroid/support/v7/app/I;->hj:Landroid/widget/PopupWindow;

    :cond_2
    invoke-virtual {p0}, Landroid/support/v7/app/I;->Ja()V

    const/4 v0, 0x0

    invoke-virtual {p0, v0, v0}, Landroid/support/v7/app/I;->getPanelState(IZ)Landroid/support/v7/app/G;

    move-result-object p0

    if-eqz p0, :cond_3

    iget-object p0, p0, Landroid/support/v7/app/G;->menu:Landroid/support/v7/view/menu/r;

    if-eqz p0, :cond_3

    const/4 v0, 0x1

    .line 1
    invoke-virtual {p0, v0}, Landroid/support/v7/view/menu/r;->close(Z)V

    :cond_3
    return-void
.end method

.method dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    .locals 4

    iget-object v0, p0, Landroid/support/v7/app/I;->mWindow:Landroid/view/Window;

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    invoke-static {v0, p1}, Landroid/support/v4/view/r;->a(Landroid/view/View;Landroid/view/KeyEvent;)Z

    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result v0

    const/16 v1, 0x52

    const/4 v2, 0x1

    if-ne v0, v1, :cond_0

    iget-object v0, p0, Landroid/support/v7/app/I;->aj:Landroid/view/Window$Callback;

    invoke-interface {v0, p1}, Landroid/view/Window$Callback;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z

    move-result v0

    if-eqz v0, :cond_0

    return v2

    :cond_0
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result v0

    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    move-result v1

    const/4 v3, 0x0

    if-nez v1, :cond_1

    move v1, v2

    goto :goto_0

    :cond_1
    move v1, v3

    :goto_0
    if-eqz v1, :cond_2

    invoke-virtual {p0, v0, p1}, Landroid/support/v7/app/I;->onKeyDown(ILandroid/view/KeyEvent;)Z

    move-result p0

    if-eqz p0, :cond_3

    goto :goto_1

    :cond_2
    invoke-virtual {p0, v0, p1}, Landroid/support/v7/app/I;->onKeyUp(ILandroid/view/KeyEvent;)Z

    move-result p0

    if-eqz p0, :cond_3

    :goto_1
    return v2

    .line 1
    :cond_3
    sget p0, Landroid/os/Build$VERSION;->SDK_INT:I

    return v3
.end method

.method doInvalidatePanelMenu(I)V
    .locals 4

    const/4 v0, 0x1

    invoke-virtual {p0, p1, v0}, Landroid/support/v7/app/I;->getPanelState(IZ)Landroid/support/v7/app/G;

    move-result-object v1

    iget-object v2, v1, Landroid/support/v7/app/G;->menu:Landroid/support/v7/view/menu/r;

    if-eqz v2, :cond_1

    new-instance v2, Landroid/os/Bundle;

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    iget-object v3, v1, Landroid/support/v7/app/G;->menu:Landroid/support/v7/view/menu/r;

    invoke-virtual {v3, v2}, Landroid/support/v7/view/menu/r;->saveActionViewStates(Landroid/os/Bundle;)V

    invoke-virtual {v2}, Landroid/os/Bundle;->size()I

    move-result v3

    if-lez v3, :cond_0

    iput-object v2, v1, Landroid/support/v7/app/G;->frozenActionViewState:Landroid/os/Bundle;

    :cond_0
    iget-object v2, v1, Landroid/support/v7/app/G;->menu:Landroid/support/v7/view/menu/r;

    invoke-virtual {v2}, Landroid/support/v7/view/menu/r;->stopDispatchingItemsChanged()V

    iget-object v2, v1, Landroid/support/v7/app/G;->menu:Landroid/support/v7/view/menu/r;

    invoke-virtual {v2}, Landroid/support/v7/view/menu/r;->clear()V

    :cond_1
    iput-boolean v0, v1, Landroid/support/v7/app/G;->refreshMenuContent:Z

    iput-boolean v0, v1, Landroid/support/v7/app/G;->refreshDecorView:Z

    const/16 v0, 0x6c

    if-eq p1, v0, :cond_2

    if-nez p1, :cond_3

    :cond_2
    iget-object p1, p0, Landroid/support/v7/app/I;->mDecorContentParent:Landroid/support/v7/widget/ga;

    if-eqz p1, :cond_3

    const/4 p1, 0x0

    invoke-virtual {p0, p1, p1}, Landroid/support/v7/app/I;->getPanelState(IZ)Landroid/support/v7/app/G;

    move-result-object v0

    if-eqz v0, :cond_3

    iput-boolean p1, v0, Landroid/support/v7/app/G;->isPrepared:Z

    const/4 p1, 0x0

    invoke-direct {p0, v0, p1}, Landroid/support/v7/app/I;->b(Landroid/support/v7/app/G;Landroid/view/KeyEvent;)Z

    :cond_3
    return-void
.end method

.method findMenuPanel(Landroid/view/Menu;)Landroid/support/v7/app/G;
    .locals 4

    iget-object p0, p0, Landroid/support/v7/app/I;->vj:[Landroid/support/v7/app/G;

    const/4 v0, 0x0

    if-eqz p0, :cond_0

    array-length v1, p0

    goto :goto_0

    :cond_0
    move v1, v0

    :goto_0
    if-ge v0, v1, :cond_2

    aget-object v2, p0, v0

    if-eqz v2, :cond_1

    iget-object v3, v2, Landroid/support/v7/app/G;->menu:Landroid/support/v7/view/menu/r;

    if-ne v3, p1, :cond_1

    return-object v2

    :cond_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_2
    const/4 p0, 0x0

    return-object p0
.end method

.method public findViewById(I)Landroid/view/View;
    .locals 0

    invoke-direct {p0}, Landroid/support/v7/app/I;->Yf()V

    iget-object p0, p0, Landroid/support/v7/app/I;->mWindow:Landroid/view/Window;

    invoke-virtual {p0, p1}, Landroid/view/Window;->findViewById(I)Landroid/view/View;

    move-result-object p0

    return-object p0
.end method

.method final getAutoNightModeManager()Landroid/support/v7/app/AppCompatDelegateImpl$AutoNightModeManager;
    .locals 0

    invoke-direct {p0}, Landroid/support/v7/app/I;->Xf()V

    iget-object p0, p0, Landroid/support/v7/app/I;->Aj:Landroid/support/v7/app/AppCompatDelegateImpl$AutoNightModeManager;

    return-object p0
.end method

.method public getMenuInflater()Landroid/view/MenuInflater;
    .locals 2

    iget-object v0, p0, Landroid/support/v7/app/I;->dj:Landroid/view/MenuInflater;

    if-nez v0, :cond_1

    invoke-direct {p0}, Landroid/support/v7/app/I;->Zf()V

    new-instance v0, La/b/d/e/k;

    iget-object v1, p0, Landroid/support/v7/app/I;->mActionBar:Landroid/support/v7/app/c;

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Landroid/support/v7/app/c;->getThemedContext()Landroid/content/Context;

    move-result-object v1

    goto :goto_0

    :cond_0
    iget-object v1, p0, Landroid/support/v7/app/I;->mContext:Landroid/content/Context;

    :goto_0
    invoke-direct {v0, v1}, La/b/d/e/k;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Landroid/support/v7/app/I;->dj:Landroid/view/MenuInflater;

    :cond_1
    iget-object p0, p0, Landroid/support/v7/app/I;->dj:Landroid/view/MenuInflater;

    return-object p0
.end method

.method protected getPanelState(IZ)Landroid/support/v7/app/G;
    .locals 3

    iget-object p2, p0, Landroid/support/v7/app/I;->vj:[Landroid/support/v7/app/G;

    if-eqz p2, :cond_0

    array-length v0, p2

    if-gt v0, p1, :cond_2

    :cond_0
    add-int/lit8 v0, p1, 0x1

    new-array v0, v0, [Landroid/support/v7/app/G;

    if-eqz p2, :cond_1

    array-length v1, p2

    const/4 v2, 0x0

    invoke-static {p2, v2, v0, v2, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    :cond_1
    iput-object v0, p0, Landroid/support/v7/app/I;->vj:[Landroid/support/v7/app/G;

    move-object p2, v0

    :cond_2
    aget-object p0, p2, p1

    if-nez p0, :cond_3

    new-instance p0, Landroid/support/v7/app/G;

    invoke-direct {p0, p1}, Landroid/support/v7/app/G;-><init>(I)V

    aput-object p0, p2, p1

    :cond_3
    return-object p0
.end method

.method final getTitle()Ljava/lang/CharSequence;
    .locals 2

    iget-object v0, p0, Landroid/support/v7/app/I;->aj:Landroid/view/Window$Callback;

    instance-of v1, v0, Landroid/app/Activity;

    if-eqz v1, :cond_0

    check-cast v0, Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->getTitle()Ljava/lang/CharSequence;

    move-result-object p0

    return-object p0

    :cond_0
    iget-object p0, p0, Landroid/support/v7/app/I;->mTitle:Ljava/lang/CharSequence;

    return-object p0
.end method

.method public invalidateOptionsMenu()V
    .locals 1

    invoke-virtual {p0}, Landroid/support/v7/app/I;->Y()Landroid/support/v7/app/c;

    move-result-object v0

    const/4 v0, 0x0

    invoke-direct {p0, v0}, Landroid/support/v7/app/I;->invalidatePanelMenu(I)V

    return-void
.end method

.method onBackPressed()Z
    .locals 2

    iget-object v0, p0, Landroid/support/v7/app/I;->mActionMode:La/b/d/e/c;

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    invoke-virtual {v0}, La/b/d/e/c;->finish()V

    return v1

    :cond_0
    invoke-virtual {p0}, Landroid/support/v7/app/I;->Y()Landroid/support/v7/app/c;

    move-result-object p0

    if-eqz p0, :cond_1

    invoke-virtual {p0}, Landroid/support/v7/app/c;->collapseActionView()Z

    move-result p0

    if-eqz p0, :cond_1

    return v1

    :cond_1
    const/4 p0, 0x0

    return p0
.end method

.method public onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 1

    iget-boolean v0, p0, Landroid/support/v7/app/I;->qj:Z

    if-eqz v0, :cond_0

    iget-boolean v0, p0, Landroid/support/v7/app/I;->lj:Z

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Landroid/support/v7/app/I;->Y()Landroid/support/v7/app/c;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Landroid/support/v7/app/c;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    :cond_0
    invoke-static {}, Landroid/support/v7/widget/F;->get()Landroid/support/v7/widget/F;

    move-result-object p1

    iget-object v0, p0, Landroid/support/v7/app/I;->mContext:Landroid/content/Context;

    invoke-virtual {p1, v0}, Landroid/support/v7/widget/F;->e(Landroid/content/Context;)V

    invoke-virtual {p0}, Landroid/support/v7/app/I;->Ha()Z

    return-void
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .locals 3

    iget-object v0, p0, Landroid/support/v7/app/I;->aj:Landroid/view/Window$Callback;

    instance-of v1, v0, Landroid/app/Activity;

    if-eqz v1, :cond_1

    const/4 v1, 0x0

    :try_start_0
    check-cast v0, Landroid/app/Activity;
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_1

    .line 1
    :try_start_1
    invoke-virtual {v0}, Landroid/app/Activity;->getComponentName()Landroid/content/ComponentName;

    move-result-object v2

    invoke-static {v0, v2}, La/b/a/a;->b(Landroid/content/Context;Landroid/content/ComponentName;)Ljava/lang/String;

    move-result-object v1
    :try_end_1
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_0

    :catch_0
    move-exception v0

    :try_start_2
    new-instance v2, Ljava/lang/IllegalArgumentException;

    invoke-direct {v2, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/Throwable;)V

    throw v2
    :try_end_2
    .catch Ljava/lang/IllegalArgumentException; {:try_start_2 .. :try_end_2} :catch_1

    :catch_1
    :goto_0
    if-eqz v1, :cond_1

    .line 2
    invoke-virtual {p0}, Landroid/support/v7/app/I;->Na()Landroid/support/v7/app/c;

    move-result-object v0

    const/4 v1, 0x1

    if-nez v0, :cond_0

    iput-boolean v1, p0, Landroid/support/v7/app/I;->Ej:Z

    goto :goto_1

    :cond_0
    invoke-virtual {v0, v1}, Landroid/support/v7/app/c;->setDefaultDisplayHomeAsUpEnabled(Z)V

    :cond_1
    :goto_1
    if-eqz p1, :cond_2

    iget v0, p0, Landroid/support/v7/app/I;->yj:I

    const/16 v1, -0x64

    if-ne v0, v1, :cond_2

    const-string v0, "appcompat:local_night_mode"

    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->getInt(Ljava/lang/String;I)I

    move-result p1

    iput p1, p0, Landroid/support/v7/app/I;->yj:I

    :cond_2
    return-void
.end method

.method public final onCreateView(Landroid/view/View;Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;
    .locals 0

    invoke-virtual {p0, p1, p2, p3, p4}, Landroid/support/v7/app/I;->b(Landroid/view/View;Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;

    move-result-object p0

    return-object p0
.end method

.method public onCreateView(Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;
    .locals 1

    const/4 v0, 0x0

    invoke-virtual {p0, v0, p1, p2, p3}, Landroid/support/v7/app/I;->onCreateView(Landroid/view/View;Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;

    move-result-object p0

    return-object p0
.end method

.method public onDestroy()V
    .locals 2

    iget-boolean v0, p0, Landroid/support/v7/app/I;->Bj:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroid/support/v7/app/I;->mWindow:Landroid/view/Window;

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    iget-object v1, p0, Landroid/support/v7/app/I;->Dj:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v7/app/I;->xj:Z

    iget-object v0, p0, Landroid/support/v7/app/I;->mActionBar:Landroid/support/v7/app/c;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Landroid/support/v7/app/c;->onDestroy()V

    :cond_1
    iget-object p0, p0, Landroid/support/v7/app/I;->Aj:Landroid/support/v7/app/AppCompatDelegateImpl$AutoNightModeManager;

    if-eqz p0, :cond_2

    invoke-virtual {p0}, Landroid/support/v7/app/AppCompatDelegateImpl$AutoNightModeManager;->cleanup()V

    :cond_2
    return-void
.end method

.method onKeyDown(ILandroid/view/KeyEvent;)Z
    .locals 3

    const/4 v0, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eq p1, v0, :cond_2

    const/16 v0, 0x52

    if-eq p1, v0, :cond_0

    goto :goto_1

    .line 1
    :cond_0
    invoke-virtual {p2}, Landroid/view/KeyEvent;->getRepeatCount()I

    move-result p1

    if-nez p1, :cond_1

    invoke-virtual {p0, v2, v1}, Landroid/support/v7/app/I;->getPanelState(IZ)Landroid/support/v7/app/G;

    move-result-object p1

    iget-boolean v0, p1, Landroid/support/v7/app/G;->isOpen:Z

    if-nez v0, :cond_1

    invoke-direct {p0, p1, p2}, Landroid/support/v7/app/I;->b(Landroid/support/v7/app/G;Landroid/view/KeyEvent;)Z

    :cond_1
    return v1

    .line 2
    :cond_2
    invoke-virtual {p2}, Landroid/view/KeyEvent;->getFlags()I

    move-result p1

    and-int/lit16 p1, p1, 0x80

    if-eqz p1, :cond_3

    goto :goto_0

    :cond_3
    move v1, v2

    :goto_0
    iput-boolean v1, p0, Landroid/support/v7/app/I;->wj:Z

    :goto_1
    return v2
.end method

.method onKeyShortcut(ILandroid/view/KeyEvent;)Z
    .locals 3

    invoke-virtual {p0}, Landroid/support/v7/app/I;->Y()Landroid/support/v7/app/c;

    move-result-object v0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1, p2}, Landroid/support/v7/app/c;->onKeyShortcut(ILandroid/view/KeyEvent;)Z

    move-result p1

    if-eqz p1, :cond_0

    return v1

    :cond_0
    iget-object p1, p0, Landroid/support/v7/app/I;->mPreparedPanel:Landroid/support/v7/app/G;

    if-eqz p1, :cond_2

    invoke-virtual {p2}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result v0

    invoke-direct {p0, p1, v0, p2, v1}, Landroid/support/v7/app/I;->a(Landroid/support/v7/app/G;ILandroid/view/KeyEvent;I)Z

    move-result p1

    if-eqz p1, :cond_2

    iget-object p0, p0, Landroid/support/v7/app/I;->mPreparedPanel:Landroid/support/v7/app/G;

    if-eqz p0, :cond_1

    iput-boolean v1, p0, Landroid/support/v7/app/G;->isHandled:Z

    :cond_1
    return v1

    :cond_2
    iget-object p1, p0, Landroid/support/v7/app/I;->mPreparedPanel:Landroid/support/v7/app/G;

    const/4 v0, 0x0

    if-nez p1, :cond_3

    invoke-virtual {p0, v0, v1}, Landroid/support/v7/app/I;->getPanelState(IZ)Landroid/support/v7/app/G;

    move-result-object p1

    invoke-direct {p0, p1, p2}, Landroid/support/v7/app/I;->b(Landroid/support/v7/app/G;Landroid/view/KeyEvent;)Z

    invoke-virtual {p2}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result v2

    invoke-direct {p0, p1, v2, p2, v1}, Landroid/support/v7/app/I;->a(Landroid/support/v7/app/G;ILandroid/view/KeyEvent;I)Z

    move-result p0

    iput-boolean v0, p1, Landroid/support/v7/app/G;->isPrepared:Z

    if-eqz p0, :cond_3

    return v1

    :cond_3
    return v0
.end method

.method onKeyUp(ILandroid/view/KeyEvent;)Z
    .locals 3

    const/4 v0, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eq p1, v0, :cond_a

    const/16 v0, 0x52

    if-eq p1, v0, :cond_0

    goto/16 :goto_4

    .line 1
    :cond_0
    iget-object p1, p0, Landroid/support/v7/app/I;->mActionMode:La/b/d/e/c;

    if-eqz p1, :cond_1

    goto/16 :goto_3

    :cond_1
    invoke-virtual {p0, v2, v1}, Landroid/support/v7/app/I;->getPanelState(IZ)Landroid/support/v7/app/G;

    move-result-object p1

    iget-object v0, p0, Landroid/support/v7/app/I;->mDecorContentParent:Landroid/support/v7/widget/ga;

    if-eqz v0, :cond_3

    invoke-interface {v0}, Landroid/support/v7/widget/ga;->canShowOverflowMenu()Z

    move-result v0

    if-eqz v0, :cond_3

    iget-object v0, p0, Landroid/support/v7/app/I;->mContext:Landroid/content/Context;

    invoke-static {v0}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/ViewConfiguration;->hasPermanentMenuKey()Z

    move-result v0

    if-nez v0, :cond_3

    iget-object v0, p0, Landroid/support/v7/app/I;->mDecorContentParent:Landroid/support/v7/widget/ga;

    invoke-interface {v0}, Landroid/support/v7/widget/ga;->isOverflowMenuShowing()Z

    move-result v0

    if-nez v0, :cond_2

    iget-boolean v0, p0, Landroid/support/v7/app/I;->xj:Z

    if-nez v0, :cond_6

    invoke-direct {p0, p1, p2}, Landroid/support/v7/app/I;->b(Landroid/support/v7/app/G;Landroid/view/KeyEvent;)Z

    move-result p1

    if-eqz p1, :cond_6

    iget-object p1, p0, Landroid/support/v7/app/I;->mDecorContentParent:Landroid/support/v7/widget/ga;

    invoke-interface {p1}, Landroid/support/v7/widget/ga;->showOverflowMenu()Z

    move-result p1

    goto :goto_2

    :cond_2
    iget-object p1, p0, Landroid/support/v7/app/I;->mDecorContentParent:Landroid/support/v7/widget/ga;

    invoke-interface {p1}, Landroid/support/v7/widget/ga;->hideOverflowMenu()Z

    move-result p1

    goto :goto_2

    :cond_3
    iget-boolean v0, p1, Landroid/support/v7/app/G;->isOpen:Z

    if-nez v0, :cond_7

    iget-boolean v0, p1, Landroid/support/v7/app/G;->isHandled:Z

    if-eqz v0, :cond_4

    goto :goto_1

    :cond_4
    iget-boolean v0, p1, Landroid/support/v7/app/G;->isPrepared:Z

    if-eqz v0, :cond_6

    iget-boolean v0, p1, Landroid/support/v7/app/G;->refreshMenuContent:Z

    if-eqz v0, :cond_5

    iput-boolean v2, p1, Landroid/support/v7/app/G;->isPrepared:Z

    invoke-direct {p0, p1, p2}, Landroid/support/v7/app/I;->b(Landroid/support/v7/app/G;Landroid/view/KeyEvent;)Z

    move-result v0

    goto :goto_0

    :cond_5
    move v0, v1

    :goto_0
    if-eqz v0, :cond_6

    invoke-direct {p0, p1, p2}, Landroid/support/v7/app/I;->a(Landroid/support/v7/app/G;Landroid/view/KeyEvent;)V

    move p1, v1

    goto :goto_2

    :cond_6
    move p1, v2

    goto :goto_2

    :cond_7
    :goto_1
    iget-boolean p2, p1, Landroid/support/v7/app/G;->isOpen:Z

    invoke-virtual {p0, p1, v1}, Landroid/support/v7/app/I;->a(Landroid/support/v7/app/G;Z)V

    move p1, p2

    :goto_2
    if-eqz p1, :cond_9

    iget-object p0, p0, Landroid/support/v7/app/I;->mContext:Landroid/content/Context;

    const-string p1, "audio"

    invoke-virtual {p0, p1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/media/AudioManager;

    if-eqz p0, :cond_8

    invoke-virtual {p0, v2}, Landroid/media/AudioManager;->playSoundEffect(I)V

    goto :goto_3

    :cond_8
    const-string p0, "AppCompatDelegate"

    const-string p1, "Couldn\'t get audio manager"

    invoke-static {p0, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    :cond_9
    :goto_3
    return v1

    .line 2
    :cond_a
    iget-boolean p1, p0, Landroid/support/v7/app/I;->wj:Z

    iput-boolean v2, p0, Landroid/support/v7/app/I;->wj:Z

    invoke-virtual {p0, v2, v2}, Landroid/support/v7/app/I;->getPanelState(IZ)Landroid/support/v7/app/G;

    move-result-object p2

    if-eqz p2, :cond_c

    iget-boolean v0, p2, Landroid/support/v7/app/G;->isOpen:Z

    if-eqz v0, :cond_c

    if-nez p1, :cond_b

    invoke-virtual {p0, p2, v1}, Landroid/support/v7/app/I;->a(Landroid/support/v7/app/G;Z)V

    :cond_b
    return v1

    :cond_c
    invoke-virtual {p0}, Landroid/support/v7/app/I;->onBackPressed()Z

    move-result p0

    if-eqz p0, :cond_d

    return v1

    :cond_d
    :goto_4
    return v2
.end method

.method public onPostCreate(Landroid/os/Bundle;)V
    .locals 0

    invoke-direct {p0}, Landroid/support/v7/app/I;->Yf()V

    return-void
.end method

.method public onPostResume()V
    .locals 1

    invoke-virtual {p0}, Landroid/support/v7/app/I;->Y()Landroid/support/v7/app/c;

    move-result-object p0

    if-eqz p0, :cond_0

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Landroid/support/v7/app/c;->setShowHideAnimationEnabled(Z)V

    :cond_0
    return-void
.end method

.method public onSaveInstanceState(Landroid/os/Bundle;)V
    .locals 1

    iget p0, p0, Landroid/support/v7/app/I;->yj:I

    const/16 v0, -0x64

    if-eq p0, v0, :cond_0

    const-string v0, "appcompat:local_night_mode"

    invoke-virtual {p1, v0, p0}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    :cond_0
    return-void
.end method

.method public onStart()V
    .locals 0

    invoke-virtual {p0}, Landroid/support/v7/app/I;->Ha()Z

    return-void
.end method

.method public onStop()V
    .locals 2

    invoke-virtual {p0}, Landroid/support/v7/app/I;->Y()Landroid/support/v7/app/c;

    move-result-object v0

    if-eqz v0, :cond_0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/support/v7/app/c;->setShowHideAnimationEnabled(Z)V

    :cond_0
    iget-object p0, p0, Landroid/support/v7/app/I;->Aj:Landroid/support/v7/app/AppCompatDelegateImpl$AutoNightModeManager;

    if-eqz p0, :cond_1

    invoke-virtual {p0}, Landroid/support/v7/app/AppCompatDelegateImpl$AutoNightModeManager;->cleanup()V

    :cond_1
    return-void
.end method

.method public requestWindowFeature(I)Z
    .locals 5

    const-string v0, "AppCompatDelegate"

    const/16 v1, 0x8

    const/16 v2, 0x6d

    const/16 v3, 0x6c

    if-ne p1, v1, :cond_0

    const-string p1, "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR id when requesting this feature."

    .line 1
    invoke-static {v0, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    move p1, v3

    goto :goto_0

    :cond_0
    const/16 v1, 0x9

    if-ne p1, v1, :cond_1

    const-string p1, "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR_OVERLAY id when requesting this feature."

    invoke-static {v0, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    move p1, v2

    .line 2
    :cond_1
    :goto_0
    iget-boolean v0, p0, Landroid/support/v7/app/I;->tj:Z

    const/4 v1, 0x0

    if-eqz v0, :cond_2

    if-ne p1, v3, :cond_2

    return v1

    :cond_2
    iget-boolean v0, p0, Landroid/support/v7/app/I;->qj:Z

    const/4 v4, 0x1

    if-eqz v0, :cond_3

    if-ne p1, v4, :cond_3

    iput-boolean v1, p0, Landroid/support/v7/app/I;->qj:Z

    :cond_3
    if-eq p1, v4, :cond_9

    const/4 v0, 0x2

    if-eq p1, v0, :cond_8

    const/4 v0, 0x5

    if-eq p1, v0, :cond_7

    const/16 v0, 0xa

    if-eq p1, v0, :cond_6

    if-eq p1, v3, :cond_5

    if-eq p1, v2, :cond_4

    iget-object p0, p0, Landroid/support/v7/app/I;->mWindow:Landroid/view/Window;

    invoke-virtual {p0, p1}, Landroid/view/Window;->requestFeature(I)Z

    move-result p0

    return p0

    :cond_4
    invoke-direct {p0}, Landroid/support/v7/app/I;->_f()V

    iput-boolean v4, p0, Landroid/support/v7/app/I;->rj:Z

    return v4

    :cond_5
    invoke-direct {p0}, Landroid/support/v7/app/I;->_f()V

    iput-boolean v4, p0, Landroid/support/v7/app/I;->qj:Z

    return v4

    :cond_6
    invoke-direct {p0}, Landroid/support/v7/app/I;->_f()V

    iput-boolean v4, p0, Landroid/support/v7/app/I;->sj:Z

    return v4

    :cond_7
    invoke-direct {p0}, Landroid/support/v7/app/I;->_f()V

    iput-boolean v4, p0, Landroid/support/v7/app/I;->pj:Z

    return v4

    :cond_8
    invoke-direct {p0}, Landroid/support/v7/app/I;->_f()V

    iput-boolean v4, p0, Landroid/support/v7/app/I;->oj:Z

    return v4

    :cond_9
    invoke-direct {p0}, Landroid/support/v7/app/I;->_f()V

    iput-boolean v4, p0, Landroid/support/v7/app/I;->tj:Z

    return v4
.end method

.method public setContentView(I)V
    .locals 2

    invoke-direct {p0}, Landroid/support/v7/app/I;->Yf()V

    iget-object v0, p0, Landroid/support/v7/app/I;->mj:Landroid/view/ViewGroup;

    const v1, 0x1020002

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/view/ViewGroup;

    invoke-virtual {v0}, Landroid/view/ViewGroup;->removeAllViews()V

    iget-object v1, p0, Landroid/support/v7/app/I;->mContext:Landroid/content/Context;

    invoke-static {v1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v1

    invoke-virtual {v1, p1, v0}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    iget-object p0, p0, Landroid/support/v7/app/I;->aj:Landroid/view/Window$Callback;

    invoke-interface {p0}, Landroid/view/Window$Callback;->onContentChanged()V

    return-void
.end method

.method public setContentView(Landroid/view/View;)V
    .locals 2

    invoke-direct {p0}, Landroid/support/v7/app/I;->Yf()V

    iget-object v0, p0, Landroid/support/v7/app/I;->mj:Landroid/view/ViewGroup;

    const v1, 0x1020002

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/view/ViewGroup;

    invoke-virtual {v0}, Landroid/view/ViewGroup;->removeAllViews()V

    invoke-virtual {v0, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    iget-object p0, p0, Landroid/support/v7/app/I;->aj:Landroid/view/Window$Callback;

    invoke-interface {p0}, Landroid/view/Window$Callback;->onContentChanged()V

    return-void
.end method

.method public setContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    .locals 2

    invoke-direct {p0}, Landroid/support/v7/app/I;->Yf()V

    iget-object v0, p0, Landroid/support/v7/app/I;->mj:Landroid/view/ViewGroup;

    const v1, 0x1020002

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/view/ViewGroup;

    invoke-virtual {v0}, Landroid/view/ViewGroup;->removeAllViews()V

    invoke-virtual {v0, p1, p2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object p0, p0, Landroid/support/v7/app/I;->aj:Landroid/view/Window$Callback;

    invoke-interface {p0}, Landroid/view/Window$Callback;->onContentChanged()V

    return-void
.end method

.method public final setTitle(Ljava/lang/CharSequence;)V
    .locals 1

    iput-object p1, p0, Landroid/support/v7/app/I;->mTitle:Ljava/lang/CharSequence;

    iget-object v0, p0, Landroid/support/v7/app/I;->mDecorContentParent:Landroid/support/v7/widget/ga;

    if-eqz v0, :cond_0

    invoke-interface {v0, p1}, Landroid/support/v7/widget/ga;->setWindowTitle(Ljava/lang/CharSequence;)V

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Landroid/support/v7/app/I;->Na()Landroid/support/v7/app/c;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-virtual {p0}, Landroid/support/v7/app/I;->Na()Landroid/support/v7/app/c;

    move-result-object p0

    invoke-virtual {p0, p1}, Landroid/support/v7/app/c;->setWindowTitle(Ljava/lang/CharSequence;)V

    goto :goto_0

    :cond_1
    iget-object p0, p0, Landroid/support/v7/app/I;->Ri:Landroid/widget/TextView;

    if-eqz p0, :cond_2

    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_2
    :goto_0
    return-void
.end method
