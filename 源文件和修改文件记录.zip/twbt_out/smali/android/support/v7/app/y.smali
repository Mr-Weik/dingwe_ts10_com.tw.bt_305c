.class Landroid/support/v7/app/y;
.super Landroid/support/v4/view/y;
.source ""


# instance fields
.field final synthetic n:Landroid/support/v7/app/I;


# direct methods
.method constructor <init>(Landroid/support/v7/app/I;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/app/y;->n:Landroid/support/v7/app/I;

    invoke-direct {p0}, Landroid/support/v4/view/y;-><init>()V

    return-void
.end method


# virtual methods
.method public d(Landroid/view/View;)V
    .locals 1

    iget-object p1, p0, Landroid/support/v7/app/y;->n:Landroid/support/v7/app/I;

    iget-object p1, p1, Landroid/support/v7/app/I;->gj:Landroid/support/v7/widget/ActionBarContextView;

    const/high16 v0, 0x3f800000    # 1.0f

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->setAlpha(F)V

    iget-object p1, p0, Landroid/support/v7/app/y;->n:Landroid/support/v7/app/I;

    iget-object p1, p1, Landroid/support/v7/app/I;->jj:Landroid/support/v4/view/w;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/support/v4/view/w;->a(Landroid/support/v4/view/x;)Landroid/support/v4/view/w;

    iget-object p0, p0, Landroid/support/v7/app/y;->n:Landroid/support/v7/app/I;

    iput-object v0, p0, Landroid/support/v7/app/I;->jj:Landroid/support/v4/view/w;

    return-void
.end method

.method public f(Landroid/view/View;)V
    .locals 1

    iget-object p1, p0, Landroid/support/v7/app/y;->n:Landroid/support/v7/app/I;

    iget-object p1, p1, Landroid/support/v7/app/I;->gj:Landroid/support/v7/widget/ActionBarContextView;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/support/v7/widget/ActionBarContextView;->setVisibility(I)V

    iget-object p1, p0, Landroid/support/v7/app/y;->n:Landroid/support/v7/app/I;

    iget-object p1, p1, Landroid/support/v7/app/I;->gj:Landroid/support/v7/widget/ActionBarContextView;

    const/16 v0, 0x20

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->sendAccessibilityEvent(I)V

    iget-object p1, p0, Landroid/support/v7/app/y;->n:Landroid/support/v7/app/I;

    iget-object p1, p1, Landroid/support/v7/app/I;->gj:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {p1}, Landroid/view/ViewGroup;->getParent()Landroid/view/ViewParent;

    move-result-object p1

    instance-of p1, p1, Landroid/view/View;

    if-eqz p1, :cond_0

    iget-object p0, p0, Landroid/support/v7/app/y;->n:Landroid/support/v7/app/I;

    iget-object p0, p0, Landroid/support/v7/app/I;->gj:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getParent()Landroid/view/ViewParent;

    move-result-object p0

    check-cast p0, Landroid/view/View;

    invoke-static {p0}, Landroid/support/v4/view/r;->A(Landroid/view/View;)V

    :cond_0
    return-void
.end method
