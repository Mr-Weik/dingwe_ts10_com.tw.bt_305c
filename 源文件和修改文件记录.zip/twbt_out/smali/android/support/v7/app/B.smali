.class Landroid/support/v7/app/B;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements La/b/d/e/b;


# instance fields
.field private mWrapped:La/b/d/e/b;

.field final synthetic n:Landroid/support/v7/app/I;


# direct methods
.method public constructor <init>(Landroid/support/v7/app/I;La/b/d/e/b;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/app/B;->n:Landroid/support/v7/app/I;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Landroid/support/v7/app/B;->mWrapped:La/b/d/e/b;

    return-void
.end method


# virtual methods
.method public a(La/b/d/e/c;Landroid/view/Menu;)Z
    .locals 0

    iget-object p0, p0, Landroid/support/v7/app/B;->mWrapped:La/b/d/e/b;

    invoke-interface {p0, p1, p2}, La/b/d/e/b;->a(La/b/d/e/c;Landroid/view/Menu;)Z

    move-result p0

    return p0
.end method

.method public a(La/b/d/e/c;Landroid/view/MenuItem;)Z
    .locals 0

    iget-object p0, p0, Landroid/support/v7/app/B;->mWrapped:La/b/d/e/b;

    invoke-interface {p0, p1, p2}, La/b/d/e/b;->a(La/b/d/e/c;Landroid/view/MenuItem;)Z

    move-result p0

    return p0
.end method

.method public b(La/b/d/e/c;Landroid/view/Menu;)Z
    .locals 0

    iget-object p0, p0, Landroid/support/v7/app/B;->mWrapped:La/b/d/e/b;

    invoke-interface {p0, p1, p2}, La/b/d/e/b;->b(La/b/d/e/c;Landroid/view/Menu;)Z

    move-result p0

    return p0
.end method

.method public c(La/b/d/e/c;)V
    .locals 2

    iget-object v0, p0, Landroid/support/v7/app/B;->mWrapped:La/b/d/e/b;

    invoke-interface {v0, p1}, La/b/d/e/b;->c(La/b/d/e/c;)V

    iget-object p1, p0, Landroid/support/v7/app/B;->n:Landroid/support/v7/app/I;

    iget-object v0, p1, Landroid/support/v7/app/I;->hj:Landroid/widget/PopupWindow;

    if-eqz v0, :cond_0

    iget-object p1, p1, Landroid/support/v7/app/I;->mWindow:Landroid/view/Window;

    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p1

    iget-object v0, p0, Landroid/support/v7/app/B;->n:Landroid/support/v7/app/I;

    iget-object v0, v0, Landroid/support/v7/app/I;->ij:Ljava/lang/Runnable;

    invoke-virtual {p1, v0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    :cond_0
    iget-object p1, p0, Landroid/support/v7/app/B;->n:Landroid/support/v7/app/I;

    iget-object v0, p1, Landroid/support/v7/app/I;->gj:Landroid/support/v7/widget/ActionBarContextView;

    if-eqz v0, :cond_1

    invoke-virtual {p1}, Landroid/support/v7/app/I;->Ja()V

    iget-object p1, p0, Landroid/support/v7/app/B;->n:Landroid/support/v7/app/I;

    iget-object v0, p1, Landroid/support/v7/app/I;->gj:Landroid/support/v7/widget/ActionBarContextView;

    invoke-static {v0}, Landroid/support/v4/view/r;->j(Landroid/view/View;)Landroid/support/v4/view/w;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/support/v4/view/w;->alpha(F)Landroid/support/v4/view/w;

    iput-object v0, p1, Landroid/support/v7/app/I;->jj:Landroid/support/v4/view/w;

    iget-object p1, p0, Landroid/support/v7/app/B;->n:Landroid/support/v7/app/I;

    iget-object p1, p1, Landroid/support/v7/app/I;->jj:Landroid/support/v4/view/w;

    new-instance v0, Landroid/support/v7/app/A;

    invoke-direct {v0, p0}, Landroid/support/v7/app/A;-><init>(Landroid/support/v7/app/B;)V

    invoke-virtual {p1, v0}, Landroid/support/v4/view/w;->a(Landroid/support/v4/view/x;)Landroid/support/v4/view/w;

    :cond_1
    iget-object p1, p0, Landroid/support/v7/app/B;->n:Landroid/support/v7/app/I;

    iget-object v0, p1, Landroid/support/v7/app/I;->cj:Landroid/support/v7/app/q;

    if-eqz v0, :cond_2

    iget-object p1, p1, Landroid/support/v7/app/I;->mActionMode:La/b/d/e/c;

    invoke-interface {v0, p1}, Landroid/support/v7/app/q;->a(La/b/d/e/c;)V

    :cond_2
    iget-object p0, p0, Landroid/support/v7/app/B;->n:Landroid/support/v7/app/I;

    const/4 p1, 0x0

    iput-object p1, p0, Landroid/support/v7/app/I;->mActionMode:La/b/d/e/c;

    return-void
.end method
