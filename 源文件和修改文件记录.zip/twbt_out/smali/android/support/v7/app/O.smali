.class Landroid/support/v7/app/O;
.super Landroid/support/v4/view/y;
.source ""


# instance fields
.field final synthetic n:Landroid/support/v7/app/T;


# direct methods
.method constructor <init>(Landroid/support/v7/app/T;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/app/O;->n:Landroid/support/v7/app/T;

    invoke-direct {p0}, Landroid/support/v4/view/y;-><init>()V

    return-void
.end method


# virtual methods
.method public d(Landroid/view/View;)V
    .locals 3

    iget-object p1, p0, Landroid/support/v7/app/O;->n:Landroid/support/v7/app/T;

    iget-boolean v0, p1, Landroid/support/v7/app/T;->ni:Z

    if-eqz v0, :cond_0

    iget-object p1, p1, Landroid/support/v7/app/T;->mContentView:Landroid/view/View;

    if-eqz p1, :cond_0

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/view/View;->setTranslationY(F)V

    iget-object p1, p0, Landroid/support/v7/app/O;->n:Landroid/support/v7/app/T;

    iget-object p1, p1, Landroid/support/v7/app/T;->fi:Landroid/support/v7/widget/ActionBarContainer;

    invoke-virtual {p1, v0}, Landroid/widget/FrameLayout;->setTranslationY(F)V

    :cond_0
    iget-object p1, p0, Landroid/support/v7/app/O;->n:Landroid/support/v7/app/T;

    iget-object p1, p1, Landroid/support/v7/app/T;->fi:Landroid/support/v7/widget/ActionBarContainer;

    const/16 v0, 0x8

    invoke-virtual {p1, v0}, Landroid/support/v7/widget/ActionBarContainer;->setVisibility(I)V

    iget-object p1, p0, Landroid/support/v7/app/O;->n:Landroid/support/v7/app/T;

    iget-object p1, p1, Landroid/support/v7/app/T;->fi:Landroid/support/v7/widget/ActionBarContainer;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/support/v7/widget/ActionBarContainer;->setTransitioning(Z)V

    iget-object p1, p0, Landroid/support/v7/app/O;->n:Landroid/support/v7/app/T;

    const/4 v0, 0x0

    iput-object v0, p1, Landroid/support/v7/app/T;->ui:La/b/d/e/m;

    .line 1
    iget-object v1, p1, Landroid/support/v7/app/T;->mDeferredModeDestroyCallback:La/b/d/e/b;

    if-eqz v1, :cond_1

    iget-object v2, p1, Landroid/support/v7/app/T;->mDeferredDestroyActionMode:La/b/d/e/c;

    invoke-interface {v1, v2}, La/b/d/e/b;->c(La/b/d/e/c;)V

    iput-object v0, p1, Landroid/support/v7/app/T;->mDeferredDestroyActionMode:La/b/d/e/c;

    iput-object v0, p1, Landroid/support/v7/app/T;->mDeferredModeDestroyCallback:La/b/d/e/b;

    .line 2
    :cond_1
    iget-object p0, p0, Landroid/support/v7/app/O;->n:Landroid/support/v7/app/T;

    iget-object p0, p0, Landroid/support/v7/app/T;->ei:Landroid/support/v7/widget/ActionBarOverlayLayout;

    if-eqz p0, :cond_2

    invoke-static {p0}, Landroid/support/v4/view/r;->A(Landroid/view/View;)V

    :cond_2
    return-void
.end method
