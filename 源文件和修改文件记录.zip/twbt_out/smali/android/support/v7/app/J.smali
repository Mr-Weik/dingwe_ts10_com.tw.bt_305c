.class public Landroid/support/v7/app/J;
.super Landroid/app/Dialog;
.source ""

# interfaces
.implements Landroid/support/v7/app/q;


# instance fields
.field private ba:Landroid/support/v7/app/r;


# direct methods
.method public constructor <init>(Landroid/content/Context;I)V
    .locals 3

    if-nez p2, :cond_0

    .line 1
    new-instance p2, Landroid/util/TypedValue;

    invoke-direct {p2}, Landroid/util/TypedValue;-><init>()V

    invoke-virtual {p1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v0

    const v1, 0x7f030065

    const/4 v2, 0x1

    invoke-virtual {v0, v1, p2, v2}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    iget p2, p2, Landroid/util/TypedValue;->resourceId:I

    .line 2
    :cond_0
    invoke-direct {p0, p1, p2}, Landroid/app/Dialog;-><init>(Landroid/content/Context;I)V

    invoke-virtual {p0}, Landroid/support/v7/app/J;->B()Landroid/support/v7/app/r;

    move-result-object p1

    const/4 p2, 0x0

    invoke-virtual {p1, p2}, Landroid/support/v7/app/r;->onCreate(Landroid/os/Bundle;)V

    invoke-virtual {p0}, Landroid/support/v7/app/J;->B()Landroid/support/v7/app/r;

    move-result-object p0

    invoke-virtual {p0}, Landroid/support/v7/app/r;->Ha()Z

    return-void
.end method


# virtual methods
.method public B()Landroid/support/v7/app/r;
    .locals 3

    iget-object v0, p0, Landroid/support/v7/app/J;->ba:Landroid/support/v7/app/r;

    if-nez v0, :cond_0

    .line 1
    new-instance v0, Landroid/support/v7/app/I;

    invoke-virtual {p0}, Landroid/app/Dialog;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v2

    invoke-direct {v0, v1, v2, p0}, Landroid/support/v7/app/I;-><init>(Landroid/content/Context;Landroid/view/Window;Landroid/support/v7/app/q;)V

    .line 2
    iput-object v0, p0, Landroid/support/v7/app/J;->ba:Landroid/support/v7/app/r;

    :cond_0
    iget-object p0, p0, Landroid/support/v7/app/J;->ba:Landroid/support/v7/app/r;

    return-object p0
.end method

.method public a(La/b/d/e/b;)La/b/d/e/c;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public a(La/b/d/e/c;)V
    .locals 0

    return-void
.end method

.method public addContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    .locals 0

    invoke-virtual {p0}, Landroid/support/v7/app/J;->B()Landroid/support/v7/app/r;

    move-result-object p0

    invoke-virtual {p0, p1, p2}, Landroid/support/v7/app/r;->addContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method public b(La/b/d/e/c;)V
    .locals 0

    return-void
.end method

.method public findViewById(I)Landroid/view/View;
    .locals 0

    invoke-virtual {p0}, Landroid/support/v7/app/J;->B()Landroid/support/v7/app/r;

    move-result-object p0

    invoke-virtual {p0, p1}, Landroid/support/v7/app/r;->findViewById(I)Landroid/view/View;

    move-result-object p0

    return-object p0
.end method

.method public invalidateOptionsMenu()V
    .locals 0

    invoke-virtual {p0}, Landroid/support/v7/app/J;->B()Landroid/support/v7/app/r;

    move-result-object p0

    invoke-virtual {p0}, Landroid/support/v7/app/r;->invalidateOptionsMenu()V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 1

    invoke-virtual {p0}, Landroid/support/v7/app/J;->B()Landroid/support/v7/app/r;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/v7/app/r;->Ia()V

    invoke-super {p0, p1}, Landroid/app/Dialog;->onCreate(Landroid/os/Bundle;)V

    invoke-virtual {p0}, Landroid/support/v7/app/J;->B()Landroid/support/v7/app/r;

    move-result-object p0

    invoke-virtual {p0, p1}, Landroid/support/v7/app/r;->onCreate(Landroid/os/Bundle;)V

    return-void
.end method

.method protected onStop()V
    .locals 0

    invoke-super {p0}, Landroid/app/Dialog;->onStop()V

    invoke-virtual {p0}, Landroid/support/v7/app/J;->B()Landroid/support/v7/app/r;

    move-result-object p0

    invoke-virtual {p0}, Landroid/support/v7/app/r;->onStop()V

    return-void
.end method

.method public setContentView(I)V
    .locals 0

    invoke-virtual {p0}, Landroid/support/v7/app/J;->B()Landroid/support/v7/app/r;

    move-result-object p0

    invoke-virtual {p0, p1}, Landroid/support/v7/app/r;->setContentView(I)V

    return-void
.end method

.method public setContentView(Landroid/view/View;)V
    .locals 0

    invoke-virtual {p0}, Landroid/support/v7/app/J;->B()Landroid/support/v7/app/r;

    move-result-object p0

    invoke-virtual {p0, p1}, Landroid/support/v7/app/r;->setContentView(Landroid/view/View;)V

    return-void
.end method

.method public setContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    .locals 0

    invoke-virtual {p0}, Landroid/support/v7/app/J;->B()Landroid/support/v7/app/r;

    move-result-object p0

    invoke-virtual {p0, p1, p2}, Landroid/support/v7/app/r;->setContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method public setTitle(I)V
    .locals 1

    invoke-super {p0, p1}, Landroid/app/Dialog;->setTitle(I)V

    invoke-virtual {p0}, Landroid/support/v7/app/J;->B()Landroid/support/v7/app/r;

    move-result-object v0

    invoke-virtual {p0}, Landroid/app/Dialog;->getContext()Landroid/content/Context;

    move-result-object p0

    invoke-virtual {p0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Landroid/support/v7/app/r;->setTitle(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public setTitle(Ljava/lang/CharSequence;)V
    .locals 0

    invoke-super {p0, p1}, Landroid/app/Dialog;->setTitle(Ljava/lang/CharSequence;)V

    invoke-virtual {p0}, Landroid/support/v7/app/J;->B()Landroid/support/v7/app/r;

    move-result-object p0

    invoke-virtual {p0, p1}, Landroid/support/v7/app/r;->setTitle(Ljava/lang/CharSequence;)V

    return-void
.end method
