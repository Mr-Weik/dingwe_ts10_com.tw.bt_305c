.class final Landroid/support/v7/app/z;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/support/v7/view/menu/F;


# instance fields
.field final synthetic n:Landroid/support/v7/app/I;


# direct methods
.method constructor <init>(Landroid/support/v7/app/I;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/app/z;->n:Landroid/support/v7/app/I;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Landroid/support/v7/view/menu/r;Z)V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/app/z;->n:Landroid/support/v7/app/I;

    invoke-virtual {p0, p1}, Landroid/support/v7/app/I;->d(Landroid/support/v7/view/menu/r;)V

    return-void
.end method

.method public a(Landroid/support/v7/view/menu/r;)Z
    .locals 1

    iget-object p0, p0, Landroid/support/v7/app/z;->n:Landroid/support/v7/app/I;

    invoke-virtual {p0}, Landroid/support/v7/app/I;->La()Landroid/view/Window$Callback;

    move-result-object p0

    if-eqz p0, :cond_0

    const/16 v0, 0x6c

    invoke-interface {p0, v0, p1}, Landroid/view/Window$Callback;->onMenuOpened(ILandroid/view/Menu;)Z

    :cond_0
    const/4 p0, 0x1

    return p0
.end method
