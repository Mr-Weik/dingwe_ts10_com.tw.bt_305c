.class Landroid/support/v7/app/M;
.super Ljava/lang/Object;
.source ""


# instance fields
.field _j:Z

.field ak:J


# direct methods
.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
