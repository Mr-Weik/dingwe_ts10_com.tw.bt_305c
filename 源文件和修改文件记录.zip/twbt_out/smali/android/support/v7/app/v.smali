.class Landroid/support/v7/app/v;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/support/v7/widget/fa;


# instance fields
.field final synthetic n:Landroid/support/v7/app/I;


# direct methods
.method constructor <init>(Landroid/support/v7/app/I;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/app/v;->n:Landroid/support/v7/app/I;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onDetachedFromWindow()V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/app/v;->n:Landroid/support/v7/app/I;

    invoke-virtual {p0}, Landroid/support/v7/app/I;->dismissPopups()V

    return-void
.end method

.method public t()V
    .locals 0

    return-void
.end method
