.class public interface abstract Landroid/support/v7/view/menu/F;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract a(Landroid/support/v7/view/menu/r;Z)V
.end method

.method public abstract a(Landroid/support/v7/view/menu/r;)Z
.end method
