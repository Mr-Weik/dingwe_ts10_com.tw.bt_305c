.class public final Landroid/support/v7/view/menu/J;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static a(Landroid/content/Context;La/b/c/c/a/a;)Landroid/view/Menu;
    .locals 1

    new-instance v0, Landroid/support/v7/view/menu/K;

    invoke-direct {v0, p0, p1}, Landroid/support/v7/view/menu/K;-><init>(Landroid/content/Context;La/b/c/c/a/a;)V

    return-object v0
.end method

.method public static a(Landroid/content/Context;La/b/c/c/a/b;)Landroid/view/MenuItem;
    .locals 1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    new-instance v0, Landroid/support/v7/view/menu/B;

    invoke-direct {v0, p0, p1}, Landroid/support/v7/view/menu/B;-><init>(Landroid/content/Context;La/b/c/c/a/b;)V

    return-object v0
.end method
