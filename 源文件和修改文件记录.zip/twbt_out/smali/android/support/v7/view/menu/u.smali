.class public final Landroid/support/v7/view/menu/u;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements La/b/c/c/a/b;


# instance fields
.field private final Wl:I

.field private Xl:Ljava/lang/CharSequence;

.field private Yl:C

.field private Zl:I

.field private _l:C

.field private am:I

.field private bm:Landroid/graphics/drawable/Drawable;

.field private cm:Landroid/content/res/ColorStateList;

.field private dm:Landroid/graphics/PorterDuff$Mode;

.field private em:Z

.field private final en:I

.field private fm:Z

.field private fn:I

.field private gn:Landroid/support/v7/view/menu/P;

.field private hn:Ljava/lang/Runnable;

.field private jn:Landroid/view/MenuItem$OnMenuItemClickListener;

.field private kn:Z

.field private ln:I

.field private mContentDescription:Ljava/lang/CharSequence;

.field private mFlags:I

.field private final mGroup:I

.field private final mId:I

.field private mIntent:Landroid/content/Intent;

.field mMenu:Landroid/support/v7/view/menu/r;

.field private mTitle:Ljava/lang/CharSequence;

.field private mTooltipText:Ljava/lang/CharSequence;

.field private mn:Landroid/view/View;

.field private nn:Landroid/support/v4/view/f;

.field private pn:Landroid/view/MenuItem$OnActionExpandListener;

.field private qn:Z

.field private rn:Landroid/view/ContextMenu$ContextMenuInfo;


# direct methods
.method constructor <init>(Landroid/support/v7/view/menu/r;IIIILjava/lang/CharSequence;I)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x1000

    iput v0, p0, Landroid/support/v7/view/menu/u;->Zl:I

    iput v0, p0, Landroid/support/v7/view/menu/u;->am:I

    const/4 v0, 0x0

    iput v0, p0, Landroid/support/v7/view/menu/u;->fn:I

    const/4 v1, 0x0

    iput-object v1, p0, Landroid/support/v7/view/menu/u;->cm:Landroid/content/res/ColorStateList;

    iput-object v1, p0, Landroid/support/v7/view/menu/u;->dm:Landroid/graphics/PorterDuff$Mode;

    iput-boolean v0, p0, Landroid/support/v7/view/menu/u;->em:Z

    iput-boolean v0, p0, Landroid/support/v7/view/menu/u;->fm:Z

    iput-boolean v0, p0, Landroid/support/v7/view/menu/u;->kn:Z

    const/16 v1, 0x10

    iput v1, p0, Landroid/support/v7/view/menu/u;->mFlags:I

    iput v0, p0, Landroid/support/v7/view/menu/u;->ln:I

    iput-boolean v0, p0, Landroid/support/v7/view/menu/u;->qn:Z

    iput-object p1, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    iput p3, p0, Landroid/support/v7/view/menu/u;->mId:I

    iput p2, p0, Landroid/support/v7/view/menu/u;->mGroup:I

    iput p4, p0, Landroid/support/v7/view/menu/u;->en:I

    iput p5, p0, Landroid/support/v7/view/menu/u;->Wl:I

    iput-object p6, p0, Landroid/support/v7/view/menu/u;->mTitle:Ljava/lang/CharSequence;

    iput p7, p0, Landroid/support/v7/view/menu/u;->ln:I

    return-void
.end method

.method private static a(Ljava/lang/StringBuilder;IILjava/lang/String;)V
    .locals 0

    and-int/2addr p1, p2

    if-ne p1, p2, :cond_0

    invoke-virtual {p0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    return-void
.end method

.method private h(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;
    .locals 2

    if-eqz p1, :cond_3

    iget-boolean v0, p0, Landroid/support/v7/view/menu/u;->kn:Z

    if-eqz v0, :cond_3

    iget-boolean v0, p0, Landroid/support/v7/view/menu/u;->em:Z

    if-nez v0, :cond_0

    iget-boolean v0, p0, Landroid/support/v7/view/menu/u;->fm:Z

    if-eqz v0, :cond_3

    .line 1
    :cond_0
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2
    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object p1

    iget-boolean v0, p0, Landroid/support/v7/view/menu/u;->em:Z

    if-eqz v0, :cond_1

    iget-object v0, p0, Landroid/support/v7/view/menu/u;->cm:Landroid/content/res/ColorStateList;

    .line 3
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setTintList(Landroid/content/res/ColorStateList;)V

    .line 4
    :cond_1
    iget-boolean v0, p0, Landroid/support/v7/view/menu/u;->fm:Z

    if-eqz v0, :cond_2

    iget-object v0, p0, Landroid/support/v7/view/menu/u;->dm:Landroid/graphics/PorterDuff$Mode;

    .line 5
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setTintMode(Landroid/graphics/PorterDuff$Mode;)V

    :cond_2
    const/4 v0, 0x0

    .line 6
    iput-boolean v0, p0, Landroid/support/v7/view/menu/u;->kn:Z

    :cond_3
    return-object p1
.end method


# virtual methods
.method public a(Landroid/support/v4/view/f;)La/b/c/c/a/b;
    .locals 1

    iget-object v0, p0, Landroid/support/v7/view/menu/u;->nn:Landroid/support/v4/view/f;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/support/v4/view/f;->reset()V

    :cond_0
    const/4 v0, 0x0

    iput-object v0, p0, Landroid/support/v7/view/menu/u;->mn:Landroid/view/View;

    iput-object p1, p0, Landroid/support/v7/view/menu/u;->nn:Landroid/support/v4/view/f;

    iget-object p1, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Landroid/support/v7/view/menu/r;->onItemsChanged(Z)V

    iget-object p1, p0, Landroid/support/v7/view/menu/u;->nn:Landroid/support/v4/view/f;

    if-eqz p1, :cond_1

    new-instance v0, Landroid/support/v7/view/menu/t;

    invoke-direct {v0, p0}, Landroid/support/v7/view/menu/t;-><init>(Landroid/support/v7/view/menu/u;)V

    invoke-virtual {p1, v0}, Landroid/support/v4/view/f;->a(Landroid/support/v4/view/e;)V

    :cond_1
    return-object p0
.end method

.method a(Landroid/support/v7/view/menu/H;)Ljava/lang/CharSequence;
    .locals 0

    if-eqz p1, :cond_1

    invoke-interface {p1}, Landroid/support/v7/view/menu/H;->prefersCondensedTitle()Z

    move-result p1

    if-eqz p1, :cond_1

    .line 1
    iget-object p1, p0, Landroid/support/v7/view/menu/u;->Xl:Ljava/lang/CharSequence;

    if-eqz p1, :cond_0

    goto :goto_0

    :cond_0
    iget-object p1, p0, Landroid/support/v7/view/menu/u;->mTitle:Ljava/lang/CharSequence;

    :goto_0
    sget p0, Landroid/os/Build$VERSION;->SDK_INT:I

    goto :goto_1

    .line 2
    :cond_1
    iget-object p1, p0, Landroid/support/v7/view/menu/u;->mTitle:Ljava/lang/CharSequence;

    :goto_1
    return-object p1
.end method

.method public b(Landroid/support/v7/view/menu/P;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/view/menu/u;->gn:Landroid/support/v7/view/menu/P;

    .line 1
    iget-object p0, p0, Landroid/support/v7/view/menu/u;->mTitle:Ljava/lang/CharSequence;

    .line 2
    invoke-virtual {p1, p0}, Landroid/support/v7/view/menu/P;->setHeaderTitle(Ljava/lang/CharSequence;)Landroid/view/SubMenu;

    return-void
.end method

.method public collapseActionView()Z
    .locals 2

    iget v0, p0, Landroid/support/v7/view/menu/u;->ln:I

    and-int/lit8 v0, v0, 0x8

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    iget-object v0, p0, Landroid/support/v7/view/menu/u;->mn:Landroid/view/View;

    if-nez v0, :cond_1

    const/4 p0, 0x1

    return p0

    :cond_1
    iget-object v0, p0, Landroid/support/v7/view/menu/u;->pn:Landroid/view/MenuItem$OnActionExpandListener;

    if-eqz v0, :cond_3

    invoke-interface {v0, p0}, Landroid/view/MenuItem$OnActionExpandListener;->onMenuItemActionCollapse(Landroid/view/MenuItem;)Z

    move-result v0

    if-eqz v0, :cond_2

    goto :goto_0

    :cond_2
    return v1

    :cond_3
    :goto_0
    iget-object v0, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    invoke-virtual {v0, p0}, Landroid/support/v7/view/menu/r;->b(Landroid/support/v7/view/menu/u;)Z

    move-result p0

    return p0
.end method

.method public expandActionView()Z
    .locals 2

    invoke-virtual {p0}, Landroid/support/v7/view/menu/u;->hasCollapsibleActionView()Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    iget-object v0, p0, Landroid/support/v7/view/menu/u;->pn:Landroid/view/MenuItem$OnActionExpandListener;

    if-eqz v0, :cond_2

    invoke-interface {v0, p0}, Landroid/view/MenuItem$OnActionExpandListener;->onMenuItemActionExpand(Landroid/view/MenuItem;)Z

    move-result v0

    if-eqz v0, :cond_1

    goto :goto_0

    :cond_1
    return v1

    :cond_2
    :goto_0
    iget-object v0, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    invoke-virtual {v0, p0}, Landroid/support/v7/view/menu/r;->c(Landroid/support/v7/view/menu/u;)Z

    move-result p0

    return p0
.end method

.method public getActionProvider()Landroid/view/ActionProvider;
    .locals 1

    new-instance p0, Ljava/lang/UnsupportedOperationException;

    const-string v0, "This is not supported, use MenuItemCompat.getActionProvider()"

    invoke-direct {p0, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public getActionView()Landroid/view/View;
    .locals 1

    iget-object v0, p0, Landroid/support/v7/view/menu/u;->mn:Landroid/view/View;

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    iget-object v0, p0, Landroid/support/v7/view/menu/u;->nn:Landroid/support/v4/view/f;

    if-eqz v0, :cond_1

    invoke-virtual {v0, p0}, Landroid/support/v4/view/f;->onCreateActionView(Landroid/view/MenuItem;)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Landroid/support/v7/view/menu/u;->mn:Landroid/view/View;

    iget-object p0, p0, Landroid/support/v7/view/menu/u;->mn:Landroid/view/View;

    return-object p0

    :cond_1
    const/4 p0, 0x0

    return-object p0
.end method

.method public getAlphabeticModifiers()I
    .locals 0

    iget p0, p0, Landroid/support/v7/view/menu/u;->am:I

    return p0
.end method

.method public getAlphabeticShortcut()C
    .locals 0

    iget-char p0, p0, Landroid/support/v7/view/menu/u;->_l:C

    return p0
.end method

.method public getContentDescription()Ljava/lang/CharSequence;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/u;->mContentDescription:Ljava/lang/CharSequence;

    return-object p0
.end method

.method public getGroupId()I
    .locals 0

    iget p0, p0, Landroid/support/v7/view/menu/u;->mGroup:I

    return p0
.end method

.method public getIcon()Landroid/graphics/drawable/Drawable;
    .locals 2

    iget-object v0, p0, Landroid/support/v7/view/menu/u;->bm:Landroid/graphics/drawable/Drawable;

    if-eqz v0, :cond_0

    invoke-direct {p0, v0}, Landroid/support/v7/view/menu/u;->h(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    move-result-object p0

    return-object p0

    :cond_0
    iget v0, p0, Landroid/support/v7/view/menu/u;->fn:I

    if-eqz v0, :cond_1

    iget-object v0, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    invoke-virtual {v0}, Landroid/support/v7/view/menu/r;->getContext()Landroid/content/Context;

    move-result-object v0

    iget v1, p0, Landroid/support/v7/view/menu/u;->fn:I

    invoke-static {v0, v1}, La/b/d/b/a/a;->a(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v1, 0x0

    iput v1, p0, Landroid/support/v7/view/menu/u;->fn:I

    iput-object v0, p0, Landroid/support/v7/view/menu/u;->bm:Landroid/graphics/drawable/Drawable;

    invoke-direct {p0, v0}, Landroid/support/v7/view/menu/u;->h(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    move-result-object p0

    return-object p0

    :cond_1
    const/4 p0, 0x0

    return-object p0
.end method

.method public getIconTintList()Landroid/content/res/ColorStateList;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/u;->cm:Landroid/content/res/ColorStateList;

    return-object p0
.end method

.method public getIconTintMode()Landroid/graphics/PorterDuff$Mode;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/u;->dm:Landroid/graphics/PorterDuff$Mode;

    return-object p0
.end method

.method public getIntent()Landroid/content/Intent;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/u;->mIntent:Landroid/content/Intent;

    return-object p0
.end method

.method public getItemId()I
    .locals 0
    .annotation runtime Landroid/view/ViewDebug$CapturedViewProperty;
    .end annotation

    iget p0, p0, Landroid/support/v7/view/menu/u;->mId:I

    return p0
.end method

.method public getMenuInfo()Landroid/view/ContextMenu$ContextMenuInfo;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/u;->rn:Landroid/view/ContextMenu$ContextMenuInfo;

    return-object p0
.end method

.method public getNumericModifiers()I
    .locals 0

    iget p0, p0, Landroid/support/v7/view/menu/u;->Zl:I

    return p0
.end method

.method public getNumericShortcut()C
    .locals 0

    iget-char p0, p0, Landroid/support/v7/view/menu/u;->Yl:C

    return p0
.end method

.method public getOrder()I
    .locals 0

    iget p0, p0, Landroid/support/v7/view/menu/u;->en:I

    return p0
.end method

.method public getOrdering()I
    .locals 0

    iget p0, p0, Landroid/support/v7/view/menu/u;->Wl:I

    return p0
.end method

.method getShortcut()C
    .locals 1

    iget-object v0, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    invoke-virtual {v0}, Landroid/support/v7/view/menu/r;->isQwertyMode()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-char p0, p0, Landroid/support/v7/view/menu/u;->_l:C

    goto :goto_0

    :cond_0
    iget-char p0, p0, Landroid/support/v7/view/menu/u;->Yl:C

    :goto_0
    return p0
.end method

.method getShortcutLabel()Ljava/lang/String;
    .locals 5

    invoke-virtual {p0}, Landroid/support/v7/view/menu/u;->getShortcut()C

    move-result v0

    if-nez v0, :cond_0

    const-string p0, ""

    return-object p0

    :cond_0
    iget-object v1, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    invoke-virtual {v1}, Landroid/support/v7/view/menu/r;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    invoke-virtual {v3}, Landroid/support/v7/view/menu/r;->getContext()Landroid/content/Context;

    move-result-object v3

    invoke-static {v3}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    move-result-object v3

    invoke-virtual {v3}, Landroid/view/ViewConfiguration;->hasPermanentMenuKey()Z

    move-result v3

    if-eqz v3, :cond_1

    const v3, 0x7f0e001f

    invoke-virtual {v1, v3}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_1
    iget-object v3, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    invoke-virtual {v3}, Landroid/support/v7/view/menu/r;->isQwertyMode()Z

    move-result v3

    if-eqz v3, :cond_2

    iget p0, p0, Landroid/support/v7/view/menu/u;->am:I

    goto :goto_0

    :cond_2
    iget p0, p0, Landroid/support/v7/view/menu/u;->Zl:I

    :goto_0
    const/high16 v3, 0x10000

    const v4, 0x7f0e001b

    invoke-virtual {v1, v4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-static {v2, p0, v3, v4}, Landroid/support/v7/view/menu/u;->a(Ljava/lang/StringBuilder;IILjava/lang/String;)V

    const/16 v3, 0x1000

    const v4, 0x7f0e0017

    invoke-virtual {v1, v4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-static {v2, p0, v3, v4}, Landroid/support/v7/view/menu/u;->a(Ljava/lang/StringBuilder;IILjava/lang/String;)V

    const/4 v3, 0x2

    const v4, 0x7f0e0016

    invoke-virtual {v1, v4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-static {v2, p0, v3, v4}, Landroid/support/v7/view/menu/u;->a(Ljava/lang/StringBuilder;IILjava/lang/String;)V

    const/4 v3, 0x1

    const v4, 0x7f0e001c

    invoke-virtual {v1, v4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-static {v2, p0, v3, v4}, Landroid/support/v7/view/menu/u;->a(Ljava/lang/StringBuilder;IILjava/lang/String;)V

    const/4 v3, 0x4

    const v4, 0x7f0e001e

    invoke-virtual {v1, v4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-static {v2, p0, v3, v4}, Landroid/support/v7/view/menu/u;->a(Ljava/lang/StringBuilder;IILjava/lang/String;)V

    const v3, 0x7f0e001a

    invoke-virtual {v1, v3}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v3

    const/16 v4, 0x8

    invoke-static {v2, p0, v4, v3}, Landroid/support/v7/view/menu/u;->a(Ljava/lang/StringBuilder;IILjava/lang/String;)V

    if-eq v0, v4, :cond_5

    const/16 p0, 0xa

    if-eq v0, p0, :cond_4

    const/16 p0, 0x20

    if-eq v0, p0, :cond_3

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_2

    :cond_3
    const p0, 0x7f0e001d

    goto :goto_1

    :cond_4
    const p0, 0x7f0e0019

    goto :goto_1

    :cond_5
    const p0, 0x7f0e0018

    :goto_1
    invoke-virtual {v1, p0}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :goto_2
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public getSubMenu()Landroid/view/SubMenu;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/u;->gn:Landroid/support/v7/view/menu/P;

    return-object p0
.end method

.method public getTitle()Ljava/lang/CharSequence;
    .locals 0
    .annotation runtime Landroid/view/ViewDebug$CapturedViewProperty;
    .end annotation

    iget-object p0, p0, Landroid/support/v7/view/menu/u;->mTitle:Ljava/lang/CharSequence;

    return-object p0
.end method

.method public getTitleCondensed()Ljava/lang/CharSequence;
    .locals 1

    iget-object v0, p0, Landroid/support/v7/view/menu/u;->Xl:Ljava/lang/CharSequence;

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    iget-object v0, p0, Landroid/support/v7/view/menu/u;->mTitle:Ljava/lang/CharSequence;

    :goto_0
    sget p0, Landroid/os/Build$VERSION;->SDK_INT:I

    return-object v0
.end method

.method public getTooltipText()Ljava/lang/CharSequence;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/u;->mTooltipText:Ljava/lang/CharSequence;

    return-object p0
.end method

.method public hasCollapsibleActionView()Z
    .locals 2

    iget v0, p0, Landroid/support/v7/view/menu/u;->ln:I

    and-int/lit8 v0, v0, 0x8

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    iget-object v0, p0, Landroid/support/v7/view/menu/u;->mn:Landroid/view/View;

    if-nez v0, :cond_0

    iget-object v0, p0, Landroid/support/v7/view/menu/u;->nn:Landroid/support/v4/view/f;

    if-eqz v0, :cond_0

    invoke-virtual {v0, p0}, Landroid/support/v4/view/f;->onCreateActionView(Landroid/view/MenuItem;)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Landroid/support/v7/view/menu/u;->mn:Landroid/view/View;

    :cond_0
    iget-object p0, p0, Landroid/support/v7/view/menu/u;->mn:Landroid/view/View;

    if-eqz p0, :cond_1

    const/4 v1, 0x1

    :cond_1
    return v1
.end method

.method public hasSubMenu()Z
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/u;->gn:Landroid/support/v7/view/menu/P;

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public invoke()Z
    .locals 4

    iget-object v0, p0, Landroid/support/v7/view/menu/u;->jn:Landroid/view/MenuItem$OnMenuItemClickListener;

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    invoke-interface {v0, p0}, Landroid/view/MenuItem$OnMenuItemClickListener;->onMenuItemClick(Landroid/view/MenuItem;)Z

    move-result v0

    if-eqz v0, :cond_0

    return v1

    :cond_0
    iget-object v0, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    invoke-virtual {v0, v0, p0}, Landroid/support/v7/view/menu/r;->d(Landroid/support/v7/view/menu/r;Landroid/view/MenuItem;)Z

    move-result v0

    if-eqz v0, :cond_1

    return v1

    :cond_1
    iget-object v0, p0, Landroid/support/v7/view/menu/u;->hn:Ljava/lang/Runnable;

    if-eqz v0, :cond_2

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    return v1

    :cond_2
    iget-object v0, p0, Landroid/support/v7/view/menu/u;->mIntent:Landroid/content/Intent;

    if-eqz v0, :cond_3

    :try_start_0
    iget-object v0, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    invoke-virtual {v0}, Landroid/support/v7/view/menu/r;->getContext()Landroid/content/Context;

    move-result-object v0

    iget-object v2, p0, Landroid/support/v7/view/menu/u;->mIntent:Landroid/content/Intent;

    invoke-virtual {v0, v2}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Landroid/content/ActivityNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    return v1

    :catch_0
    move-exception v0

    const-string v2, "MenuItemImpl"

    const-string v3, "Can\'t find activity to handle intent; ignoring"

    invoke-static {v2, v3, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_3
    iget-object p0, p0, Landroid/support/v7/view/menu/u;->nn:Landroid/support/v4/view/f;

    if-eqz p0, :cond_4

    check-cast p0, Landroid/support/v7/view/menu/v;

    .line 1
    iget-object p0, p0, Landroid/support/v7/view/menu/v;->kg:Landroid/view/ActionProvider;

    invoke-virtual {p0}, Landroid/view/ActionProvider;->onPerformDefaultAction()Z

    move-result p0

    if-eqz p0, :cond_4

    return v1

    :cond_4
    const/4 p0, 0x0

    return p0
.end method

.method public isActionButton()Z
    .locals 1

    iget p0, p0, Landroid/support/v7/view/menu/u;->mFlags:I

    const/16 v0, 0x20

    and-int/2addr p0, v0

    if-ne p0, v0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public isActionViewExpanded()Z
    .locals 0

    iget-boolean p0, p0, Landroid/support/v7/view/menu/u;->qn:Z

    return p0
.end method

.method public isCheckable()Z
    .locals 1

    iget p0, p0, Landroid/support/v7/view/menu/u;->mFlags:I

    const/4 v0, 0x1

    and-int/2addr p0, v0

    if-ne p0, v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public isChecked()Z
    .locals 1

    iget p0, p0, Landroid/support/v7/view/menu/u;->mFlags:I

    const/4 v0, 0x2

    and-int/2addr p0, v0

    if-ne p0, v0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public isEnabled()Z
    .locals 0

    iget p0, p0, Landroid/support/v7/view/menu/u;->mFlags:I

    and-int/lit8 p0, p0, 0x10

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public isExclusiveCheckable()Z
    .locals 0

    iget p0, p0, Landroid/support/v7/view/menu/u;->mFlags:I

    and-int/lit8 p0, p0, 0x4

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public isVisible()Z
    .locals 3

    iget-object v0, p0, Landroid/support/v7/view/menu/u;->nn:Landroid/support/v4/view/f;

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Landroid/support/v4/view/f;->overridesItemVisibility()Z

    move-result v0

    if-eqz v0, :cond_1

    iget v0, p0, Landroid/support/v7/view/menu/u;->mFlags:I

    and-int/lit8 v0, v0, 0x8

    if-nez v0, :cond_0

    iget-object p0, p0, Landroid/support/v7/view/menu/u;->nn:Landroid/support/v4/view/f;

    invoke-virtual {p0}, Landroid/support/v4/view/f;->isVisible()Z

    move-result p0

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    move v1, v2

    :goto_0
    return v1

    :cond_1
    iget p0, p0, Landroid/support/v7/view/menu/u;->mFlags:I

    and-int/lit8 p0, p0, 0x8

    if-nez p0, :cond_2

    goto :goto_1

    :cond_2
    move v1, v2

    :goto_1
    return v1
.end method

.method public m()Landroid/support/v4/view/f;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/u;->nn:Landroid/support/v4/view/f;

    return-object p0
.end method

.method public requestsActionButton()Z
    .locals 1

    iget p0, p0, Landroid/support/v7/view/menu/u;->ln:I

    const/4 v0, 0x1

    and-int/2addr p0, v0

    if-ne p0, v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public requiresActionButton()Z
    .locals 1

    iget p0, p0, Landroid/support/v7/view/menu/u;->ln:I

    const/4 v0, 0x2

    and-int/2addr p0, v0

    if-ne p0, v0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public setActionProvider(Landroid/view/ActionProvider;)Landroid/view/MenuItem;
    .locals 0

    new-instance p0, Ljava/lang/UnsupportedOperationException;

    const-string p1, "This is not supported, use MenuItemCompat.setActionProvider()"

    invoke-direct {p0, p1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public setActionView(Landroid/view/View;)La/b/c/c/a/b;
    .locals 2

    iput-object p1, p0, Landroid/support/v7/view/menu/u;->mn:Landroid/view/View;

    const/4 v0, 0x0

    iput-object v0, p0, Landroid/support/v7/view/menu/u;->nn:Landroid/support/v4/view/f;

    if-eqz p1, :cond_0

    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v0

    const/4 v1, -0x1

    if-ne v0, v1, :cond_0

    iget v0, p0, Landroid/support/v7/view/menu/u;->mId:I

    if-lez v0, :cond_0

    invoke-virtual {p1, v0}, Landroid/view/View;->setId(I)V

    :cond_0
    iget-object p1, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    invoke-virtual {p1, p0}, Landroid/support/v7/view/menu/r;->d(Landroid/support/v7/view/menu/u;)V

    return-object p0
.end method

.method public setActionView(I)Landroid/view/MenuItem;
    .locals 3

    .line 1
    iget-object v0, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    invoke-virtual {v0}, Landroid/support/v7/view/menu/r;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v1

    new-instance v2, Landroid/widget/LinearLayout;

    invoke-direct {v2, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v0, 0x0

    invoke-virtual {v1, p1, v2, v0}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/support/v7/view/menu/u;->setActionView(Landroid/view/View;)La/b/c/c/a/b;

    return-object p0
.end method

.method public bridge synthetic setActionView(Landroid/view/View;)Landroid/view/MenuItem;
    .locals 0

    invoke-virtual {p0, p1}, Landroid/support/v7/view/menu/u;->setActionView(Landroid/view/View;)La/b/c/c/a/b;

    return-object p0
.end method

.method public setActionViewExpanded(Z)V
    .locals 0

    iput-boolean p1, p0, Landroid/support/v7/view/menu/u;->qn:Z

    iget-object p0, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Landroid/support/v7/view/menu/r;->onItemsChanged(Z)V

    return-void
.end method

.method public setAlphabeticShortcut(C)Landroid/view/MenuItem;
    .locals 1

    iget-char v0, p0, Landroid/support/v7/view/menu/u;->_l:C

    if-ne v0, p1, :cond_0

    return-object p0

    :cond_0
    invoke-static {p1}, Ljava/lang/Character;->toLowerCase(C)C

    move-result p1

    iput-char p1, p0, Landroid/support/v7/view/menu/u;->_l:C

    iget-object p1, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/support/v7/view/menu/r;->onItemsChanged(Z)V

    return-object p0
.end method

.method public setAlphabeticShortcut(CI)Landroid/view/MenuItem;
    .locals 1

    iget-char v0, p0, Landroid/support/v7/view/menu/u;->_l:C

    if-ne v0, p1, :cond_0

    iget v0, p0, Landroid/support/v7/view/menu/u;->am:I

    if-ne v0, p2, :cond_0

    return-object p0

    :cond_0
    invoke-static {p1}, Ljava/lang/Character;->toLowerCase(C)C

    move-result p1

    iput-char p1, p0, Landroid/support/v7/view/menu/u;->_l:C

    invoke-static {p2}, Landroid/view/KeyEvent;->normalizeMetaState(I)I

    move-result p1

    iput p1, p0, Landroid/support/v7/view/menu/u;->am:I

    iget-object p1, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    const/4 p2, 0x0

    invoke-virtual {p1, p2}, Landroid/support/v7/view/menu/r;->onItemsChanged(Z)V

    return-object p0
.end method

.method public setCheckable(Z)Landroid/view/MenuItem;
    .locals 2

    iget v0, p0, Landroid/support/v7/view/menu/u;->mFlags:I

    and-int/lit8 v1, v0, -0x2

    or-int/2addr p1, v1

    iput p1, p0, Landroid/support/v7/view/menu/u;->mFlags:I

    iget p1, p0, Landroid/support/v7/view/menu/u;->mFlags:I

    if-eq v0, p1, :cond_0

    iget-object p1, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/support/v7/view/menu/r;->onItemsChanged(Z)V

    :cond_0
    return-object p0
.end method

.method public setChecked(Z)Landroid/view/MenuItem;
    .locals 1

    iget v0, p0, Landroid/support/v7/view/menu/u;->mFlags:I

    and-int/lit8 v0, v0, 0x4

    if-eqz v0, :cond_0

    iget-object p1, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    invoke-virtual {p1, p0}, Landroid/support/v7/view/menu/r;->setExclusiveItemChecked(Landroid/view/MenuItem;)V

    goto :goto_0

    :cond_0
    invoke-virtual {p0, p1}, Landroid/support/v7/view/menu/u;->setCheckedInt(Z)V

    :goto_0
    return-object p0
.end method

.method setCheckedInt(Z)V
    .locals 3

    iget v0, p0, Landroid/support/v7/view/menu/u;->mFlags:I

    and-int/lit8 v1, v0, -0x3

    const/4 v2, 0x0

    if-eqz p1, :cond_0

    const/4 p1, 0x2

    goto :goto_0

    :cond_0
    move p1, v2

    :goto_0
    or-int/2addr p1, v1

    iput p1, p0, Landroid/support/v7/view/menu/u;->mFlags:I

    iget p1, p0, Landroid/support/v7/view/menu/u;->mFlags:I

    if-eq v0, p1, :cond_1

    iget-object p0, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    invoke-virtual {p0, v2}, Landroid/support/v7/view/menu/r;->onItemsChanged(Z)V

    :cond_1
    return-void
.end method

.method public setContentDescription(Ljava/lang/CharSequence;)La/b/c/c/a/b;
    .locals 1

    iput-object p1, p0, Landroid/support/v7/view/menu/u;->mContentDescription:Ljava/lang/CharSequence;

    iget-object p1, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/support/v7/view/menu/r;->onItemsChanged(Z)V

    return-object p0
.end method

.method public setContentDescription(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 1

    .line 1
    iput-object p1, p0, Landroid/support/v7/view/menu/u;->mContentDescription:Ljava/lang/CharSequence;

    iget-object p1, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/support/v7/view/menu/r;->onItemsChanged(Z)V

    return-object p0
.end method

.method public setEnabled(Z)Landroid/view/MenuItem;
    .locals 1

    if-eqz p1, :cond_0

    iget p1, p0, Landroid/support/v7/view/menu/u;->mFlags:I

    or-int/lit8 p1, p1, 0x10

    goto :goto_0

    :cond_0
    iget p1, p0, Landroid/support/v7/view/menu/u;->mFlags:I

    and-int/lit8 p1, p1, -0x11

    :goto_0
    iput p1, p0, Landroid/support/v7/view/menu/u;->mFlags:I

    iget-object p1, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/support/v7/view/menu/r;->onItemsChanged(Z)V

    return-object p0
.end method

.method public setExclusiveCheckable(Z)V
    .locals 1

    iget v0, p0, Landroid/support/v7/view/menu/u;->mFlags:I

    and-int/lit8 v0, v0, -0x5

    if-eqz p1, :cond_0

    const/4 p1, 0x4

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    or-int/2addr p1, v0

    iput p1, p0, Landroid/support/v7/view/menu/u;->mFlags:I

    return-void
.end method

.method public setIcon(I)Landroid/view/MenuItem;
    .locals 1

    const/4 v0, 0x0

    iput-object v0, p0, Landroid/support/v7/view/menu/u;->bm:Landroid/graphics/drawable/Drawable;

    iput p1, p0, Landroid/support/v7/view/menu/u;->fn:I

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroid/support/v7/view/menu/u;->kn:Z

    iget-object p1, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/support/v7/view/menu/r;->onItemsChanged(Z)V

    return-object p0
.end method

.method public setIcon(Landroid/graphics/drawable/Drawable;)Landroid/view/MenuItem;
    .locals 1

    const/4 v0, 0x0

    iput v0, p0, Landroid/support/v7/view/menu/u;->fn:I

    iput-object p1, p0, Landroid/support/v7/view/menu/u;->bm:Landroid/graphics/drawable/Drawable;

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroid/support/v7/view/menu/u;->kn:Z

    iget-object p1, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    invoke-virtual {p1, v0}, Landroid/support/v7/view/menu/r;->onItemsChanged(Z)V

    return-object p0
.end method

.method public setIconTintList(Landroid/content/res/ColorStateList;)Landroid/view/MenuItem;
    .locals 1

    iput-object p1, p0, Landroid/support/v7/view/menu/u;->cm:Landroid/content/res/ColorStateList;

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroid/support/v7/view/menu/u;->em:Z

    iput-boolean p1, p0, Landroid/support/v7/view/menu/u;->kn:Z

    iget-object p1, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/support/v7/view/menu/r;->onItemsChanged(Z)V

    return-object p0
.end method

.method public setIconTintMode(Landroid/graphics/PorterDuff$Mode;)Landroid/view/MenuItem;
    .locals 1

    iput-object p1, p0, Landroid/support/v7/view/menu/u;->dm:Landroid/graphics/PorterDuff$Mode;

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroid/support/v7/view/menu/u;->fm:Z

    iput-boolean p1, p0, Landroid/support/v7/view/menu/u;->kn:Z

    iget-object p1, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/support/v7/view/menu/r;->onItemsChanged(Z)V

    return-object p0
.end method

.method public setIntent(Landroid/content/Intent;)Landroid/view/MenuItem;
    .locals 0

    iput-object p1, p0, Landroid/support/v7/view/menu/u;->mIntent:Landroid/content/Intent;

    return-object p0
.end method

.method public setIsActionButton(Z)V
    .locals 0

    if-eqz p1, :cond_0

    iget p1, p0, Landroid/support/v7/view/menu/u;->mFlags:I

    or-int/lit8 p1, p1, 0x20

    goto :goto_0

    :cond_0
    iget p1, p0, Landroid/support/v7/view/menu/u;->mFlags:I

    and-int/lit8 p1, p1, -0x21

    :goto_0
    iput p1, p0, Landroid/support/v7/view/menu/u;->mFlags:I

    return-void
.end method

.method setMenuInfo(Landroid/view/ContextMenu$ContextMenuInfo;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/view/menu/u;->rn:Landroid/view/ContextMenu$ContextMenuInfo;

    return-void
.end method

.method public setNumericShortcut(C)Landroid/view/MenuItem;
    .locals 1

    iget-char v0, p0, Landroid/support/v7/view/menu/u;->Yl:C

    if-ne v0, p1, :cond_0

    return-object p0

    :cond_0
    iput-char p1, p0, Landroid/support/v7/view/menu/u;->Yl:C

    iget-object p1, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/support/v7/view/menu/r;->onItemsChanged(Z)V

    return-object p0
.end method

.method public setNumericShortcut(CI)Landroid/view/MenuItem;
    .locals 1

    iget-char v0, p0, Landroid/support/v7/view/menu/u;->Yl:C

    if-ne v0, p1, :cond_0

    iget v0, p0, Landroid/support/v7/view/menu/u;->Zl:I

    if-ne v0, p2, :cond_0

    return-object p0

    :cond_0
    iput-char p1, p0, Landroid/support/v7/view/menu/u;->Yl:C

    invoke-static {p2}, Landroid/view/KeyEvent;->normalizeMetaState(I)I

    move-result p1

    iput p1, p0, Landroid/support/v7/view/menu/u;->Zl:I

    iget-object p1, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    const/4 p2, 0x0

    invoke-virtual {p1, p2}, Landroid/support/v7/view/menu/r;->onItemsChanged(Z)V

    return-object p0
.end method

.method public setOnActionExpandListener(Landroid/view/MenuItem$OnActionExpandListener;)Landroid/view/MenuItem;
    .locals 0

    iput-object p1, p0, Landroid/support/v7/view/menu/u;->pn:Landroid/view/MenuItem$OnActionExpandListener;

    return-object p0
.end method

.method public setOnMenuItemClickListener(Landroid/view/MenuItem$OnMenuItemClickListener;)Landroid/view/MenuItem;
    .locals 0

    iput-object p1, p0, Landroid/support/v7/view/menu/u;->jn:Landroid/view/MenuItem$OnMenuItemClickListener;

    return-object p0
.end method

.method public setShortcut(CC)Landroid/view/MenuItem;
    .locals 0

    iput-char p1, p0, Landroid/support/v7/view/menu/u;->Yl:C

    invoke-static {p2}, Ljava/lang/Character;->toLowerCase(C)C

    move-result p1

    iput-char p1, p0, Landroid/support/v7/view/menu/u;->_l:C

    iget-object p1, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    const/4 p2, 0x0

    invoke-virtual {p1, p2}, Landroid/support/v7/view/menu/r;->onItemsChanged(Z)V

    return-object p0
.end method

.method public setShortcut(CCII)Landroid/view/MenuItem;
    .locals 0

    iput-char p1, p0, Landroid/support/v7/view/menu/u;->Yl:C

    invoke-static {p3}, Landroid/view/KeyEvent;->normalizeMetaState(I)I

    move-result p1

    iput p1, p0, Landroid/support/v7/view/menu/u;->Zl:I

    invoke-static {p2}, Ljava/lang/Character;->toLowerCase(C)C

    move-result p1

    iput-char p1, p0, Landroid/support/v7/view/menu/u;->_l:C

    invoke-static {p4}, Landroid/view/KeyEvent;->normalizeMetaState(I)I

    move-result p1

    iput p1, p0, Landroid/support/v7/view/menu/u;->am:I

    iget-object p1, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    const/4 p2, 0x0

    invoke-virtual {p1, p2}, Landroid/support/v7/view/menu/r;->onItemsChanged(Z)V

    return-object p0
.end method

.method public setShowAsAction(I)V
    .locals 2

    and-int/lit8 v0, p1, 0x3

    if-eqz v0, :cond_1

    const/4 v1, 0x1

    if-eq v0, v1, :cond_1

    const/4 v1, 0x2

    if-ne v0, v1, :cond_0

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "SHOW_AS_ACTION_ALWAYS, SHOW_AS_ACTION_IF_ROOM, and SHOW_AS_ACTION_NEVER are mutually exclusive."

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    :goto_0
    iput p1, p0, Landroid/support/v7/view/menu/u;->ln:I

    iget-object p1, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    invoke-virtual {p1, p0}, Landroid/support/v7/view/menu/r;->d(Landroid/support/v7/view/menu/u;)V

    return-void
.end method

.method public setShowAsActionFlags(I)Landroid/view/MenuItem;
    .locals 2

    and-int/lit8 v0, p1, 0x3

    if-eqz v0, :cond_1

    const/4 v1, 0x1

    if-eq v0, v1, :cond_1

    const/4 v1, 0x2

    if-ne v0, v1, :cond_0

    goto :goto_0

    .line 1
    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "SHOW_AS_ACTION_ALWAYS, SHOW_AS_ACTION_IF_ROOM, and SHOW_AS_ACTION_NEVER are mutually exclusive."

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    :goto_0
    iput p1, p0, Landroid/support/v7/view/menu/u;->ln:I

    iget-object p1, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    invoke-virtual {p1, p0}, Landroid/support/v7/view/menu/r;->d(Landroid/support/v7/view/menu/u;)V

    return-object p0
.end method

.method public setTitle(I)Landroid/view/MenuItem;
    .locals 2

    iget-object v0, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    invoke-virtual {v0}, Landroid/support/v7/view/menu/r;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p1

    .line 1
    iput-object p1, p0, Landroid/support/v7/view/menu/u;->mTitle:Ljava/lang/CharSequence;

    iget-object v0, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/support/v7/view/menu/r;->onItemsChanged(Z)V

    iget-object v0, p0, Landroid/support/v7/view/menu/u;->gn:Landroid/support/v7/view/menu/P;

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Landroid/support/v7/view/menu/P;->setHeaderTitle(Ljava/lang/CharSequence;)Landroid/view/SubMenu;

    :cond_0
    return-object p0
.end method

.method public setTitle(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 2

    iput-object p1, p0, Landroid/support/v7/view/menu/u;->mTitle:Ljava/lang/CharSequence;

    iget-object v0, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/support/v7/view/menu/r;->onItemsChanged(Z)V

    iget-object v0, p0, Landroid/support/v7/view/menu/u;->gn:Landroid/support/v7/view/menu/P;

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Landroid/support/v7/view/menu/P;->setHeaderTitle(Ljava/lang/CharSequence;)Landroid/view/SubMenu;

    :cond_0
    return-object p0
.end method

.method public setTitleCondensed(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 1

    iput-object p1, p0, Landroid/support/v7/view/menu/u;->Xl:Ljava/lang/CharSequence;

    iget-object p1, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/support/v7/view/menu/r;->onItemsChanged(Z)V

    return-object p0
.end method

.method public setTooltipText(Ljava/lang/CharSequence;)La/b/c/c/a/b;
    .locals 1

    iput-object p1, p0, Landroid/support/v7/view/menu/u;->mTooltipText:Ljava/lang/CharSequence;

    iget-object p1, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/support/v7/view/menu/r;->onItemsChanged(Z)V

    return-object p0
.end method

.method public setTooltipText(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 1

    .line 1
    iput-object p1, p0, Landroid/support/v7/view/menu/u;->mTooltipText:Ljava/lang/CharSequence;

    iget-object p1, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/support/v7/view/menu/r;->onItemsChanged(Z)V

    return-object p0
.end method

.method public setVisible(Z)Landroid/view/MenuItem;
    .locals 0

    invoke-virtual {p0, p1}, Landroid/support/v7/view/menu/u;->setVisibleInt(Z)Z

    move-result p1

    if-eqz p1, :cond_0

    iget-object p1, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    invoke-virtual {p1, p0}, Landroid/support/v7/view/menu/r;->e(Landroid/support/v7/view/menu/u;)V

    :cond_0
    return-object p0
.end method

.method setVisibleInt(Z)Z
    .locals 3

    iget v0, p0, Landroid/support/v7/view/menu/u;->mFlags:I

    and-int/lit8 v1, v0, -0x9

    const/4 v2, 0x0

    if-eqz p1, :cond_0

    move p1, v2

    goto :goto_0

    :cond_0
    const/16 p1, 0x8

    :goto_0
    or-int/2addr p1, v1

    iput p1, p0, Landroid/support/v7/view/menu/u;->mFlags:I

    iget p0, p0, Landroid/support/v7/view/menu/u;->mFlags:I

    if-eq v0, p0, :cond_1

    const/4 v2, 0x1

    :cond_1
    return v2
.end method

.method shouldShowShortcut()Z
    .locals 1

    iget-object v0, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    invoke-virtual {v0}, Landroid/support/v7/view/menu/r;->isShortcutsVisible()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Landroid/support/v7/view/menu/u;->getShortcut()C

    move-result p0

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public showsTextAsAction()Z
    .locals 1

    iget p0, p0, Landroid/support/v7/view/menu/u;->ln:I

    const/4 v0, 0x4

    and-int/2addr p0, v0

    if-ne p0, v0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/u;->mTitle:Ljava/lang/CharSequence;

    if-eqz p0, :cond_0

    invoke-interface {p0}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return-object p0
.end method
