.class Landroid/support/v7/view/menu/k;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public final menu:Landroid/support/v7/view/menu/r;

.field public final position:I

.field public final window:Landroid/support/v7/widget/db;


# direct methods
.method public constructor <init>(Landroid/support/v7/widget/db;Landroid/support/v7/view/menu/r;I)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroid/support/v7/view/menu/k;->window:Landroid/support/v7/widget/db;

    iput-object p2, p0, Landroid/support/v7/view/menu/k;->menu:Landroid/support/v7/view/menu/r;

    iput p3, p0, Landroid/support/v7/view/menu/k;->position:I

    return-void
.end method


# virtual methods
.method public getListView()Landroid/widget/ListView;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/k;->window:Landroid/support/v7/widget/db;

    invoke-virtual {p0}, Landroid/support/v7/widget/ab;->getListView()Landroid/widget/ListView;

    move-result-object p0

    return-object p0
.end method
