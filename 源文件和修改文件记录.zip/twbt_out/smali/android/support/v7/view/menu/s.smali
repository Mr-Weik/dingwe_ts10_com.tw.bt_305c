.class Landroid/support/v7/view/menu/s;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/content/DialogInterface$OnKeyListener;
.implements Landroid/content/DialogInterface$OnClickListener;
.implements Landroid/content/DialogInterface$OnDismissListener;
.implements Landroid/support/v7/view/menu/F;


# instance fields
.field private dn:Landroid/support/v7/view/menu/F;

.field private mDialog:Landroid/support/v7/app/o;

.field private mMenu:Landroid/support/v7/view/menu/r;

.field mPresenter:Landroid/support/v7/view/menu/n;


# direct methods
.method public constructor <init>(Landroid/support/v7/view/menu/r;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroid/support/v7/view/menu/s;->mMenu:Landroid/support/v7/view/menu/r;

    return-void
.end method


# virtual methods
.method public a(Landroid/support/v7/view/menu/r;Z)V
    .locals 1

    if-nez p2, :cond_0

    iget-object v0, p0, Landroid/support/v7/view/menu/s;->mMenu:Landroid/support/v7/view/menu/r;

    if-ne p1, v0, :cond_1

    .line 1
    :cond_0
    iget-object v0, p0, Landroid/support/v7/view/menu/s;->mDialog:Landroid/support/v7/app/o;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V

    .line 2
    :cond_1
    iget-object p0, p0, Landroid/support/v7/view/menu/s;->dn:Landroid/support/v7/view/menu/F;

    if-eqz p0, :cond_2

    invoke-interface {p0, p1, p2}, Landroid/support/v7/view/menu/F;->a(Landroid/support/v7/view/menu/r;Z)V

    :cond_2
    return-void
.end method

.method public a(Landroid/support/v7/view/menu/r;)Z
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/s;->dn:Landroid/support/v7/view/menu/F;

    if-eqz p0, :cond_0

    invoke-interface {p0, p1}, Landroid/support/v7/view/menu/F;->a(Landroid/support/v7/view/menu/r;)Z

    move-result p0

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 0

    iget-object p1, p0, Landroid/support/v7/view/menu/s;->mMenu:Landroid/support/v7/view/menu/r;

    iget-object p0, p0, Landroid/support/v7/view/menu/s;->mPresenter:Landroid/support/v7/view/menu/n;

    invoke-virtual {p0}, Landroid/support/v7/view/menu/n;->getAdapter()Landroid/widget/ListAdapter;

    move-result-object p0

    invoke-interface {p0, p2}, Landroid/widget/ListAdapter;->getItem(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/support/v7/view/menu/u;

    const/4 p2, 0x0

    invoke-virtual {p1, p0, p2}, Landroid/support/v7/view/menu/r;->performItemAction(Landroid/view/MenuItem;I)Z

    return-void
.end method

.method public onDismiss(Landroid/content/DialogInterface;)V
    .locals 1

    iget-object p1, p0, Landroid/support/v7/view/menu/s;->mPresenter:Landroid/support/v7/view/menu/n;

    iget-object p0, p0, Landroid/support/v7/view/menu/s;->mMenu:Landroid/support/v7/view/menu/r;

    const/4 v0, 0x1

    invoke-virtual {p1, p0, v0}, Landroid/support/v7/view/menu/n;->a(Landroid/support/v7/view/menu/r;Z)V

    return-void
.end method

.method public onKey(Landroid/content/DialogInterface;ILandroid/view/KeyEvent;)Z
    .locals 2

    const/16 v0, 0x52

    if-eq p2, v0, :cond_0

    const/4 v0, 0x4

    if-ne p2, v0, :cond_2

    :cond_0
    invoke-virtual {p3}, Landroid/view/KeyEvent;->getAction()I

    move-result v0

    const/4 v1, 0x1

    if-nez v0, :cond_1

    invoke-virtual {p3}, Landroid/view/KeyEvent;->getRepeatCount()I

    move-result v0

    if-nez v0, :cond_1

    iget-object p1, p0, Landroid/support/v7/view/menu/s;->mDialog:Landroid/support/v7/app/o;

    invoke-virtual {p1}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object p1

    if-eqz p1, :cond_2

    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p1

    if-eqz p1, :cond_2

    invoke-virtual {p1}, Landroid/view/View;->getKeyDispatcherState()Landroid/view/KeyEvent$DispatcherState;

    move-result-object p1

    if-eqz p1, :cond_2

    invoke-virtual {p1, p3, p0}, Landroid/view/KeyEvent$DispatcherState;->startTracking(Landroid/view/KeyEvent;Ljava/lang/Object;)V

    return v1

    :cond_1
    invoke-virtual {p3}, Landroid/view/KeyEvent;->getAction()I

    move-result v0

    if-ne v0, v1, :cond_2

    invoke-virtual {p3}, Landroid/view/KeyEvent;->isCanceled()Z

    move-result v0

    if-nez v0, :cond_2

    iget-object v0, p0, Landroid/support/v7/view/menu/s;->mDialog:Landroid/support/v7/app/o;

    invoke-virtual {v0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Landroid/view/View;->getKeyDispatcherState()Landroid/view/KeyEvent$DispatcherState;

    move-result-object v0

    if-eqz v0, :cond_2

    invoke-virtual {v0, p3}, Landroid/view/KeyEvent$DispatcherState;->isTracking(Landroid/view/KeyEvent;)Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object p0, p0, Landroid/support/v7/view/menu/s;->mMenu:Landroid/support/v7/view/menu/r;

    invoke-virtual {p0, v1}, Landroid/support/v7/view/menu/r;->close(Z)V

    invoke-interface {p1}, Landroid/content/DialogInterface;->dismiss()V

    return v1

    :cond_2
    iget-object p0, p0, Landroid/support/v7/view/menu/s;->mMenu:Landroid/support/v7/view/menu/r;

    const/4 p1, 0x0

    invoke-virtual {p0, p2, p3, p1}, Landroid/support/v7/view/menu/r;->performShortcut(ILandroid/view/KeyEvent;I)Z

    move-result p0

    return p0
.end method

.method public show(Landroid/os/IBinder;)V
    .locals 5

    iget-object v0, p0, Landroid/support/v7/view/menu/s;->mMenu:Landroid/support/v7/view/menu/r;

    new-instance v1, Landroid/support/v7/app/n;

    invoke-virtual {v0}, Landroid/support/v7/view/menu/r;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/support/v7/app/n;-><init>(Landroid/content/Context;)V

    new-instance v2, Landroid/support/v7/view/menu/n;

    invoke-virtual {v1}, Landroid/support/v7/app/n;->getContext()Landroid/content/Context;

    move-result-object v3

    const v4, 0x7f0a0010

    invoke-direct {v2, v3, v4}, Landroid/support/v7/view/menu/n;-><init>(Landroid/content/Context;I)V

    iput-object v2, p0, Landroid/support/v7/view/menu/s;->mPresenter:Landroid/support/v7/view/menu/n;

    iget-object v2, p0, Landroid/support/v7/view/menu/s;->mPresenter:Landroid/support/v7/view/menu/n;

    invoke-virtual {v2, p0}, Landroid/support/v7/view/menu/n;->a(Landroid/support/v7/view/menu/F;)V

    iget-object v2, p0, Landroid/support/v7/view/menu/s;->mMenu:Landroid/support/v7/view/menu/r;

    iget-object v3, p0, Landroid/support/v7/view/menu/s;->mPresenter:Landroid/support/v7/view/menu/n;

    invoke-virtual {v2, v3}, Landroid/support/v7/view/menu/r;->a(Landroid/support/v7/view/menu/G;)V

    iget-object v2, p0, Landroid/support/v7/view/menu/s;->mPresenter:Landroid/support/v7/view/menu/n;

    invoke-virtual {v2}, Landroid/support/v7/view/menu/n;->getAdapter()Landroid/widget/ListAdapter;

    move-result-object v2

    invoke-virtual {v1, v2, p0}, Landroid/support/v7/app/n;->setAdapter(Landroid/widget/ListAdapter;Landroid/content/DialogInterface$OnClickListener;)Landroid/support/v7/app/n;

    .line 1
    iget-object v2, v0, Landroid/support/v7/view/menu/r;->mHeaderView:Landroid/view/View;

    if-eqz v2, :cond_0

    .line 2
    invoke-virtual {v1, v2}, Landroid/support/v7/app/n;->setCustomTitle(Landroid/view/View;)Landroid/support/v7/app/n;

    goto :goto_0

    .line 3
    :cond_0
    iget-object v2, v0, Landroid/support/v7/view/menu/r;->mHeaderIcon:Landroid/graphics/drawable/Drawable;

    .line 4
    invoke-virtual {v1, v2}, Landroid/support/v7/app/n;->setIcon(Landroid/graphics/drawable/Drawable;)Landroid/support/v7/app/n;

    .line 5
    iget-object v0, v0, Landroid/support/v7/view/menu/r;->mHeaderTitle:Ljava/lang/CharSequence;

    .line 6
    invoke-virtual {v1, v0}, Landroid/support/v7/app/n;->setTitle(Ljava/lang/CharSequence;)Landroid/support/v7/app/n;

    :goto_0
    invoke-virtual {v1, p0}, Landroid/support/v7/app/n;->setOnKeyListener(Landroid/content/DialogInterface$OnKeyListener;)Landroid/support/v7/app/n;

    invoke-virtual {v1}, Landroid/support/v7/app/n;->create()Landroid/support/v7/app/o;

    move-result-object v0

    iput-object v0, p0, Landroid/support/v7/view/menu/s;->mDialog:Landroid/support/v7/app/o;

    iget-object v0, p0, Landroid/support/v7/view/menu/s;->mDialog:Landroid/support/v7/app/o;

    invoke-virtual {v0, p0}, Landroid/app/Dialog;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)V

    iget-object v0, p0, Landroid/support/v7/view/menu/s;->mDialog:Landroid/support/v7/app/o;

    invoke-virtual {v0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    move-result-object v0

    const/16 v1, 0x3eb

    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->type:I

    if-eqz p1, :cond_1

    iput-object p1, v0, Landroid/view/WindowManager$LayoutParams;->token:Landroid/os/IBinder;

    :cond_1
    iget p1, v0, Landroid/view/WindowManager$LayoutParams;->flags:I

    const/high16 v1, 0x20000

    or-int/2addr p1, v1

    iput p1, v0, Landroid/view/WindowManager$LayoutParams;->flags:I

    iget-object p0, p0, Landroid/support/v7/view/menu/s;->mDialog:Landroid/support/v7/app/o;

    invoke-virtual {p0}, Landroid/app/Dialog;->show()V

    return-void
.end method
