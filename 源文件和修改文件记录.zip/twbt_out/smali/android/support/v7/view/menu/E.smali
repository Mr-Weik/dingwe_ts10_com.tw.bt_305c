.class public Landroid/support/v7/view/menu/E;
.super Ljava/lang/Object;
.source ""


# instance fields
.field private En:I

.field private Fn:Landroid/view/View;

.field private Ln:Z

.field private final Sn:Landroid/widget/PopupWindow$OnDismissListener;

.field private dn:Landroid/support/v7/view/menu/F;

.field private final mContext:Landroid/content/Context;

.field private final mMenu:Landroid/support/v7/view/menu/r;

.field private mOnDismissListener:Landroid/widget/PopupWindow$OnDismissListener;

.field private mPopup:Landroid/support/v7/view/menu/C;

.field private final un:I

.field private final vn:I

.field private final wn:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/support/v7/view/menu/r;Landroid/view/View;ZII)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const v0, 0x800003

    iput v0, p0, Landroid/support/v7/view/menu/E;->En:I

    new-instance v0, Landroid/support/v7/view/menu/D;

    invoke-direct {v0, p0}, Landroid/support/v7/view/menu/D;-><init>(Landroid/support/v7/view/menu/E;)V

    iput-object v0, p0, Landroid/support/v7/view/menu/E;->Sn:Landroid/widget/PopupWindow$OnDismissListener;

    iput-object p1, p0, Landroid/support/v7/view/menu/E;->mContext:Landroid/content/Context;

    iput-object p2, p0, Landroid/support/v7/view/menu/E;->mMenu:Landroid/support/v7/view/menu/r;

    iput-object p3, p0, Landroid/support/v7/view/menu/E;->Fn:Landroid/view/View;

    iput-boolean p4, p0, Landroid/support/v7/view/menu/E;->wn:Z

    iput p5, p0, Landroid/support/v7/view/menu/E;->un:I

    iput p6, p0, Landroid/support/v7/view/menu/E;->vn:I

    return-void
.end method

.method private a(IIZZ)V
    .locals 2

    invoke-virtual {p0}, Landroid/support/v7/view/menu/E;->getPopup()Landroid/support/v7/view/menu/C;

    move-result-object v0

    invoke-virtual {v0, p4}, Landroid/support/v7/view/menu/C;->setShowTitle(Z)V

    if-eqz p3, :cond_1

    iget p3, p0, Landroid/support/v7/view/menu/E;->En:I

    iget-object p4, p0, Landroid/support/v7/view/menu/E;->Fn:Landroid/view/View;

    invoke-static {p4}, Landroid/support/v4/view/r;->o(Landroid/view/View;)I

    move-result p4

    invoke-static {p3, p4}, La/b/a/a;->getAbsoluteGravity(II)I

    move-result p3

    and-int/lit8 p3, p3, 0x7

    const/4 p4, 0x5

    if-ne p3, p4, :cond_0

    iget-object p3, p0, Landroid/support/v7/view/menu/E;->Fn:Landroid/view/View;

    invoke-virtual {p3}, Landroid/view/View;->getWidth()I

    move-result p3

    sub-int/2addr p1, p3

    :cond_0
    invoke-virtual {v0, p1}, Landroid/support/v7/view/menu/C;->setHorizontalOffset(I)V

    invoke-virtual {v0, p2}, Landroid/support/v7/view/menu/C;->setVerticalOffset(I)V

    iget-object p0, p0, Landroid/support/v7/view/menu/E;->mContext:Landroid/content/Context;

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    iget p0, p0, Landroid/util/DisplayMetrics;->density:F

    const/high16 p3, 0x42400000    # 48.0f

    mul-float/2addr p0, p3

    const/high16 p3, 0x40000000    # 2.0f

    div-float/2addr p0, p3

    float-to-int p0, p0

    new-instance p3, Landroid/graphics/Rect;

    sub-int p4, p1, p0

    sub-int v1, p2, p0

    add-int/2addr p1, p0

    add-int/2addr p2, p0

    invoke-direct {p3, p4, v1, p1, p2}, Landroid/graphics/Rect;-><init>(IIII)V

    invoke-virtual {v0, p3}, Landroid/support/v7/view/menu/C;->setEpicenterBounds(Landroid/graphics/Rect;)V

    :cond_1
    invoke-interface {v0}, Landroid/support/v7/view/menu/L;->show()V

    return-void
.end method


# virtual methods
.method public b(Landroid/support/v7/view/menu/F;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/view/menu/E;->dn:Landroid/support/v7/view/menu/F;

    iget-object p0, p0, Landroid/support/v7/view/menu/E;->mPopup:Landroid/support/v7/view/menu/C;

    if-eqz p0, :cond_0

    invoke-interface {p0, p1}, Landroid/support/v7/view/menu/G;->a(Landroid/support/v7/view/menu/F;)V

    :cond_0
    return-void
.end method

.method public dismiss()V
    .locals 1

    invoke-virtual {p0}, Landroid/support/v7/view/menu/E;->isShowing()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object p0, p0, Landroid/support/v7/view/menu/E;->mPopup:Landroid/support/v7/view/menu/C;

    invoke-interface {p0}, Landroid/support/v7/view/menu/L;->dismiss()V

    :cond_0
    return-void
.end method

.method public getPopup()Landroid/support/v7/view/menu/C;
    .locals 14

    iget-object v0, p0, Landroid/support/v7/view/menu/E;->mPopup:Landroid/support/v7/view/menu/C;

    if-nez v0, :cond_2

    .line 1
    iget-object v0, p0, Landroid/support/v7/view/menu/E;->mContext:Landroid/content/Context;

    const-string v1, "window"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/WindowManager;

    invoke-interface {v0}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object v0

    new-instance v1, Landroid/graphics/Point;

    invoke-direct {v1}, Landroid/graphics/Point;-><init>()V

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-virtual {v0, v1}, Landroid/view/Display;->getRealSize(Landroid/graphics/Point;)V

    iget v0, v1, Landroid/graphics/Point;->x:I

    iget v1, v1, Landroid/graphics/Point;->y:I

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v0

    iget-object v1, p0, Landroid/support/v7/view/menu/E;->mContext:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f060016

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v1

    if-lt v0, v1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    if-eqz v0, :cond_1

    new-instance v0, Landroid/support/v7/view/menu/l;

    iget-object v2, p0, Landroid/support/v7/view/menu/E;->mContext:Landroid/content/Context;

    iget-object v3, p0, Landroid/support/v7/view/menu/E;->Fn:Landroid/view/View;

    iget v4, p0, Landroid/support/v7/view/menu/E;->un:I

    iget v5, p0, Landroid/support/v7/view/menu/E;->vn:I

    iget-boolean v6, p0, Landroid/support/v7/view/menu/E;->wn:Z

    move-object v1, v0

    invoke-direct/range {v1 .. v6}, Landroid/support/v7/view/menu/l;-><init>(Landroid/content/Context;Landroid/view/View;IIZ)V

    goto :goto_1

    :cond_1
    new-instance v0, Landroid/support/v7/view/menu/O;

    iget-object v8, p0, Landroid/support/v7/view/menu/E;->mContext:Landroid/content/Context;

    iget-object v9, p0, Landroid/support/v7/view/menu/E;->mMenu:Landroid/support/v7/view/menu/r;

    iget-object v10, p0, Landroid/support/v7/view/menu/E;->Fn:Landroid/view/View;

    iget v11, p0, Landroid/support/v7/view/menu/E;->un:I

    iget v12, p0, Landroid/support/v7/view/menu/E;->vn:I

    iget-boolean v13, p0, Landroid/support/v7/view/menu/E;->wn:Z

    move-object v7, v0

    invoke-direct/range {v7 .. v13}, Landroid/support/v7/view/menu/O;-><init>(Landroid/content/Context;Landroid/support/v7/view/menu/r;Landroid/view/View;IIZ)V

    :goto_1
    iget-object v1, p0, Landroid/support/v7/view/menu/E;->mMenu:Landroid/support/v7/view/menu/r;

    invoke-virtual {v0, v1}, Landroid/support/v7/view/menu/C;->f(Landroid/support/v7/view/menu/r;)V

    iget-object v1, p0, Landroid/support/v7/view/menu/E;->Sn:Landroid/widget/PopupWindow$OnDismissListener;

    invoke-virtual {v0, v1}, Landroid/support/v7/view/menu/C;->setOnDismissListener(Landroid/widget/PopupWindow$OnDismissListener;)V

    iget-object v1, p0, Landroid/support/v7/view/menu/E;->Fn:Landroid/view/View;

    invoke-virtual {v0, v1}, Landroid/support/v7/view/menu/C;->setAnchorView(Landroid/view/View;)V

    iget-object v1, p0, Landroid/support/v7/view/menu/E;->dn:Landroid/support/v7/view/menu/F;

    invoke-interface {v0, v1}, Landroid/support/v7/view/menu/G;->a(Landroid/support/v7/view/menu/F;)V

    iget-boolean v1, p0, Landroid/support/v7/view/menu/E;->Ln:Z

    invoke-virtual {v0, v1}, Landroid/support/v7/view/menu/C;->setForceShowIcon(Z)V

    iget v1, p0, Landroid/support/v7/view/menu/E;->En:I

    invoke-virtual {v0, v1}, Landroid/support/v7/view/menu/C;->setGravity(I)V

    .line 2
    iput-object v0, p0, Landroid/support/v7/view/menu/E;->mPopup:Landroid/support/v7/view/menu/C;

    :cond_2
    iget-object p0, p0, Landroid/support/v7/view/menu/E;->mPopup:Landroid/support/v7/view/menu/C;

    return-object p0
.end method

.method public isShowing()Z
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/E;->mPopup:Landroid/support/v7/view/menu/C;

    if-eqz p0, :cond_0

    invoke-interface {p0}, Landroid/support/v7/view/menu/L;->isShowing()Z

    move-result p0

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method protected onDismiss()V
    .locals 1

    const/4 v0, 0x0

    iput-object v0, p0, Landroid/support/v7/view/menu/E;->mPopup:Landroid/support/v7/view/menu/C;

    iget-object p0, p0, Landroid/support/v7/view/menu/E;->mOnDismissListener:Landroid/widget/PopupWindow$OnDismissListener;

    if-eqz p0, :cond_0

    invoke-interface {p0}, Landroid/widget/PopupWindow$OnDismissListener;->onDismiss()V

    :cond_0
    return-void
.end method

.method public setAnchorView(Landroid/view/View;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/view/menu/E;->Fn:Landroid/view/View;

    return-void
.end method

.method public setForceShowIcon(Z)V
    .locals 0

    iput-boolean p1, p0, Landroid/support/v7/view/menu/E;->Ln:Z

    iget-object p0, p0, Landroid/support/v7/view/menu/E;->mPopup:Landroid/support/v7/view/menu/C;

    if-eqz p0, :cond_0

    invoke-virtual {p0, p1}, Landroid/support/v7/view/menu/C;->setForceShowIcon(Z)V

    :cond_0
    return-void
.end method

.method public setGravity(I)V
    .locals 0

    iput p1, p0, Landroid/support/v7/view/menu/E;->En:I

    return-void
.end method

.method public setOnDismissListener(Landroid/widget/PopupWindow$OnDismissListener;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/view/menu/E;->mOnDismissListener:Landroid/widget/PopupWindow$OnDismissListener;

    return-void
.end method

.method public tryShow()Z
    .locals 3

    invoke-virtual {p0}, Landroid/support/v7/view/menu/E;->isShowing()Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    return v1

    :cond_0
    iget-object v0, p0, Landroid/support/v7/view/menu/E;->Fn:Landroid/view/View;

    const/4 v2, 0x0

    if-nez v0, :cond_1

    return v2

    :cond_1
    invoke-direct {p0, v2, v2, v2, v2}, Landroid/support/v7/view/menu/E;->a(IIZZ)V

    return v1
.end method

.method public tryShow(II)Z
    .locals 2

    invoke-virtual {p0}, Landroid/support/v7/view/menu/E;->isShowing()Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    return v1

    :cond_0
    iget-object v0, p0, Landroid/support/v7/view/menu/E;->Fn:Landroid/view/View;

    if-nez v0, :cond_1

    const/4 p0, 0x0

    return p0

    :cond_1
    invoke-direct {p0, p1, p2, v1, v1}, Landroid/support/v7/view/menu/E;->a(IIZZ)V

    return v1
.end method
