.class abstract Landroid/support/v7/view/menu/e;
.super Landroid/support/v7/view/menu/f;
.source ""


# instance fields
.field private Bm:Ljava/util/Map;

.field private Cm:Ljava/util/Map;

.field final mContext:Landroid/content/Context;


# direct methods
.method constructor <init>(Landroid/content/Context;Ljava/lang/Object;)V
    .locals 0

    invoke-direct {p0, p2}, Landroid/support/v7/view/menu/f;-><init>(Ljava/lang/Object;)V

    iput-object p1, p0, Landroid/support/v7/view/menu/e;->mContext:Landroid/content/Context;

    return-void
.end method


# virtual methods
.method final Ta()V
    .locals 1

    iget-object v0, p0, Landroid/support/v7/view/menu/e;->Bm:Ljava/util/Map;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Ljava/util/Map;->clear()V

    :cond_0
    iget-object p0, p0, Landroid/support/v7/view/menu/e;->Cm:Ljava/util/Map;

    if-eqz p0, :cond_1

    invoke-interface {p0}, Ljava/util/Map;->clear()V

    :cond_1
    return-void
.end method

.method final U(I)V
    .locals 1

    iget-object p0, p0, Landroid/support/v7/view/menu/e;->Bm:Ljava/util/Map;

    if-nez p0, :cond_0

    return-void

    :cond_0
    invoke-interface {p0}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_1
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/MenuItem;

    invoke-interface {v0}, Landroid/view/MenuItem;->getGroupId()I

    move-result v0

    if-ne p1, v0, :cond_1

    invoke-interface {p0}, Ljava/util/Iterator;->remove()V

    goto :goto_0

    :cond_2
    return-void
.end method

.method final V(I)V
    .locals 1

    iget-object p0, p0, Landroid/support/v7/view/menu/e;->Bm:Ljava/util/Map;

    if-nez p0, :cond_0

    return-void

    :cond_0
    invoke-interface {p0}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_1
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/MenuItem;

    invoke-interface {v0}, Landroid/view/MenuItem;->getItemId()I

    move-result v0

    if-ne p1, v0, :cond_1

    invoke-interface {p0}, Ljava/util/Iterator;->remove()V

    :cond_2
    return-void
.end method

.method final a(Landroid/view/MenuItem;)Landroid/view/MenuItem;
    .locals 2

    instance-of v0, p1, La/b/c/c/a/b;

    if-eqz v0, :cond_1

    move-object v0, p1

    check-cast v0, La/b/c/c/a/b;

    iget-object v1, p0, Landroid/support/v7/view/menu/e;->Bm:Ljava/util/Map;

    if-nez v1, :cond_0

    new-instance v1, La/b/c/f/b;

    invoke-direct {v1}, La/b/c/f/b;-><init>()V

    iput-object v1, p0, Landroid/support/v7/view/menu/e;->Bm:Ljava/util/Map;

    :cond_0
    iget-object v1, p0, Landroid/support/v7/view/menu/e;->Bm:Ljava/util/Map;

    invoke-interface {v1, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/view/MenuItem;

    if-nez p1, :cond_1

    iget-object p1, p0, Landroid/support/v7/view/menu/e;->mContext:Landroid/content/Context;

    invoke-static {p1, v0}, Landroid/support/v7/view/menu/J;->a(Landroid/content/Context;La/b/c/c/a/b;)Landroid/view/MenuItem;

    move-result-object p1

    iget-object p0, p0, Landroid/support/v7/view/menu/e;->Bm:Ljava/util/Map;

    invoke-interface {p0, v0, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1
    return-object p1
.end method

.method final a(Landroid/view/SubMenu;)Landroid/view/SubMenu;
    .locals 2

    instance-of v0, p1, La/b/c/c/a/c;

    if-eqz v0, :cond_2

    check-cast p1, La/b/c/c/a/c;

    iget-object v0, p0, Landroid/support/v7/view/menu/e;->Cm:Ljava/util/Map;

    if-nez v0, :cond_0

    new-instance v0, La/b/c/f/b;

    invoke-direct {v0}, La/b/c/f/b;-><init>()V

    iput-object v0, p0, Landroid/support/v7/view/menu/e;->Cm:Ljava/util/Map;

    :cond_0
    iget-object v0, p0, Landroid/support/v7/view/menu/e;->Cm:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/SubMenu;

    if-nez v0, :cond_1

    iget-object v0, p0, Landroid/support/v7/view/menu/e;->mContext:Landroid/content/Context;

    .line 1
    new-instance v1, Landroid/support/v7/view/menu/Q;

    invoke-direct {v1, v0, p1}, Landroid/support/v7/view/menu/Q;-><init>(Landroid/content/Context;La/b/c/c/a/c;)V

    .line 2
    iget-object p0, p0, Landroid/support/v7/view/menu/e;->Cm:Ljava/util/Map;

    invoke-interface {p0, p1, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-object v0, v1

    :cond_1
    return-object v0

    :cond_2
    return-object p1
.end method
