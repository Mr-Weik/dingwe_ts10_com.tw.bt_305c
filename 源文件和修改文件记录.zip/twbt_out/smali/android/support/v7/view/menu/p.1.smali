.class public interface abstract Landroid/support/v7/view/menu/p;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract b(Landroid/support/v7/view/menu/r;)V
.end method

.method public abstract c(Landroid/support/v7/view/menu/r;Landroid/view/MenuItem;)Z
.end method
