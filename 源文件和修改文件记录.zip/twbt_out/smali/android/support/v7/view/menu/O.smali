.class final Landroid/support/v7/view/menu/O;
.super Landroid/support/v7/view/menu/C;
.source ""

# interfaces
.implements Landroid/widget/PopupWindow$OnDismissListener;
.implements Landroid/widget/AdapterView$OnItemClickListener;
.implements Landroid/support/v7/view/menu/G;
.implements Landroid/view/View$OnKeyListener;


# instance fields
.field private final An:Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;

.field private final Bn:Landroid/view/View$OnAttachStateChangeListener;

.field private En:I

.field private Fn:Landroid/view/View;

.field Gn:Landroid/view/View;

.field private final Nn:I

.field private Pn:Z

.field private Qn:Z

.field private Rn:I

.field private Yi:Z

.field private dn:Landroid/support/v7/view/menu/F;

.field private final mAdapter:Landroid/support/v7/view/menu/o;

.field private final mContext:Landroid/content/Context;

.field private final mMenu:Landroid/support/v7/view/menu/r;

.field private mOnDismissListener:Landroid/widget/PopupWindow$OnDismissListener;

.field final mPopup:Landroid/support/v7/widget/db;

.field private mTreeObserver:Landroid/view/ViewTreeObserver;

.field private final un:I

.field private final vn:I

.field private final wn:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/support/v7/view/menu/r;Landroid/view/View;IIZ)V
    .locals 3

    invoke-direct {p0}, Landroid/support/v7/view/menu/C;-><init>()V

    new-instance v0, Landroid/support/v7/view/menu/M;

    invoke-direct {v0, p0}, Landroid/support/v7/view/menu/M;-><init>(Landroid/support/v7/view/menu/O;)V

    iput-object v0, p0, Landroid/support/v7/view/menu/O;->An:Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;

    new-instance v0, Landroid/support/v7/view/menu/N;

    invoke-direct {v0, p0}, Landroid/support/v7/view/menu/N;-><init>(Landroid/support/v7/view/menu/O;)V

    iput-object v0, p0, Landroid/support/v7/view/menu/O;->Bn:Landroid/view/View$OnAttachStateChangeListener;

    const/4 v0, 0x0

    iput v0, p0, Landroid/support/v7/view/menu/O;->En:I

    iput-object p1, p0, Landroid/support/v7/view/menu/O;->mContext:Landroid/content/Context;

    iput-object p2, p0, Landroid/support/v7/view/menu/O;->mMenu:Landroid/support/v7/view/menu/r;

    iput-boolean p6, p0, Landroid/support/v7/view/menu/O;->wn:Z

    invoke-static {p1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object p6

    new-instance v0, Landroid/support/v7/view/menu/o;

    iget-boolean v1, p0, Landroid/support/v7/view/menu/O;->wn:Z

    const v2, 0x7f0a0013

    invoke-direct {v0, p2, p6, v1, v2}, Landroid/support/v7/view/menu/o;-><init>(Landroid/support/v7/view/menu/r;Landroid/view/LayoutInflater;ZI)V

    iput-object v0, p0, Landroid/support/v7/view/menu/O;->mAdapter:Landroid/support/v7/view/menu/o;

    iput p4, p0, Landroid/support/v7/view/menu/O;->un:I

    iput p5, p0, Landroid/support/v7/view/menu/O;->vn:I

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p4

    invoke-virtual {p4}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p5

    iget p5, p5, Landroid/util/DisplayMetrics;->widthPixels:I

    div-int/lit8 p5, p5, 0x2

    const p6, 0x7f060017

    invoke-virtual {p4, p6}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result p4

    invoke-static {p5, p4}, Ljava/lang/Math;->max(II)I

    move-result p4

    iput p4, p0, Landroid/support/v7/view/menu/O;->Nn:I

    iput-object p3, p0, Landroid/support/v7/view/menu/O;->Fn:Landroid/view/View;

    new-instance p3, Landroid/support/v7/widget/db;

    iget-object p4, p0, Landroid/support/v7/view/menu/O;->mContext:Landroid/content/Context;

    iget p5, p0, Landroid/support/v7/view/menu/O;->un:I

    iget p6, p0, Landroid/support/v7/view/menu/O;->vn:I

    const/4 v0, 0x0

    invoke-direct {p3, p4, v0, p5, p6}, Landroid/support/v7/widget/db;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    iput-object p3, p0, Landroid/support/v7/view/menu/O;->mPopup:Landroid/support/v7/widget/db;

    invoke-virtual {p2, p0, p1}, Landroid/support/v7/view/menu/r;->a(Landroid/support/v7/view/menu/G;Landroid/content/Context;)V

    return-void
.end method

.method static synthetic a(Landroid/support/v7/view/menu/O;)Landroid/view/ViewTreeObserver;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/O;->mTreeObserver:Landroid/view/ViewTreeObserver;

    return-object p0
.end method

.method static synthetic a(Landroid/support/v7/view/menu/O;Landroid/view/ViewTreeObserver;)Landroid/view/ViewTreeObserver;
    .locals 0

    iput-object p1, p0, Landroid/support/v7/view/menu/O;->mTreeObserver:Landroid/view/ViewTreeObserver;

    return-object p1
.end method

.method static synthetic b(Landroid/support/v7/view/menu/O;)Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/O;->An:Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;

    return-object p0
.end method


# virtual methods
.method public a(Landroid/support/v7/view/menu/F;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/view/menu/O;->dn:Landroid/support/v7/view/menu/F;

    return-void
.end method

.method public a(Landroid/support/v7/view/menu/r;Z)V
    .locals 1

    iget-object v0, p0, Landroid/support/v7/view/menu/O;->mMenu:Landroid/support/v7/view/menu/r;

    if-eq p1, v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {p0}, Landroid/support/v7/view/menu/O;->dismiss()V

    iget-object p0, p0, Landroid/support/v7/view/menu/O;->dn:Landroid/support/v7/view/menu/F;

    if-eqz p0, :cond_1

    invoke-interface {p0, p1, p2}, Landroid/support/v7/view/menu/F;->a(Landroid/support/v7/view/menu/r;Z)V

    :cond_1
    return-void
.end method

.method public a(Landroid/support/v7/view/menu/P;)Z
    .locals 9

    invoke-virtual {p1}, Landroid/support/v7/view/menu/r;->hasVisibleItems()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_2

    new-instance v0, Landroid/support/v7/view/menu/E;

    iget-object v3, p0, Landroid/support/v7/view/menu/O;->mContext:Landroid/content/Context;

    iget-object v5, p0, Landroid/support/v7/view/menu/O;->Gn:Landroid/view/View;

    iget-boolean v6, p0, Landroid/support/v7/view/menu/O;->wn:Z

    iget v7, p0, Landroid/support/v7/view/menu/O;->un:I

    iget v8, p0, Landroid/support/v7/view/menu/O;->vn:I

    move-object v2, v0

    move-object v4, p1

    invoke-direct/range {v2 .. v8}, Landroid/support/v7/view/menu/E;-><init>(Landroid/content/Context;Landroid/support/v7/view/menu/r;Landroid/view/View;ZII)V

    iget-object v2, p0, Landroid/support/v7/view/menu/O;->dn:Landroid/support/v7/view/menu/F;

    invoke-virtual {v0, v2}, Landroid/support/v7/view/menu/E;->b(Landroid/support/v7/view/menu/F;)V

    invoke-static {p1}, Landroid/support/v7/view/menu/C;->g(Landroid/support/v7/view/menu/r;)Z

    move-result v2

    invoke-virtual {v0, v2}, Landroid/support/v7/view/menu/E;->setForceShowIcon(Z)V

    iget-object v2, p0, Landroid/support/v7/view/menu/O;->mOnDismissListener:Landroid/widget/PopupWindow$OnDismissListener;

    invoke-virtual {v0, v2}, Landroid/support/v7/view/menu/E;->setOnDismissListener(Landroid/widget/PopupWindow$OnDismissListener;)V

    const/4 v2, 0x0

    iput-object v2, p0, Landroid/support/v7/view/menu/O;->mOnDismissListener:Landroid/widget/PopupWindow$OnDismissListener;

    iget-object v2, p0, Landroid/support/v7/view/menu/O;->mMenu:Landroid/support/v7/view/menu/r;

    invoke-virtual {v2, v1}, Landroid/support/v7/view/menu/r;->close(Z)V

    iget-object v2, p0, Landroid/support/v7/view/menu/O;->mPopup:Landroid/support/v7/widget/db;

    invoke-virtual {v2}, Landroid/support/v7/widget/ab;->getHorizontalOffset()I

    move-result v2

    iget-object v3, p0, Landroid/support/v7/view/menu/O;->mPopup:Landroid/support/v7/widget/db;

    invoke-virtual {v3}, Landroid/support/v7/widget/ab;->getVerticalOffset()I

    move-result v3

    iget v4, p0, Landroid/support/v7/view/menu/O;->En:I

    iget-object v5, p0, Landroid/support/v7/view/menu/O;->Fn:Landroid/view/View;

    invoke-static {v5}, Landroid/support/v4/view/r;->o(Landroid/view/View;)I

    move-result v5

    invoke-static {v4, v5}, Landroid/view/Gravity;->getAbsoluteGravity(II)I

    move-result v4

    and-int/lit8 v4, v4, 0x7

    const/4 v5, 0x5

    if-ne v4, v5, :cond_0

    iget-object v4, p0, Landroid/support/v7/view/menu/O;->Fn:Landroid/view/View;

    invoke-virtual {v4}, Landroid/view/View;->getWidth()I

    move-result v4

    add-int/2addr v2, v4

    :cond_0
    invoke-virtual {v0, v2, v3}, Landroid/support/v7/view/menu/E;->tryShow(II)Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object p0, p0, Landroid/support/v7/view/menu/O;->dn:Landroid/support/v7/view/menu/F;

    if-eqz p0, :cond_1

    invoke-interface {p0, p1}, Landroid/support/v7/view/menu/F;->a(Landroid/support/v7/view/menu/r;)Z

    :cond_1
    const/4 p0, 0x1

    return p0

    :cond_2
    return v1
.end method

.method public dismiss()V
    .locals 1

    invoke-virtual {p0}, Landroid/support/v7/view/menu/O;->isShowing()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object p0, p0, Landroid/support/v7/view/menu/O;->mPopup:Landroid/support/v7/widget/db;

    invoke-virtual {p0}, Landroid/support/v7/widget/ab;->dismiss()V

    :cond_0
    return-void
.end method

.method public f(Landroid/support/v7/view/menu/r;)V
    .locals 0

    return-void
.end method

.method public flagActionItems()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public getListView()Landroid/widget/ListView;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/O;->mPopup:Landroid/support/v7/widget/db;

    invoke-virtual {p0}, Landroid/support/v7/widget/ab;->getListView()Landroid/widget/ListView;

    move-result-object p0

    return-object p0
.end method

.method public isShowing()Z
    .locals 1

    iget-boolean v0, p0, Landroid/support/v7/view/menu/O;->Pn:Z

    if-nez v0, :cond_0

    iget-object p0, p0, Landroid/support/v7/view/menu/O;->mPopup:Landroid/support/v7/widget/db;

    invoke-virtual {p0}, Landroid/support/v7/widget/ab;->isShowing()Z

    move-result p0

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public onDismiss()V
    .locals 2

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v7/view/menu/O;->Pn:Z

    iget-object v1, p0, Landroid/support/v7/view/menu/O;->mMenu:Landroid/support/v7/view/menu/r;

    .line 1
    invoke-virtual {v1, v0}, Landroid/support/v7/view/menu/r;->close(Z)V

    .line 2
    iget-object v0, p0, Landroid/support/v7/view/menu/O;->mTreeObserver:Landroid/view/ViewTreeObserver;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Landroid/view/ViewTreeObserver;->isAlive()Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Landroid/support/v7/view/menu/O;->Gn:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    iput-object v0, p0, Landroid/support/v7/view/menu/O;->mTreeObserver:Landroid/view/ViewTreeObserver;

    :cond_0
    iget-object v0, p0, Landroid/support/v7/view/menu/O;->mTreeObserver:Landroid/view/ViewTreeObserver;

    iget-object v1, p0, Landroid/support/v7/view/menu/O;->An:Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;

    invoke-virtual {v0, v1}, Landroid/view/ViewTreeObserver;->removeGlobalOnLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    const/4 v0, 0x0

    iput-object v0, p0, Landroid/support/v7/view/menu/O;->mTreeObserver:Landroid/view/ViewTreeObserver;

    :cond_1
    iget-object v0, p0, Landroid/support/v7/view/menu/O;->Gn:Landroid/view/View;

    iget-object v1, p0, Landroid/support/v7/view/menu/O;->Bn:Landroid/view/View$OnAttachStateChangeListener;

    invoke-virtual {v0, v1}, Landroid/view/View;->removeOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    iget-object p0, p0, Landroid/support/v7/view/menu/O;->mOnDismissListener:Landroid/widget/PopupWindow$OnDismissListener;

    if-eqz p0, :cond_2

    invoke-interface {p0}, Landroid/widget/PopupWindow$OnDismissListener;->onDismiss()V

    :cond_2
    return-void
.end method

.method public onKey(Landroid/view/View;ILandroid/view/KeyEvent;)Z
    .locals 0

    invoke-virtual {p3}, Landroid/view/KeyEvent;->getAction()I

    move-result p1

    const/4 p3, 0x1

    if-ne p1, p3, :cond_0

    const/16 p1, 0x52

    if-ne p2, p1, :cond_0

    invoke-virtual {p0}, Landroid/support/v7/view/menu/O;->dismiss()V

    return p3

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public setAnchorView(Landroid/view/View;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/view/menu/O;->Fn:Landroid/view/View;

    return-void
.end method

.method public setForceShowIcon(Z)V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/O;->mAdapter:Landroid/support/v7/view/menu/o;

    invoke-virtual {p0, p1}, Landroid/support/v7/view/menu/o;->setForceShowIcon(Z)V

    return-void
.end method

.method public setGravity(I)V
    .locals 0

    iput p1, p0, Landroid/support/v7/view/menu/O;->En:I

    return-void
.end method

.method public setHorizontalOffset(I)V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/O;->mPopup:Landroid/support/v7/widget/db;

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/ab;->setHorizontalOffset(I)V

    return-void
.end method

.method public setOnDismissListener(Landroid/widget/PopupWindow$OnDismissListener;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/view/menu/O;->mOnDismissListener:Landroid/widget/PopupWindow$OnDismissListener;

    return-void
.end method

.method public setShowTitle(Z)V
    .locals 0

    iput-boolean p1, p0, Landroid/support/v7/view/menu/O;->Yi:Z

    return-void
.end method

.method public setVerticalOffset(I)V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/O;->mPopup:Landroid/support/v7/widget/db;

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/ab;->setVerticalOffset(I)V

    return-void
.end method

.method public show()V
    .locals 7

    .line 1
    invoke-virtual {p0}, Landroid/support/v7/view/menu/O;->isShowing()Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    goto/16 :goto_2

    :cond_0
    iget-boolean v0, p0, Landroid/support/v7/view/menu/O;->Pn:Z

    const/4 v2, 0x0

    if-nez v0, :cond_7

    iget-object v0, p0, Landroid/support/v7/view/menu/O;->Fn:Landroid/view/View;

    if-nez v0, :cond_1

    goto/16 :goto_1

    :cond_1
    iput-object v0, p0, Landroid/support/v7/view/menu/O;->Gn:Landroid/view/View;

    iget-object v0, p0, Landroid/support/v7/view/menu/O;->mPopup:Landroid/support/v7/widget/db;

    invoke-virtual {v0, p0}, Landroid/support/v7/widget/ab;->setOnDismissListener(Landroid/widget/PopupWindow$OnDismissListener;)V

    iget-object v0, p0, Landroid/support/v7/view/menu/O;->mPopup:Landroid/support/v7/widget/db;

    invoke-virtual {v0, p0}, Landroid/support/v7/widget/ab;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    iget-object v0, p0, Landroid/support/v7/view/menu/O;->mPopup:Landroid/support/v7/widget/db;

    invoke-virtual {v0, v1}, Landroid/support/v7/widget/ab;->setModal(Z)V

    iget-object v0, p0, Landroid/support/v7/view/menu/O;->Gn:Landroid/view/View;

    iget-object v3, p0, Landroid/support/v7/view/menu/O;->mTreeObserver:Landroid/view/ViewTreeObserver;

    if-nez v3, :cond_2

    move v3, v1

    goto :goto_0

    :cond_2
    move v3, v2

    :goto_0
    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v4

    iput-object v4, p0, Landroid/support/v7/view/menu/O;->mTreeObserver:Landroid/view/ViewTreeObserver;

    if-eqz v3, :cond_3

    iget-object v3, p0, Landroid/support/v7/view/menu/O;->mTreeObserver:Landroid/view/ViewTreeObserver;

    iget-object v4, p0, Landroid/support/v7/view/menu/O;->An:Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;

    invoke-virtual {v3, v4}, Landroid/view/ViewTreeObserver;->addOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    :cond_3
    iget-object v3, p0, Landroid/support/v7/view/menu/O;->Bn:Landroid/view/View$OnAttachStateChangeListener;

    invoke-virtual {v0, v3}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    iget-object v3, p0, Landroid/support/v7/view/menu/O;->mPopup:Landroid/support/v7/widget/db;

    invoke-virtual {v3, v0}, Landroid/support/v7/widget/ab;->setAnchorView(Landroid/view/View;)V

    iget-object v0, p0, Landroid/support/v7/view/menu/O;->mPopup:Landroid/support/v7/widget/db;

    iget v3, p0, Landroid/support/v7/view/menu/O;->En:I

    invoke-virtual {v0, v3}, Landroid/support/v7/widget/ab;->setDropDownGravity(I)V

    iget-boolean v0, p0, Landroid/support/v7/view/menu/O;->Qn:Z

    const/4 v3, 0x0

    if-nez v0, :cond_4

    iget-object v0, p0, Landroid/support/v7/view/menu/O;->mAdapter:Landroid/support/v7/view/menu/o;

    iget-object v4, p0, Landroid/support/v7/view/menu/O;->mContext:Landroid/content/Context;

    iget v5, p0, Landroid/support/v7/view/menu/O;->Nn:I

    invoke-static {v0, v3, v4, v5}, Landroid/support/v7/view/menu/C;->measureIndividualMenuWidth(Landroid/widget/ListAdapter;Landroid/view/ViewGroup;Landroid/content/Context;I)I

    move-result v0

    iput v0, p0, Landroid/support/v7/view/menu/O;->Rn:I

    iput-boolean v1, p0, Landroid/support/v7/view/menu/O;->Qn:Z

    :cond_4
    iget-object v0, p0, Landroid/support/v7/view/menu/O;->mPopup:Landroid/support/v7/widget/db;

    iget v4, p0, Landroid/support/v7/view/menu/O;->Rn:I

    invoke-virtual {v0, v4}, Landroid/support/v7/widget/ab;->setContentWidth(I)V

    iget-object v0, p0, Landroid/support/v7/view/menu/O;->mPopup:Landroid/support/v7/widget/db;

    const/4 v4, 0x2

    invoke-virtual {v0, v4}, Landroid/support/v7/widget/ab;->setInputMethodMode(I)V

    iget-object v0, p0, Landroid/support/v7/view/menu/O;->mPopup:Landroid/support/v7/widget/db;

    invoke-virtual {p0}, Landroid/support/v7/view/menu/C;->getEpicenterBounds()Landroid/graphics/Rect;

    move-result-object v4

    invoke-virtual {v0, v4}, Landroid/support/v7/widget/ab;->setEpicenterBounds(Landroid/graphics/Rect;)V

    iget-object v0, p0, Landroid/support/v7/view/menu/O;->mPopup:Landroid/support/v7/widget/db;

    invoke-virtual {v0}, Landroid/support/v7/widget/ab;->show()V

    iget-object v0, p0, Landroid/support/v7/view/menu/O;->mPopup:Landroid/support/v7/widget/db;

    invoke-virtual {v0}, Landroid/support/v7/widget/ab;->getListView()Landroid/widget/ListView;

    move-result-object v0

    invoke-virtual {v0, p0}, Landroid/widget/ListView;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    iget-boolean v4, p0, Landroid/support/v7/view/menu/O;->Yi:Z

    if-eqz v4, :cond_6

    iget-object v4, p0, Landroid/support/v7/view/menu/O;->mMenu:Landroid/support/v7/view/menu/r;

    .line 2
    iget-object v4, v4, Landroid/support/v7/view/menu/r;->mHeaderTitle:Ljava/lang/CharSequence;

    if-eqz v4, :cond_6

    .line 3
    iget-object v4, p0, Landroid/support/v7/view/menu/O;->mContext:Landroid/content/Context;

    invoke-static {v4}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v4

    const v5, 0x7f0a0012

    invoke-virtual {v4, v5, v0, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/FrameLayout;

    const v5, 0x1020016

    invoke-virtual {v4, v5}, Landroid/widget/FrameLayout;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/TextView;

    if-eqz v5, :cond_5

    iget-object v6, p0, Landroid/support/v7/view/menu/O;->mMenu:Landroid/support/v7/view/menu/r;

    .line 4
    iget-object v6, v6, Landroid/support/v7/view/menu/r;->mHeaderTitle:Ljava/lang/CharSequence;

    .line 5
    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_5
    invoke-virtual {v4, v2}, Landroid/widget/FrameLayout;->setEnabled(Z)V

    invoke-virtual {v0, v4, v3, v2}, Landroid/widget/ListView;->addHeaderView(Landroid/view/View;Ljava/lang/Object;Z)V

    :cond_6
    iget-object v0, p0, Landroid/support/v7/view/menu/O;->mPopup:Landroid/support/v7/widget/db;

    iget-object v2, p0, Landroid/support/v7/view/menu/O;->mAdapter:Landroid/support/v7/view/menu/o;

    invoke-virtual {v0, v2}, Landroid/support/v7/widget/ab;->setAdapter(Landroid/widget/ListAdapter;)V

    iget-object p0, p0, Landroid/support/v7/view/menu/O;->mPopup:Landroid/support/v7/widget/db;

    invoke-virtual {p0}, Landroid/support/v7/widget/ab;->show()V

    goto :goto_2

    :cond_7
    :goto_1
    move v1, v2

    :goto_2
    if-eqz v1, :cond_8

    return-void

    .line 6
    :cond_8
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string v0, "StandardMenuPopup cannot be used without an anchor"

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public updateMenuView(Z)V
    .locals 0

    const/4 p1, 0x0

    iput-boolean p1, p0, Landroid/support/v7/view/menu/O;->Qn:Z

    iget-object p0, p0, Landroid/support/v7/view/menu/O;->mAdapter:Landroid/support/v7/view/menu/o;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroid/support/v7/view/menu/o;->notifyDataSetChanged()V

    :cond_0
    return-void
.end method
