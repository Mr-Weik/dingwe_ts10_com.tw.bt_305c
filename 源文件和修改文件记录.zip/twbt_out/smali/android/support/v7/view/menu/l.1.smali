.class final Landroid/support/v7/view/menu/l;
.super Landroid/support/v7/view/menu/C;
.source ""

# interfaces
.implements Landroid/support/v7/view/menu/G;
.implements Landroid/view/View$OnKeyListener;
.implements Landroid/widget/PopupWindow$OnDismissListener;


# instance fields
.field private final An:Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;

.field private final Bn:Landroid/view/View$OnAttachStateChangeListener;

.field private final Cn:Landroid/support/v7/widget/bb;

.field private Dn:I

.field private En:I

.field private Fn:Landroid/view/View;

.field Gn:Landroid/view/View;

.field private Hn:I

.field private In:Z

.field private Jn:Z

.field private Kn:I

.field private Ln:Z

.field Mn:Z

.field private Yi:Z

.field private dn:Landroid/support/v7/view/menu/F;

.field private final mContext:Landroid/content/Context;

.field private mOnDismissListener:Landroid/widget/PopupWindow$OnDismissListener;

.field private mTreeObserver:Landroid/view/ViewTreeObserver;

.field private mXOffset:I

.field private final tn:I

.field private final un:I

.field private final vn:I

.field private final wn:Z

.field final xn:Landroid/os/Handler;

.field private final yn:Ljava/util/List;

.field final zn:Ljava/util/List;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/view/View;IIZ)V
    .locals 1

    invoke-direct {p0}, Landroid/support/v7/view/menu/C;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroid/support/v7/view/menu/l;->yn:Ljava/util/List;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroid/support/v7/view/menu/l;->zn:Ljava/util/List;

    new-instance v0, Landroid/support/v7/view/menu/g;

    invoke-direct {v0, p0}, Landroid/support/v7/view/menu/g;-><init>(Landroid/support/v7/view/menu/l;)V

    iput-object v0, p0, Landroid/support/v7/view/menu/l;->An:Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;

    new-instance v0, Landroid/support/v7/view/menu/h;

    invoke-direct {v0, p0}, Landroid/support/v7/view/menu/h;-><init>(Landroid/support/v7/view/menu/l;)V

    iput-object v0, p0, Landroid/support/v7/view/menu/l;->Bn:Landroid/view/View$OnAttachStateChangeListener;

    new-instance v0, Landroid/support/v7/view/menu/j;

    invoke-direct {v0, p0}, Landroid/support/v7/view/menu/j;-><init>(Landroid/support/v7/view/menu/l;)V

    iput-object v0, p0, Landroid/support/v7/view/menu/l;->Cn:Landroid/support/v7/widget/bb;

    const/4 v0, 0x0

    iput v0, p0, Landroid/support/v7/view/menu/l;->Dn:I

    iput v0, p0, Landroid/support/v7/view/menu/l;->En:I

    iput-object p1, p0, Landroid/support/v7/view/menu/l;->mContext:Landroid/content/Context;

    iput-object p2, p0, Landroid/support/v7/view/menu/l;->Fn:Landroid/view/View;

    iput p3, p0, Landroid/support/v7/view/menu/l;->un:I

    iput p4, p0, Landroid/support/v7/view/menu/l;->vn:I

    iput-boolean p5, p0, Landroid/support/v7/view/menu/l;->wn:Z

    iput-boolean v0, p0, Landroid/support/v7/view/menu/l;->Ln:Z

    .line 1
    iget-object p2, p0, Landroid/support/v7/view/menu/l;->Fn:Landroid/view/View;

    invoke-static {p2}, Landroid/support/v4/view/r;->o(Landroid/view/View;)I

    move-result p2

    const/4 p3, 0x1

    if-ne p2, p3, :cond_0

    move p3, v0

    .line 2
    :cond_0
    iput p3, p0, Landroid/support/v7/view/menu/l;->Hn:I

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p2

    iget p2, p2, Landroid/util/DisplayMetrics;->widthPixels:I

    div-int/lit8 p2, p2, 0x2

    const p3, 0x7f060017

    invoke-virtual {p1, p3}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result p1

    invoke-static {p2, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    iput p1, p0, Landroid/support/v7/view/menu/l;->tn:I

    new-instance p1, Landroid/os/Handler;

    invoke-direct {p1}, Landroid/os/Handler;-><init>()V

    iput-object p1, p0, Landroid/support/v7/view/menu/l;->xn:Landroid/os/Handler;

    return-void
.end method

.method static synthetic a(Landroid/support/v7/view/menu/l;)Landroid/view/ViewTreeObserver;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/l;->mTreeObserver:Landroid/view/ViewTreeObserver;

    return-object p0
.end method

.method static synthetic a(Landroid/support/v7/view/menu/l;Landroid/view/ViewTreeObserver;)Landroid/view/ViewTreeObserver;
    .locals 0

    iput-object p1, p0, Landroid/support/v7/view/menu/l;->mTreeObserver:Landroid/view/ViewTreeObserver;

    return-object p1
.end method

.method static synthetic b(Landroid/support/v7/view/menu/l;)Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/l;->An:Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;

    return-object p0
.end method

.method private h(Landroid/support/v7/view/menu/r;)V
    .locals 16

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iget-object v2, v0, Landroid/support/v7/view/menu/l;->mContext:Landroid/content/Context;

    invoke-static {v2}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v2

    new-instance v3, Landroid/support/v7/view/menu/o;

    iget-boolean v4, v0, Landroid/support/v7/view/menu/l;->wn:Z

    const v5, 0x7f0a000b

    invoke-direct {v3, v1, v2, v4, v5}, Landroid/support/v7/view/menu/o;-><init>(Landroid/support/v7/view/menu/r;Landroid/view/LayoutInflater;ZI)V

    invoke-virtual/range {p0 .. p0}, Landroid/support/v7/view/menu/l;->isShowing()Z

    move-result v4

    const/4 v5, 0x1

    if-nez v4, :cond_0

    iget-boolean v4, v0, Landroid/support/v7/view/menu/l;->Ln:Z

    if-eqz v4, :cond_0

    invoke-virtual {v3, v5}, Landroid/support/v7/view/menu/o;->setForceShowIcon(Z)V

    goto :goto_0

    :cond_0
    invoke-virtual/range {p0 .. p0}, Landroid/support/v7/view/menu/l;->isShowing()Z

    move-result v4

    if-eqz v4, :cond_1

    invoke-static/range {p1 .. p1}, Landroid/support/v7/view/menu/C;->g(Landroid/support/v7/view/menu/r;)Z

    move-result v4

    invoke-virtual {v3, v4}, Landroid/support/v7/view/menu/o;->setForceShowIcon(Z)V

    :cond_1
    :goto_0
    iget-object v4, v0, Landroid/support/v7/view/menu/l;->mContext:Landroid/content/Context;

    iget v6, v0, Landroid/support/v7/view/menu/l;->tn:I

    const/4 v7, 0x0

    invoke-static {v3, v7, v4, v6}, Landroid/support/v7/view/menu/C;->measureIndividualMenuWidth(Landroid/widget/ListAdapter;Landroid/view/ViewGroup;Landroid/content/Context;I)I

    move-result v4

    .line 1
    new-instance v6, Landroid/support/v7/widget/db;

    iget-object v8, v0, Landroid/support/v7/view/menu/l;->mContext:Landroid/content/Context;

    iget v9, v0, Landroid/support/v7/view/menu/l;->un:I

    iget v10, v0, Landroid/support/v7/view/menu/l;->vn:I

    invoke-direct {v6, v8, v7, v9, v10}, Landroid/support/v7/widget/db;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    iget-object v8, v0, Landroid/support/v7/view/menu/l;->Cn:Landroid/support/v7/widget/bb;

    invoke-virtual {v6, v8}, Landroid/support/v7/widget/db;->a(Landroid/support/v7/widget/bb;)V

    invoke-virtual {v6, v0}, Landroid/support/v7/widget/ab;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    invoke-virtual {v6, v0}, Landroid/support/v7/widget/ab;->setOnDismissListener(Landroid/widget/PopupWindow$OnDismissListener;)V

    iget-object v8, v0, Landroid/support/v7/view/menu/l;->Fn:Landroid/view/View;

    invoke-virtual {v6, v8}, Landroid/support/v7/widget/ab;->setAnchorView(Landroid/view/View;)V

    iget v8, v0, Landroid/support/v7/view/menu/l;->En:I

    invoke-virtual {v6, v8}, Landroid/support/v7/widget/ab;->setDropDownGravity(I)V

    invoke-virtual {v6, v5}, Landroid/support/v7/widget/ab;->setModal(Z)V

    const/4 v8, 0x2

    invoke-virtual {v6, v8}, Landroid/support/v7/widget/ab;->setInputMethodMode(I)V

    .line 2
    invoke-virtual {v6, v3}, Landroid/support/v7/widget/ab;->setAdapter(Landroid/widget/ListAdapter;)V

    invoke-virtual {v6, v4}, Landroid/support/v7/widget/ab;->setContentWidth(I)V

    iget v3, v0, Landroid/support/v7/view/menu/l;->En:I

    invoke-virtual {v6, v3}, Landroid/support/v7/widget/ab;->setDropDownGravity(I)V

    iget-object v3, v0, Landroid/support/v7/view/menu/l;->zn:Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v3

    const/4 v9, 0x0

    if-lez v3, :cond_b

    iget-object v3, v0, Landroid/support/v7/view/menu/l;->zn:Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v10

    sub-int/2addr v10, v5

    invoke-interface {v3, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/support/v7/view/menu/k;

    .line 3
    iget-object v10, v3, Landroid/support/v7/view/menu/k;->menu:Landroid/support/v7/view/menu/r;

    .line 4
    invoke-virtual {v10}, Landroid/support/v7/view/menu/r;->size()I

    move-result v11

    move v12, v9

    :goto_1
    if-ge v12, v11, :cond_3

    invoke-virtual {v10, v12}, Landroid/support/v7/view/menu/r;->getItem(I)Landroid/view/MenuItem;

    move-result-object v13

    invoke-interface {v13}, Landroid/view/MenuItem;->hasSubMenu()Z

    move-result v14

    if-eqz v14, :cond_2

    invoke-interface {v13}, Landroid/view/MenuItem;->getSubMenu()Landroid/view/SubMenu;

    move-result-object v14

    if-ne v1, v14, :cond_2

    goto :goto_2

    :cond_2
    add-int/lit8 v12, v12, 0x1

    goto :goto_1

    :cond_3
    move-object v13, v7

    :goto_2
    if-nez v13, :cond_5

    :cond_4
    :goto_3
    move-object v5, v7

    goto :goto_7

    .line 5
    :cond_5
    invoke-virtual {v3}, Landroid/support/v7/view/menu/k;->getListView()Landroid/widget/ListView;

    move-result-object v10

    invoke-virtual {v10}, Landroid/widget/ListView;->getAdapter()Landroid/widget/ListAdapter;

    move-result-object v11

    instance-of v12, v11, Landroid/widget/HeaderViewListAdapter;

    if-eqz v12, :cond_6

    check-cast v11, Landroid/widget/HeaderViewListAdapter;

    invoke-virtual {v11}, Landroid/widget/HeaderViewListAdapter;->getHeadersCount()I

    move-result v12

    invoke-virtual {v11}, Landroid/widget/HeaderViewListAdapter;->getWrappedAdapter()Landroid/widget/ListAdapter;

    move-result-object v11

    check-cast v11, Landroid/support/v7/view/menu/o;

    goto :goto_4

    :cond_6
    check-cast v11, Landroid/support/v7/view/menu/o;

    move v12, v9

    :goto_4
    invoke-virtual {v11}, Landroid/support/v7/view/menu/o;->getCount()I

    move-result v14

    move v15, v9

    :goto_5
    const/4 v8, -0x1

    if-ge v15, v14, :cond_8

    invoke-virtual {v11, v15}, Landroid/support/v7/view/menu/o;->getItem(I)Landroid/support/v7/view/menu/u;

    move-result-object v5

    if-ne v13, v5, :cond_7

    goto :goto_6

    :cond_7
    add-int/lit8 v15, v15, 0x1

    const/4 v5, 0x1

    goto :goto_5

    :cond_8
    move v15, v8

    :goto_6
    if-ne v15, v8, :cond_9

    goto :goto_3

    :cond_9
    add-int/2addr v15, v12

    invoke-virtual {v10}, Landroid/widget/ListView;->getFirstVisiblePosition()I

    move-result v5

    sub-int/2addr v15, v5

    if-ltz v15, :cond_4

    invoke-virtual {v10}, Landroid/widget/ListView;->getChildCount()I

    move-result v5

    if-lt v15, v5, :cond_a

    goto :goto_3

    :cond_a
    invoke-virtual {v10, v15}, Landroid/widget/ListView;->getChildAt(I)Landroid/view/View;

    move-result-object v5

    goto :goto_7

    :cond_b
    move-object v3, v7

    move-object v5, v3

    :goto_7
    if-eqz v5, :cond_13

    .line 6
    invoke-virtual {v6, v9}, Landroid/support/v7/widget/db;->setTouchModal(Z)V

    invoke-virtual {v6, v7}, Landroid/support/v7/widget/db;->q(Ljava/lang/Object;)V

    .line 7
    iget-object v8, v0, Landroid/support/v7/view/menu/l;->zn:Ljava/util/List;

    invoke-interface {v8}, Ljava/util/List;->size()I

    move-result v10

    const/4 v11, 0x1

    sub-int/2addr v10, v11

    invoke-interface {v8, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Landroid/support/v7/view/menu/k;

    invoke-virtual {v8}, Landroid/support/v7/view/menu/k;->getListView()Landroid/widget/ListView;

    move-result-object v8

    const/4 v10, 0x2

    new-array v10, v10, [I

    invoke-virtual {v8, v10}, Landroid/widget/ListView;->getLocationOnScreen([I)V

    new-instance v12, Landroid/graphics/Rect;

    invoke-direct {v12}, Landroid/graphics/Rect;-><init>()V

    iget-object v13, v0, Landroid/support/v7/view/menu/l;->Gn:Landroid/view/View;

    invoke-virtual {v13, v12}, Landroid/view/View;->getWindowVisibleDisplayFrame(Landroid/graphics/Rect;)V

    iget v13, v0, Landroid/support/v7/view/menu/l;->Hn:I

    if-ne v13, v11, :cond_c

    aget v10, v10, v9

    invoke-virtual {v8}, Landroid/widget/ListView;->getWidth()I

    move-result v8

    add-int/2addr v8, v10

    add-int/2addr v8, v4

    iget v10, v12, Landroid/graphics/Rect;->right:I

    if-le v8, v10, :cond_d

    goto :goto_8

    :cond_c
    aget v8, v10, v9

    sub-int/2addr v8, v4

    if-gez v8, :cond_e

    :cond_d
    const/4 v8, 0x1

    goto :goto_9

    :cond_e
    :goto_8
    move v8, v9

    :goto_9
    const/4 v10, 0x1

    if-ne v8, v10, :cond_f

    const/4 v10, 0x1

    goto :goto_a

    :cond_f
    move v10, v9

    .line 8
    :goto_a
    iput v8, v0, Landroid/support/v7/view/menu/l;->Hn:I

    sget v8, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-virtual {v6, v5}, Landroid/support/v7/widget/ab;->setAnchorView(Landroid/view/View;)V

    iget v8, v0, Landroid/support/v7/view/menu/l;->En:I

    const/4 v11, 0x5

    and-int/2addr v8, v11

    if-ne v8, v11, :cond_11

    if-eqz v10, :cond_10

    add-int/2addr v4, v9

    goto :goto_c

    :cond_10
    invoke-virtual {v5}, Landroid/view/View;->getWidth()I

    move-result v4

    goto :goto_b

    :cond_11
    if-eqz v10, :cond_12

    invoke-virtual {v5}, Landroid/view/View;->getWidth()I

    move-result v4

    add-int/2addr v4, v9

    goto :goto_c

    :cond_12
    :goto_b
    rsub-int/lit8 v4, v4, 0x0

    :goto_c
    invoke-virtual {v6, v4}, Landroid/support/v7/widget/ab;->setHorizontalOffset(I)V

    const/4 v4, 0x1

    invoke-virtual {v6, v4}, Landroid/support/v7/widget/ab;->setOverlapAnchor(Z)V

    invoke-virtual {v6, v9}, Landroid/support/v7/widget/ab;->setVerticalOffset(I)V

    goto :goto_d

    :cond_13
    iget-boolean v4, v0, Landroid/support/v7/view/menu/l;->In:Z

    if-eqz v4, :cond_14

    iget v4, v0, Landroid/support/v7/view/menu/l;->mXOffset:I

    invoke-virtual {v6, v4}, Landroid/support/v7/widget/ab;->setHorizontalOffset(I)V

    :cond_14
    iget-boolean v4, v0, Landroid/support/v7/view/menu/l;->Jn:Z

    if-eqz v4, :cond_15

    iget v4, v0, Landroid/support/v7/view/menu/l;->Kn:I

    invoke-virtual {v6, v4}, Landroid/support/v7/widget/ab;->setVerticalOffset(I)V

    :cond_15
    invoke-virtual/range {p0 .. p0}, Landroid/support/v7/view/menu/C;->getEpicenterBounds()Landroid/graphics/Rect;

    move-result-object v4

    invoke-virtual {v6, v4}, Landroid/support/v7/widget/ab;->setEpicenterBounds(Landroid/graphics/Rect;)V

    :goto_d
    new-instance v4, Landroid/support/v7/view/menu/k;

    iget v5, v0, Landroid/support/v7/view/menu/l;->Hn:I

    invoke-direct {v4, v6, v1, v5}, Landroid/support/v7/view/menu/k;-><init>(Landroid/support/v7/widget/db;Landroid/support/v7/view/menu/r;I)V

    iget-object v5, v0, Landroid/support/v7/view/menu/l;->zn:Ljava/util/List;

    invoke-interface {v5, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {v6}, Landroid/support/v7/widget/ab;->show()V

    invoke-virtual {v6}, Landroid/support/v7/widget/ab;->getListView()Landroid/widget/ListView;

    move-result-object v4

    invoke-virtual {v4, v0}, Landroid/widget/ListView;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    if-nez v3, :cond_16

    iget-boolean v0, v0, Landroid/support/v7/view/menu/l;->Yi:Z

    if-eqz v0, :cond_16

    .line 9
    iget-object v0, v1, Landroid/support/v7/view/menu/r;->mHeaderTitle:Ljava/lang/CharSequence;

    if-eqz v0, :cond_16

    const v0, 0x7f0a0012

    .line 10
    invoke-virtual {v2, v0, v4, v9}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/FrameLayout;

    const v2, 0x1020016

    invoke-virtual {v0, v2}, Landroid/widget/FrameLayout;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    invoke-virtual {v0, v9}, Landroid/widget/FrameLayout;->setEnabled(Z)V

    .line 11
    iget-object v1, v1, Landroid/support/v7/view/menu/r;->mHeaderTitle:Ljava/lang/CharSequence;

    .line 12
    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v4, v0, v7, v9}, Landroid/widget/ListView;->addHeaderView(Landroid/view/View;Ljava/lang/Object;Z)V

    invoke-virtual {v6}, Landroid/support/v7/widget/ab;->show()V

    :cond_16
    return-void
.end method


# virtual methods
.method protected Ua()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public a(Landroid/support/v7/view/menu/F;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/view/menu/l;->dn:Landroid/support/v7/view/menu/F;

    return-void
.end method

.method public a(Landroid/support/v7/view/menu/r;Z)V
    .locals 6

    .line 1
    iget-object v0, p0, Landroid/support/v7/view/menu/l;->zn:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    if-ge v2, v0, :cond_1

    iget-object v3, p0, Landroid/support/v7/view/menu/l;->zn:Ljava/util/List;

    invoke-interface {v3, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/support/v7/view/menu/k;

    iget-object v3, v3, Landroid/support/v7/view/menu/k;->menu:Landroid/support/v7/view/menu/r;

    if-ne p1, v3, :cond_0

    goto :goto_1

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    const/4 v2, -0x1

    :goto_1
    if-gez v2, :cond_2

    return-void

    :cond_2
    add-int/lit8 v0, v2, 0x1

    .line 2
    iget-object v3, p0, Landroid/support/v7/view/menu/l;->zn:Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v3

    if-ge v0, v3, :cond_3

    iget-object v3, p0, Landroid/support/v7/view/menu/l;->zn:Ljava/util/List;

    invoke-interface {v3, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v7/view/menu/k;

    iget-object v0, v0, Landroid/support/v7/view/menu/k;->menu:Landroid/support/v7/view/menu/r;

    invoke-virtual {v0, v1}, Landroid/support/v7/view/menu/r;->close(Z)V

    :cond_3
    iget-object v0, p0, Landroid/support/v7/view/menu/l;->zn:Ljava/util/List;

    invoke-interface {v0, v2}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v7/view/menu/k;

    iget-object v2, v0, Landroid/support/v7/view/menu/k;->menu:Landroid/support/v7/view/menu/r;

    invoke-virtual {v2, p0}, Landroid/support/v7/view/menu/r;->b(Landroid/support/v7/view/menu/G;)V

    iget-boolean v2, p0, Landroid/support/v7/view/menu/l;->Mn:Z

    const/4 v3, 0x0

    if-eqz v2, :cond_4

    iget-object v2, v0, Landroid/support/v7/view/menu/k;->window:Landroid/support/v7/widget/db;

    invoke-virtual {v2, v3}, Landroid/support/v7/widget/db;->r(Ljava/lang/Object;)V

    iget-object v2, v0, Landroid/support/v7/view/menu/k;->window:Landroid/support/v7/widget/db;

    invoke-virtual {v2, v1}, Landroid/support/v7/widget/ab;->setAnimationStyle(I)V

    :cond_4
    iget-object v0, v0, Landroid/support/v7/view/menu/k;->window:Landroid/support/v7/widget/db;

    invoke-virtual {v0}, Landroid/support/v7/widget/ab;->dismiss()V

    iget-object v0, p0, Landroid/support/v7/view/menu/l;->zn:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v2, 0x1

    if-lez v0, :cond_5

    iget-object v4, p0, Landroid/support/v7/view/menu/l;->zn:Ljava/util/List;

    add-int/lit8 v5, v0, -0x1

    invoke-interface {v4, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/support/v7/view/menu/k;

    iget v4, v4, Landroid/support/v7/view/menu/k;->position:I

    goto :goto_2

    .line 3
    :cond_5
    iget-object v4, p0, Landroid/support/v7/view/menu/l;->Fn:Landroid/view/View;

    invoke-static {v4}, Landroid/support/v4/view/r;->o(Landroid/view/View;)I

    move-result v4

    if-ne v4, v2, :cond_6

    move v4, v1

    goto :goto_2

    :cond_6
    move v4, v2

    .line 4
    :goto_2
    iput v4, p0, Landroid/support/v7/view/menu/l;->Hn:I

    if-nez v0, :cond_a

    invoke-virtual {p0}, Landroid/support/v7/view/menu/l;->dismiss()V

    iget-object p2, p0, Landroid/support/v7/view/menu/l;->dn:Landroid/support/v7/view/menu/F;

    if-eqz p2, :cond_7

    invoke-interface {p2, p1, v2}, Landroid/support/v7/view/menu/F;->a(Landroid/support/v7/view/menu/r;Z)V

    :cond_7
    iget-object p1, p0, Landroid/support/v7/view/menu/l;->mTreeObserver:Landroid/view/ViewTreeObserver;

    if-eqz p1, :cond_9

    invoke-virtual {p1}, Landroid/view/ViewTreeObserver;->isAlive()Z

    move-result p1

    if-eqz p1, :cond_8

    iget-object p1, p0, Landroid/support/v7/view/menu/l;->mTreeObserver:Landroid/view/ViewTreeObserver;

    iget-object p2, p0, Landroid/support/v7/view/menu/l;->An:Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;

    invoke-virtual {p1, p2}, Landroid/view/ViewTreeObserver;->removeGlobalOnLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    :cond_8
    iput-object v3, p0, Landroid/support/v7/view/menu/l;->mTreeObserver:Landroid/view/ViewTreeObserver;

    :cond_9
    iget-object p1, p0, Landroid/support/v7/view/menu/l;->Gn:Landroid/view/View;

    iget-object p2, p0, Landroid/support/v7/view/menu/l;->Bn:Landroid/view/View$OnAttachStateChangeListener;

    invoke-virtual {p1, p2}, Landroid/view/View;->removeOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    iget-object p0, p0, Landroid/support/v7/view/menu/l;->mOnDismissListener:Landroid/widget/PopupWindow$OnDismissListener;

    invoke-interface {p0}, Landroid/widget/PopupWindow$OnDismissListener;->onDismiss()V

    goto :goto_3

    :cond_a
    if-eqz p2, :cond_b

    iget-object p0, p0, Landroid/support/v7/view/menu/l;->zn:Ljava/util/List;

    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/support/v7/view/menu/k;

    iget-object p0, p0, Landroid/support/v7/view/menu/k;->menu:Landroid/support/v7/view/menu/r;

    invoke-virtual {p0, v1}, Landroid/support/v7/view/menu/r;->close(Z)V

    :cond_b
    :goto_3
    return-void
.end method

.method public a(Landroid/support/v7/view/menu/P;)Z
    .locals 4

    iget-object v0, p0, Landroid/support/v7/view/menu/l;->zn:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v2, 0x1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/support/v7/view/menu/k;

    iget-object v3, v1, Landroid/support/v7/view/menu/k;->menu:Landroid/support/v7/view/menu/r;

    if-ne p1, v3, :cond_0

    invoke-virtual {v1}, Landroid/support/v7/view/menu/k;->getListView()Landroid/widget/ListView;

    move-result-object p0

    invoke-virtual {p0}, Landroid/widget/ListView;->requestFocus()Z

    return v2

    :cond_1
    invoke-virtual {p1}, Landroid/support/v7/view/menu/r;->hasVisibleItems()Z

    move-result v0

    if-eqz v0, :cond_4

    .line 5
    iget-object v0, p0, Landroid/support/v7/view/menu/l;->mContext:Landroid/content/Context;

    invoke-virtual {p1, p0, v0}, Landroid/support/v7/view/menu/r;->a(Landroid/support/v7/view/menu/G;Landroid/content/Context;)V

    invoke-virtual {p0}, Landroid/support/v7/view/menu/l;->isShowing()Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-direct {p0, p1}, Landroid/support/v7/view/menu/l;->h(Landroid/support/v7/view/menu/r;)V

    goto :goto_0

    :cond_2
    iget-object v0, p0, Landroid/support/v7/view/menu/l;->yn:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 6
    :goto_0
    iget-object p0, p0, Landroid/support/v7/view/menu/l;->dn:Landroid/support/v7/view/menu/F;

    if-eqz p0, :cond_3

    invoke-interface {p0, p1}, Landroid/support/v7/view/menu/F;->a(Landroid/support/v7/view/menu/r;)Z

    :cond_3
    return v2

    :cond_4
    const/4 p0, 0x0

    return p0
.end method

.method public dismiss()V
    .locals 3

    iget-object v0, p0, Landroid/support/v7/view/menu/l;->zn:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    if-lez v0, :cond_1

    iget-object p0, p0, Landroid/support/v7/view/menu/l;->zn:Ljava/util/List;

    new-array v1, v0, [Landroid/support/v7/view/menu/k;

    invoke-interface {p0, v1}, Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p0

    check-cast p0, [Landroid/support/v7/view/menu/k;

    add-int/lit8 v0, v0, -0x1

    :goto_0
    if-ltz v0, :cond_1

    aget-object v1, p0, v0

    iget-object v2, v1, Landroid/support/v7/view/menu/k;->window:Landroid/support/v7/widget/db;

    invoke-virtual {v2}, Landroid/support/v7/widget/ab;->isShowing()Z

    move-result v2

    if-eqz v2, :cond_0

    iget-object v1, v1, Landroid/support/v7/view/menu/k;->window:Landroid/support/v7/widget/db;

    invoke-virtual {v1}, Landroid/support/v7/widget/ab;->dismiss()V

    :cond_0
    add-int/lit8 v0, v0, -0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method public f(Landroid/support/v7/view/menu/r;)V
    .locals 1

    iget-object v0, p0, Landroid/support/v7/view/menu/l;->mContext:Landroid/content/Context;

    invoke-virtual {p1, p0, v0}, Landroid/support/v7/view/menu/r;->a(Landroid/support/v7/view/menu/G;Landroid/content/Context;)V

    invoke-virtual {p0}, Landroid/support/v7/view/menu/l;->isShowing()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-direct {p0, p1}, Landroid/support/v7/view/menu/l;->h(Landroid/support/v7/view/menu/r;)V

    goto :goto_0

    :cond_0
    iget-object p0, p0, Landroid/support/v7/view/menu/l;->yn:Ljava/util/List;

    invoke-interface {p0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :goto_0
    return-void
.end method

.method public flagActionItems()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public getListView()Landroid/widget/ListView;
    .locals 1

    iget-object v0, p0, Landroid/support/v7/view/menu/l;->zn:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 p0, 0x0

    goto :goto_0

    :cond_0
    iget-object p0, p0, Landroid/support/v7/view/menu/l;->zn:Ljava/util/List;

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    invoke-interface {p0, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/support/v7/view/menu/k;

    invoke-virtual {p0}, Landroid/support/v7/view/menu/k;->getListView()Landroid/widget/ListView;

    move-result-object p0

    :goto_0
    return-object p0
.end method

.method public isShowing()Z
    .locals 2

    iget-object v0, p0, Landroid/support/v7/view/menu/l;->zn:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    if-lez v0, :cond_0

    iget-object p0, p0, Landroid/support/v7/view/menu/l;->zn:Ljava/util/List;

    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/support/v7/view/menu/k;

    iget-object p0, p0, Landroid/support/v7/view/menu/k;->window:Landroid/support/v7/widget/db;

    invoke-virtual {p0}, Landroid/support/v7/widget/ab;->isShowing()Z

    move-result p0

    if-eqz p0, :cond_0

    const/4 v1, 0x1

    :cond_0
    return v1
.end method

.method public onDismiss()V
    .locals 5

    iget-object v0, p0, Landroid/support/v7/view/menu/l;->zn:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    if-ge v2, v0, :cond_1

    iget-object v3, p0, Landroid/support/v7/view/menu/l;->zn:Ljava/util/List;

    invoke-interface {v3, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/support/v7/view/menu/k;

    iget-object v4, v3, Landroid/support/v7/view/menu/k;->window:Landroid/support/v7/widget/db;

    invoke-virtual {v4}, Landroid/support/v7/widget/ab;->isShowing()Z

    move-result v4

    if-nez v4, :cond_0

    goto :goto_1

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    const/4 v3, 0x0

    :goto_1
    if-eqz v3, :cond_2

    iget-object p0, v3, Landroid/support/v7/view/menu/k;->menu:Landroid/support/v7/view/menu/r;

    invoke-virtual {p0, v1}, Landroid/support/v7/view/menu/r;->close(Z)V

    :cond_2
    return-void
.end method

.method public onKey(Landroid/view/View;ILandroid/view/KeyEvent;)Z
    .locals 0

    invoke-virtual {p3}, Landroid/view/KeyEvent;->getAction()I

    move-result p1

    const/4 p3, 0x1

    if-ne p1, p3, :cond_0

    const/16 p1, 0x52

    if-ne p2, p1, :cond_0

    invoke-virtual {p0}, Landroid/support/v7/view/menu/l;->dismiss()V

    return p3

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public setAnchorView(Landroid/view/View;)V
    .locals 1

    iget-object v0, p0, Landroid/support/v7/view/menu/l;->Fn:Landroid/view/View;

    if-eq v0, p1, :cond_0

    iput-object p1, p0, Landroid/support/v7/view/menu/l;->Fn:Landroid/view/View;

    iget p1, p0, Landroid/support/v7/view/menu/l;->Dn:I

    iget-object v0, p0, Landroid/support/v7/view/menu/l;->Fn:Landroid/view/View;

    invoke-static {v0}, Landroid/support/v4/view/r;->o(Landroid/view/View;)I

    move-result v0

    invoke-static {p1, v0}, La/b/a/a;->getAbsoluteGravity(II)I

    move-result p1

    iput p1, p0, Landroid/support/v7/view/menu/l;->En:I

    :cond_0
    return-void
.end method

.method public setForceShowIcon(Z)V
    .locals 0

    iput-boolean p1, p0, Landroid/support/v7/view/menu/l;->Ln:Z

    return-void
.end method

.method public setGravity(I)V
    .locals 1

    iget v0, p0, Landroid/support/v7/view/menu/l;->Dn:I

    if-eq v0, p1, :cond_0

    iput p1, p0, Landroid/support/v7/view/menu/l;->Dn:I

    iget-object v0, p0, Landroid/support/v7/view/menu/l;->Fn:Landroid/view/View;

    invoke-static {v0}, Landroid/support/v4/view/r;->o(Landroid/view/View;)I

    move-result v0

    invoke-static {p1, v0}, La/b/a/a;->getAbsoluteGravity(II)I

    move-result p1

    iput p1, p0, Landroid/support/v7/view/menu/l;->En:I

    :cond_0
    return-void
.end method

.method public setHorizontalOffset(I)V
    .locals 1

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v7/view/menu/l;->In:Z

    iput p1, p0, Landroid/support/v7/view/menu/l;->mXOffset:I

    return-void
.end method

.method public setOnDismissListener(Landroid/widget/PopupWindow$OnDismissListener;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/view/menu/l;->mOnDismissListener:Landroid/widget/PopupWindow$OnDismissListener;

    return-void
.end method

.method public setShowTitle(Z)V
    .locals 0

    iput-boolean p1, p0, Landroid/support/v7/view/menu/l;->Yi:Z

    return-void
.end method

.method public setVerticalOffset(I)V
    .locals 1

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v7/view/menu/l;->Jn:Z

    iput p1, p0, Landroid/support/v7/view/menu/l;->Kn:I

    return-void
.end method

.method public show()V
    .locals 2

    invoke-virtual {p0}, Landroid/support/v7/view/menu/l;->isShowing()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Landroid/support/v7/view/menu/l;->yn:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/support/v7/view/menu/r;

    invoke-direct {p0, v1}, Landroid/support/v7/view/menu/l;->h(Landroid/support/v7/view/menu/r;)V

    goto :goto_0

    :cond_1
    iget-object v0, p0, Landroid/support/v7/view/menu/l;->yn:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    iget-object v0, p0, Landroid/support/v7/view/menu/l;->Fn:Landroid/view/View;

    iput-object v0, p0, Landroid/support/v7/view/menu/l;->Gn:Landroid/view/View;

    iget-object v0, p0, Landroid/support/v7/view/menu/l;->Gn:Landroid/view/View;

    if-eqz v0, :cond_4

    iget-object v0, p0, Landroid/support/v7/view/menu/l;->mTreeObserver:Landroid/view/ViewTreeObserver;

    if-nez v0, :cond_2

    const/4 v0, 0x1

    goto :goto_1

    :cond_2
    const/4 v0, 0x0

    :goto_1
    iget-object v1, p0, Landroid/support/v7/view/menu/l;->Gn:Landroid/view/View;

    invoke-virtual {v1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v1

    iput-object v1, p0, Landroid/support/v7/view/menu/l;->mTreeObserver:Landroid/view/ViewTreeObserver;

    if-eqz v0, :cond_3

    iget-object v0, p0, Landroid/support/v7/view/menu/l;->mTreeObserver:Landroid/view/ViewTreeObserver;

    iget-object v1, p0, Landroid/support/v7/view/menu/l;->An:Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;

    invoke-virtual {v0, v1}, Landroid/view/ViewTreeObserver;->addOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    :cond_3
    iget-object v0, p0, Landroid/support/v7/view/menu/l;->Gn:Landroid/view/View;

    iget-object p0, p0, Landroid/support/v7/view/menu/l;->Bn:Landroid/view/View$OnAttachStateChangeListener;

    invoke-virtual {v0, p0}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    :cond_4
    return-void
.end method

.method public updateMenuView(Z)V
    .locals 1

    iget-object p0, p0, Landroid/support/v7/view/menu/l;->zn:Ljava/util/List;

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/support/v7/view/menu/k;

    invoke-virtual {p1}, Landroid/support/v7/view/menu/k;->getListView()Landroid/widget/ListView;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/ListView;->getAdapter()Landroid/widget/ListAdapter;

    move-result-object p1

    .line 1
    instance-of v0, p1, Landroid/widget/HeaderViewListAdapter;

    if-eqz v0, :cond_0

    check-cast p1, Landroid/widget/HeaderViewListAdapter;

    invoke-virtual {p1}, Landroid/widget/HeaderViewListAdapter;->getWrappedAdapter()Landroid/widget/ListAdapter;

    move-result-object p1

    :cond_0
    check-cast p1, Landroid/support/v7/view/menu/o;

    .line 2
    invoke-virtual {p1}, Landroid/support/v7/view/menu/o;->notifyDataSetChanged()V

    goto :goto_0

    :cond_1
    return-void
.end method
