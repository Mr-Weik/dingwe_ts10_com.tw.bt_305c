.class public abstract Landroid/support/v7/view/menu/c;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public abstract getPopup()Landroid/support/v7/view/menu/L;
.end method
