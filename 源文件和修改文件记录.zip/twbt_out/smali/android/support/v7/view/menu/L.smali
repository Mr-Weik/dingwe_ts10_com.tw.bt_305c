.class public interface abstract Landroid/support/v7/view/menu/L;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract dismiss()V
.end method

.method public abstract getListView()Landroid/widget/ListView;
.end method

.method public abstract isShowing()Z
.end method

.method public abstract show()V
.end method
