.class Landroid/support/v7/view/menu/B;
.super Landroid/support/v7/view/menu/z;
.source ""


# direct methods
.method constructor <init>(Landroid/content/Context;La/b/c/c/a/b;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Landroid/support/v7/view/menu/z;-><init>(Landroid/content/Context;La/b/c/c/a/b;)V

    return-void
.end method


# virtual methods
.method a(Landroid/view/ActionProvider;)Landroid/support/v7/view/menu/v;
    .locals 2

    new-instance v0, Landroid/support/v7/view/menu/A;

    iget-object v1, p0, Landroid/support/v7/view/menu/e;->mContext:Landroid/content/Context;

    invoke-direct {v0, p0, v1, p1}, Landroid/support/v7/view/menu/A;-><init>(Landroid/support/v7/view/menu/B;Landroid/content/Context;Landroid/view/ActionProvider;)V

    return-object v0
.end method
