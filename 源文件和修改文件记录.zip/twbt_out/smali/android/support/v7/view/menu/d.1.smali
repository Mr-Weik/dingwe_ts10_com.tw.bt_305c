.class public abstract Landroid/support/v7/view/menu/d;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/support/v7/view/menu/G;


# instance fields
.field private gm:I

.field private mCallback:Landroid/support/v7/view/menu/F;

.field protected mContext:Landroid/content/Context;

.field private mItemLayoutRes:I

.field protected mMenu:Landroid/support/v7/view/menu/r;

.field protected mMenuView:Landroid/support/v7/view/menu/I;

.field protected mSystemContext:Landroid/content/Context;

.field protected mSystemInflater:Landroid/view/LayoutInflater;


# direct methods
.method public constructor <init>(Landroid/content/Context;II)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroid/support/v7/view/menu/d;->mSystemContext:Landroid/content/Context;

    invoke-static {p1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object p1

    iput-object p1, p0, Landroid/support/v7/view/menu/d;->mSystemInflater:Landroid/view/LayoutInflater;

    iput p2, p0, Landroid/support/v7/view/menu/d;->gm:I

    iput p3, p0, Landroid/support/v7/view/menu/d;->mItemLayoutRes:I

    return-void
.end method


# virtual methods
.method public a(Landroid/support/v7/view/menu/u;Landroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 2

    instance-of v0, p2, Landroid/support/v7/view/menu/H;

    if-eqz v0, :cond_0

    check-cast p2, Landroid/support/v7/view/menu/H;

    goto :goto_0

    .line 1
    :cond_0
    iget-object p2, p0, Landroid/support/v7/view/menu/d;->mSystemInflater:Landroid/view/LayoutInflater;

    iget v0, p0, Landroid/support/v7/view/menu/d;->mItemLayoutRes:I

    const/4 v1, 0x0

    invoke-virtual {p2, v0, p3, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/support/v7/view/menu/H;

    .line 2
    :goto_0
    invoke-virtual {p0, p1, p2}, Landroid/support/v7/view/menu/d;->a(Landroid/support/v7/view/menu/u;Landroid/support/v7/view/menu/H;)V

    check-cast p2, Landroid/view/View;

    return-object p2
.end method

.method public a(Landroid/content/Context;Landroid/support/v7/view/menu/r;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/view/menu/d;->mContext:Landroid/content/Context;

    iget-object p1, p0, Landroid/support/v7/view/menu/d;->mContext:Landroid/content/Context;

    invoke-static {p1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    iput-object p2, p0, Landroid/support/v7/view/menu/d;->mMenu:Landroid/support/v7/view/menu/r;

    return-void
.end method

.method public a(Landroid/support/v7/view/menu/F;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/view/menu/d;->mCallback:Landroid/support/v7/view/menu/F;

    return-void
.end method

.method public a(Landroid/support/v7/view/menu/r;Z)V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/d;->mCallback:Landroid/support/v7/view/menu/F;

    if-eqz p0, :cond_0

    invoke-interface {p0, p1, p2}, Landroid/support/v7/view/menu/F;->a(Landroid/support/v7/view/menu/r;Z)V

    :cond_0
    return-void
.end method

.method public abstract a(Landroid/support/v7/view/menu/u;Landroid/support/v7/view/menu/H;)V
.end method

.method public abstract a(ILandroid/support/v7/view/menu/u;)Z
.end method

.method public a(Landroid/support/v7/view/menu/P;)Z
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/d;->mCallback:Landroid/support/v7/view/menu/F;

    if-eqz p0, :cond_0

    invoke-interface {p0, p1}, Landroid/support/v7/view/menu/F;->a(Landroid/support/v7/view/menu/r;)Z

    move-result p0

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public a(Landroid/support/v7/view/menu/r;Landroid/support/v7/view/menu/u;)Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public b(Landroid/support/v7/view/menu/r;Landroid/support/v7/view/menu/u;)Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method protected abstract filterLeftoverView(Landroid/view/ViewGroup;I)Z
.end method

.method public getCallback()Landroid/support/v7/view/menu/F;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/d;->mCallback:Landroid/support/v7/view/menu/F;

    return-object p0
.end method

.method public getMenuView(Landroid/view/ViewGroup;)Landroid/support/v7/view/menu/I;
    .locals 3

    iget-object v0, p0, Landroid/support/v7/view/menu/d;->mMenuView:Landroid/support/v7/view/menu/I;

    if-nez v0, :cond_0

    iget-object v0, p0, Landroid/support/v7/view/menu/d;->mSystemInflater:Landroid/view/LayoutInflater;

    iget v1, p0, Landroid/support/v7/view/menu/d;->gm:I

    const/4 v2, 0x0

    invoke-virtual {v0, v1, p1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/support/v7/view/menu/I;

    iput-object p1, p0, Landroid/support/v7/view/menu/d;->mMenuView:Landroid/support/v7/view/menu/I;

    iget-object p1, p0, Landroid/support/v7/view/menu/d;->mMenuView:Landroid/support/v7/view/menu/I;

    iget-object v0, p0, Landroid/support/v7/view/menu/d;->mMenu:Landroid/support/v7/view/menu/r;

    invoke-interface {p1, v0}, Landroid/support/v7/view/menu/I;->c(Landroid/support/v7/view/menu/r;)V

    const/4 p1, 0x1

    invoke-virtual {p0, p1}, Landroid/support/v7/view/menu/d;->updateMenuView(Z)V

    :cond_0
    iget-object p0, p0, Landroid/support/v7/view/menu/d;->mMenuView:Landroid/support/v7/view/menu/I;

    return-object p0
.end method

.method public setId(I)V
    .locals 0

    return-void
.end method

.method public updateMenuView(Z)V
    .locals 9

    iget-object p1, p0, Landroid/support/v7/view/menu/d;->mMenuView:Landroid/support/v7/view/menu/I;

    check-cast p1, Landroid/view/ViewGroup;

    if-nez p1, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Landroid/support/v7/view/menu/d;->mMenu:Landroid/support/v7/view/menu/r;

    const/4 v1, 0x0

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Landroid/support/v7/view/menu/r;->flagActionItems()V

    iget-object v0, p0, Landroid/support/v7/view/menu/d;->mMenu:Landroid/support/v7/view/menu/r;

    invoke-virtual {v0}, Landroid/support/v7/view/menu/r;->getVisibleItems()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v2

    move v3, v1

    move v4, v3

    :goto_0
    if-ge v3, v2, :cond_6

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/support/v7/view/menu/u;

    invoke-virtual {p0, v4, v5}, Landroid/support/v7/view/menu/d;->a(ILandroid/support/v7/view/menu/u;)Z

    move-result v6

    if-eqz v6, :cond_5

    invoke-virtual {p1, v4}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v6

    instance-of v7, v6, Landroid/support/v7/view/menu/H;

    if-eqz v7, :cond_1

    move-object v7, v6

    check-cast v7, Landroid/support/v7/view/menu/H;

    invoke-interface {v7}, Landroid/support/v7/view/menu/H;->getItemData()Landroid/support/v7/view/menu/u;

    move-result-object v7

    goto :goto_1

    :cond_1
    const/4 v7, 0x0

    :goto_1
    invoke-virtual {p0, v5, v6, p1}, Landroid/support/v7/view/menu/d;->a(Landroid/support/v7/view/menu/u;Landroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v8

    if-eq v5, v7, :cond_2

    invoke-virtual {v8, v1}, Landroid/view/View;->setPressed(Z)V

    invoke-virtual {v8}, Landroid/view/View;->jumpDrawablesToCurrentState()V

    :cond_2
    if-eq v8, v6, :cond_4

    .line 1
    invoke-virtual {v8}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v5

    check-cast v5, Landroid/view/ViewGroup;

    if-eqz v5, :cond_3

    invoke-virtual {v5, v8}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_3
    iget-object v5, p0, Landroid/support/v7/view/menu/d;->mMenuView:Landroid/support/v7/view/menu/I;

    check-cast v5, Landroid/view/ViewGroup;

    invoke-virtual {v5, v8, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V

    :cond_4
    add-int/lit8 v4, v4, 0x1

    :cond_5
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_6
    move v1, v4

    .line 2
    :cond_7
    :goto_2
    invoke-virtual {p1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    if-ge v1, v0, :cond_8

    invoke-virtual {p0, p1, v1}, Landroid/support/v7/view/menu/d;->filterLeftoverView(Landroid/view/ViewGroup;I)Z

    move-result v0

    if-nez v0, :cond_7

    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    :cond_8
    return-void
.end method
