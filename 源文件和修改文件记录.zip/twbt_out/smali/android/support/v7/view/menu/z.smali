.class public Landroid/support/v7/view/menu/z;
.super Landroid/support/v7/view/menu/e;
.source ""

# interfaces
.implements Landroid/view/MenuItem;


# instance fields
.field private Dm:Ljava/lang/reflect/Method;


# direct methods
.method constructor <init>(Landroid/content/Context;La/b/c/c/a/b;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Landroid/support/v7/view/menu/e;-><init>(Landroid/content/Context;Ljava/lang/Object;)V

    return-void
.end method


# virtual methods
.method a(Landroid/view/ActionProvider;)Landroid/support/v7/view/menu/v;
    .locals 2

    new-instance v0, Landroid/support/v7/view/menu/v;

    iget-object v1, p0, Landroid/support/v7/view/menu/e;->mContext:Landroid/content/Context;

    invoke-direct {v0, p0, v1, p1}, Landroid/support/v7/view/menu/v;-><init>(Landroid/support/v7/view/menu/z;Landroid/content/Context;Landroid/view/ActionProvider;)V

    return-object v0
.end method

.method public collapseActionView()Z
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast p0, La/b/c/c/a/b;

    invoke-interface {p0}, La/b/c/c/a/b;->collapseActionView()Z

    move-result p0

    return p0
.end method

.method public expandActionView()Z
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast p0, La/b/c/c/a/b;

    invoke-interface {p0}, La/b/c/c/a/b;->expandActionView()Z

    move-result p0

    return p0
.end method

.method public getActionProvider()Landroid/view/ActionProvider;
    .locals 1

    iget-object p0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast p0, La/b/c/c/a/b;

    invoke-interface {p0}, La/b/c/c/a/b;->m()Landroid/support/v4/view/f;

    move-result-object p0

    instance-of v0, p0, Landroid/support/v7/view/menu/v;

    if-eqz v0, :cond_0

    check-cast p0, Landroid/support/v7/view/menu/v;

    iget-object p0, p0, Landroid/support/v7/view/menu/v;->kg:Landroid/view/ActionProvider;

    return-object p0

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public getActionView()Landroid/view/View;
    .locals 1

    iget-object p0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast p0, La/b/c/c/a/b;

    invoke-interface {p0}, La/b/c/c/a/b;->getActionView()Landroid/view/View;

    move-result-object p0

    instance-of v0, p0, Landroid/support/v7/view/menu/w;

    if-eqz v0, :cond_0

    check-cast p0, Landroid/support/v7/view/menu/w;

    .line 1
    iget-object p0, p0, Landroid/support/v7/view/menu/w;->bw:Landroid/view/CollapsibleActionView;

    check-cast p0, Landroid/view/View;

    :cond_0
    return-object p0
.end method

.method public getAlphabeticModifiers()I
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast p0, La/b/c/c/a/b;

    invoke-interface {p0}, La/b/c/c/a/b;->getAlphabeticModifiers()I

    move-result p0

    return p0
.end method

.method public getAlphabeticShortcut()C
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast p0, La/b/c/c/a/b;

    invoke-interface {p0}, Landroid/view/MenuItem;->getAlphabeticShortcut()C

    move-result p0

    return p0
.end method

.method public getContentDescription()Ljava/lang/CharSequence;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast p0, La/b/c/c/a/b;

    invoke-interface {p0}, La/b/c/c/a/b;->getContentDescription()Ljava/lang/CharSequence;

    move-result-object p0

    return-object p0
.end method

.method public getGroupId()I
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast p0, La/b/c/c/a/b;

    invoke-interface {p0}, Landroid/view/MenuItem;->getGroupId()I

    move-result p0

    return p0
.end method

.method public getIcon()Landroid/graphics/drawable/Drawable;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast p0, La/b/c/c/a/b;

    invoke-interface {p0}, Landroid/view/MenuItem;->getIcon()Landroid/graphics/drawable/Drawable;

    move-result-object p0

    return-object p0
.end method

.method public getIconTintList()Landroid/content/res/ColorStateList;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast p0, La/b/c/c/a/b;

    invoke-interface {p0}, La/b/c/c/a/b;->getIconTintList()Landroid/content/res/ColorStateList;

    move-result-object p0

    return-object p0
.end method

.method public getIconTintMode()Landroid/graphics/PorterDuff$Mode;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast p0, La/b/c/c/a/b;

    invoke-interface {p0}, La/b/c/c/a/b;->getIconTintMode()Landroid/graphics/PorterDuff$Mode;

    move-result-object p0

    return-object p0
.end method

.method public getIntent()Landroid/content/Intent;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast p0, La/b/c/c/a/b;

    invoke-interface {p0}, Landroid/view/MenuItem;->getIntent()Landroid/content/Intent;

    move-result-object p0

    return-object p0
.end method

.method public getItemId()I
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast p0, La/b/c/c/a/b;

    invoke-interface {p0}, Landroid/view/MenuItem;->getItemId()I

    move-result p0

    return p0
.end method

.method public getMenuInfo()Landroid/view/ContextMenu$ContextMenuInfo;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast p0, La/b/c/c/a/b;

    invoke-interface {p0}, Landroid/view/MenuItem;->getMenuInfo()Landroid/view/ContextMenu$ContextMenuInfo;

    move-result-object p0

    return-object p0
.end method

.method public getNumericModifiers()I
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast p0, La/b/c/c/a/b;

    invoke-interface {p0}, La/b/c/c/a/b;->getNumericModifiers()I

    move-result p0

    return p0
.end method

.method public getNumericShortcut()C
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast p0, La/b/c/c/a/b;

    invoke-interface {p0}, Landroid/view/MenuItem;->getNumericShortcut()C

    move-result p0

    return p0
.end method

.method public getOrder()I
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast p0, La/b/c/c/a/b;

    invoke-interface {p0}, Landroid/view/MenuItem;->getOrder()I

    move-result p0

    return p0
.end method

.method public getSubMenu()Landroid/view/SubMenu;
    .locals 1

    iget-object v0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast v0, La/b/c/c/a/b;

    invoke-interface {v0}, Landroid/view/MenuItem;->getSubMenu()Landroid/view/SubMenu;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroid/support/v7/view/menu/e;->a(Landroid/view/SubMenu;)Landroid/view/SubMenu;

    move-result-object p0

    return-object p0
.end method

.method public getTitle()Ljava/lang/CharSequence;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast p0, La/b/c/c/a/b;

    invoke-interface {p0}, Landroid/view/MenuItem;->getTitle()Ljava/lang/CharSequence;

    move-result-object p0

    return-object p0
.end method

.method public getTitleCondensed()Ljava/lang/CharSequence;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast p0, La/b/c/c/a/b;

    invoke-interface {p0}, Landroid/view/MenuItem;->getTitleCondensed()Ljava/lang/CharSequence;

    move-result-object p0

    return-object p0
.end method

.method public getTooltipText()Ljava/lang/CharSequence;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast p0, La/b/c/c/a/b;

    invoke-interface {p0}, La/b/c/c/a/b;->getTooltipText()Ljava/lang/CharSequence;

    move-result-object p0

    return-object p0
.end method

.method public hasSubMenu()Z
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast p0, La/b/c/c/a/b;

    invoke-interface {p0}, Landroid/view/MenuItem;->hasSubMenu()Z

    move-result p0

    return p0
.end method

.method public isActionViewExpanded()Z
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast p0, La/b/c/c/a/b;

    invoke-interface {p0}, La/b/c/c/a/b;->isActionViewExpanded()Z

    move-result p0

    return p0
.end method

.method public isCheckable()Z
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast p0, La/b/c/c/a/b;

    invoke-interface {p0}, Landroid/view/MenuItem;->isCheckable()Z

    move-result p0

    return p0
.end method

.method public isChecked()Z
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast p0, La/b/c/c/a/b;

    invoke-interface {p0}, Landroid/view/MenuItem;->isChecked()Z

    move-result p0

    return p0
.end method

.method public isEnabled()Z
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast p0, La/b/c/c/a/b;

    invoke-interface {p0}, Landroid/view/MenuItem;->isEnabled()Z

    move-result p0

    return p0
.end method

.method public isVisible()Z
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast p0, La/b/c/c/a/b;

    invoke-interface {p0}, Landroid/view/MenuItem;->isVisible()Z

    move-result p0

    return p0
.end method

.method public setActionProvider(Landroid/view/ActionProvider;)Landroid/view/MenuItem;
    .locals 1

    iget-object v0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast v0, La/b/c/c/a/b;

    if-eqz p1, :cond_0

    invoke-virtual {p0, p1}, Landroid/support/v7/view/menu/z;->a(Landroid/view/ActionProvider;)Landroid/support/v7/view/menu/v;

    move-result-object p1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    invoke-interface {v0, p1}, La/b/c/c/a/b;->a(Landroid/support/v4/view/f;)La/b/c/c/a/b;

    return-object p0
.end method

.method public setActionView(I)Landroid/view/MenuItem;
    .locals 2

    iget-object v0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast v0, La/b/c/c/a/b;

    invoke-interface {v0, p1}, La/b/c/c/a/b;->setActionView(I)Landroid/view/MenuItem;

    iget-object p1, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast p1, La/b/c/c/a/b;

    invoke-interface {p1}, La/b/c/c/a/b;->getActionView()Landroid/view/View;

    move-result-object p1

    instance-of v0, p1, Landroid/view/CollapsibleActionView;

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast v0, La/b/c/c/a/b;

    new-instance v1, Landroid/support/v7/view/menu/w;

    invoke-direct {v1, p1}, Landroid/support/v7/view/menu/w;-><init>(Landroid/view/View;)V

    invoke-interface {v0, v1}, La/b/c/c/a/b;->setActionView(Landroid/view/View;)Landroid/view/MenuItem;

    :cond_0
    return-object p0
.end method

.method public setActionView(Landroid/view/View;)Landroid/view/MenuItem;
    .locals 1

    instance-of v0, p1, Landroid/view/CollapsibleActionView;

    if-eqz v0, :cond_0

    new-instance v0, Landroid/support/v7/view/menu/w;

    invoke-direct {v0, p1}, Landroid/support/v7/view/menu/w;-><init>(Landroid/view/View;)V

    move-object p1, v0

    :cond_0
    iget-object v0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast v0, La/b/c/c/a/b;

    invoke-interface {v0, p1}, La/b/c/c/a/b;->setActionView(Landroid/view/View;)Landroid/view/MenuItem;

    return-object p0
.end method

.method public setAlphabeticShortcut(C)Landroid/view/MenuItem;
    .locals 1

    iget-object v0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast v0, La/b/c/c/a/b;

    invoke-interface {v0, p1}, Landroid/view/MenuItem;->setAlphabeticShortcut(C)Landroid/view/MenuItem;

    return-object p0
.end method

.method public setAlphabeticShortcut(CI)Landroid/view/MenuItem;
    .locals 1

    iget-object v0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast v0, La/b/c/c/a/b;

    invoke-interface {v0, p1, p2}, La/b/c/c/a/b;->setAlphabeticShortcut(CI)Landroid/view/MenuItem;

    return-object p0
.end method

.method public setCheckable(Z)Landroid/view/MenuItem;
    .locals 1

    iget-object v0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast v0, La/b/c/c/a/b;

    invoke-interface {v0, p1}, Landroid/view/MenuItem;->setCheckable(Z)Landroid/view/MenuItem;

    return-object p0
.end method

.method public setChecked(Z)Landroid/view/MenuItem;
    .locals 1

    iget-object v0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast v0, La/b/c/c/a/b;

    invoke-interface {v0, p1}, Landroid/view/MenuItem;->setChecked(Z)Landroid/view/MenuItem;

    return-object p0
.end method

.method public setContentDescription(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 1

    iget-object v0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast v0, La/b/c/c/a/b;

    invoke-interface {v0, p1}, La/b/c/c/a/b;->setContentDescription(Ljava/lang/CharSequence;)La/b/c/c/a/b;

    return-object p0
.end method

.method public setEnabled(Z)Landroid/view/MenuItem;
    .locals 1

    iget-object v0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast v0, La/b/c/c/a/b;

    invoke-interface {v0, p1}, Landroid/view/MenuItem;->setEnabled(Z)Landroid/view/MenuItem;

    return-object p0
.end method

.method public setExclusiveCheckable(Z)V
    .locals 6

    :try_start_0
    iget-object v0, p0, Landroid/support/v7/view/menu/z;->Dm:Ljava/lang/reflect/Method;

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-nez v0, :cond_0

    iget-object v0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast v0, La/b/c/c/a/b;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const-string v3, "setExclusiveCheckable"

    new-array v4, v2, [Ljava/lang/Class;

    sget-object v5, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    aput-object v5, v4, v1

    invoke-virtual {v0, v3, v4}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    iput-object v0, p0, Landroid/support/v7/view/menu/z;->Dm:Ljava/lang/reflect/Method;

    :cond_0
    iget-object v0, p0, Landroid/support/v7/view/menu/z;->Dm:Ljava/lang/reflect/Method;

    iget-object p0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    new-array v2, v2, [Ljava/lang/Object;

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    aput-object p1, v2, v1

    invoke-virtual {v0, p0, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p0

    const-string p1, "MenuItemWrapper"

    const-string v0, "Error while calling setExclusiveCheckable"

    invoke-static {p1, v0, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_0
    return-void
.end method

.method public setIcon(I)Landroid/view/MenuItem;
    .locals 1

    iget-object v0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast v0, La/b/c/c/a/b;

    invoke-interface {v0, p1}, Landroid/view/MenuItem;->setIcon(I)Landroid/view/MenuItem;

    return-object p0
.end method

.method public setIcon(Landroid/graphics/drawable/Drawable;)Landroid/view/MenuItem;
    .locals 1

    iget-object v0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast v0, La/b/c/c/a/b;

    invoke-interface {v0, p1}, Landroid/view/MenuItem;->setIcon(Landroid/graphics/drawable/Drawable;)Landroid/view/MenuItem;

    return-object p0
.end method

.method public setIconTintList(Landroid/content/res/ColorStateList;)Landroid/view/MenuItem;
    .locals 1

    iget-object v0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast v0, La/b/c/c/a/b;

    invoke-interface {v0, p1}, La/b/c/c/a/b;->setIconTintList(Landroid/content/res/ColorStateList;)Landroid/view/MenuItem;

    return-object p0
.end method

.method public setIconTintMode(Landroid/graphics/PorterDuff$Mode;)Landroid/view/MenuItem;
    .locals 1

    iget-object v0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast v0, La/b/c/c/a/b;

    invoke-interface {v0, p1}, La/b/c/c/a/b;->setIconTintMode(Landroid/graphics/PorterDuff$Mode;)Landroid/view/MenuItem;

    return-object p0
.end method

.method public setIntent(Landroid/content/Intent;)Landroid/view/MenuItem;
    .locals 1

    iget-object v0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast v0, La/b/c/c/a/b;

    invoke-interface {v0, p1}, Landroid/view/MenuItem;->setIntent(Landroid/content/Intent;)Landroid/view/MenuItem;

    return-object p0
.end method

.method public setNumericShortcut(C)Landroid/view/MenuItem;
    .locals 1

    iget-object v0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast v0, La/b/c/c/a/b;

    invoke-interface {v0, p1}, Landroid/view/MenuItem;->setNumericShortcut(C)Landroid/view/MenuItem;

    return-object p0
.end method

.method public setNumericShortcut(CI)Landroid/view/MenuItem;
    .locals 1

    iget-object v0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast v0, La/b/c/c/a/b;

    invoke-interface {v0, p1, p2}, La/b/c/c/a/b;->setNumericShortcut(CI)Landroid/view/MenuItem;

    return-object p0
.end method

.method public setOnActionExpandListener(Landroid/view/MenuItem$OnActionExpandListener;)Landroid/view/MenuItem;
    .locals 2

    iget-object v0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast v0, La/b/c/c/a/b;

    if-eqz p1, :cond_0

    new-instance v1, Landroid/support/v7/view/menu/x;

    invoke-direct {v1, p0, p1}, Landroid/support/v7/view/menu/x;-><init>(Landroid/support/v7/view/menu/z;Landroid/view/MenuItem$OnActionExpandListener;)V

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    invoke-interface {v0, v1}, Landroid/view/MenuItem;->setOnActionExpandListener(Landroid/view/MenuItem$OnActionExpandListener;)Landroid/view/MenuItem;

    return-object p0
.end method

.method public setOnMenuItemClickListener(Landroid/view/MenuItem$OnMenuItemClickListener;)Landroid/view/MenuItem;
    .locals 2

    iget-object v0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast v0, La/b/c/c/a/b;

    if-eqz p1, :cond_0

    new-instance v1, Landroid/support/v7/view/menu/y;

    invoke-direct {v1, p0, p1}, Landroid/support/v7/view/menu/y;-><init>(Landroid/support/v7/view/menu/z;Landroid/view/MenuItem$OnMenuItemClickListener;)V

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    invoke-interface {v0, v1}, Landroid/view/MenuItem;->setOnMenuItemClickListener(Landroid/view/MenuItem$OnMenuItemClickListener;)Landroid/view/MenuItem;

    return-object p0
.end method

.method public setShortcut(CC)Landroid/view/MenuItem;
    .locals 1

    iget-object v0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast v0, La/b/c/c/a/b;

    invoke-interface {v0, p1, p2}, Landroid/view/MenuItem;->setShortcut(CC)Landroid/view/MenuItem;

    return-object p0
.end method

.method public setShortcut(CCII)Landroid/view/MenuItem;
    .locals 1

    iget-object v0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast v0, La/b/c/c/a/b;

    invoke-interface {v0, p1, p2, p3, p4}, La/b/c/c/a/b;->setShortcut(CCII)Landroid/view/MenuItem;

    return-object p0
.end method

.method public setShowAsAction(I)V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast p0, La/b/c/c/a/b;

    invoke-interface {p0, p1}, La/b/c/c/a/b;->setShowAsAction(I)V

    return-void
.end method

.method public setShowAsActionFlags(I)Landroid/view/MenuItem;
    .locals 1

    iget-object v0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast v0, La/b/c/c/a/b;

    invoke-interface {v0, p1}, La/b/c/c/a/b;->setShowAsActionFlags(I)Landroid/view/MenuItem;

    return-object p0
.end method

.method public setTitle(I)Landroid/view/MenuItem;
    .locals 1

    iget-object v0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast v0, La/b/c/c/a/b;

    invoke-interface {v0, p1}, Landroid/view/MenuItem;->setTitle(I)Landroid/view/MenuItem;

    return-object p0
.end method

.method public setTitle(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 1

    iget-object v0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast v0, La/b/c/c/a/b;

    invoke-interface {v0, p1}, Landroid/view/MenuItem;->setTitle(Ljava/lang/CharSequence;)Landroid/view/MenuItem;

    return-object p0
.end method

.method public setTitleCondensed(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 1

    iget-object v0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast v0, La/b/c/c/a/b;

    invoke-interface {v0, p1}, Landroid/view/MenuItem;->setTitleCondensed(Ljava/lang/CharSequence;)Landroid/view/MenuItem;

    return-object p0
.end method

.method public setTooltipText(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 1

    iget-object v0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast v0, La/b/c/c/a/b;

    invoke-interface {v0, p1}, La/b/c/c/a/b;->setTooltipText(Ljava/lang/CharSequence;)La/b/c/c/a/b;

    return-object p0
.end method

.method public setVisible(Z)Landroid/view/MenuItem;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/f;->Am:Ljava/lang/Object;

    check-cast p0, La/b/c/c/a/b;

    invoke-interface {p0, p1}, Landroid/view/MenuItem;->setVisible(Z)Landroid/view/MenuItem;

    move-result-object p0

    return-object p0
.end method
