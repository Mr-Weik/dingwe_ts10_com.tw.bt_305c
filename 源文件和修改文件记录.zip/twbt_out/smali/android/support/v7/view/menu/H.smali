.class public interface abstract Landroid/support/v7/view/menu/H;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract a(Landroid/support/v7/view/menu/u;I)V
.end method

.method public abstract getItemData()Landroid/support/v7/view/menu/u;
.end method

.method public abstract prefersCondensedTitle()Z
.end method
