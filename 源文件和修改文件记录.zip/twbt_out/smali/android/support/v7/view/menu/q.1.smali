.class public interface abstract Landroid/support/v7/view/menu/q;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract a(Landroid/support/v7/view/menu/u;)Z
.end method
