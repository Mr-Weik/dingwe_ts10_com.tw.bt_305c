.class public interface abstract Landroid/support/v7/view/menu/G;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract a(Landroid/content/Context;Landroid/support/v7/view/menu/r;)V
.end method

.method public abstract a(Landroid/support/v7/view/menu/F;)V
.end method

.method public abstract a(Landroid/support/v7/view/menu/r;Z)V
.end method

.method public abstract a(Landroid/support/v7/view/menu/P;)Z
.end method

.method public abstract a(Landroid/support/v7/view/menu/r;Landroid/support/v7/view/menu/u;)Z
.end method

.method public abstract b(Landroid/support/v7/view/menu/r;Landroid/support/v7/view/menu/u;)Z
.end method

.method public abstract flagActionItems()Z
.end method

.method public abstract updateMenuView(Z)V
.end method
