.class Landroid/support/v7/view/menu/D;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/widget/PopupWindow$OnDismissListener;


# instance fields
.field final synthetic n:Landroid/support/v7/view/menu/E;


# direct methods
.method constructor <init>(Landroid/support/v7/view/menu/E;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/view/menu/D;->n:Landroid/support/v7/view/menu/E;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onDismiss()V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/D;->n:Landroid/support/v7/view/menu/E;

    invoke-virtual {p0}, Landroid/support/v7/view/menu/E;->onDismiss()V

    return-void
.end method
