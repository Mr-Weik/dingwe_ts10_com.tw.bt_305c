.class Landroid/support/v7/view/menu/i;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic Em:Landroid/support/v7/view/menu/k;

.field final synthetic Fm:Landroid/view/MenuItem;

.field final synthetic Gm:Landroid/support/v7/view/menu/r;

.field final synthetic Hc:Landroid/support/v7/view/menu/j;


# direct methods
.method constructor <init>(Landroid/support/v7/view/menu/j;Landroid/support/v7/view/menu/k;Landroid/view/MenuItem;Landroid/support/v7/view/menu/r;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/view/menu/i;->Hc:Landroid/support/v7/view/menu/j;

    iput-object p2, p0, Landroid/support/v7/view/menu/i;->Em:Landroid/support/v7/view/menu/k;

    iput-object p3, p0, Landroid/support/v7/view/menu/i;->Fm:Landroid/view/MenuItem;

    iput-object p4, p0, Landroid/support/v7/view/menu/i;->Gm:Landroid/support/v7/view/menu/r;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    iget-object v0, p0, Landroid/support/v7/view/menu/i;->Em:Landroid/support/v7/view/menu/k;

    if-eqz v0, :cond_0

    iget-object v1, p0, Landroid/support/v7/view/menu/i;->Hc:Landroid/support/v7/view/menu/j;

    iget-object v1, v1, Landroid/support/v7/view/menu/j;->n:Landroid/support/v7/view/menu/l;

    const/4 v2, 0x1

    iput-boolean v2, v1, Landroid/support/v7/view/menu/l;->Mn:Z

    iget-object v0, v0, Landroid/support/v7/view/menu/k;->menu:Landroid/support/v7/view/menu/r;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/support/v7/view/menu/r;->close(Z)V

    iget-object v0, p0, Landroid/support/v7/view/menu/i;->Hc:Landroid/support/v7/view/menu/j;

    iget-object v0, v0, Landroid/support/v7/view/menu/j;->n:Landroid/support/v7/view/menu/l;

    iput-boolean v1, v0, Landroid/support/v7/view/menu/l;->Mn:Z

    :cond_0
    iget-object v0, p0, Landroid/support/v7/view/menu/i;->Fm:Landroid/view/MenuItem;

    invoke-interface {v0}, Landroid/view/MenuItem;->isEnabled()Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Landroid/support/v7/view/menu/i;->Fm:Landroid/view/MenuItem;

    invoke-interface {v0}, Landroid/view/MenuItem;->hasSubMenu()Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Landroid/support/v7/view/menu/i;->Gm:Landroid/support/v7/view/menu/r;

    iget-object p0, p0, Landroid/support/v7/view/menu/i;->Fm:Landroid/view/MenuItem;

    const/4 v1, 0x4

    invoke-virtual {v0, p0, v1}, Landroid/support/v7/view/menu/r;->performItemAction(Landroid/view/MenuItem;I)Z

    :cond_1
    return-void
.end method
