.class Landroid/support/v7/view/menu/A;
.super Landroid/support/v7/view/menu/v;
.source ""

# interfaces
.implements Landroid/view/ActionProvider$VisibilityListener;


# instance fields
.field mListener:Landroid/support/v4/view/e;


# direct methods
.method public constructor <init>(Landroid/support/v7/view/menu/B;Landroid/content/Context;Landroid/view/ActionProvider;)V
    .locals 0

    invoke-direct {p0, p1, p2, p3}, Landroid/support/v7/view/menu/v;-><init>(Landroid/support/v7/view/menu/z;Landroid/content/Context;Landroid/view/ActionProvider;)V

    return-void
.end method


# virtual methods
.method public a(Landroid/support/v4/view/e;)V
    .locals 1

    iput-object p1, p0, Landroid/support/v7/view/menu/A;->mListener:Landroid/support/v4/view/e;

    iget-object v0, p0, Landroid/support/v7/view/menu/v;->kg:Landroid/view/ActionProvider;

    if-eqz p1, :cond_0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    invoke-virtual {v0, p0}, Landroid/view/ActionProvider;->setVisibilityListener(Landroid/view/ActionProvider$VisibilityListener;)V

    return-void
.end method

.method public isVisible()Z
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/v;->kg:Landroid/view/ActionProvider;

    invoke-virtual {p0}, Landroid/view/ActionProvider;->isVisible()Z

    move-result p0

    return p0
.end method

.method public onActionProviderVisibilityChanged(Z)V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/A;->mListener:Landroid/support/v4/view/e;

    if-eqz p0, :cond_0

    check-cast p0, Landroid/support/v7/view/menu/t;

    .line 1
    iget-object p0, p0, Landroid/support/v7/view/menu/t;->n:Landroid/support/v7/view/menu/u;

    iget-object p1, p0, Landroid/support/v7/view/menu/u;->mMenu:Landroid/support/v7/view/menu/r;

    invoke-virtual {p1, p0}, Landroid/support/v7/view/menu/r;->e(Landroid/support/v7/view/menu/u;)V

    :cond_0
    return-void
.end method

.method public onCreateActionView(Landroid/view/MenuItem;)Landroid/view/View;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/v;->kg:Landroid/view/ActionProvider;

    invoke-virtual {p0, p1}, Landroid/view/ActionProvider;->onCreateActionView(Landroid/view/MenuItem;)Landroid/view/View;

    move-result-object p0

    return-object p0
.end method

.method public overridesItemVisibility()Z
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/v;->kg:Landroid/view/ActionProvider;

    invoke-virtual {p0}, Landroid/view/ActionProvider;->overridesItemVisibility()Z

    move-result p0

    return p0
.end method
