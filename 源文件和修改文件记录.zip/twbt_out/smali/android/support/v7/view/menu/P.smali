.class public Landroid/support/v7/view/menu/P;
.super Landroid/support/v7/view/menu/r;
.source ""

# interfaces
.implements Landroid/view/SubMenu;


# instance fields
.field private bn:Landroid/support/v7/view/menu/r;

.field private cn:Landroid/support/v7/view/menu/u;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/support/v7/view/menu/r;Landroid/support/v7/view/menu/u;)V
    .locals 0

    invoke-direct {p0, p1}, Landroid/support/v7/view/menu/r;-><init>(Landroid/content/Context;)V

    iput-object p2, p0, Landroid/support/v7/view/menu/P;->bn:Landroid/support/v7/view/menu/r;

    iput-object p3, p0, Landroid/support/v7/view/menu/P;->cn:Landroid/support/v7/view/menu/u;

    return-void
.end method


# virtual methods
.method public a(Landroid/support/v7/view/menu/p;)V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/P;->bn:Landroid/support/v7/view/menu/r;

    invoke-virtual {p0, p1}, Landroid/support/v7/view/menu/r;->a(Landroid/support/v7/view/menu/p;)V

    return-void
.end method

.method public b(Landroid/support/v7/view/menu/u;)Z
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/P;->bn:Landroid/support/v7/view/menu/r;

    invoke-virtual {p0, p1}, Landroid/support/v7/view/menu/r;->b(Landroid/support/v7/view/menu/u;)Z

    move-result p0

    return p0
.end method

.method public c(Landroid/support/v7/view/menu/u;)Z
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/P;->bn:Landroid/support/v7/view/menu/r;

    invoke-virtual {p0, p1}, Landroid/support/v7/view/menu/r;->c(Landroid/support/v7/view/menu/u;)Z

    move-result p0

    return p0
.end method

.method d(Landroid/support/v7/view/menu/r;Landroid/view/MenuItem;)Z
    .locals 1

    invoke-super {p0, p1, p2}, Landroid/support/v7/view/menu/r;->d(Landroid/support/v7/view/menu/r;Landroid/view/MenuItem;)Z

    move-result v0

    if-nez v0, :cond_1

    iget-object p0, p0, Landroid/support/v7/view/menu/P;->bn:Landroid/support/v7/view/menu/r;

    invoke-virtual {p0, p1, p2}, Landroid/support/v7/view/menu/r;->d(Landroid/support/v7/view/menu/r;Landroid/view/MenuItem;)Z

    move-result p0

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 p0, 0x1

    :goto_1
    return p0
.end method

.method public getActionViewStatesKey()Ljava/lang/String;
    .locals 2

    iget-object p0, p0, Landroid/support/v7/view/menu/P;->cn:Landroid/support/v7/view/menu/u;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroid/support/v7/view/menu/u;->getItemId()I

    move-result p0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    if-nez p0, :cond_1

    const/4 p0, 0x0

    return-object p0

    :cond_1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "android:menu:actionviewstates"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ":"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public getItem()Landroid/view/MenuItem;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/P;->cn:Landroid/support/v7/view/menu/u;

    return-object p0
.end method

.method public getParentMenu()Landroid/view/Menu;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/P;->bn:Landroid/support/v7/view/menu/r;

    return-object p0
.end method

.method public getRootMenu()Landroid/support/v7/view/menu/r;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/P;->bn:Landroid/support/v7/view/menu/r;

    invoke-virtual {p0}, Landroid/support/v7/view/menu/r;->getRootMenu()Landroid/support/v7/view/menu/r;

    move-result-object p0

    return-object p0
.end method

.method public isGroupDividerEnabled()Z
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/P;->bn:Landroid/support/v7/view/menu/r;

    invoke-virtual {p0}, Landroid/support/v7/view/menu/r;->isGroupDividerEnabled()Z

    move-result p0

    return p0
.end method

.method public isQwertyMode()Z
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/P;->bn:Landroid/support/v7/view/menu/r;

    invoke-virtual {p0}, Landroid/support/v7/view/menu/r;->isQwertyMode()Z

    move-result p0

    return p0
.end method

.method public isShortcutsVisible()Z
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/P;->bn:Landroid/support/v7/view/menu/r;

    invoke-virtual {p0}, Landroid/support/v7/view/menu/r;->isShortcutsVisible()Z

    move-result p0

    return p0
.end method

.method public setGroupDividerEnabled(Z)V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/P;->bn:Landroid/support/v7/view/menu/r;

    invoke-virtual {p0, p1}, Landroid/support/v7/view/menu/r;->setGroupDividerEnabled(Z)V

    return-void
.end method

.method public setHeaderIcon(I)Landroid/view/SubMenu;
    .locals 0

    invoke-super {p0, p1}, Landroid/support/v7/view/menu/r;->setHeaderIconInt(I)Landroid/support/v7/view/menu/r;

    check-cast p0, Landroid/view/SubMenu;

    return-object p0
.end method

.method public setHeaderIcon(Landroid/graphics/drawable/Drawable;)Landroid/view/SubMenu;
    .locals 0

    invoke-super {p0, p1}, Landroid/support/v7/view/menu/r;->setHeaderIconInt(Landroid/graphics/drawable/Drawable;)Landroid/support/v7/view/menu/r;

    check-cast p0, Landroid/view/SubMenu;

    return-object p0
.end method

.method public setHeaderTitle(I)Landroid/view/SubMenu;
    .locals 0

    invoke-super {p0, p1}, Landroid/support/v7/view/menu/r;->setHeaderTitleInt(I)Landroid/support/v7/view/menu/r;

    check-cast p0, Landroid/view/SubMenu;

    return-object p0
.end method

.method public setHeaderTitle(Ljava/lang/CharSequence;)Landroid/view/SubMenu;
    .locals 0

    invoke-super {p0, p1}, Landroid/support/v7/view/menu/r;->setHeaderTitleInt(Ljava/lang/CharSequence;)Landroid/support/v7/view/menu/r;

    check-cast p0, Landroid/view/SubMenu;

    return-object p0
.end method

.method public setHeaderView(Landroid/view/View;)Landroid/view/SubMenu;
    .locals 0

    invoke-super {p0, p1}, Landroid/support/v7/view/menu/r;->setHeaderViewInt(Landroid/view/View;)Landroid/support/v7/view/menu/r;

    check-cast p0, Landroid/view/SubMenu;

    return-object p0
.end method

.method public setIcon(I)Landroid/view/SubMenu;
    .locals 1

    iget-object v0, p0, Landroid/support/v7/view/menu/P;->cn:Landroid/support/v7/view/menu/u;

    invoke-virtual {v0, p1}, Landroid/support/v7/view/menu/u;->setIcon(I)Landroid/view/MenuItem;

    return-object p0
.end method

.method public setIcon(Landroid/graphics/drawable/Drawable;)Landroid/view/SubMenu;
    .locals 1

    iget-object v0, p0, Landroid/support/v7/view/menu/P;->cn:Landroid/support/v7/view/menu/u;

    invoke-virtual {v0, p1}, Landroid/support/v7/view/menu/u;->setIcon(Landroid/graphics/drawable/Drawable;)Landroid/view/MenuItem;

    return-object p0
.end method

.method public setQwertyMode(Z)V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/P;->bn:Landroid/support/v7/view/menu/r;

    invoke-virtual {p0, p1}, Landroid/support/v7/view/menu/r;->setQwertyMode(Z)V

    return-void
.end method
