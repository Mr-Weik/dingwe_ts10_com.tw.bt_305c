.class Landroid/support/v7/view/menu/M;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;


# instance fields
.field final synthetic n:Landroid/support/v7/view/menu/O;


# direct methods
.method constructor <init>(Landroid/support/v7/view/menu/O;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/view/menu/M;->n:Landroid/support/v7/view/menu/O;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onGlobalLayout()V
    .locals 1

    iget-object v0, p0, Landroid/support/v7/view/menu/M;->n:Landroid/support/v7/view/menu/O;

    invoke-virtual {v0}, Landroid/support/v7/view/menu/O;->isShowing()Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object v0, p0, Landroid/support/v7/view/menu/M;->n:Landroid/support/v7/view/menu/O;

    iget-object v0, v0, Landroid/support/v7/view/menu/O;->mPopup:Landroid/support/v7/widget/db;

    invoke-virtual {v0}, Landroid/support/v7/widget/ab;->isModal()Z

    move-result v0

    if-nez v0, :cond_2

    iget-object v0, p0, Landroid/support/v7/view/menu/M;->n:Landroid/support/v7/view/menu/O;

    iget-object v0, v0, Landroid/support/v7/view/menu/O;->Gn:Landroid/view/View;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Landroid/view/View;->isShown()Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    iget-object p0, p0, Landroid/support/v7/view/menu/M;->n:Landroid/support/v7/view/menu/O;

    iget-object p0, p0, Landroid/support/v7/view/menu/O;->mPopup:Landroid/support/v7/widget/db;

    invoke-virtual {p0}, Landroid/support/v7/widget/ab;->show()V

    goto :goto_1

    :cond_1
    :goto_0
    iget-object p0, p0, Landroid/support/v7/view/menu/M;->n:Landroid/support/v7/view/menu/O;

    invoke-virtual {p0}, Landroid/support/v7/view/menu/O;->dismiss()V

    :cond_2
    :goto_1
    return-void
.end method
