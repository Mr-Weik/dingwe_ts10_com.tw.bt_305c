.class Landroid/support/v7/view/menu/t;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/support/v4/view/e;


# instance fields
.field final synthetic n:Landroid/support/v7/view/menu/u;


# direct methods
.method constructor <init>(Landroid/support/v7/view/menu/u;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/view/menu/t;->n:Landroid/support/v7/view/menu/u;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
