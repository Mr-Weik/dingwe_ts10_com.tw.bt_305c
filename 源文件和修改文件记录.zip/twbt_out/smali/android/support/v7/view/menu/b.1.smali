.class Landroid/support/v7/view/menu/b;
.super Landroid/support/v7/widget/Ga;
.source ""


# instance fields
.field final synthetic n:Landroid/support/v7/view/menu/ActionMenuItemView;


# direct methods
.method public constructor <init>(Landroid/support/v7/view/menu/ActionMenuItemView;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/view/menu/b;->n:Landroid/support/v7/view/menu/ActionMenuItemView;

    invoke-direct {p0, p1}, Landroid/support/v7/widget/Ga;-><init>(Landroid/view/View;)V

    return-void
.end method


# virtual methods
.method public getPopup()Landroid/support/v7/view/menu/L;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/b;->n:Landroid/support/v7/view/menu/ActionMenuItemView;

    iget-object p0, p0, Landroid/support/v7/view/menu/ActionMenuItemView;->zm:Landroid/support/v7/view/menu/c;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroid/support/v7/view/menu/c;->getPopup()Landroid/support/v7/view/menu/L;

    move-result-object p0

    return-object p0

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method protected onForwardingStarted()Z
    .locals 3

    iget-object v0, p0, Landroid/support/v7/view/menu/b;->n:Landroid/support/v7/view/menu/ActionMenuItemView;

    iget-object v1, v0, Landroid/support/v7/view/menu/ActionMenuItemView;->Mw:Landroid/support/v7/view/menu/q;

    const/4 v2, 0x0

    if-eqz v1, :cond_1

    iget-object v0, v0, Landroid/support/v7/view/menu/ActionMenuItemView;->ow:Landroid/support/v7/view/menu/u;

    invoke-interface {v1, v0}, Landroid/support/v7/view/menu/q;->a(Landroid/support/v7/view/menu/u;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 1
    iget-object p0, p0, Landroid/support/v7/view/menu/b;->n:Landroid/support/v7/view/menu/ActionMenuItemView;

    iget-object p0, p0, Landroid/support/v7/view/menu/ActionMenuItemView;->zm:Landroid/support/v7/view/menu/c;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroid/support/v7/view/menu/c;->getPopup()Landroid/support/v7/view/menu/L;

    move-result-object p0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    if-eqz p0, :cond_1

    .line 2
    invoke-interface {p0}, Landroid/support/v7/view/menu/L;->isShowing()Z

    move-result p0

    if-eqz p0, :cond_1

    const/4 v2, 0x1

    :cond_1
    return v2
.end method
