.class Landroid/support/v7/view/menu/v;
.super Landroid/support/v4/view/f;
.source ""


# instance fields
.field final kg:Landroid/view/ActionProvider;

.field final synthetic n:Landroid/support/v7/view/menu/z;


# direct methods
.method public constructor <init>(Landroid/support/v7/view/menu/z;Landroid/content/Context;Landroid/view/ActionProvider;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/view/menu/v;->n:Landroid/support/v7/view/menu/z;

    invoke-direct {p0, p2}, Landroid/support/v4/view/f;-><init>(Landroid/content/Context;)V

    iput-object p3, p0, Landroid/support/v7/view/menu/v;->kg:Landroid/view/ActionProvider;

    return-void
.end method


# virtual methods
.method public hasSubMenu()Z
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/v;->kg:Landroid/view/ActionProvider;

    invoke-virtual {p0}, Landroid/view/ActionProvider;->hasSubMenu()Z

    move-result p0

    return p0
.end method

.method public onCreateActionView()Landroid/view/View;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/v;->kg:Landroid/view/ActionProvider;

    invoke-virtual {p0}, Landroid/view/ActionProvider;->onCreateActionView()Landroid/view/View;

    move-result-object p0

    return-object p0
.end method
