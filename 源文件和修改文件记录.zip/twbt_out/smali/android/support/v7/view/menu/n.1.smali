.class public Landroid/support/v7/view/menu/n;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/support/v7/view/menu/G;
.implements Landroid/widget/AdapterView$OnItemClickListener;


# instance fields
.field Hm:I

.field mAdapter:Landroid/support/v7/view/menu/m;

.field private mCallback:Landroid/support/v7/view/menu/F;

.field mContext:Landroid/content/Context;

.field mInflater:Landroid/view/LayoutInflater;

.field mItemLayoutRes:I

.field mMenu:Landroid/support/v7/view/menu/r;

.field mMenuView:Landroid/support/v7/view/menu/ExpandedMenuView;

.field mThemeRes:I


# direct methods
.method public constructor <init>(Landroid/content/Context;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p2, p0, Landroid/support/v7/view/menu/n;->mItemLayoutRes:I

    const/4 p2, 0x0

    iput p2, p0, Landroid/support/v7/view/menu/n;->mThemeRes:I

    .line 2
    iput-object p1, p0, Landroid/support/v7/view/menu/n;->mContext:Landroid/content/Context;

    iget-object p1, p0, Landroid/support/v7/view/menu/n;->mContext:Landroid/content/Context;

    invoke-static {p1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object p1

    iput-object p1, p0, Landroid/support/v7/view/menu/n;->mInflater:Landroid/view/LayoutInflater;

    return-void
.end method


# virtual methods
.method public a(Landroid/content/Context;Landroid/support/v7/view/menu/r;)V
    .locals 2

    iget v0, p0, Landroid/support/v7/view/menu/n;->mThemeRes:I

    if-eqz v0, :cond_0

    new-instance v1, Landroid/view/ContextThemeWrapper;

    invoke-direct {v1, p1, v0}, Landroid/view/ContextThemeWrapper;-><init>(Landroid/content/Context;I)V

    iput-object v1, p0, Landroid/support/v7/view/menu/n;->mContext:Landroid/content/Context;

    :goto_0
    iget-object p1, p0, Landroid/support/v7/view/menu/n;->mContext:Landroid/content/Context;

    invoke-static {p1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object p1

    iput-object p1, p0, Landroid/support/v7/view/menu/n;->mInflater:Landroid/view/LayoutInflater;

    goto :goto_1

    :cond_0
    iget-object v0, p0, Landroid/support/v7/view/menu/n;->mContext:Landroid/content/Context;

    if-eqz v0, :cond_1

    iput-object p1, p0, Landroid/support/v7/view/menu/n;->mContext:Landroid/content/Context;

    iget-object p1, p0, Landroid/support/v7/view/menu/n;->mInflater:Landroid/view/LayoutInflater;

    if-nez p1, :cond_1

    goto :goto_0

    :cond_1
    :goto_1
    iput-object p2, p0, Landroid/support/v7/view/menu/n;->mMenu:Landroid/support/v7/view/menu/r;

    iget-object p0, p0, Landroid/support/v7/view/menu/n;->mAdapter:Landroid/support/v7/view/menu/m;

    if-eqz p0, :cond_2

    invoke-virtual {p0}, Landroid/support/v7/view/menu/m;->notifyDataSetChanged()V

    :cond_2
    return-void
.end method

.method public a(Landroid/support/v7/view/menu/F;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/view/menu/n;->mCallback:Landroid/support/v7/view/menu/F;

    return-void
.end method

.method public a(Landroid/support/v7/view/menu/r;Z)V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/n;->mCallback:Landroid/support/v7/view/menu/F;

    if-eqz p0, :cond_0

    invoke-interface {p0, p1, p2}, Landroid/support/v7/view/menu/F;->a(Landroid/support/v7/view/menu/r;Z)V

    :cond_0
    return-void
.end method

.method public a(Landroid/support/v7/view/menu/P;)Z
    .locals 2

    invoke-virtual {p1}, Landroid/support/v7/view/menu/r;->hasVisibleItems()Z

    move-result v0

    if-nez v0, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    new-instance v0, Landroid/support/v7/view/menu/s;

    invoke-direct {v0, p1}, Landroid/support/v7/view/menu/s;-><init>(Landroid/support/v7/view/menu/r;)V

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/support/v7/view/menu/s;->show(Landroid/os/IBinder;)V

    iget-object p0, p0, Landroid/support/v7/view/menu/n;->mCallback:Landroid/support/v7/view/menu/F;

    if-eqz p0, :cond_1

    invoke-interface {p0, p1}, Landroid/support/v7/view/menu/F;->a(Landroid/support/v7/view/menu/r;)Z

    :cond_1
    const/4 p0, 0x1

    return p0
.end method

.method public a(Landroid/support/v7/view/menu/r;Landroid/support/v7/view/menu/u;)Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public b(Landroid/support/v7/view/menu/r;Landroid/support/v7/view/menu/u;)Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public flagActionItems()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public getAdapter()Landroid/widget/ListAdapter;
    .locals 1

    iget-object v0, p0, Landroid/support/v7/view/menu/n;->mAdapter:Landroid/support/v7/view/menu/m;

    if-nez v0, :cond_0

    new-instance v0, Landroid/support/v7/view/menu/m;

    invoke-direct {v0, p0}, Landroid/support/v7/view/menu/m;-><init>(Landroid/support/v7/view/menu/n;)V

    iput-object v0, p0, Landroid/support/v7/view/menu/n;->mAdapter:Landroid/support/v7/view/menu/m;

    :cond_0
    iget-object p0, p0, Landroid/support/v7/view/menu/n;->mAdapter:Landroid/support/v7/view/menu/m;

    return-object p0
.end method

.method public getMenuView(Landroid/view/ViewGroup;)Landroid/support/v7/view/menu/I;
    .locals 3

    iget-object v0, p0, Landroid/support/v7/view/menu/n;->mMenuView:Landroid/support/v7/view/menu/ExpandedMenuView;

    if-nez v0, :cond_1

    iget-object v0, p0, Landroid/support/v7/view/menu/n;->mInflater:Landroid/view/LayoutInflater;

    const v1, 0x7f0a000d

    const/4 v2, 0x0

    invoke-virtual {v0, v1, p1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/support/v7/view/menu/ExpandedMenuView;

    iput-object p1, p0, Landroid/support/v7/view/menu/n;->mMenuView:Landroid/support/v7/view/menu/ExpandedMenuView;

    iget-object p1, p0, Landroid/support/v7/view/menu/n;->mAdapter:Landroid/support/v7/view/menu/m;

    if-nez p1, :cond_0

    new-instance p1, Landroid/support/v7/view/menu/m;

    invoke-direct {p1, p0}, Landroid/support/v7/view/menu/m;-><init>(Landroid/support/v7/view/menu/n;)V

    iput-object p1, p0, Landroid/support/v7/view/menu/n;->mAdapter:Landroid/support/v7/view/menu/m;

    :cond_0
    iget-object p1, p0, Landroid/support/v7/view/menu/n;->mMenuView:Landroid/support/v7/view/menu/ExpandedMenuView;

    iget-object v0, p0, Landroid/support/v7/view/menu/n;->mAdapter:Landroid/support/v7/view/menu/m;

    invoke-virtual {p1, v0}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    iget-object p1, p0, Landroid/support/v7/view/menu/n;->mMenuView:Landroid/support/v7/view/menu/ExpandedMenuView;

    invoke-virtual {p1, p0}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    :cond_1
    iget-object p0, p0, Landroid/support/v7/view/menu/n;->mMenuView:Landroid/support/v7/view/menu/ExpandedMenuView;

    return-object p0
.end method

.method public onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 0

    iget-object p1, p0, Landroid/support/v7/view/menu/n;->mMenu:Landroid/support/v7/view/menu/r;

    iget-object p2, p0, Landroid/support/v7/view/menu/n;->mAdapter:Landroid/support/v7/view/menu/m;

    invoke-virtual {p2, p3}, Landroid/support/v7/view/menu/m;->getItem(I)Landroid/support/v7/view/menu/u;

    move-result-object p2

    const/4 p3, 0x0

    invoke-virtual {p1, p2, p0, p3}, Landroid/support/v7/view/menu/r;->a(Landroid/view/MenuItem;Landroid/support/v7/view/menu/G;I)Z

    return-void
.end method

.method public updateMenuView(Z)V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/view/menu/n;->mAdapter:Landroid/support/v7/view/menu/m;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroid/support/v7/view/menu/m;->notifyDataSetChanged()V

    :cond_0
    return-void
.end method
