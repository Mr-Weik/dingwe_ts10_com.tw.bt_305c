.class public interface abstract Landroid/support/v7/widget/Db;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract a(Landroid/support/v7/widget/RecyclerView;Landroid/view/MotionEvent;)V
.end method

.method public abstract b(Landroid/support/v7/widget/RecyclerView;Landroid/view/MotionEvent;)Z
.end method

.method public abstract onRequestDisallowInterceptTouchEvent(Z)V
.end method
