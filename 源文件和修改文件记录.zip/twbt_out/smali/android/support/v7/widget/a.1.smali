.class public Landroid/support/v7/widget/a;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/support/v4/view/x;


# instance fields
.field private mCanceled:Z

.field mFinalVisibility:I

.field final synthetic n:Landroid/support/v7/widget/b;


# direct methods
.method protected constructor <init>(Landroid/support/v7/widget/b;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/widget/a;->n:Landroid/support/v7/widget/b;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 p1, 0x0

    iput-boolean p1, p0, Landroid/support/v7/widget/a;->mCanceled:Z

    return-void
.end method


# virtual methods
.method public a(Landroid/support/v4/view/w;I)Landroid/support/v7/widget/a;
    .locals 1

    iget-object v0, p0, Landroid/support/v7/widget/a;->n:Landroid/support/v7/widget/b;

    iput-object p1, v0, Landroid/support/v7/widget/b;->mVisibilityAnim:Landroid/support/v4/view/w;

    iput p2, p0, Landroid/support/v7/widget/a;->mFinalVisibility:I

    return-object p0
.end method

.method public b(Landroid/view/View;)V
    .locals 0

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroid/support/v7/widget/a;->mCanceled:Z

    return-void
.end method

.method public d(Landroid/view/View;)V
    .locals 1

    iget-boolean p1, p0, Landroid/support/v7/widget/a;->mCanceled:Z

    if-eqz p1, :cond_0

    return-void

    :cond_0
    iget-object p1, p0, Landroid/support/v7/widget/a;->n:Landroid/support/v7/widget/b;

    const/4 v0, 0x0

    iput-object v0, p1, Landroid/support/v7/widget/b;->mVisibilityAnim:Landroid/support/v4/view/w;

    iget p0, p0, Landroid/support/v7/widget/a;->mFinalVisibility:I

    invoke-static {p1, p0}, Landroid/support/v7/widget/b;->b(Landroid/support/v7/widget/b;I)V

    return-void
.end method

.method public f(Landroid/view/View;)V
    .locals 1

    iget-object p1, p0, Landroid/support/v7/widget/a;->n:Landroid/support/v7/widget/b;

    const/4 v0, 0x0

    invoke-static {p1, v0}, Landroid/support/v7/widget/b;->a(Landroid/support/v7/widget/b;I)V

    iput-boolean v0, p0, Landroid/support/v7/widget/a;->mCanceled:Z

    return-void
.end method
