.class Landroid/support/v7/widget/Fb;
.super Ljava/lang/Object;
.source ""


# instance fields
.field mBindRunningAverageNs:J

.field mCreateRunningAverageNs:J

.field mMaxScrap:I

.field final mScrapHeap:Ljava/util/ArrayList;


# direct methods
.method constructor <init>()V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroid/support/v7/widget/Fb;->mScrapHeap:Ljava/util/ArrayList;

    const/4 v0, 0x5

    iput v0, p0, Landroid/support/v7/widget/Fb;->mMaxScrap:I

    const-wide/16 v0, 0x0

    iput-wide v0, p0, Landroid/support/v7/widget/Fb;->mCreateRunningAverageNs:J

    iput-wide v0, p0, Landroid/support/v7/widget/Fb;->mBindRunningAverageNs:J

    return-void
.end method
