.class public abstract Landroid/support/v7/widget/hb;
.super Ljava/lang/Object;
.source ""


# instance fields
.field private Up:I

.field protected final mLayoutManager:Landroid/support/v7/widget/Ab;

.field final mTmpRect:Landroid/graphics/Rect;


# direct methods
.method synthetic constructor <init>(Landroid/support/v7/widget/Ab;Landroid/support/v7/widget/fb;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/high16 p2, -0x80000000

    iput p2, p0, Landroid/support/v7/widget/hb;->Up:I

    new-instance p2, Landroid/graphics/Rect;

    invoke-direct {p2}, Landroid/graphics/Rect;-><init>()V

    iput-object p2, p0, Landroid/support/v7/widget/hb;->mTmpRect:Landroid/graphics/Rect;

    iput-object p1, p0, Landroid/support/v7/widget/hb;->mLayoutManager:Landroid/support/v7/widget/Ab;

    return-void
.end method

.method public static a(Landroid/support/v7/widget/Ab;I)Landroid/support/v7/widget/hb;
    .locals 1

    if-eqz p1, :cond_1

    const/4 v0, 0x1

    if-ne p1, v0, :cond_0

    .line 1
    new-instance p1, Landroid/support/v7/widget/gb;

    invoke-direct {p1, p0}, Landroid/support/v7/widget/gb;-><init>(Landroid/support/v7/widget/Ab;)V

    return-object p1

    .line 2
    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "invalid orientation"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    .line 3
    :cond_1
    new-instance p1, Landroid/support/v7/widget/fb;

    invoke-direct {p1, p0}, Landroid/support/v7/widget/fb;-><init>(Landroid/support/v7/widget/Ab;)V

    return-object p1
.end method


# virtual methods
.method public abstract getDecoratedEnd(Landroid/view/View;)I
.end method

.method public abstract getDecoratedMeasurement(Landroid/view/View;)I
.end method

.method public abstract getDecoratedMeasurementInOther(Landroid/view/View;)I
.end method

.method public abstract getDecoratedStart(Landroid/view/View;)I
.end method

.method public abstract getEnd()I
.end method

.method public abstract getEndAfterPadding()I
.end method

.method public abstract getEndPadding()I
.end method

.method public abstract getMode()I
.end method

.method public abstract getModeInOther()I
.end method

.method public abstract getStartAfterPadding()I
.end method

.method public abstract getTotalSpace()I
.end method

.method public getTotalSpaceChange()I
    .locals 2

    iget v0, p0, Landroid/support/v7/widget/hb;->Up:I

    const/high16 v1, -0x80000000

    if-ne v1, v0, :cond_0

    const/4 p0, 0x0

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Landroid/support/v7/widget/hb;->getTotalSpace()I

    move-result v0

    iget p0, p0, Landroid/support/v7/widget/hb;->Up:I

    sub-int p0, v0, p0

    :goto_0
    return p0
.end method

.method public abstract getTransformedEndWithDecoration(Landroid/view/View;)I
.end method

.method public abstract getTransformedStartWithDecoration(Landroid/view/View;)I
.end method

.method public abstract offsetChildren(I)V
.end method

.method public onLayoutComplete()V
    .locals 1

    invoke-virtual {p0}, Landroid/support/v7/widget/hb;->getTotalSpace()I

    move-result v0

    iput v0, p0, Landroid/support/v7/widget/hb;->Up:I

    return-void
.end method
