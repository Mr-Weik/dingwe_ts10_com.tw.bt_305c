.class Landroid/support/v7/widget/e;
.super Landroid/animation/AnimatorListenerAdapter;
.source ""


# instance fields
.field final synthetic n:Landroid/support/v7/widget/ActionBarOverlayLayout;


# direct methods
.method constructor <init>(Landroid/support/v7/widget/ActionBarOverlayLayout;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/widget/e;->n:Landroid/support/v7/widget/ActionBarOverlayLayout;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public onAnimationCancel(Landroid/animation/Animator;)V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/e;->n:Landroid/support/v7/widget/ActionBarOverlayLayout;

    const/4 p1, 0x0

    iput-object p1, p0, Landroid/support/v7/widget/ActionBarOverlayLayout;->Mt:Landroid/view/ViewPropertyAnimator;

    const/4 p1, 0x0

    iput-boolean p1, p0, Landroid/support/v7/widget/ActionBarOverlayLayout;->Ct:Z

    return-void
.end method

.method public onAnimationEnd(Landroid/animation/Animator;)V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/e;->n:Landroid/support/v7/widget/ActionBarOverlayLayout;

    const/4 p1, 0x0

    iput-object p1, p0, Landroid/support/v7/widget/ActionBarOverlayLayout;->Mt:Landroid/view/ViewPropertyAnimator;

    const/4 p1, 0x0

    iput-boolean p1, p0, Landroid/support/v7/widget/ActionBarOverlayLayout;->Ct:Z

    return-void
.end method
