.class public Landroid/support/v7/widget/GridLayoutManager;
.super Landroid/support/v7/widget/LinearLayoutManager;
.source ""


# instance fields
.field Lq:Z

.field Mq:I

.field Nq:[I

.field Oq:[Landroid/view/View;

.field final Pq:Landroid/util/SparseIntArray;

.field final Qq:Landroid/util/SparseIntArray;

.field Rq:Landroid/support/v7/widget/La;

.field final mDecorInsets:Landroid/graphics/Rect;


# direct methods
.method public constructor <init>(Landroid/content/Context;I)V
    .locals 2

    const/4 v0, 0x1

    const/4 v1, 0x0

    .line 1
    invoke-direct {p0, p1, v0, v1}, Landroid/support/v7/widget/LinearLayoutManager;-><init>(Landroid/content/Context;IZ)V

    .line 2
    iput-boolean v1, p0, Landroid/support/v7/widget/GridLayoutManager;->Lq:Z

    const/4 p1, -0x1

    iput p1, p0, Landroid/support/v7/widget/GridLayoutManager;->Mq:I

    new-instance p1, Landroid/util/SparseIntArray;

    invoke-direct {p1}, Landroid/util/SparseIntArray;-><init>()V

    iput-object p1, p0, Landroid/support/v7/widget/GridLayoutManager;->Pq:Landroid/util/SparseIntArray;

    new-instance p1, Landroid/util/SparseIntArray;

    invoke-direct {p1}, Landroid/util/SparseIntArray;-><init>()V

    iput-object p1, p0, Landroid/support/v7/widget/GridLayoutManager;->Qq:Landroid/util/SparseIntArray;

    new-instance p1, Landroid/support/v7/widget/La;

    invoke-direct {p1}, Landroid/support/v7/widget/La;-><init>()V

    iput-object p1, p0, Landroid/support/v7/widget/GridLayoutManager;->Rq:Landroid/support/v7/widget/La;

    new-instance p1, Landroid/graphics/Rect;

    invoke-direct {p1}, Landroid/graphics/Rect;-><init>()V

    iput-object p1, p0, Landroid/support/v7/widget/GridLayoutManager;->mDecorInsets:Landroid/graphics/Rect;

    invoke-virtual {p0, p2}, Landroid/support/v7/widget/GridLayoutManager;->Z(I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;IIZ)V
    .locals 0

    invoke-direct {p0, p1, p3, p4}, Landroid/support/v7/widget/LinearLayoutManager;-><init>(Landroid/content/Context;IZ)V

    const/4 p1, 0x0

    iput-boolean p1, p0, Landroid/support/v7/widget/GridLayoutManager;->Lq:Z

    const/4 p1, -0x1

    iput p1, p0, Landroid/support/v7/widget/GridLayoutManager;->Mq:I

    new-instance p1, Landroid/util/SparseIntArray;

    invoke-direct {p1}, Landroid/util/SparseIntArray;-><init>()V

    iput-object p1, p0, Landroid/support/v7/widget/GridLayoutManager;->Pq:Landroid/util/SparseIntArray;

    new-instance p1, Landroid/util/SparseIntArray;

    invoke-direct {p1}, Landroid/util/SparseIntArray;-><init>()V

    iput-object p1, p0, Landroid/support/v7/widget/GridLayoutManager;->Qq:Landroid/util/SparseIntArray;

    new-instance p1, Landroid/support/v7/widget/La;

    invoke-direct {p1}, Landroid/support/v7/widget/La;-><init>()V

    iput-object p1, p0, Landroid/support/v7/widget/GridLayoutManager;->Rq:Landroid/support/v7/widget/La;

    new-instance p1, Landroid/graphics/Rect;

    invoke-direct {p1}, Landroid/graphics/Rect;-><init>()V

    iput-object p1, p0, Landroid/support/v7/widget/GridLayoutManager;->mDecorInsets:Landroid/graphics/Rect;

    invoke-virtual {p0, p2}, Landroid/support/v7/widget/GridLayoutManager;->Z(I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V
    .locals 1

    invoke-direct {p0, p1, p2, p3, p4}, Landroid/support/v7/widget/LinearLayoutManager;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/support/v7/widget/GridLayoutManager;->Lq:Z

    const/4 v0, -0x1

    iput v0, p0, Landroid/support/v7/widget/GridLayoutManager;->Mq:I

    new-instance v0, Landroid/util/SparseIntArray;

    invoke-direct {v0}, Landroid/util/SparseIntArray;-><init>()V

    iput-object v0, p0, Landroid/support/v7/widget/GridLayoutManager;->Pq:Landroid/util/SparseIntArray;

    new-instance v0, Landroid/util/SparseIntArray;

    invoke-direct {v0}, Landroid/util/SparseIntArray;-><init>()V

    iput-object v0, p0, Landroid/support/v7/widget/GridLayoutManager;->Qq:Landroid/util/SparseIntArray;

    new-instance v0, Landroid/support/v7/widget/La;

    invoke-direct {v0}, Landroid/support/v7/widget/La;-><init>()V

    iput-object v0, p0, Landroid/support/v7/widget/GridLayoutManager;->Rq:Landroid/support/v7/widget/La;

    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    iput-object v0, p0, Landroid/support/v7/widget/GridLayoutManager;->mDecorInsets:Landroid/graphics/Rect;

    invoke-static {p1, p2, p3, p4}, Landroid/support/v7/widget/Ab;->getProperties(Landroid/content/Context;Landroid/util/AttributeSet;II)Landroid/support/v7/widget/zb;

    move-result-object p1

    iget p1, p1, Landroid/support/v7/widget/zb;->spanCount:I

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/GridLayoutManager;->Z(I)V

    return-void
.end method

.method private Qa(I)V
    .locals 7

    iget-object v0, p0, Landroid/support/v7/widget/GridLayoutManager;->Nq:[I

    iget v1, p0, Landroid/support/v7/widget/GridLayoutManager;->Mq:I

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    .line 1
    array-length v3, v0

    add-int/lit8 v4, v1, 0x1

    if-ne v3, v4, :cond_0

    array-length v3, v0

    sub-int/2addr v3, v2

    aget v3, v0, v3

    if-eq v3, p1, :cond_1

    :cond_0
    add-int/lit8 v0, v1, 0x1

    new-array v0, v0, [I

    :cond_1
    const/4 v3, 0x0

    aput v3, v0, v3

    div-int v4, p1, v1

    rem-int/2addr p1, v1

    move v5, v3

    :goto_0
    if-gt v2, v1, :cond_3

    add-int/2addr v3, p1

    if-lez v3, :cond_2

    sub-int v6, v1, v3

    if-ge v6, p1, :cond_2

    add-int/lit8 v6, v4, 0x1

    sub-int/2addr v3, v1

    goto :goto_1

    :cond_2
    move v6, v4

    :goto_1
    add-int/2addr v5, v6

    aput v5, v0, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 2
    :cond_3
    iput-object v0, p0, Landroid/support/v7/widget/GridLayoutManager;->Nq:[I

    return-void
.end method

.method private a(Landroid/support/v7/widget/Hb;Landroid/support/v7/widget/Mb;I)I
    .locals 0

    .line 1
    iget-boolean p2, p2, Landroid/support/v7/widget/Mb;->mInPreLayout:Z

    if-nez p2, :cond_0

    .line 2
    iget-object p1, p0, Landroid/support/v7/widget/GridLayoutManager;->Rq:Landroid/support/v7/widget/La;

    iget p0, p0, Landroid/support/v7/widget/GridLayoutManager;->Mq:I

    invoke-virtual {p1, p3, p0}, Landroid/support/v7/widget/La;->h(II)I

    move-result p0

    return p0

    :cond_0
    invoke-virtual {p1, p3}, Landroid/support/v7/widget/Hb;->convertPreLayoutPositionToPostLayout(I)I

    move-result p1

    const/4 p2, -0x1

    if-ne p1, p2, :cond_1

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const-string p1, "Cannot find span size for pre layout position. "

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string p1, "GridLayoutManager"

    invoke-static {p1, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p0, 0x0

    return p0

    :cond_1
    iget-object p2, p0, Landroid/support/v7/widget/GridLayoutManager;->Rq:Landroid/support/v7/widget/La;

    iget p0, p0, Landroid/support/v7/widget/GridLayoutManager;->Mq:I

    invoke-virtual {p2, p1, p0}, Landroid/support/v7/widget/La;->h(II)I

    move-result p0

    return p0
.end method

.method private a(Landroid/view/View;IIZ)V
    .locals 1

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroid/support/v7/widget/Bb;

    if-eqz p4, :cond_0

    invoke-virtual {p0, p1, p2, p3, v0}, Landroid/support/v7/widget/Ab;->b(Landroid/view/View;IILandroid/support/v7/widget/Bb;)Z

    move-result p0

    goto :goto_0

    :cond_0
    invoke-virtual {p0, p1, p2, p3, v0}, Landroid/support/v7/widget/Ab;->a(Landroid/view/View;IILandroid/support/v7/widget/Bb;)Z

    move-result p0

    :goto_0
    if-eqz p0, :cond_1

    invoke-virtual {p1, p2, p3}, Landroid/view/View;->measure(II)V

    :cond_1
    return-void
.end method

.method private b(Landroid/support/v7/widget/Hb;Landroid/support/v7/widget/Mb;I)I
    .locals 1

    .line 1
    iget-boolean p2, p2, Landroid/support/v7/widget/Mb;->mInPreLayout:Z

    if-nez p2, :cond_0

    .line 2
    iget-object p1, p0, Landroid/support/v7/widget/GridLayoutManager;->Rq:Landroid/support/v7/widget/La;

    iget p0, p0, Landroid/support/v7/widget/GridLayoutManager;->Mq:I

    invoke-virtual {p1, p3, p0}, Landroid/support/v7/widget/La;->g(II)I

    move-result p0

    return p0

    :cond_0
    iget-object p2, p0, Landroid/support/v7/widget/GridLayoutManager;->Qq:Landroid/util/SparseIntArray;

    const/4 v0, -0x1

    invoke-virtual {p2, p3, v0}, Landroid/util/SparseIntArray;->get(II)I

    move-result p2

    if-eq p2, v0, :cond_1

    return p2

    :cond_1
    invoke-virtual {p1, p3}, Landroid/support/v7/widget/Hb;->convertPreLayoutPositionToPostLayout(I)I

    move-result p1

    if-ne p1, v0, :cond_2

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const-string p1, "Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:"

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string p1, "GridLayoutManager"

    invoke-static {p1, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p0, 0x0

    return p0

    :cond_2
    iget-object p2, p0, Landroid/support/v7/widget/GridLayoutManager;->Rq:Landroid/support/v7/widget/La;

    iget p0, p0, Landroid/support/v7/widget/GridLayoutManager;->Mq:I

    invoke-virtual {p2, p1, p0}, Landroid/support/v7/widget/La;->g(II)I

    move-result p0

    return p0
.end method

.method private b(Landroid/view/View;IZ)V
    .locals 8

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroid/support/v7/widget/Ma;

    iget-object v1, v0, Landroid/support/v7/widget/Bb;->mDecorInsets:Landroid/graphics/Rect;

    iget v2, v1, Landroid/graphics/Rect;->top:I

    iget v3, v1, Landroid/graphics/Rect;->bottom:I

    add-int/2addr v2, v3

    iget v3, v0, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    add-int/2addr v2, v3

    iget v3, v0, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    add-int/2addr v2, v3

    iget v3, v1, Landroid/graphics/Rect;->left:I

    iget v1, v1, Landroid/graphics/Rect;->right:I

    add-int/2addr v3, v1

    iget v1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    add-int/2addr v3, v1

    iget v1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    add-int/2addr v3, v1

    iget v1, v0, Landroid/support/v7/widget/Ma;->Yw:I

    iget v4, v0, Landroid/support/v7/widget/Ma;->Zw:I

    invoke-virtual {p0, v1, v4}, Landroid/support/v7/widget/GridLayoutManager;->l(II)I

    move-result v1

    iget v4, p0, Landroid/support/v7/widget/LinearLayoutManager;->mOrientation:I

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-ne v4, v6, :cond_0

    iget v4, v0, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    invoke-static {v1, p2, v3, v4, v5}, Landroid/support/v7/widget/Ab;->getChildMeasureSpec(IIIIZ)I

    move-result p2

    iget-object v1, p0, Landroid/support/v7/widget/LinearLayoutManager;->mOrientationHelper:Landroid/support/v7/widget/hb;

    invoke-virtual {v1}, Landroid/support/v7/widget/hb;->getTotalSpace()I

    move-result v1

    invoke-virtual {p0}, Landroid/support/v7/widget/Ab;->getHeightMode()I

    move-result v3

    iget v0, v0, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    invoke-static {v1, v3, v2, v0, v6}, Landroid/support/v7/widget/Ab;->getChildMeasureSpec(IIIIZ)I

    move-result v0

    goto :goto_0

    :cond_0
    iget v4, v0, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    invoke-static {v1, p2, v2, v4, v5}, Landroid/support/v7/widget/Ab;->getChildMeasureSpec(IIIIZ)I

    move-result p2

    iget-object v1, p0, Landroid/support/v7/widget/LinearLayoutManager;->mOrientationHelper:Landroid/support/v7/widget/hb;

    invoke-virtual {v1}, Landroid/support/v7/widget/hb;->getTotalSpace()I

    move-result v1

    invoke-virtual {p0}, Landroid/support/v7/widget/Ab;->getWidthMode()I

    move-result v2

    iget v0, v0, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    invoke-static {v1, v2, v3, v0, v6}, Landroid/support/v7/widget/Ab;->getChildMeasureSpec(IIIIZ)I

    move-result v0

    move v7, v0

    move v0, p2

    move p2, v7

    :goto_0
    invoke-direct {p0, p1, p2, v0, p3}, Landroid/support/v7/widget/GridLayoutManager;->a(Landroid/view/View;IIZ)V

    return-void
.end method

.method private c(Landroid/support/v7/widget/Hb;Landroid/support/v7/widget/Mb;I)I
    .locals 2

    .line 1
    iget-boolean p2, p2, Landroid/support/v7/widget/Mb;->mInPreLayout:Z

    const/4 v0, 0x1

    if-nez p2, :cond_0

    .line 2
    iget-object p0, p0, Landroid/support/v7/widget/GridLayoutManager;->Rq:Landroid/support/v7/widget/La;

    invoke-virtual {p0, p3}, Landroid/support/v7/widget/La;->Y(I)I

    return v0

    :cond_0
    iget-object p2, p0, Landroid/support/v7/widget/GridLayoutManager;->Pq:Landroid/util/SparseIntArray;

    const/4 v1, -0x1

    invoke-virtual {p2, p3, v1}, Landroid/util/SparseIntArray;->get(II)I

    move-result p2

    if-eq p2, v1, :cond_1

    return p2

    :cond_1
    invoke-virtual {p1, p3}, Landroid/support/v7/widget/Hb;->convertPreLayoutPositionToPostLayout(I)I

    move-result p1

    if-ne p1, v1, :cond_2

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const-string p1, "Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:"

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string p1, "GridLayoutManager"

    invoke-static {p1, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    return v0

    :cond_2
    iget-object p0, p0, Landroid/support/v7/widget/GridLayoutManager;->Rq:Landroid/support/v7/widget/La;

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/La;->Y(I)I

    return v0
.end method

.method private ng()V
    .locals 2

    iget-object v0, p0, Landroid/support/v7/widget/GridLayoutManager;->Oq:[Landroid/view/View;

    if-eqz v0, :cond_0

    array-length v0, v0

    iget v1, p0, Landroid/support/v7/widget/GridLayoutManager;->Mq:I

    if-eq v0, v1, :cond_1

    :cond_0
    iget v0, p0, Landroid/support/v7/widget/GridLayoutManager;->Mq:I

    new-array v0, v0, [Landroid/view/View;

    iput-object v0, p0, Landroid/support/v7/widget/GridLayoutManager;->Oq:[Landroid/view/View;

    :cond_1
    return-void
.end method

.method private og()V
    .locals 2

    invoke-virtual {p0}, Landroid/support/v7/widget/LinearLayoutManager;->getOrientation()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    invoke-virtual {p0}, Landroid/support/v7/widget/Ab;->getWidth()I

    move-result v0

    invoke-virtual {p0}, Landroid/support/v7/widget/Ab;->getPaddingRight()I

    move-result v1

    sub-int/2addr v0, v1

    invoke-virtual {p0}, Landroid/support/v7/widget/Ab;->getPaddingLeft()I

    move-result v1

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Landroid/support/v7/widget/Ab;->getHeight()I

    move-result v0

    invoke-virtual {p0}, Landroid/support/v7/widget/Ab;->getPaddingBottom()I

    move-result v1

    sub-int/2addr v0, v1

    invoke-virtual {p0}, Landroid/support/v7/widget/Ab;->getPaddingTop()I

    move-result v1

    :goto_0
    sub-int/2addr v0, v1

    invoke-direct {p0, v0}, Landroid/support/v7/widget/GridLayoutManager;->Qa(I)V

    return-void
.end method


# virtual methods
.method public Z(I)V
    .locals 2

    iget v0, p0, Landroid/support/v7/widget/GridLayoutManager;->Mq:I

    if-ne p1, v0, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v7/widget/GridLayoutManager;->Lq:Z

    if-lt p1, v0, :cond_1

    iput p1, p0, Landroid/support/v7/widget/GridLayoutManager;->Mq:I

    iget-object p1, p0, Landroid/support/v7/widget/GridLayoutManager;->Rq:Landroid/support/v7/widget/La;

    .line 1
    iget-object p1, p1, Landroid/support/v7/widget/La;->kp:Landroid/util/SparseIntArray;

    invoke-virtual {p1}, Landroid/util/SparseIntArray;->clear()V

    .line 2
    invoke-virtual {p0}, Landroid/support/v7/widget/Ab;->requestLayout()V

    return-void

    :cond_1
    new-instance p0, Ljava/lang/IllegalArgumentException;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Span count should be at least 1. Provided "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public a(ILandroid/support/v7/widget/Hb;Landroid/support/v7/widget/Mb;)I
    .locals 2

    invoke-direct {p0}, Landroid/support/v7/widget/GridLayoutManager;->og()V

    invoke-direct {p0}, Landroid/support/v7/widget/GridLayoutManager;->ng()V

    .line 18
    iget v0, p0, Landroid/support/v7/widget/LinearLayoutManager;->mOrientation:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    const/4 p0, 0x0

    goto :goto_0

    :cond_0
    invoke-virtual {p0, p1, p2, p3}, Landroid/support/v7/widget/LinearLayoutManager;->c(ILandroid/support/v7/widget/Hb;Landroid/support/v7/widget/Mb;)I

    move-result p0

    :goto_0
    return p0
.end method

.method public a(Landroid/support/v7/widget/Hb;Landroid/support/v7/widget/Mb;)I
    .locals 2

    iget v0, p0, Landroid/support/v7/widget/LinearLayoutManager;->mOrientation:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    iget p0, p0, Landroid/support/v7/widget/GridLayoutManager;->Mq:I

    return p0

    :cond_0
    invoke-virtual {p2}, Landroid/support/v7/widget/Mb;->getItemCount()I

    move-result v0

    if-ge v0, v1, :cond_1

    const/4 p0, 0x0

    return p0

    :cond_1
    invoke-virtual {p2}, Landroid/support/v7/widget/Mb;->getItemCount()I

    move-result v0

    sub-int/2addr v0, v1

    invoke-direct {p0, p1, p2, v0}, Landroid/support/v7/widget/GridLayoutManager;->a(Landroid/support/v7/widget/Hb;Landroid/support/v7/widget/Mb;I)I

    move-result p0

    add-int/2addr p0, v1

    return p0
.end method

.method a(Landroid/support/v7/widget/Hb;Landroid/support/v7/widget/Mb;III)Landroid/view/View;
    .locals 7

    invoke-virtual {p0}, Landroid/support/v7/widget/LinearLayoutManager;->ensureLayoutState()V

    iget-object v0, p0, Landroid/support/v7/widget/LinearLayoutManager;->mOrientationHelper:Landroid/support/v7/widget/hb;

    invoke-virtual {v0}, Landroid/support/v7/widget/hb;->getStartAfterPadding()I

    move-result v0

    iget-object v1, p0, Landroid/support/v7/widget/LinearLayoutManager;->mOrientationHelper:Landroid/support/v7/widget/hb;

    invoke-virtual {v1}, Landroid/support/v7/widget/hb;->getEndAfterPadding()I

    move-result v1

    if-le p4, p3, :cond_0

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, -0x1

    :goto_0
    const/4 v3, 0x0

    move-object v4, v3

    :goto_1
    if-eq p3, p4, :cond_6

    invoke-virtual {p0, p3}, Landroid/support/v7/widget/Ab;->getChildAt(I)Landroid/view/View;

    move-result-object v5

    invoke-virtual {p0, v5}, Landroid/support/v7/widget/Ab;->getPosition(Landroid/view/View;)I

    move-result v6

    if-ltz v6, :cond_5

    if-ge v6, p5, :cond_5

    invoke-direct {p0, p1, p2, v6}, Landroid/support/v7/widget/GridLayoutManager;->b(Landroid/support/v7/widget/Hb;Landroid/support/v7/widget/Mb;I)I

    move-result v6

    if-eqz v6, :cond_1

    goto :goto_3

    :cond_1
    invoke-virtual {v5}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v6

    check-cast v6, Landroid/support/v7/widget/Bb;

    invoke-virtual {v6}, Landroid/support/v7/widget/Bb;->isItemRemoved()Z

    move-result v6

    if-eqz v6, :cond_2

    if-nez v4, :cond_5

    move-object v4, v5

    goto :goto_3

    :cond_2
    iget-object v6, p0, Landroid/support/v7/widget/LinearLayoutManager;->mOrientationHelper:Landroid/support/v7/widget/hb;

    invoke-virtual {v6, v5}, Landroid/support/v7/widget/hb;->getDecoratedStart(Landroid/view/View;)I

    move-result v6

    if-ge v6, v1, :cond_4

    iget-object v6, p0, Landroid/support/v7/widget/LinearLayoutManager;->mOrientationHelper:Landroid/support/v7/widget/hb;

    invoke-virtual {v6, v5}, Landroid/support/v7/widget/hb;->getDecoratedEnd(Landroid/view/View;)I

    move-result v6

    if-ge v6, v0, :cond_3

    goto :goto_2

    :cond_3
    return-object v5

    :cond_4
    :goto_2
    if-nez v3, :cond_5

    move-object v3, v5

    :cond_5
    :goto_3
    add-int/2addr p3, v2

    goto :goto_1

    :cond_6
    if-eqz v3, :cond_7

    goto :goto_4

    :cond_7
    move-object v3, v4

    :goto_4
    return-object v3
.end method

.method public a(Landroid/view/View;ILandroid/support/v7/widget/Hb;Landroid/support/v7/widget/Mb;)Landroid/view/View;
    .locals 23

    move-object/from16 v0, p0

    move-object/from16 v1, p3

    move-object/from16 v2, p4

    invoke-virtual/range {p0 .. p1}, Landroid/support/v7/widget/Ab;->findContainingItemView(Landroid/view/View;)Landroid/view/View;

    move-result-object v3

    const/4 v4, 0x0

    if-nez v3, :cond_0

    return-object v4

    :cond_0
    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v5

    check-cast v5, Landroid/support/v7/widget/Ma;

    iget v6, v5, Landroid/support/v7/widget/Ma;->Yw:I

    iget v5, v5, Landroid/support/v7/widget/Ma;->Zw:I

    add-int/2addr v5, v6

    invoke-super/range {p0 .. p4}, Landroid/support/v7/widget/LinearLayoutManager;->a(Landroid/view/View;ILandroid/support/v7/widget/Hb;Landroid/support/v7/widget/Mb;)Landroid/view/View;

    move-result-object v7

    if-nez v7, :cond_1

    return-object v4

    :cond_1
    move/from16 v7, p2

    invoke-virtual {v0, v7}, Landroid/support/v7/widget/LinearLayoutManager;->convertFocusDirectionToLayoutDirection(I)I

    move-result v7

    const/4 v9, 0x1

    if-ne v7, v9, :cond_2

    move v7, v9

    goto :goto_0

    :cond_2
    const/4 v7, 0x0

    :goto_0
    iget-boolean v10, v0, Landroid/support/v7/widget/LinearLayoutManager;->mShouldReverseLayout:Z

    if-eq v7, v10, :cond_3

    move v7, v9

    goto :goto_1

    :cond_3
    const/4 v7, 0x0

    :goto_1
    const/4 v10, -0x1

    if-eqz v7, :cond_4

    invoke-virtual/range {p0 .. p0}, Landroid/support/v7/widget/Ab;->getChildCount()I

    move-result v7

    sub-int/2addr v7, v9

    move v11, v10

    move v12, v11

    goto :goto_2

    :cond_4
    invoke-virtual/range {p0 .. p0}, Landroid/support/v7/widget/Ab;->getChildCount()I

    move-result v7

    move v11, v7

    move v12, v9

    const/4 v7, 0x0

    :goto_2
    iget v13, v0, Landroid/support/v7/widget/LinearLayoutManager;->mOrientation:I

    if-ne v13, v9, :cond_5

    invoke-virtual/range {p0 .. p0}, Landroid/support/v7/widget/LinearLayoutManager;->isLayoutRTL()Z

    move-result v13

    if-eqz v13, :cond_5

    move v13, v9

    goto :goto_3

    :cond_5
    const/4 v13, 0x0

    :goto_3
    invoke-direct {v0, v1, v2, v7}, Landroid/support/v7/widget/GridLayoutManager;->a(Landroid/support/v7/widget/Hb;Landroid/support/v7/widget/Mb;I)I

    move-result v14

    move v8, v10

    move/from16 v17, v8

    const/4 v15, 0x0

    const/16 v16, 0x0

    move-object v10, v4

    :goto_4
    if-eq v7, v11, :cond_17

    invoke-direct {v0, v1, v2, v7}, Landroid/support/v7/widget/GridLayoutManager;->a(Landroid/support/v7/widget/Hb;Landroid/support/v7/widget/Mb;I)I

    move-result v9

    invoke-virtual {v0, v7}, Landroid/support/v7/widget/Ab;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    if-ne v1, v3, :cond_6

    goto/16 :goto_d

    :cond_6
    invoke-virtual {v1}, Landroid/view/View;->hasFocusable()Z

    move-result v18

    if-eqz v18, :cond_8

    if-eq v9, v14, :cond_8

    if-eqz v4, :cond_7

    goto/16 :goto_d

    :cond_7
    move-object/from16 v18, v3

    move/from16 v19, v8

    move-object/from16 v21, v10

    move/from16 v20, v11

    move/from16 v8, v16

    move/from16 v10, v17

    goto/16 :goto_b

    :cond_8
    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v9

    check-cast v9, Landroid/support/v7/widget/Ma;

    iget v2, v9, Landroid/support/v7/widget/Ma;->Yw:I

    move-object/from16 v18, v3

    iget v3, v9, Landroid/support/v7/widget/Ma;->Zw:I

    add-int/2addr v3, v2

    invoke-virtual {v1}, Landroid/view/View;->hasFocusable()Z

    move-result v19

    if-eqz v19, :cond_9

    if-ne v2, v6, :cond_9

    if-ne v3, v5, :cond_9

    return-object v1

    :cond_9
    invoke-virtual {v1}, Landroid/view/View;->hasFocusable()Z

    move-result v19

    if-eqz v19, :cond_a

    if-eqz v4, :cond_b

    :cond_a
    invoke-virtual {v1}, Landroid/view/View;->hasFocusable()Z

    move-result v19

    if-nez v19, :cond_c

    if-nez v10, :cond_c

    :cond_b
    move/from16 v19, v8

    move-object/from16 v21, v10

    :goto_5
    move/from16 v20, v11

    move/from16 v8, v16

    move/from16 v10, v17

    :goto_6
    const/4 v11, 0x1

    goto :goto_a

    :cond_c
    invoke-static {v2, v6}, Ljava/lang/Math;->max(II)I

    move-result v19

    invoke-static {v3, v5}, Ljava/lang/Math;->min(II)I

    move-result v20

    move-object/from16 v21, v10

    sub-int v10, v20, v19

    invoke-virtual {v1}, Landroid/view/View;->hasFocusable()Z

    move-result v19

    if-eqz v19, :cond_f

    if-le v10, v15, :cond_d

    :goto_7
    move/from16 v19, v8

    goto :goto_5

    :cond_d
    if-ne v10, v15, :cond_12

    if-le v2, v8, :cond_e

    const/4 v10, 0x1

    goto :goto_8

    :cond_e
    const/4 v10, 0x0

    :goto_8
    if-ne v13, v10, :cond_12

    goto :goto_7

    :cond_f
    if-nez v4, :cond_12

    move/from16 v19, v8

    move/from16 v20, v11

    const/4 v8, 0x0

    const/4 v11, 0x1

    invoke-virtual {v0, v1, v8, v11}, Landroid/support/v7/widget/Ab;->a(Landroid/view/View;ZZ)Z

    move-result v22

    move/from16 v8, v16

    if-eqz v22, :cond_13

    if-le v10, v8, :cond_10

    move/from16 v10, v17

    goto :goto_a

    :cond_10
    if-ne v10, v8, :cond_13

    move/from16 v10, v17

    if-le v2, v10, :cond_11

    goto :goto_9

    :cond_11
    const/4 v11, 0x0

    :goto_9
    if-ne v13, v11, :cond_14

    goto :goto_6

    :cond_12
    move/from16 v19, v8

    move/from16 v20, v11

    move/from16 v8, v16

    :cond_13
    move/from16 v10, v17

    :cond_14
    const/4 v11, 0x0

    :goto_a
    if-eqz v11, :cond_16

    invoke-virtual {v1}, Landroid/view/View;->hasFocusable()Z

    move-result v11

    if-eqz v11, :cond_15

    iget v4, v9, Landroid/support/v7/widget/Ma;->Yw:I

    invoke-static {v3, v5}, Ljava/lang/Math;->min(II)I

    move-result v3

    invoke-static {v2, v6}, Ljava/lang/Math;->max(II)I

    move-result v2

    sub-int/2addr v3, v2

    move v15, v3

    move/from16 v16, v8

    move/from16 v17, v10

    move-object/from16 v10, v21

    move v8, v4

    move-object v4, v1

    goto :goto_c

    :cond_15
    iget v8, v9, Landroid/support/v7/widget/Ma;->Yw:I

    invoke-static {v3, v5}, Ljava/lang/Math;->min(II)I

    move-result v3

    invoke-static {v2, v6}, Ljava/lang/Math;->max(II)I

    move-result v2

    sub-int/2addr v3, v2

    move-object v10, v1

    move/from16 v16, v3

    move/from16 v17, v8

    move/from16 v8, v19

    goto :goto_c

    :cond_16
    :goto_b
    move/from16 v16, v8

    move/from16 v17, v10

    move/from16 v8, v19

    move-object/from16 v10, v21

    :goto_c
    add-int/2addr v7, v12

    move-object/from16 v1, p3

    move-object/from16 v2, p4

    move-object/from16 v3, v18

    move/from16 v11, v20

    const/4 v9, 0x1

    goto/16 :goto_4

    :cond_17
    :goto_d
    move-object/from16 v21, v10

    if-eqz v4, :cond_18

    goto :goto_e

    :cond_18
    move-object/from16 v4, v21

    :goto_e
    return-object v4
.end method

.method a(Landroid/support/v7/widget/Hb;Landroid/support/v7/widget/Mb;Landroid/support/v7/widget/Qa;I)V
    .locals 4

    invoke-direct {p0}, Landroid/support/v7/widget/GridLayoutManager;->og()V

    invoke-virtual {p2}, Landroid/support/v7/widget/Mb;->getItemCount()I

    move-result v0

    if-lez v0, :cond_3

    .line 7
    iget-boolean v0, p2, Landroid/support/v7/widget/Mb;->mInPreLayout:Z

    if-nez v0, :cond_3

    const/4 v0, 0x1

    if-ne p4, v0, :cond_0

    move p4, v0

    goto :goto_0

    :cond_0
    const/4 p4, 0x0

    .line 8
    :goto_0
    iget v1, p3, Landroid/support/v7/widget/Qa;->mPosition:I

    invoke-direct {p0, p1, p2, v1}, Landroid/support/v7/widget/GridLayoutManager;->b(Landroid/support/v7/widget/Hb;Landroid/support/v7/widget/Mb;I)I

    move-result v1

    if-eqz p4, :cond_1

    :goto_1
    if-lez v1, :cond_3

    iget p4, p3, Landroid/support/v7/widget/Qa;->mPosition:I

    if-lez p4, :cond_3

    add-int/lit8 p4, p4, -0x1

    iput p4, p3, Landroid/support/v7/widget/Qa;->mPosition:I

    iget p4, p3, Landroid/support/v7/widget/Qa;->mPosition:I

    invoke-direct {p0, p1, p2, p4}, Landroid/support/v7/widget/GridLayoutManager;->b(Landroid/support/v7/widget/Hb;Landroid/support/v7/widget/Mb;I)I

    move-result v1

    goto :goto_1

    :cond_1
    invoke-virtual {p2}, Landroid/support/v7/widget/Mb;->getItemCount()I

    move-result p4

    sub-int/2addr p4, v0

    iget v0, p3, Landroid/support/v7/widget/Qa;->mPosition:I

    :goto_2
    if-ge v0, p4, :cond_2

    add-int/lit8 v2, v0, 0x1

    invoke-direct {p0, p1, p2, v2}, Landroid/support/v7/widget/GridLayoutManager;->b(Landroid/support/v7/widget/Hb;Landroid/support/v7/widget/Mb;I)I

    move-result v3

    if-le v3, v1, :cond_2

    move v0, v2

    move v1, v3

    goto :goto_2

    :cond_2
    iput v0, p3, Landroid/support/v7/widget/Qa;->mPosition:I

    .line 9
    :cond_3
    invoke-direct {p0}, Landroid/support/v7/widget/GridLayoutManager;->ng()V

    return-void
.end method

.method a(Landroid/support/v7/widget/Hb;Landroid/support/v7/widget/Mb;Landroid/support/v7/widget/Sa;Landroid/support/v7/widget/Ra;)V
    .locals 20

    move-object/from16 v6, p0

    move-object/from16 v0, p1

    move-object/from16 v1, p2

    move-object/from16 v2, p3

    move-object/from16 v7, p4

    iget-object v3, v6, Landroid/support/v7/widget/LinearLayoutManager;->mOrientationHelper:Landroid/support/v7/widget/hb;

    invoke-virtual {v3}, Landroid/support/v7/widget/hb;->getModeInOther()I

    move-result v3

    const/high16 v4, 0x40000000    # 2.0f

    const/4 v8, 0x1

    const/4 v5, 0x0

    if-eq v3, v4, :cond_0

    move v9, v8

    goto :goto_0

    :cond_0
    move v9, v5

    :goto_0
    invoke-virtual/range {p0 .. p0}, Landroid/support/v7/widget/Ab;->getChildCount()I

    move-result v10

    if-lez v10, :cond_1

    iget-object v10, v6, Landroid/support/v7/widget/GridLayoutManager;->Nq:[I

    iget v11, v6, Landroid/support/v7/widget/GridLayoutManager;->Mq:I

    aget v10, v10, v11

    goto :goto_1

    :cond_1
    move v10, v5

    :goto_1
    if-eqz v9, :cond_2

    invoke-direct/range {p0 .. p0}, Landroid/support/v7/widget/GridLayoutManager;->og()V

    :cond_2
    iget v11, v2, Landroid/support/v7/widget/Sa;->mItemDirection:I

    if-ne v11, v8, :cond_3

    move v11, v8

    goto :goto_2

    :cond_3
    move v11, v5

    :goto_2
    iget v12, v6, Landroid/support/v7/widget/GridLayoutManager;->Mq:I

    if-nez v11, :cond_4

    iget v12, v2, Landroid/support/v7/widget/Sa;->mCurrentPosition:I

    invoke-direct {v6, v0, v1, v12}, Landroid/support/v7/widget/GridLayoutManager;->b(Landroid/support/v7/widget/Hb;Landroid/support/v7/widget/Mb;I)I

    move-result v12

    iget v13, v2, Landroid/support/v7/widget/Sa;->mCurrentPosition:I

    invoke-direct {v6, v0, v1, v13}, Landroid/support/v7/widget/GridLayoutManager;->c(Landroid/support/v7/widget/Hb;Landroid/support/v7/widget/Mb;I)I

    move-result v13

    add-int/2addr v12, v13

    :cond_4
    move v13, v12

    move v12, v5

    :goto_3
    iget v14, v6, Landroid/support/v7/widget/GridLayoutManager;->Mq:I

    if-ge v12, v14, :cond_8

    invoke-virtual {v2, v1}, Landroid/support/v7/widget/Sa;->a(Landroid/support/v7/widget/Mb;)Z

    move-result v14

    if-eqz v14, :cond_8

    if-lez v13, :cond_8

    iget v14, v2, Landroid/support/v7/widget/Sa;->mCurrentPosition:I

    invoke-direct {v6, v0, v1, v14}, Landroid/support/v7/widget/GridLayoutManager;->c(Landroid/support/v7/widget/Hb;Landroid/support/v7/widget/Mb;I)I

    move-result v15

    iget v4, v6, Landroid/support/v7/widget/GridLayoutManager;->Mq:I

    if-gt v15, v4, :cond_7

    sub-int/2addr v13, v15

    if-gez v13, :cond_5

    goto :goto_4

    :cond_5
    invoke-virtual {v2, v0}, Landroid/support/v7/widget/Sa;->a(Landroid/support/v7/widget/Hb;)Landroid/view/View;

    move-result-object v4

    if-nez v4, :cond_6

    goto :goto_4

    :cond_6
    iget-object v14, v6, Landroid/support/v7/widget/GridLayoutManager;->Oq:[Landroid/view/View;

    aput-object v4, v14, v12

    add-int/lit8 v12, v12, 0x1

    const/high16 v4, 0x40000000    # 2.0f

    goto :goto_3

    :cond_7
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Item at position "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " requires "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " spans but GridLayoutManager has only "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, v6, Landroid/support/v7/widget/GridLayoutManager;->Mq:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " spans."

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_8
    :goto_4
    if-nez v12, :cond_9

    iput-boolean v8, v7, Landroid/support/v7/widget/Ra;->mFinished:Z

    return-void

    :cond_9
    if-eqz v11, :cond_a

    move v4, v5

    move v14, v4

    move/from16 v17, v8

    move v15, v12

    goto :goto_5

    :cond_a
    add-int/lit8 v14, v12, -0x1

    move v4, v5

    const/4 v15, -0x1

    const/16 v17, -0x1

    :goto_5
    if-eq v14, v15, :cond_b

    .line 3
    iget-object v13, v6, Landroid/support/v7/widget/GridLayoutManager;->Oq:[Landroid/view/View;

    aget-object v13, v13, v14

    invoke-virtual {v13}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v18

    move-object/from16 v8, v18

    check-cast v8, Landroid/support/v7/widget/Ma;

    invoke-virtual {v6, v13}, Landroid/support/v7/widget/Ab;->getPosition(Landroid/view/View;)I

    move-result v13

    invoke-direct {v6, v0, v1, v13}, Landroid/support/v7/widget/GridLayoutManager;->c(Landroid/support/v7/widget/Hb;Landroid/support/v7/widget/Mb;I)I

    move-result v13

    iput v13, v8, Landroid/support/v7/widget/Ma;->Zw:I

    iput v4, v8, Landroid/support/v7/widget/Ma;->Yw:I

    iget v8, v8, Landroid/support/v7/widget/Ma;->Zw:I

    add-int/2addr v4, v8

    add-int v14, v14, v17

    const/4 v8, 0x1

    goto :goto_5

    :cond_b
    move v0, v5

    move v1, v0

    const/16 v16, 0x0

    :goto_6
    if-ge v0, v12, :cond_11

    .line 4
    iget-object v4, v6, Landroid/support/v7/widget/GridLayoutManager;->Oq:[Landroid/view/View;

    aget-object v4, v4, v0

    iget-object v8, v2, Landroid/support/v7/widget/Sa;->mScrapList:Ljava/util/List;

    if-nez v8, :cond_d

    if-eqz v11, :cond_c

    invoke-virtual {v6, v4}, Landroid/support/v7/widget/Ab;->addView(Landroid/view/View;)V

    goto :goto_7

    :cond_c
    invoke-virtual {v6, v4, v5}, Landroid/support/v7/widget/Ab;->addView(Landroid/view/View;I)V

    goto :goto_7

    :cond_d
    if-eqz v11, :cond_e

    invoke-virtual {v6, v4}, Landroid/support/v7/widget/Ab;->addDisappearingView(Landroid/view/View;)V

    goto :goto_7

    :cond_e
    invoke-virtual {v6, v4, v5}, Landroid/support/v7/widget/Ab;->addDisappearingView(Landroid/view/View;I)V

    :goto_7
    iget-object v8, v6, Landroid/support/v7/widget/GridLayoutManager;->mDecorInsets:Landroid/graphics/Rect;

    invoke-virtual {v6, v4, v8}, Landroid/support/v7/widget/Ab;->calculateItemDecorationsForChild(Landroid/view/View;Landroid/graphics/Rect;)V

    invoke-direct {v6, v4, v3, v5}, Landroid/support/v7/widget/GridLayoutManager;->b(Landroid/view/View;IZ)V

    iget-object v8, v6, Landroid/support/v7/widget/LinearLayoutManager;->mOrientationHelper:Landroid/support/v7/widget/hb;

    invoke-virtual {v8, v4}, Landroid/support/v7/widget/hb;->getDecoratedMeasurement(Landroid/view/View;)I

    move-result v8

    if-le v8, v1, :cond_f

    move v1, v8

    :cond_f
    invoke-virtual {v4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v8

    check-cast v8, Landroid/support/v7/widget/Ma;

    const/high16 v13, 0x3f800000    # 1.0f

    iget-object v14, v6, Landroid/support/v7/widget/LinearLayoutManager;->mOrientationHelper:Landroid/support/v7/widget/hb;

    invoke-virtual {v14, v4}, Landroid/support/v7/widget/hb;->getDecoratedMeasurementInOther(Landroid/view/View;)I

    move-result v4

    int-to-float v4, v4

    mul-float/2addr v4, v13

    iget v8, v8, Landroid/support/v7/widget/Ma;->Zw:I

    int-to-float v8, v8

    div-float/2addr v4, v8

    cmpl-float v8, v4, v16

    if-lez v8, :cond_10

    move/from16 v16, v4

    :cond_10
    add-int/lit8 v0, v0, 0x1

    goto :goto_6

    :cond_11
    if-eqz v9, :cond_13

    .line 5
    iget v0, v6, Landroid/support/v7/widget/GridLayoutManager;->Mq:I

    int-to-float v0, v0

    mul-float v16, v16, v0

    invoke-static/range {v16 .. v16}, Ljava/lang/Math;->round(F)I

    move-result v0

    invoke-static {v0, v10}, Ljava/lang/Math;->max(II)I

    move-result v0

    invoke-direct {v6, v0}, Landroid/support/v7/widget/GridLayoutManager;->Qa(I)V

    move v0, v5

    move v1, v0

    :goto_8
    if-ge v0, v12, :cond_13

    .line 6
    iget-object v3, v6, Landroid/support/v7/widget/GridLayoutManager;->Oq:[Landroid/view/View;

    aget-object v3, v3, v0

    const/high16 v4, 0x40000000    # 2.0f

    const/4 v8, 0x1

    invoke-direct {v6, v3, v4, v8}, Landroid/support/v7/widget/GridLayoutManager;->b(Landroid/view/View;IZ)V

    iget-object v4, v6, Landroid/support/v7/widget/LinearLayoutManager;->mOrientationHelper:Landroid/support/v7/widget/hb;

    invoke-virtual {v4, v3}, Landroid/support/v7/widget/hb;->getDecoratedMeasurement(Landroid/view/View;)I

    move-result v3

    if-le v3, v1, :cond_12

    move v1, v3

    :cond_12
    add-int/lit8 v0, v0, 0x1

    goto :goto_8

    :cond_13
    move v0, v5

    :goto_9
    if-ge v0, v12, :cond_16

    iget-object v3, v6, Landroid/support/v7/widget/GridLayoutManager;->Oq:[Landroid/view/View;

    aget-object v3, v3, v0

    iget-object v4, v6, Landroid/support/v7/widget/LinearLayoutManager;->mOrientationHelper:Landroid/support/v7/widget/hb;

    invoke-virtual {v4, v3}, Landroid/support/v7/widget/hb;->getDecoratedMeasurement(Landroid/view/View;)I

    move-result v4

    if-eq v4, v1, :cond_15

    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v4

    check-cast v4, Landroid/support/v7/widget/Ma;

    iget-object v8, v4, Landroid/support/v7/widget/Bb;->mDecorInsets:Landroid/graphics/Rect;

    iget v9, v8, Landroid/graphics/Rect;->top:I

    iget v10, v8, Landroid/graphics/Rect;->bottom:I

    add-int/2addr v9, v10

    iget v10, v4, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    add-int/2addr v9, v10

    iget v10, v4, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    add-int/2addr v9, v10

    iget v10, v8, Landroid/graphics/Rect;->left:I

    iget v8, v8, Landroid/graphics/Rect;->right:I

    add-int/2addr v10, v8

    iget v8, v4, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    add-int/2addr v10, v8

    iget v8, v4, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    add-int/2addr v10, v8

    iget v8, v4, Landroid/support/v7/widget/Ma;->Yw:I

    iget v11, v4, Landroid/support/v7/widget/Ma;->Zw:I

    invoke-virtual {v6, v8, v11}, Landroid/support/v7/widget/GridLayoutManager;->l(II)I

    move-result v8

    iget v11, v6, Landroid/support/v7/widget/LinearLayoutManager;->mOrientation:I

    const/4 v13, 0x1

    if-ne v11, v13, :cond_14

    iget v4, v4, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    const/high16 v11, 0x40000000    # 2.0f

    invoke-static {v8, v11, v10, v4, v5}, Landroid/support/v7/widget/Ab;->getChildMeasureSpec(IIIIZ)I

    move-result v4

    sub-int v8, v1, v9

    invoke-static {v8, v11}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v8

    goto :goto_a

    :cond_14
    const/high16 v11, 0x40000000    # 2.0f

    sub-int v10, v1, v10

    invoke-static {v10, v11}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v10

    iget v4, v4, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    invoke-static {v8, v11, v9, v4, v5}, Landroid/support/v7/widget/Ab;->getChildMeasureSpec(IIIIZ)I

    move-result v8

    move v4, v10

    :goto_a
    invoke-direct {v6, v3, v4, v8, v13}, Landroid/support/v7/widget/GridLayoutManager;->a(Landroid/view/View;IIZ)V

    goto :goto_b

    :cond_15
    const/high16 v11, 0x40000000    # 2.0f

    const/4 v13, 0x1

    :goto_b
    add-int/lit8 v0, v0, 0x1

    goto :goto_9

    :cond_16
    const/4 v13, 0x1

    iput v1, v7, Landroid/support/v7/widget/Ra;->mConsumed:I

    iget v0, v6, Landroid/support/v7/widget/LinearLayoutManager;->mOrientation:I

    if-ne v0, v13, :cond_18

    iget v0, v2, Landroid/support/v7/widget/Sa;->mLayoutDirection:I

    const/4 v3, -0x1

    if-ne v0, v3, :cond_17

    iget v0, v2, Landroid/support/v7/widget/Sa;->mOffset:I

    sub-int v1, v0, v1

    move v3, v0

    move v2, v1

    goto :goto_c

    :cond_17
    iget v0, v2, Landroid/support/v7/widget/Sa;->mOffset:I

    add-int/2addr v1, v0

    move v2, v0

    move v3, v1

    :goto_c
    move v0, v5

    move v1, v0

    goto :goto_d

    :cond_18
    const/4 v3, -0x1

    iget v0, v2, Landroid/support/v7/widget/Sa;->mLayoutDirection:I

    if-ne v0, v3, :cond_19

    iget v0, v2, Landroid/support/v7/widget/Sa;->mOffset:I

    sub-int v1, v0, v1

    move v2, v5

    move v3, v2

    move/from16 v19, v1

    move v1, v0

    move/from16 v0, v19

    goto :goto_d

    :cond_19
    iget v0, v2, Landroid/support/v7/widget/Sa;->mOffset:I

    add-int/2addr v1, v0

    move v2, v5

    move v3, v2

    :goto_d
    move v8, v5

    :goto_e
    if-ge v8, v12, :cond_1e

    iget-object v4, v6, Landroid/support/v7/widget/GridLayoutManager;->Oq:[Landroid/view/View;

    aget-object v9, v4, v8

    invoke-virtual {v9}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v4

    move-object v10, v4

    check-cast v10, Landroid/support/v7/widget/Ma;

    iget v4, v6, Landroid/support/v7/widget/LinearLayoutManager;->mOrientation:I

    const/4 v5, 0x1

    if-ne v4, v5, :cond_1b

    invoke-virtual/range {p0 .. p0}, Landroid/support/v7/widget/LinearLayoutManager;->isLayoutRTL()Z

    move-result v0

    if-eqz v0, :cond_1a

    invoke-virtual/range {p0 .. p0}, Landroid/support/v7/widget/Ab;->getPaddingLeft()I

    move-result v0

    iget-object v1, v6, Landroid/support/v7/widget/GridLayoutManager;->Nq:[I

    iget v4, v6, Landroid/support/v7/widget/GridLayoutManager;->Mq:I

    iget v5, v10, Landroid/support/v7/widget/Ma;->Yw:I

    sub-int/2addr v4, v5

    aget v1, v1, v4

    add-int/2addr v0, v1

    iget-object v1, v6, Landroid/support/v7/widget/LinearLayoutManager;->mOrientationHelper:Landroid/support/v7/widget/hb;

    invoke-virtual {v1, v9}, Landroid/support/v7/widget/hb;->getDecoratedMeasurementInOther(Landroid/view/View;)I

    move-result v1

    sub-int v1, v0, v1

    move v14, v0

    move v11, v1

    goto :goto_10

    :cond_1a
    invoke-virtual/range {p0 .. p0}, Landroid/support/v7/widget/Ab;->getPaddingLeft()I

    move-result v0

    iget-object v1, v6, Landroid/support/v7/widget/GridLayoutManager;->Nq:[I

    iget v4, v10, Landroid/support/v7/widget/Ma;->Yw:I

    aget v1, v1, v4

    add-int/2addr v0, v1

    iget-object v1, v6, Landroid/support/v7/widget/LinearLayoutManager;->mOrientationHelper:Landroid/support/v7/widget/hb;

    invoke-virtual {v1, v9}, Landroid/support/v7/widget/hb;->getDecoratedMeasurementInOther(Landroid/view/View;)I

    move-result v1

    add-int/2addr v1, v0

    goto :goto_f

    :cond_1b
    invoke-virtual/range {p0 .. p0}, Landroid/support/v7/widget/Ab;->getPaddingTop()I

    move-result v2

    iget-object v3, v6, Landroid/support/v7/widget/GridLayoutManager;->Nq:[I

    iget v4, v10, Landroid/support/v7/widget/Ma;->Yw:I

    aget v3, v3, v4

    add-int/2addr v2, v3

    iget-object v3, v6, Landroid/support/v7/widget/LinearLayoutManager;->mOrientationHelper:Landroid/support/v7/widget/hb;

    invoke-virtual {v3, v9}, Landroid/support/v7/widget/hb;->getDecoratedMeasurementInOther(Landroid/view/View;)I

    move-result v3

    add-int/2addr v3, v2

    :goto_f
    move v11, v0

    move v14, v1

    :goto_10
    move v13, v2

    move v15, v3

    move-object/from16 v0, p0

    move-object v1, v9

    move v2, v11

    move v3, v13

    move v4, v14

    move v5, v15

    invoke-virtual/range {v0 .. v5}, Landroid/support/v7/widget/Ab;->layoutDecoratedWithMargins(Landroid/view/View;IIII)V

    invoke-virtual {v10}, Landroid/support/v7/widget/Bb;->isItemRemoved()Z

    move-result v0

    if-nez v0, :cond_1d

    invoke-virtual {v10}, Landroid/support/v7/widget/Bb;->isItemChanged()Z

    move-result v0

    if-eqz v0, :cond_1c

    goto :goto_11

    :cond_1c
    const/4 v0, 0x1

    goto :goto_12

    :cond_1d
    :goto_11
    const/4 v0, 0x1

    iput-boolean v0, v7, Landroid/support/v7/widget/Ra;->mIgnoreConsumed:Z

    :goto_12
    iget-boolean v1, v7, Landroid/support/v7/widget/Ra;->mFocusable:Z

    invoke-virtual {v9}, Landroid/view/View;->hasFocusable()Z

    move-result v2

    or-int/2addr v1, v2

    iput-boolean v1, v7, Landroid/support/v7/widget/Ra;->mFocusable:Z

    add-int/lit8 v8, v8, 0x1

    move v0, v11

    move v2, v13

    move v1, v14

    move v3, v15

    goto/16 :goto_e

    :cond_1e
    iget-object v0, v6, Landroid/support/v7/widget/GridLayoutManager;->Oq:[Landroid/view/View;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Ljava/util/Arrays;->fill([Ljava/lang/Object;Ljava/lang/Object;)V

    return-void
.end method

.method public a(Landroid/support/v7/widget/Hb;Landroid/support/v7/widget/Mb;Landroid/view/View;Landroid/support/v4/view/a/c;)V
    .locals 7

    invoke-virtual {p3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    instance-of v1, v0, Landroid/support/v7/widget/Ma;

    if-nez v1, :cond_0

    invoke-super {p0, p3, p4}, Landroid/support/v7/widget/Ab;->b(Landroid/view/View;Landroid/support/v4/view/a/c;)V

    return-void

    :cond_0
    check-cast v0, Landroid/support/v7/widget/Ma;

    invoke-virtual {v0}, Landroid/support/v7/widget/Bb;->getViewLayoutPosition()I

    move-result p3

    invoke-direct {p0, p1, p2, p3}, Landroid/support/v7/widget/GridLayoutManager;->a(Landroid/support/v7/widget/Hb;Landroid/support/v7/widget/Mb;I)I

    move-result p1

    iget p2, p0, Landroid/support/v7/widget/LinearLayoutManager;->mOrientation:I

    const/4 p3, 0x0

    const/4 v1, 0x1

    if-nez p2, :cond_2

    .line 10
    iget p2, v0, Landroid/support/v7/widget/Ma;->Yw:I

    .line 11
    iget v2, v0, Landroid/support/v7/widget/Ma;->Zw:I

    const/4 v4, 0x1

    .line 12
    iget p0, p0, Landroid/support/v7/widget/GridLayoutManager;->Mq:I

    if-le p0, v1, :cond_1

    if-ne v2, p0, :cond_1

    move v5, v1

    goto :goto_0

    :cond_1
    move v5, p3

    :goto_0
    const/4 v6, 0x0

    move v1, p2

    move v3, p1

    goto :goto_2

    :cond_2
    const/4 v2, 0x1

    .line 13
    iget v3, v0, Landroid/support/v7/widget/Ma;->Yw:I

    .line 14
    iget v4, v0, Landroid/support/v7/widget/Ma;->Zw:I

    .line 15
    iget p0, p0, Landroid/support/v7/widget/GridLayoutManager;->Mq:I

    if-le p0, v1, :cond_3

    if-ne v4, p0, :cond_3

    move v5, v1

    goto :goto_1

    :cond_3
    move v5, p3

    :goto_1
    const/4 v6, 0x0

    move v1, p1

    :goto_2
    invoke-static/range {v1 .. v6}, Landroid/support/v4/view/a/b;->obtain(IIIIZZ)Landroid/support/v4/view/a/b;

    move-result-object p0

    invoke-virtual {p4, p0}, Landroid/support/v4/view/a/c;->p(Ljava/lang/Object;)V

    return-void
.end method

.method a(Landroid/support/v7/widget/Mb;Landroid/support/v7/widget/Sa;Landroid/support/v7/widget/yb;)V
    .locals 6

    iget v0, p0, Landroid/support/v7/widget/GridLayoutManager;->Mq:I

    const/4 v1, 0x0

    move v2, v0

    move v0, v1

    :goto_0
    iget v3, p0, Landroid/support/v7/widget/GridLayoutManager;->Mq:I

    if-ge v0, v3, :cond_0

    invoke-virtual {p2, p1}, Landroid/support/v7/widget/Sa;->a(Landroid/support/v7/widget/Mb;)Z

    move-result v3

    if-eqz v3, :cond_0

    if-lez v2, :cond_0

    iget v3, p2, Landroid/support/v7/widget/Sa;->mCurrentPosition:I

    iget v4, p2, Landroid/support/v7/widget/Sa;->mScrollingOffset:I

    invoke-static {v1, v4}, Ljava/lang/Math;->max(II)I

    move-result v4

    move-object v5, p3

    check-cast v5, Landroid/support/v7/widget/Ia;

    invoke-virtual {v5, v3, v4}, Landroid/support/v7/widget/Ia;->addPosition(II)V

    iget-object v4, p0, Landroid/support/v7/widget/GridLayoutManager;->Rq:Landroid/support/v7/widget/La;

    invoke-virtual {v4, v3}, Landroid/support/v7/widget/La;->Y(I)I

    add-int/lit8 v2, v2, -0x1

    iget v3, p2, Landroid/support/v7/widget/Sa;->mCurrentPosition:I

    iget v4, p2, Landroid/support/v7/widget/Sa;->mItemDirection:I

    add-int/2addr v3, v4

    iput v3, p2, Landroid/support/v7/widget/Sa;->mCurrentPosition:I

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method public a(Landroid/support/v7/widget/RecyclerView;III)V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/GridLayoutManager;->Rq:Landroid/support/v7/widget/La;

    .line 16
    iget-object p0, p0, Landroid/support/v7/widget/La;->kp:Landroid/util/SparseIntArray;

    invoke-virtual {p0}, Landroid/util/SparseIntArray;->clear()V

    return-void
.end method

.method public a(Landroid/support/v7/widget/RecyclerView;IILjava/lang/Object;)V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/GridLayoutManager;->Rq:Landroid/support/v7/widget/La;

    .line 17
    iget-object p0, p0, Landroid/support/v7/widget/La;->kp:Landroid/util/SparseIntArray;

    invoke-virtual {p0}, Landroid/util/SparseIntArray;->clear()V

    return-void
.end method

.method public a(Landroid/support/v7/widget/Bb;)Z
    .locals 0

    instance-of p0, p1, Landroid/support/v7/widget/Ma;

    return p0
.end method

.method public b(ILandroid/support/v7/widget/Hb;Landroid/support/v7/widget/Mb;)I
    .locals 1

    invoke-direct {p0}, Landroid/support/v7/widget/GridLayoutManager;->og()V

    invoke-direct {p0}, Landroid/support/v7/widget/GridLayoutManager;->ng()V

    .line 4
    iget v0, p0, Landroid/support/v7/widget/LinearLayoutManager;->mOrientation:I

    if-nez v0, :cond_0

    const/4 p0, 0x0

    goto :goto_0

    :cond_0
    invoke-virtual {p0, p1, p2, p3}, Landroid/support/v7/widget/LinearLayoutManager;->c(ILandroid/support/v7/widget/Hb;Landroid/support/v7/widget/Mb;)I

    move-result p0

    :goto_0
    return p0
.end method

.method public b(Landroid/support/v7/widget/Hb;Landroid/support/v7/widget/Mb;)I
    .locals 2

    iget v0, p0, Landroid/support/v7/widget/LinearLayoutManager;->mOrientation:I

    if-nez v0, :cond_0

    iget p0, p0, Landroid/support/v7/widget/GridLayoutManager;->Mq:I

    return p0

    :cond_0
    invoke-virtual {p2}, Landroid/support/v7/widget/Mb;->getItemCount()I

    move-result v0

    const/4 v1, 0x1

    if-ge v0, v1, :cond_1

    const/4 p0, 0x0

    return p0

    :cond_1
    invoke-virtual {p2}, Landroid/support/v7/widget/Mb;->getItemCount()I

    move-result v0

    sub-int/2addr v0, v1

    invoke-direct {p0, p1, p2, v0}, Landroid/support/v7/widget/GridLayoutManager;->a(Landroid/support/v7/widget/Hb;Landroid/support/v7/widget/Mb;I)I

    move-result p0

    add-int/2addr p0, v1

    return p0
.end method

.method public b(Landroid/support/v7/widget/RecyclerView;II)V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/GridLayoutManager;->Rq:Landroid/support/v7/widget/La;

    .line 3
    iget-object p0, p0, Landroid/support/v7/widget/La;->kp:Landroid/util/SparseIntArray;

    invoke-virtual {p0}, Landroid/util/SparseIntArray;->clear()V

    return-void
.end method

.method public c(Landroid/support/v7/widget/RecyclerView;II)V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/GridLayoutManager;->Rq:Landroid/support/v7/widget/La;

    .line 3
    iget-object p0, p0, Landroid/support/v7/widget/La;->kp:Landroid/util/SparseIntArray;

    invoke-virtual {p0}, Landroid/util/SparseIntArray;->clear()V

    return-void
.end method

.method public e(Landroid/support/v7/widget/Hb;Landroid/support/v7/widget/Mb;)V
    .locals 6

    .line 1
    iget-boolean v0, p2, Landroid/support/v7/widget/Mb;->mInPreLayout:Z

    if-eqz v0, :cond_0

    .line 2
    invoke-virtual {p0}, Landroid/support/v7/widget/Ab;->getChildCount()I

    move-result v0

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_0

    invoke-virtual {p0, v1}, Landroid/support/v7/widget/Ab;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    check-cast v2, Landroid/support/v7/widget/Ma;

    invoke-virtual {v2}, Landroid/support/v7/widget/Bb;->getViewLayoutPosition()I

    move-result v3

    iget-object v4, p0, Landroid/support/v7/widget/GridLayoutManager;->Pq:Landroid/util/SparseIntArray;

    .line 3
    iget v5, v2, Landroid/support/v7/widget/Ma;->Zw:I

    .line 4
    invoke-virtual {v4, v3, v5}, Landroid/util/SparseIntArray;->put(II)V

    iget-object v4, p0, Landroid/support/v7/widget/GridLayoutManager;->Qq:Landroid/util/SparseIntArray;

    .line 5
    iget v2, v2, Landroid/support/v7/widget/Ma;->Yw:I

    .line 6
    invoke-virtual {v4, v3, v2}, Landroid/util/SparseIntArray;->put(II)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 7
    :cond_0
    invoke-super {p0, p1, p2}, Landroid/support/v7/widget/LinearLayoutManager;->e(Landroid/support/v7/widget/Hb;Landroid/support/v7/widget/Mb;)V

    .line 8
    iget-object p1, p0, Landroid/support/v7/widget/GridLayoutManager;->Pq:Landroid/util/SparseIntArray;

    invoke-virtual {p1}, Landroid/util/SparseIntArray;->clear()V

    iget-object p0, p0, Landroid/support/v7/widget/GridLayoutManager;->Qq:Landroid/util/SparseIntArray;

    invoke-virtual {p0}, Landroid/util/SparseIntArray;->clear()V

    return-void
.end method

.method public f(Landroid/support/v7/widget/RecyclerView;)V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/GridLayoutManager;->Rq:Landroid/support/v7/widget/La;

    .line 1
    iget-object p0, p0, Landroid/support/v7/widget/La;->kp:Landroid/util/SparseIntArray;

    invoke-virtual {p0}, Landroid/util/SparseIntArray;->clear()V

    return-void
.end method

.method public generateDefaultLayoutParams()Landroid/support/v7/widget/Bb;
    .locals 2

    iget p0, p0, Landroid/support/v7/widget/LinearLayoutManager;->mOrientation:I

    const/4 v0, -0x2

    const/4 v1, -0x1

    if-nez p0, :cond_0

    new-instance p0, Landroid/support/v7/widget/Ma;

    invoke-direct {p0, v0, v1}, Landroid/support/v7/widget/Ma;-><init>(II)V

    return-object p0

    :cond_0
    new-instance p0, Landroid/support/v7/widget/Ma;

    invoke-direct {p0, v1, v0}, Landroid/support/v7/widget/Ma;-><init>(II)V

    return-object p0
.end method

.method public generateLayoutParams(Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/support/v7/widget/Bb;
    .locals 0

    new-instance p0, Landroid/support/v7/widget/Ma;

    invoke-direct {p0, p1, p2}, Landroid/support/v7/widget/Ma;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-object p0
.end method

.method public generateLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Landroid/support/v7/widget/Bb;
    .locals 0

    instance-of p0, p1, Landroid/view/ViewGroup$MarginLayoutParams;

    if-eqz p0, :cond_0

    new-instance p0, Landroid/support/v7/widget/Ma;

    check-cast p1, Landroid/view/ViewGroup$MarginLayoutParams;

    invoke-direct {p0, p1}, Landroid/support/v7/widget/Ma;-><init>(Landroid/view/ViewGroup$MarginLayoutParams;)V

    return-object p0

    :cond_0
    new-instance p0, Landroid/support/v7/widget/Ma;

    invoke-direct {p0, p1}, Landroid/support/v7/widget/Ma;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    return-object p0
.end method

.method public h(Landroid/support/v7/widget/Mb;)V
    .locals 0

    invoke-super {p0, p1}, Landroid/support/v7/widget/LinearLayoutManager;->h(Landroid/support/v7/widget/Mb;)V

    const/4 p1, 0x0

    iput-boolean p1, p0, Landroid/support/v7/widget/GridLayoutManager;->Lq:Z

    return-void
.end method

.method l(II)I
    .locals 2

    iget v0, p0, Landroid/support/v7/widget/LinearLayoutManager;->mOrientation:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    invoke-virtual {p0}, Landroid/support/v7/widget/LinearLayoutManager;->isLayoutRTL()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroid/support/v7/widget/GridLayoutManager;->Nq:[I

    iget p0, p0, Landroid/support/v7/widget/GridLayoutManager;->Mq:I

    sub-int v1, p0, p1

    aget v1, v0, v1

    sub-int/2addr p0, p1

    sub-int/2addr p0, p2

    aget p0, v0, p0

    sub-int/2addr v1, p0

    return v1

    :cond_0
    iget-object p0, p0, Landroid/support/v7/widget/GridLayoutManager;->Nq:[I

    add-int/2addr p2, p1

    aget p2, p0, p2

    aget p0, p0, p1

    sub-int/2addr p2, p0

    return p2
.end method

.method public setMeasuredDimension(Landroid/graphics/Rect;II)V
    .locals 4

    iget-object v0, p0, Landroid/support/v7/widget/GridLayoutManager;->Nq:[I

    if-nez v0, :cond_0

    .line 1
    invoke-virtual {p1}, Landroid/graphics/Rect;->width()I

    move-result v0

    invoke-virtual {p0}, Landroid/support/v7/widget/Ab;->getPaddingLeft()I

    move-result v1

    add-int/2addr v1, v0

    invoke-virtual {p0}, Landroid/support/v7/widget/Ab;->getPaddingRight()I

    move-result v0

    add-int/2addr v0, v1

    invoke-virtual {p1}, Landroid/graphics/Rect;->height()I

    move-result v1

    invoke-virtual {p0}, Landroid/support/v7/widget/Ab;->getPaddingTop()I

    move-result v2

    add-int/2addr v2, v1

    invoke-virtual {p0}, Landroid/support/v7/widget/Ab;->getPaddingBottom()I

    move-result v1

    add-int/2addr v1, v2

    invoke-virtual {p0}, Landroid/support/v7/widget/Ab;->getMinimumWidth()I

    move-result v2

    invoke-static {p2, v0, v2}, Landroid/support/v7/widget/Ab;->chooseSize(III)I

    move-result v0

    invoke-virtual {p0}, Landroid/support/v7/widget/Ab;->getMinimumHeight()I

    move-result v2

    invoke-static {p3, v1, v2}, Landroid/support/v7/widget/Ab;->chooseSize(III)I

    move-result v1

    invoke-virtual {p0, v0, v1}, Landroid/support/v7/widget/Ab;->setMeasuredDimension(II)V

    .line 2
    :cond_0
    invoke-virtual {p0}, Landroid/support/v7/widget/Ab;->getPaddingLeft()I

    move-result v0

    invoke-virtual {p0}, Landroid/support/v7/widget/Ab;->getPaddingRight()I

    move-result v1

    add-int/2addr v1, v0

    invoke-virtual {p0}, Landroid/support/v7/widget/Ab;->getPaddingTop()I

    move-result v0

    invoke-virtual {p0}, Landroid/support/v7/widget/Ab;->getPaddingBottom()I

    move-result v2

    add-int/2addr v2, v0

    iget v0, p0, Landroid/support/v7/widget/LinearLayoutManager;->mOrientation:I

    const/4 v3, 0x1

    if-ne v0, v3, :cond_1

    invoke-virtual {p1}, Landroid/graphics/Rect;->height()I

    move-result p1

    add-int/2addr p1, v2

    invoke-virtual {p0}, Landroid/support/v7/widget/Ab;->getMinimumHeight()I

    move-result v0

    invoke-static {p3, p1, v0}, Landroid/support/v7/widget/Ab;->chooseSize(III)I

    move-result p1

    iget-object p3, p0, Landroid/support/v7/widget/GridLayoutManager;->Nq:[I

    array-length v0, p3

    sub-int/2addr v0, v3

    aget p3, p3, v0

    add-int/2addr p3, v1

    invoke-virtual {p0}, Landroid/support/v7/widget/Ab;->getMinimumWidth()I

    move-result v0

    invoke-static {p2, p3, v0}, Landroid/support/v7/widget/Ab;->chooseSize(III)I

    move-result p2

    goto :goto_0

    :cond_1
    invoke-virtual {p1}, Landroid/graphics/Rect;->width()I

    move-result p1

    add-int/2addr p1, v1

    invoke-virtual {p0}, Landroid/support/v7/widget/Ab;->getMinimumWidth()I

    move-result v0

    invoke-static {p2, p1, v0}, Landroid/support/v7/widget/Ab;->chooseSize(III)I

    move-result p2

    iget-object p1, p0, Landroid/support/v7/widget/GridLayoutManager;->Nq:[I

    array-length v0, p1

    sub-int/2addr v0, v3

    aget p1, p1, v0

    add-int/2addr p1, v2

    invoke-virtual {p0}, Landroid/support/v7/widget/Ab;->getMinimumHeight()I

    move-result v0

    invoke-static {p3, p1, v0}, Landroid/support/v7/widget/Ab;->chooseSize(III)I

    move-result p1

    :goto_0
    invoke-virtual {p0, p2, p1}, Landroid/support/v7/widget/Ab;->setMeasuredDimension(II)V

    return-void
.end method

.method public setStackFromEnd(Z)V
    .locals 0

    if-nez p1, :cond_0

    const/4 p1, 0x0

    invoke-super {p0, p1}, Landroid/support/v7/widget/LinearLayoutManager;->setStackFromEnd(Z)V

    return-void

    :cond_0
    new-instance p0, Ljava/lang/UnsupportedOperationException;

    const-string p1, "GridLayoutManager does not support stack from end. Consider using reverse layout"

    invoke-direct {p0, p1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public supportsPredictiveItemAnimations()Z
    .locals 1

    iget-object v0, p0, Landroid/support/v7/widget/LinearLayoutManager;->mPendingSavedState:Landroid/support/v7/widget/LinearLayoutManager$SavedState;

    if-nez v0, :cond_0

    iget-boolean p0, p0, Landroid/support/v7/widget/GridLayoutManager;->Lq:Z

    if-nez p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method
