.class public Landroid/support/v7/widget/I;
.super Ljava/lang/Object;
.source ""


# instance fields
.field private _n:Landroid/support/v7/widget/fc;

.field private final mView:Landroid/widget/ImageView;

.field private wo:Landroid/support/v7/widget/fc;

.field private xo:Landroid/support/v7/widget/fc;


# direct methods
.method public constructor <init>(Landroid/widget/ImageView;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroid/support/v7/widget/I;->mView:Landroid/widget/ImageView;

    return-void
.end method


# virtual methods
.method Ya()V
    .locals 6

    iget-object v0, p0, Landroid/support/v7/widget/I;->mView:Landroid/widget/ImageView;

    invoke-virtual {v0}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-static {v0}, Landroid/support/v7/widget/ta;->f(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    if-eqz v0, :cond_9

    .line 1
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    iget-object v1, p0, Landroid/support/v7/widget/I;->wo:Landroid/support/v7/widget/fc;

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v1, :cond_1

    move v1, v2

    goto :goto_0

    :cond_1
    move v1, v3

    :goto_0
    if-eqz v1, :cond_7

    .line 2
    iget-object v1, p0, Landroid/support/v7/widget/I;->_n:Landroid/support/v7/widget/fc;

    if-nez v1, :cond_2

    new-instance v1, Landroid/support/v7/widget/fc;

    invoke-direct {v1}, Landroid/support/v7/widget/fc;-><init>()V

    iput-object v1, p0, Landroid/support/v7/widget/I;->_n:Landroid/support/v7/widget/fc;

    :cond_2
    iget-object v1, p0, Landroid/support/v7/widget/I;->_n:Landroid/support/v7/widget/fc;

    invoke-virtual {v1}, Landroid/support/v7/widget/fc;->clear()V

    iget-object v4, p0, Landroid/support/v7/widget/I;->mView:Landroid/widget/ImageView;

    .line 3
    sget v5, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-virtual {v4}, Landroid/widget/ImageView;->getImageTintList()Landroid/content/res/ColorStateList;

    move-result-object v4

    if-eqz v4, :cond_3

    .line 4
    iput-boolean v2, v1, Landroid/support/v7/widget/fc;->mHasTintList:Z

    iput-object v4, v1, Landroid/support/v7/widget/fc;->mTintList:Landroid/content/res/ColorStateList;

    :cond_3
    iget-object v4, p0, Landroid/support/v7/widget/I;->mView:Landroid/widget/ImageView;

    .line 5
    sget v5, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-virtual {v4}, Landroid/widget/ImageView;->getImageTintMode()Landroid/graphics/PorterDuff$Mode;

    move-result-object v4

    if-eqz v4, :cond_4

    .line 6
    iput-boolean v2, v1, Landroid/support/v7/widget/fc;->mHasTintMode:Z

    iput-object v4, v1, Landroid/support/v7/widget/fc;->is:Landroid/graphics/PorterDuff$Mode;

    :cond_4
    iget-boolean v4, v1, Landroid/support/v7/widget/fc;->mHasTintList:Z

    if-nez v4, :cond_6

    iget-boolean v4, v1, Landroid/support/v7/widget/fc;->mHasTintMode:Z

    if-eqz v4, :cond_5

    goto :goto_1

    :cond_5
    move v2, v3

    goto :goto_2

    :cond_6
    :goto_1
    iget-object v3, p0, Landroid/support/v7/widget/I;->mView:Landroid/widget/ImageView;

    invoke-virtual {v3}, Landroid/widget/ImageView;->getDrawableState()[I

    move-result-object v3

    invoke-static {v0, v1, v3}, Landroid/support/v7/widget/F;->a(Landroid/graphics/drawable/Drawable;Landroid/support/v7/widget/fc;[I)V

    :goto_2
    if-eqz v2, :cond_7

    return-void

    .line 7
    :cond_7
    iget-object v1, p0, Landroid/support/v7/widget/I;->xo:Landroid/support/v7/widget/fc;

    if-eqz v1, :cond_8

    :goto_3
    iget-object p0, p0, Landroid/support/v7/widget/I;->mView:Landroid/widget/ImageView;

    invoke-virtual {p0}, Landroid/widget/ImageView;->getDrawableState()[I

    move-result-object p0

    invoke-static {v0, v1, p0}, Landroid/support/v7/widget/F;->a(Landroid/graphics/drawable/Drawable;Landroid/support/v7/widget/fc;[I)V

    goto :goto_4

    :cond_8
    iget-object v1, p0, Landroid/support/v7/widget/I;->wo:Landroid/support/v7/widget/fc;

    if-eqz v1, :cond_9

    goto :goto_3

    :cond_9
    :goto_4
    return-void
.end method

.method public a(Landroid/util/AttributeSet;I)V
    .locals 3

    iget-object v0, p0, Landroid/support/v7/widget/I;->mView:Landroid/widget/ImageView;

    invoke-virtual {v0}, Landroid/widget/ImageView;->getContext()Landroid/content/Context;

    move-result-object v0

    sget-object v1, La/b/d/a/b;->hk:[I

    const/4 v2, 0x0

    invoke-static {v0, p1, v1, p2, v2}, Landroid/support/v7/widget/hc;->a(Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroid/support/v7/widget/hc;

    move-result-object p1

    :try_start_0
    iget-object p2, p0, Landroid/support/v7/widget/I;->mView:Landroid/widget/ImageView;

    invoke-virtual {p2}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object p2

    const/4 v0, -0x1

    if-nez p2, :cond_0

    const/4 v1, 0x1

    invoke-virtual {p1, v1, v0}, Landroid/support/v7/widget/hc;->getResourceId(II)I

    move-result v1

    if-eq v1, v0, :cond_0

    iget-object p2, p0, Landroid/support/v7/widget/I;->mView:Landroid/widget/ImageView;

    invoke-virtual {p2}, Landroid/widget/ImageView;->getContext()Landroid/content/Context;

    move-result-object p2

    invoke-static {p2, v1}, La/b/d/b/a/a;->a(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p2

    if-eqz p2, :cond_0

    iget-object v1, p0, Landroid/support/v7/widget/I;->mView:Landroid/widget/ImageView;

    invoke-virtual {v1, p2}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    if-eqz p2, :cond_1

    invoke-static {p2}, Landroid/support/v7/widget/ta;->f(Landroid/graphics/drawable/Drawable;)V

    :cond_1
    const/4 p2, 0x2

    invoke-virtual {p1, p2}, Landroid/support/v7/widget/hc;->hasValue(I)Z

    move-result v1

    if-eqz v1, :cond_2

    iget-object v1, p0, Landroid/support/v7/widget/I;->mView:Landroid/widget/ImageView;

    invoke-virtual {p1, p2}, Landroid/support/v7/widget/hc;->getColorStateList(I)Landroid/content/res/ColorStateList;

    move-result-object p2

    .line 1
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-virtual {v1, p2}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    sget p2, Landroid/os/Build$VERSION;->SDK_INT:I

    :cond_2
    const/4 p2, 0x3

    .line 2
    invoke-virtual {p1, p2}, Landroid/support/v7/widget/hc;->hasValue(I)Z

    move-result v1

    if-eqz v1, :cond_3

    iget-object p0, p0, Landroid/support/v7/widget/I;->mView:Landroid/widget/ImageView;

    invoke-virtual {p1, p2, v0}, Landroid/support/v7/widget/hc;->getInt(II)I

    move-result p2

    const/4 v0, 0x0

    invoke-static {p2, v0}, Landroid/support/v7/widget/ta;->parseTintMode(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;

    move-result-object p2

    .line 3
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-virtual {p0, p2}, Landroid/widget/ImageView;->setImageTintMode(Landroid/graphics/PorterDuff$Mode;)V

    sget p0, Landroid/os/Build$VERSION;->SDK_INT:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 4
    :cond_3
    invoke-virtual {p1}, Landroid/support/v7/widget/hc;->recycle()V

    return-void

    :catchall_0
    move-exception p0

    invoke-virtual {p1}, Landroid/support/v7/widget/hc;->recycle()V

    throw p0
.end method

.method hasOverlappingRendering()Z
    .locals 1

    iget-object p0, p0, Landroid/support/v7/widget/I;->mView:Landroid/widget/ImageView;

    invoke-virtual {p0}, Landroid/widget/ImageView;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object p0

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    instance-of p0, p0, Landroid/graphics/drawable/RippleDrawable;

    if-eqz p0, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    const/4 p0, 0x1

    return p0
.end method

.method public setImageResource(I)V
    .locals 1

    if-eqz p1, :cond_1

    iget-object v0, p0, Landroid/support/v7/widget/I;->mView:Landroid/widget/ImageView;

    invoke-virtual {v0}, Landroid/widget/ImageView;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, p1}, La/b/d/b/a/a;->a(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    if-eqz p1, :cond_0

    invoke-static {p1}, Landroid/support/v7/widget/ta;->f(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    iget-object v0, p0, Landroid/support/v7/widget/I;->mView:Landroid/widget/ImageView;

    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    goto :goto_0

    :cond_1
    iget-object p1, p0, Landroid/support/v7/widget/I;->mView:Landroid/widget/ImageView;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    :goto_0
    invoke-virtual {p0}, Landroid/support/v7/widget/I;->Ya()V

    return-void
.end method
