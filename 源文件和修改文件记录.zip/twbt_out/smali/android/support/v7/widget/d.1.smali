.class Landroid/support/v7/widget/d;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field final synthetic Tn:La/b/d/e/c;


# direct methods
.method constructor <init>(Landroid/support/v7/widget/ActionBarContextView;La/b/d/e/c;)V
    .locals 0

    iput-object p2, p0, Landroid/support/v7/widget/d;->Tn:La/b/d/e/c;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/d;->Tn:La/b/d/e/c;

    invoke-virtual {p0}, La/b/d/e/c;->finish()V

    return-void
.end method
