.class Landroid/support/v7/widget/ia;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic _o:Ljava/util/ArrayList;

.field final synthetic n:Landroid/support/v7/widget/sa;


# direct methods
.method constructor <init>(Landroid/support/v7/widget/sa;Ljava/util/ArrayList;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/widget/ia;->n:Landroid/support/v7/widget/sa;

    iput-object p2, p0, Landroid/support/v7/widget/ia;->_o:Ljava/util/ArrayList;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 8

    iget-object v0, p0, Landroid/support/v7/widget/ia;->_o:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/support/v7/widget/ra;

    iget-object v2, p0, Landroid/support/v7/widget/ia;->n:Landroid/support/v7/widget/sa;

    iget-object v3, v1, Landroid/support/v7/widget/ra;->holder:Landroid/support/v7/widget/Ob;

    iget v4, v1, Landroid/support/v7/widget/ra;->fromX:I

    iget v5, v1, Landroid/support/v7/widget/ra;->fromY:I

    iget v6, v1, Landroid/support/v7/widget/ra;->toX:I

    iget v7, v1, Landroid/support/v7/widget/ra;->toY:I

    invoke-virtual/range {v2 .. v7}, Landroid/support/v7/widget/sa;->b(Landroid/support/v7/widget/Ob;IIII)V

    goto :goto_0

    :cond_0
    iget-object v0, p0, Landroid/support/v7/widget/ia;->_o:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p0, Landroid/support/v7/widget/ia;->n:Landroid/support/v7/widget/sa;

    iget-object v0, v0, Landroid/support/v7/widget/sa;->mMovesList:Ljava/util/ArrayList;

    iget-object p0, p0, Landroid/support/v7/widget/ia;->_o:Ljava/util/ArrayList;

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    return-void
.end method
