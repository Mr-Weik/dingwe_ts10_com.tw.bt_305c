.class public Landroid/support/v7/widget/db;
.super Landroid/support/v7/widget/ab;
.source ""

# interfaces
.implements Landroid/support/v7/widget/bb;


# static fields
.field private static Tp:Ljava/lang/reflect/Method;


# instance fields
.field private Sp:Landroid/support/v7/widget/bb;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    :try_start_0
    const-class v0, Landroid/widget/PopupWindow;

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/Class;

    const/4 v2, 0x0

    sget-object v3, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    aput-object v3, v1, v2
    :try_end_0
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_0

    const-string v2, "setTouchModal"

    :try_start_1
    invoke-virtual {v0, v2, v1}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    sput-object v0, Landroid/support/v7/widget/db;->Tp:Ljava/lang/reflect/Method;
    :try_end_1
    .catch Ljava/lang/NoSuchMethodException; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_0

    :catch_0
    const-string v0, "MenuPopupWindow"

    const-string v1, "Could not find method setTouchModal() on PopupWindow. Oh well."

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    :goto_0
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V
    .locals 0

    invoke-direct {p0, p1, p2, p3, p4}, Landroid/support/v7/widget/ab;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    return-void
.end method


# virtual methods
.method public a(Landroid/support/v7/view/menu/r;Landroid/view/MenuItem;)V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/db;->Sp:Landroid/support/v7/widget/bb;

    if-eqz p0, :cond_0

    invoke-interface {p0, p1, p2}, Landroid/support/v7/widget/bb;->a(Landroid/support/v7/view/menu/r;Landroid/view/MenuItem;)V

    :cond_0
    return-void
.end method

.method public a(Landroid/support/v7/widget/bb;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/widget/db;->Sp:Landroid/support/v7/widget/bb;

    return-void
.end method

.method public b(Landroid/support/v7/view/menu/r;Landroid/view/MenuItem;)V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/db;->Sp:Landroid/support/v7/widget/bb;

    if-eqz p0, :cond_0

    invoke-interface {p0, p1, p2}, Landroid/support/v7/widget/bb;->b(Landroid/support/v7/view/menu/r;Landroid/view/MenuItem;)V

    :cond_0
    return-void
.end method

.method createDropDownListView(Landroid/content/Context;Z)Landroid/support/v7/widget/xa;
    .locals 1

    new-instance v0, Landroid/support/v7/widget/cb;

    invoke-direct {v0, p1, p2}, Landroid/support/v7/widget/cb;-><init>(Landroid/content/Context;Z)V

    invoke-virtual {v0, p0}, Landroid/support/v7/widget/cb;->a(Landroid/support/v7/widget/bb;)V

    return-object v0
.end method

.method public q(Ljava/lang/Object;)V
    .locals 1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    iget-object p0, p0, Landroid/support/v7/widget/ab;->mPopup:Landroid/widget/PopupWindow;

    check-cast p1, Landroid/transition/Transition;

    invoke-virtual {p0, p1}, Landroid/widget/PopupWindow;->setEnterTransition(Landroid/transition/Transition;)V

    return-void
.end method

.method public r(Ljava/lang/Object;)V
    .locals 1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    iget-object p0, p0, Landroid/support/v7/widget/ab;->mPopup:Landroid/widget/PopupWindow;

    check-cast p1, Landroid/transition/Transition;

    invoke-virtual {p0, p1}, Landroid/widget/PopupWindow;->setExitTransition(Landroid/transition/Transition;)V

    return-void
.end method

.method public setTouchModal(Z)V
    .locals 3

    sget-object v0, Landroid/support/v7/widget/db;->Tp:Ljava/lang/reflect/Method;

    if-eqz v0, :cond_0

    :try_start_0
    iget-object p0, p0, Landroid/support/v7/widget/ab;->mPopup:Landroid/widget/PopupWindow;

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v2, 0x0

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    aput-object p1, v1, v2

    invoke-virtual {v0, p0, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    const-string p0, "MenuPopupWindow"

    const-string p1, "Could not invoke setTouchModal() on PopupWindow. Oh well."

    invoke-static {p0, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    :goto_0
    return-void
.end method
