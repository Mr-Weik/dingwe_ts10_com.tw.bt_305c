.class public final Landroid/support/v7/widget/Hb;
.super Ljava/lang/Object;
.source ""


# instance fields
.field private final fr:Ljava/util/List;

.field private gr:I

.field final mAttachedScrap:Ljava/util/ArrayList;

.field final mCachedViews:Ljava/util/ArrayList;

.field mChangedScrap:Ljava/util/ArrayList;

.field mRecyclerPool:Landroid/support/v7/widget/Gb;

.field mViewCacheMax:I

.field final synthetic n:Landroid/support/v7/widget/RecyclerView;


# direct methods
.method public constructor <init>(Landroid/support/v7/widget/RecyclerView;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, Landroid/support/v7/widget/Hb;->mAttachedScrap:Ljava/util/ArrayList;

    const/4 p1, 0x0

    iput-object p1, p0, Landroid/support/v7/widget/Hb;->mChangedScrap:Ljava/util/ArrayList;

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, Landroid/support/v7/widget/Hb;->mCachedViews:Ljava/util/ArrayList;

    iget-object p1, p0, Landroid/support/v7/widget/Hb;->mAttachedScrap:Ljava/util/ArrayList;

    invoke-static {p1}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, Landroid/support/v7/widget/Hb;->fr:Ljava/util/List;

    const/4 p1, 0x2

    iput p1, p0, Landroid/support/v7/widget/Hb;->gr:I

    iput p1, p0, Landroid/support/v7/widget/Hb;->mViewCacheMax:I

    return-void
.end method

.method private a(Landroid/view/ViewGroup;Z)V
    .locals 4

    invoke-virtual {p1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v1, 0x1

    sub-int/2addr v0, v1

    :goto_0
    if-ltz v0, :cond_1

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    instance-of v3, v2, Landroid/view/ViewGroup;

    if-eqz v3, :cond_0

    check-cast v2, Landroid/view/ViewGroup;

    invoke-direct {p0, v2, v1}, Landroid/support/v7/widget/Hb;->a(Landroid/view/ViewGroup;Z)V

    :cond_0
    add-int/lit8 v0, v0, -0x1

    goto :goto_0

    :cond_1
    if-nez p2, :cond_2

    return-void

    :cond_2
    invoke-virtual {p1}, Landroid/view/ViewGroup;->getVisibility()I

    move-result p0

    const/4 p2, 0x4

    if-ne p0, p2, :cond_3

    const/4 p0, 0x0

    invoke-virtual {p1, p0}, Landroid/view/ViewGroup;->setVisibility(I)V

    invoke-virtual {p1, p2}, Landroid/view/ViewGroup;->setVisibility(I)V

    goto :goto_1

    :cond_3
    invoke-virtual {p1}, Landroid/view/ViewGroup;->getVisibility()I

    move-result p0

    invoke-virtual {p1, p2}, Landroid/view/ViewGroup;->setVisibility(I)V

    invoke-virtual {p1, p0}, Landroid/view/ViewGroup;->setVisibility(I)V

    :goto_1
    return-void
.end method


# virtual methods
.method a(Landroid/support/v7/widget/Ob;Z)V
    .locals 3

    invoke-static {p1}, Landroid/support/v7/widget/RecyclerView;->H(Landroid/support/v7/widget/Ob;)V

    const/16 v0, 0x4000

    invoke-virtual {p1, v0}, Landroid/support/v7/widget/Ob;->hasAnyOfTheFlags(I)Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    const/4 v1, 0x0

    invoke-virtual {p1, v1, v0}, Landroid/support/v7/widget/Ob;->setFlags(II)V

    iget-object v0, p1, Landroid/support/v7/widget/Ob;->itemView:Landroid/view/View;

    invoke-static {v0, v2}, Landroid/support/v4/view/r;->a(Landroid/view/View;Landroid/support/v4/view/c;)V

    :cond_0
    if-eqz p2, :cond_2

    .line 1
    iget-object p2, p0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object p2, p2, Landroid/support/v7/widget/RecyclerView;->mAdapter:Landroid/support/v7/widget/ob;

    if-eqz p2, :cond_1

    invoke-virtual {p2, p1}, Landroid/support/v7/widget/ob;->d(Landroid/support/v7/widget/Ob;)V

    :cond_1
    iget-object p2, p0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v0, p2, Landroid/support/v7/widget/RecyclerView;->mState:Landroid/support/v7/widget/Mb;

    if-eqz v0, :cond_2

    iget-object p2, p2, Landroid/support/v7/widget/RecyclerView;->mViewInfoStore:Landroid/support/v7/widget/xc;

    invoke-virtual {p2, p1}, Landroid/support/v7/widget/xc;->F(Landroid/support/v7/widget/Ob;)V

    .line 2
    :cond_2
    iput-object v2, p1, Landroid/support/v7/widget/Ob;->mOwnerRecyclerView:Landroid/support/v7/widget/RecyclerView;

    invoke-virtual {p0}, Landroid/support/v7/widget/Hb;->getRecycledViewPool()Landroid/support/v7/widget/Gb;

    move-result-object p0

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/Gb;->g(Landroid/support/v7/widget/Ob;)V

    return-void
.end method

.method public clear()V
    .locals 1

    iget-object v0, p0, Landroid/support/v7/widget/Hb;->mAttachedScrap:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    invoke-virtual {p0}, Landroid/support/v7/widget/Hb;->recycleAndClearCachedViews()V

    return-void
.end method

.method public convertPreLayoutPositionToPostLayout(I)I
    .locals 3

    if-ltz p1, :cond_1

    iget-object v0, p0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v0, v0, Landroid/support/v7/widget/RecyclerView;->mState:Landroid/support/v7/widget/Mb;

    invoke-virtual {v0}, Landroid/support/v7/widget/Mb;->getItemCount()I

    move-result v0

    if-ge p1, v0, :cond_1

    iget-object p0, p0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v0, p0, Landroid/support/v7/widget/RecyclerView;->mState:Landroid/support/v7/widget/Mb;

    .line 1
    iget-boolean v0, v0, Landroid/support/v7/widget/Mb;->mInPreLayout:Z

    if-nez v0, :cond_0

    return p1

    .line 2
    :cond_0
    iget-object p0, p0, Landroid/support/v7/widget/RecyclerView;->mAdapterHelper:Landroid/support/v7/widget/w;

    const/4 v0, 0x0

    .line 3
    invoke-virtual {p0, p1, v0}, Landroid/support/v7/widget/w;->findPositionOffset(II)I

    move-result p0

    return p0

    .line 4
    :cond_1
    new-instance v0, Ljava/lang/IndexOutOfBoundsException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "invalid position "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p1, ". State "

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, "item count is "

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p1, p0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object p1, p1, Landroid/support/v7/widget/RecyclerView;->mState:Landroid/support/v7/widget/Mb;

    invoke-virtual {p1}, Landroid/support/v7/widget/Mb;->getItemCount()I

    move-result p1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    iget-object p0, p0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    invoke-virtual {p0}, Landroid/support/v7/widget/RecyclerView;->Bb()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method getRecycledViewPool()Landroid/support/v7/widget/Gb;
    .locals 1

    iget-object v0, p0, Landroid/support/v7/widget/Hb;->mRecyclerPool:Landroid/support/v7/widget/Gb;

    if-nez v0, :cond_0

    new-instance v0, Landroid/support/v7/widget/Gb;

    invoke-direct {v0}, Landroid/support/v7/widget/Gb;-><init>()V

    iput-object v0, p0, Landroid/support/v7/widget/Hb;->mRecyclerPool:Landroid/support/v7/widget/Gb;

    :cond_0
    iget-object p0, p0, Landroid/support/v7/widget/Hb;->mRecyclerPool:Landroid/support/v7/widget/Gb;

    return-object p0
.end method

.method public getScrapList()Ljava/util/List;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/Hb;->fr:Ljava/util/List;

    return-object p0
.end method

.method h(Landroid/support/v7/widget/Ob;)V
    .locals 6

    invoke-virtual {p1}, Landroid/support/v7/widget/Ob;->isScrap()Z

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-nez v0, :cond_c

    iget-object v0, p1, Landroid/support/v7/widget/Ob;->itemView:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    if-eqz v0, :cond_0

    goto/16 :goto_2

    :cond_0
    invoke-virtual {p1}, Landroid/support/v7/widget/Ob;->isTmpDetached()Z

    move-result v0

    if-nez v0, :cond_b

    invoke-virtual {p1}, Landroid/support/v7/widget/Ob;->shouldIgnore()Z

    move-result v0

    if-nez v0, :cond_a

    invoke-static {p1}, Landroid/support/v7/widget/Ob;->j(Landroid/support/v7/widget/Ob;)Z

    move-result v0

    iget-object v3, p0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v3, v3, Landroid/support/v7/widget/RecyclerView;->mAdapter:Landroid/support/v7/widget/ob;

    if-eqz v3, :cond_1

    if-eqz v0, :cond_1

    invoke-virtual {v3, p1}, Landroid/support/v7/widget/ob;->a(Landroid/support/v7/widget/Ob;)Z

    :cond_1
    invoke-virtual {p1}, Landroid/support/v7/widget/Ob;->isRecyclable()Z

    move-result v3

    if-eqz v3, :cond_7

    iget v3, p0, Landroid/support/v7/widget/Hb;->mViewCacheMax:I

    if-lez v3, :cond_6

    const/16 v3, 0x20e

    invoke-virtual {p1, v3}, Landroid/support/v7/widget/Ob;->hasAnyOfTheFlags(I)Z

    move-result v3

    if-nez v3, :cond_6

    iget-object v3, p0, Landroid/support/v7/widget/Hb;->mCachedViews:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    iget v4, p0, Landroid/support/v7/widget/Hb;->mViewCacheMax:I

    if-lt v3, v4, :cond_2

    if-lez v3, :cond_2

    invoke-virtual {p0, v1}, Landroid/support/v7/widget/Hb;->recycleCachedViewAt(I)V

    add-int/lit8 v3, v3, -0x1

    :cond_2
    invoke-static {}, Landroid/support/v7/widget/RecyclerView;->Ab()Z

    move-result v4

    if-eqz v4, :cond_5

    if-lez v3, :cond_5

    iget-object v4, p0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v4, v4, Landroid/support/v7/widget/RecyclerView;->mPrefetchRegistry:Landroid/support/v7/widget/Ia;

    iget v5, p1, Landroid/support/v7/widget/Ob;->mPosition:I

    invoke-virtual {v4, v5}, Landroid/support/v7/widget/Ia;->lastPrefetchIncludedPosition(I)Z

    move-result v4

    if-nez v4, :cond_5

    :cond_3
    add-int/lit8 v3, v3, -0x1

    if-ltz v3, :cond_4

    iget-object v4, p0, Landroid/support/v7/widget/Hb;->mCachedViews:Ljava/util/ArrayList;

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/support/v7/widget/Ob;

    iget v4, v4, Landroid/support/v7/widget/Ob;->mPosition:I

    iget-object v5, p0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v5, v5, Landroid/support/v7/widget/RecyclerView;->mPrefetchRegistry:Landroid/support/v7/widget/Ia;

    invoke-virtual {v5, v4}, Landroid/support/v7/widget/Ia;->lastPrefetchIncludedPosition(I)Z

    move-result v4

    if-nez v4, :cond_3

    :cond_4
    add-int/2addr v3, v2

    :cond_5
    iget-object v4, p0, Landroid/support/v7/widget/Hb;->mCachedViews:Ljava/util/ArrayList;

    invoke-virtual {v4, v3, p1}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    move v3, v2

    goto :goto_0

    :cond_6
    move v3, v1

    :goto_0
    if-nez v3, :cond_8

    invoke-virtual {p0, p1, v2}, Landroid/support/v7/widget/Hb;->a(Landroid/support/v7/widget/Ob;Z)V

    move v1, v2

    goto :goto_1

    :cond_7
    move v3, v1

    :cond_8
    :goto_1
    iget-object p0, p0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object p0, p0, Landroid/support/v7/widget/RecyclerView;->mViewInfoStore:Landroid/support/v7/widget/xc;

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/xc;->F(Landroid/support/v7/widget/Ob;)V

    if-nez v3, :cond_9

    if-nez v1, :cond_9

    if-eqz v0, :cond_9

    const/4 p0, 0x0

    iput-object p0, p1, Landroid/support/v7/widget/Ob;->mOwnerRecyclerView:Landroid/support/v7/widget/RecyclerView;

    :cond_9
    return-void

    :cond_a
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "Trying to recycle an ignored view holder. You should first call stopIgnoringView(view) before calling recycle."

    invoke-static {v0}, Lb/a/a/a/a;->x(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object p0, p0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    invoke-virtual {p0}, Landroid/support/v7/widget/RecyclerView;->Bb()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_b
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Tmp detached view should be removed from RecyclerView before it can be recycled: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    iget-object p0, p0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    invoke-virtual {p0}, Landroid/support/v7/widget/RecyclerView;->Bb()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_c
    :goto_2
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v3, "Scrapped or attached views may not be recycled. isScrap:"

    invoke-static {v3}, Lb/a/a/a/a;->x(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {p1}, Landroid/support/v7/widget/Ob;->isScrap()Z

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v4, " isAttached:"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p1, p1, Landroid/support/v7/widget/Ob;->itemView:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p1

    if-eqz p1, :cond_d

    move v1, v2

    :cond_d
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    iget-object p0, p0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    invoke-virtual {p0}, Landroid/support/v7/widget/RecyclerView;->Bb()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method i(Landroid/support/v7/widget/Ob;)V
    .locals 1

    invoke-static {p1}, Landroid/support/v7/widget/Ob;->k(Landroid/support/v7/widget/Ob;)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object p0, p0, Landroid/support/v7/widget/Hb;->mChangedScrap:Ljava/util/ArrayList;

    goto :goto_0

    :cond_0
    iget-object p0, p0, Landroid/support/v7/widget/Hb;->mAttachedScrap:Ljava/util/ArrayList;

    :goto_0
    invoke-virtual {p0, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    const/4 p0, 0x0

    invoke-static {p1, p0}, Landroid/support/v7/widget/Ob;->a(Landroid/support/v7/widget/Ob;Landroid/support/v7/widget/Hb;)Landroid/support/v7/widget/Hb;

    const/4 p0, 0x0

    invoke-static {p1, p0}, Landroid/support/v7/widget/Ob;->b(Landroid/support/v7/widget/Ob;Z)Z

    invoke-virtual {p1}, Landroid/support/v7/widget/Ob;->clearReturnedFromScrapFlag()V

    return-void
.end method

.method quickRecycleScrapView(Landroid/view/View;)V
    .locals 1

    invoke-static {p1}, Landroid/support/v7/widget/RecyclerView;->getChildViewHolderInt(Landroid/view/View;)Landroid/support/v7/widget/Ob;

    move-result-object p1

    const/4 v0, 0x0

    invoke-static {p1, v0}, Landroid/support/v7/widget/Ob;->a(Landroid/support/v7/widget/Ob;Landroid/support/v7/widget/Hb;)Landroid/support/v7/widget/Hb;

    const/4 v0, 0x0

    invoke-static {p1, v0}, Landroid/support/v7/widget/Ob;->b(Landroid/support/v7/widget/Ob;Z)Z

    invoke-virtual {p1}, Landroid/support/v7/widget/Ob;->clearReturnedFromScrapFlag()V

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/Hb;->h(Landroid/support/v7/widget/Ob;)V

    return-void
.end method

.method recycleAndClearCachedViews()V
    .locals 2

    iget-object v0, p0, Landroid/support/v7/widget/Hb;->mCachedViews:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, -0x1

    add-int/2addr v0, v1

    :goto_0
    if-ltz v0, :cond_0

    invoke-virtual {p0, v0}, Landroid/support/v7/widget/Hb;->recycleCachedViewAt(I)V

    add-int/lit8 v0, v0, -0x1

    goto :goto_0

    :cond_0
    iget-object v0, p0, Landroid/support/v7/widget/Hb;->mCachedViews:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    invoke-static {}, Landroid/support/v7/widget/RecyclerView;->Ab()Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object p0, p0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object p0, p0, Landroid/support/v7/widget/RecyclerView;->mPrefetchRegistry:Landroid/support/v7/widget/Ia;

    .line 1
    iget-object v0, p0, Landroid/support/v7/widget/Ia;->mPrefetchArray:[I

    if-eqz v0, :cond_1

    invoke-static {v0, v1}, Ljava/util/Arrays;->fill([II)V

    :cond_1
    const/4 v0, 0x0

    iput v0, p0, Landroid/support/v7/widget/Ia;->mCount:I

    :cond_2
    return-void
.end method

.method recycleCachedViewAt(I)V
    .locals 2

    iget-object v0, p0, Landroid/support/v7/widget/Hb;->mCachedViews:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v7/widget/Ob;

    const/4 v1, 0x1

    invoke-virtual {p0, v0, v1}, Landroid/support/v7/widget/Hb;->a(Landroid/support/v7/widget/Ob;Z)V

    iget-object p0, p0, Landroid/support/v7/widget/Hb;->mCachedViews:Ljava/util/ArrayList;

    invoke-virtual {p0, p1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    return-void
.end method

.method public recycleView(Landroid/view/View;)V
    .locals 3

    invoke-static {p1}, Landroid/support/v7/widget/RecyclerView;->getChildViewHolderInt(Landroid/view/View;)Landroid/support/v7/widget/Ob;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/v7/widget/Ob;->isTmpDetached()Z

    move-result v1

    if-eqz v1, :cond_0

    iget-object v1, p0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    const/4 v2, 0x0

    invoke-virtual {v1, p1, v2}, Landroid/support/v7/widget/RecyclerView;->removeDetachedView(Landroid/view/View;Z)V

    :cond_0
    invoke-virtual {v0}, Landroid/support/v7/widget/Ob;->isScrap()Z

    move-result p1

    if-eqz p1, :cond_1

    invoke-virtual {v0}, Landroid/support/v7/widget/Ob;->unScrap()V

    goto :goto_0

    :cond_1
    invoke-virtual {v0}, Landroid/support/v7/widget/Ob;->wasReturnedFromScrap()Z

    move-result p1

    if-eqz p1, :cond_2

    invoke-virtual {v0}, Landroid/support/v7/widget/Ob;->clearReturnedFromScrapFlag()V

    :cond_2
    :goto_0
    invoke-virtual {p0, v0}, Landroid/support/v7/widget/Hb;->h(Landroid/support/v7/widget/Ob;)V

    return-void
.end method

.method scrapView(Landroid/view/View;)V
    .locals 1

    invoke-static {p1}, Landroid/support/v7/widget/RecyclerView;->getChildViewHolderInt(Landroid/view/View;)Landroid/support/v7/widget/Ob;

    move-result-object p1

    const/16 v0, 0xc

    invoke-virtual {p1, v0}, Landroid/support/v7/widget/Ob;->hasAnyOfTheFlags(I)Z

    move-result v0

    if-nez v0, :cond_2

    invoke-virtual {p1}, Landroid/support/v7/widget/Ob;->isUpdated()Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object v0, p0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    invoke-virtual {v0, p1}, Landroid/support/v7/widget/RecyclerView;->G(Landroid/support/v7/widget/Ob;)Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    iget-object v0, p0, Landroid/support/v7/widget/Hb;->mChangedScrap:Ljava/util/ArrayList;

    if-nez v0, :cond_1

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroid/support/v7/widget/Hb;->mChangedScrap:Ljava/util/ArrayList;

    :cond_1
    const/4 v0, 0x1

    invoke-virtual {p1, p0, v0}, Landroid/support/v7/widget/Ob;->a(Landroid/support/v7/widget/Hb;Z)V

    iget-object p0, p0, Landroid/support/v7/widget/Hb;->mChangedScrap:Ljava/util/ArrayList;

    goto :goto_2

    :cond_2
    :goto_0
    invoke-virtual {p1}, Landroid/support/v7/widget/Ob;->isInvalid()Z

    move-result v0

    if-eqz v0, :cond_4

    invoke-virtual {p1}, Landroid/support/v7/widget/Ob;->isRemoved()Z

    move-result v0

    if-nez v0, :cond_4

    iget-object v0, p0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v0, v0, Landroid/support/v7/widget/RecyclerView;->mAdapter:Landroid/support/v7/widget/ob;

    invoke-virtual {v0}, Landroid/support/v7/widget/ob;->hasStableIds()Z

    move-result v0

    if-eqz v0, :cond_3

    goto :goto_1

    :cond_3
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "Called scrap view with an invalid view. Invalid views cannot be reused from scrap, they should rebound from recycler pool."

    invoke-static {v0}, Lb/a/a/a/a;->x(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object p0, p0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    invoke-virtual {p0}, Landroid/support/v7/widget/RecyclerView;->Bb()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_4
    :goto_1
    const/4 v0, 0x0

    invoke-virtual {p1, p0, v0}, Landroid/support/v7/widget/Ob;->a(Landroid/support/v7/widget/Hb;Z)V

    iget-object p0, p0, Landroid/support/v7/widget/Hb;->mAttachedScrap:Ljava/util/ArrayList;

    :goto_2
    invoke-virtual {p0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method tryGetViewHolderForPositionByDeadline(IZJ)Landroid/support/v7/widget/Ob;
    .locals 17

    move-object/from16 v0, p0

    move/from16 v1, p1

    if-ltz v1, :cond_38

    iget-object v2, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v2, v2, Landroid/support/v7/widget/RecyclerView;->mState:Landroid/support/v7/widget/Mb;

    invoke-virtual {v2}, Landroid/support/v7/widget/Mb;->getItemCount()I

    move-result v2

    if-ge v1, v2, :cond_38

    iget-object v2, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v2, v2, Landroid/support/v7/widget/RecyclerView;->mState:Landroid/support/v7/widget/Mb;

    .line 1
    iget-boolean v2, v2, Landroid/support/v7/widget/Mb;->mInPreLayout:Z

    const-wide/16 v3, -0x1

    const/16 v5, 0x20

    const/4 v8, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x0

    if-eqz v2, :cond_5

    .line 2
    iget-object v2, v0, Landroid/support/v7/widget/Hb;->mChangedScrap:Ljava/util/ArrayList;

    if-eqz v2, :cond_4

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-nez v2, :cond_0

    goto :goto_3

    :cond_0
    move v6, v10

    :goto_0
    if-ge v6, v2, :cond_2

    iget-object v7, v0, Landroid/support/v7/widget/Hb;->mChangedScrap:Ljava/util/ArrayList;

    invoke-virtual {v7, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Landroid/support/v7/widget/Ob;

    invoke-virtual {v7}, Landroid/support/v7/widget/Ob;->wasReturnedFromScrap()Z

    move-result v11

    if-nez v11, :cond_1

    invoke-virtual {v7}, Landroid/support/v7/widget/Ob;->getLayoutPosition()I

    move-result v11

    if-ne v11, v1, :cond_1

    :goto_1
    invoke-virtual {v7, v5}, Landroid/support/v7/widget/Ob;->addFlags(I)V

    goto :goto_4

    :cond_1
    add-int/lit8 v6, v6, 0x1

    goto :goto_0

    :cond_2
    iget-object v6, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v6, v6, Landroid/support/v7/widget/RecyclerView;->mAdapter:Landroid/support/v7/widget/ob;

    invoke-virtual {v6}, Landroid/support/v7/widget/ob;->hasStableIds()Z

    move-result v6

    if-eqz v6, :cond_4

    iget-object v6, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v6, v6, Landroid/support/v7/widget/RecyclerView;->mAdapterHelper:Landroid/support/v7/widget/w;

    .line 3
    invoke-virtual {v6, v1, v10}, Landroid/support/v7/widget/w;->findPositionOffset(II)I

    move-result v6

    if-lez v6, :cond_4

    .line 4
    iget-object v7, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v7, v7, Landroid/support/v7/widget/RecyclerView;->mAdapter:Landroid/support/v7/widget/ob;

    invoke-virtual {v7}, Landroid/support/v7/widget/ob;->getItemCount()I

    move-result v7

    if-ge v6, v7, :cond_4

    iget-object v7, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v7, v7, Landroid/support/v7/widget/RecyclerView;->mAdapter:Landroid/support/v7/widget/ob;

    invoke-virtual {v7, v6}, Landroid/support/v7/widget/ob;->getItemId(I)J

    move v6, v10

    :goto_2
    if-ge v6, v2, :cond_4

    iget-object v7, v0, Landroid/support/v7/widget/Hb;->mChangedScrap:Ljava/util/ArrayList;

    invoke-virtual {v7, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Landroid/support/v7/widget/Ob;

    invoke-virtual {v7}, Landroid/support/v7/widget/Ob;->wasReturnedFromScrap()Z

    move-result v11

    if-nez v11, :cond_3

    invoke-virtual {v7}, Landroid/support/v7/widget/Ob;->getItemId()J

    move-result-wide v11

    cmp-long v11, v11, v3

    if-nez v11, :cond_3

    goto :goto_1

    :cond_3
    add-int/lit8 v6, v6, 0x1

    goto :goto_2

    :cond_4
    :goto_3
    move-object v7, v8

    :goto_4
    if-eqz v7, :cond_6

    move v2, v9

    goto :goto_5

    :cond_5
    move-object v7, v8

    :cond_6
    move v2, v10

    :goto_5
    const/4 v6, -0x1

    if-nez v7, :cond_1a

    .line 5
    iget-object v7, v0, Landroid/support/v7/widget/Hb;->mAttachedScrap:Ljava/util/ArrayList;

    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    move-result v7

    move v11, v10

    :goto_6
    if-ge v11, v7, :cond_9

    iget-object v12, v0, Landroid/support/v7/widget/Hb;->mAttachedScrap:Ljava/util/ArrayList;

    invoke-virtual {v12, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Landroid/support/v7/widget/Ob;

    invoke-virtual {v12}, Landroid/support/v7/widget/Ob;->wasReturnedFromScrap()Z

    move-result v13

    if-nez v13, :cond_8

    invoke-virtual {v12}, Landroid/support/v7/widget/Ob;->getLayoutPosition()I

    move-result v13

    if-ne v13, v1, :cond_8

    invoke-virtual {v12}, Landroid/support/v7/widget/Ob;->isInvalid()Z

    move-result v13

    if-nez v13, :cond_8

    iget-object v13, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v13, v13, Landroid/support/v7/widget/RecyclerView;->mState:Landroid/support/v7/widget/Mb;

    iget-boolean v13, v13, Landroid/support/v7/widget/Mb;->mInPreLayout:Z

    if-nez v13, :cond_7

    invoke-virtual {v12}, Landroid/support/v7/widget/Ob;->isRemoved()Z

    move-result v13

    if-nez v13, :cond_8

    :cond_7
    invoke-virtual {v12, v5}, Landroid/support/v7/widget/Ob;->addFlags(I)V

    goto/16 :goto_a

    :cond_8
    add-int/lit8 v11, v11, 0x1

    goto :goto_6

    :cond_9
    if-nez p2, :cond_d

    iget-object v7, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v7, v7, Landroid/support/v7/widget/RecyclerView;->mChildHelper:Landroid/support/v7/widget/ea;

    .line 6
    iget-object v11, v7, Landroid/support/v7/widget/ea;->mHiddenViews:Ljava/util/List;

    invoke-interface {v11}, Ljava/util/List;->size()I

    move-result v11

    move v12, v10

    :goto_7
    if-ge v12, v11, :cond_b

    iget-object v13, v7, Landroid/support/v7/widget/ea;->mHiddenViews:Ljava/util/List;

    invoke-interface {v13, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Landroid/view/View;

    iget-object v14, v7, Landroid/support/v7/widget/ea;->mCallback:Landroid/support/v7/widget/mb;

    invoke-virtual {v14, v13}, Landroid/support/v7/widget/mb;->getChildViewHolder(Landroid/view/View;)Landroid/support/v7/widget/Ob;

    move-result-object v14

    invoke-virtual {v14}, Landroid/support/v7/widget/Ob;->getLayoutPosition()I

    move-result v15

    if-ne v15, v1, :cond_a

    invoke-virtual {v14}, Landroid/support/v7/widget/Ob;->isInvalid()Z

    move-result v15

    if-nez v15, :cond_a

    invoke-virtual {v14}, Landroid/support/v7/widget/Ob;->isRemoved()Z

    move-result v14

    if-nez v14, :cond_a

    goto :goto_8

    :cond_a
    add-int/lit8 v12, v12, 0x1

    goto :goto_7

    :cond_b
    move-object v13, v8

    :goto_8
    if-eqz v13, :cond_d

    .line 7
    invoke-static {v13}, Landroid/support/v7/widget/RecyclerView;->getChildViewHolderInt(Landroid/view/View;)Landroid/support/v7/widget/Ob;

    move-result-object v7

    iget-object v11, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v11, v11, Landroid/support/v7/widget/RecyclerView;->mChildHelper:Landroid/support/v7/widget/ea;

    invoke-virtual {v11, v13}, Landroid/support/v7/widget/ea;->unhide(Landroid/view/View;)V

    iget-object v11, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v11, v11, Landroid/support/v7/widget/RecyclerView;->mChildHelper:Landroid/support/v7/widget/ea;

    invoke-virtual {v11, v13}, Landroid/support/v7/widget/ea;->indexOfChild(Landroid/view/View;)I

    move-result v11

    if-eq v11, v6, :cond_c

    iget-object v12, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v12, v12, Landroid/support/v7/widget/RecyclerView;->mChildHelper:Landroid/support/v7/widget/ea;

    invoke-virtual {v12, v11}, Landroid/support/v7/widget/ea;->detachViewFromParent(I)V

    invoke-virtual {v0, v13}, Landroid/support/v7/widget/Hb;->scrapView(Landroid/view/View;)V

    const/16 v11, 0x2020

    invoke-virtual {v7, v11}, Landroid/support/v7/widget/Ob;->addFlags(I)V

    move-object v12, v7

    goto :goto_a

    :cond_c
    new-instance v1, Ljava/lang/IllegalStateException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "layout index should not be -1 after unhiding a view:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    iget-object v0, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    invoke-virtual {v0}, Landroid/support/v7/widget/RecyclerView;->Bb()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_d
    iget-object v7, v0, Landroid/support/v7/widget/Hb;->mCachedViews:Ljava/util/ArrayList;

    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    move-result v7

    move v11, v10

    :goto_9
    if-ge v11, v7, :cond_f

    iget-object v12, v0, Landroid/support/v7/widget/Hb;->mCachedViews:Ljava/util/ArrayList;

    invoke-virtual {v12, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Landroid/support/v7/widget/Ob;

    invoke-virtual {v12}, Landroid/support/v7/widget/Ob;->isInvalid()Z

    move-result v13

    if-nez v13, :cond_e

    invoke-virtual {v12}, Landroid/support/v7/widget/Ob;->getLayoutPosition()I

    move-result v13

    if-ne v13, v1, :cond_e

    if-nez p2, :cond_10

    iget-object v7, v0, Landroid/support/v7/widget/Hb;->mCachedViews:Ljava/util/ArrayList;

    invoke-virtual {v7, v11}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    goto :goto_a

    :cond_e
    add-int/lit8 v11, v11, 0x1

    goto :goto_9

    :cond_f
    move-object v12, v8

    :cond_10
    :goto_a
    if-eqz v12, :cond_1b

    .line 8
    invoke-virtual {v12}, Landroid/support/v7/widget/Ob;->isRemoved()Z

    move-result v7

    if-eqz v7, :cond_11

    iget-object v7, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v7, v7, Landroid/support/v7/widget/RecyclerView;->mState:Landroid/support/v7/widget/Mb;

    .line 9
    iget-boolean v7, v7, Landroid/support/v7/widget/Mb;->mInPreLayout:Z

    goto :goto_d

    .line 10
    :cond_11
    iget v7, v12, Landroid/support/v7/widget/Ob;->mPosition:I

    if-ltz v7, :cond_19

    iget-object v11, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v11, v11, Landroid/support/v7/widget/RecyclerView;->mAdapter:Landroid/support/v7/widget/ob;

    invoke-virtual {v11}, Landroid/support/v7/widget/ob;->getItemCount()I

    move-result v11

    if-ge v7, v11, :cond_19

    iget-object v7, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v11, v7, Landroid/support/v7/widget/RecyclerView;->mState:Landroid/support/v7/widget/Mb;

    .line 11
    iget-boolean v11, v11, Landroid/support/v7/widget/Mb;->mInPreLayout:Z

    if-nez v11, :cond_12

    .line 12
    iget-object v7, v7, Landroid/support/v7/widget/RecyclerView;->mAdapter:Landroid/support/v7/widget/ob;

    iget v11, v12, Landroid/support/v7/widget/Ob;->mPosition:I

    invoke-virtual {v7, v11}, Landroid/support/v7/widget/ob;->getItemViewType(I)I

    invoke-virtual {v12}, Landroid/support/v7/widget/Ob;->getItemViewType()I

    move-result v7

    if-eqz v7, :cond_12

    goto :goto_b

    :cond_12
    iget-object v7, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v7, v7, Landroid/support/v7/widget/RecyclerView;->mAdapter:Landroid/support/v7/widget/ob;

    invoke-virtual {v7}, Landroid/support/v7/widget/ob;->hasStableIds()Z

    move-result v7

    if-eqz v7, :cond_14

    invoke-virtual {v12}, Landroid/support/v7/widget/Ob;->getItemId()J

    move-result-wide v13

    iget-object v7, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v7, v7, Landroid/support/v7/widget/RecyclerView;->mAdapter:Landroid/support/v7/widget/ob;

    iget v11, v12, Landroid/support/v7/widget/Ob;->mPosition:I

    invoke-virtual {v7, v11}, Landroid/support/v7/widget/ob;->getItemId(I)J

    cmp-long v7, v13, v3

    if-nez v7, :cond_13

    goto :goto_c

    :cond_13
    :goto_b
    move v7, v10

    goto :goto_d

    :cond_14
    :goto_c
    move v7, v9

    :goto_d
    if-nez v7, :cond_18

    if-nez p2, :cond_17

    const/4 v7, 0x4

    .line 13
    invoke-virtual {v12, v7}, Landroid/support/v7/widget/Ob;->addFlags(I)V

    invoke-virtual {v12}, Landroid/support/v7/widget/Ob;->isScrap()Z

    move-result v7

    if-eqz v7, :cond_15

    iget-object v7, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v11, v12, Landroid/support/v7/widget/Ob;->itemView:Landroid/view/View;

    invoke-virtual {v7, v11, v10}, Landroid/support/v7/widget/RecyclerView;->removeDetachedView(Landroid/view/View;Z)V

    invoke-virtual {v12}, Landroid/support/v7/widget/Ob;->unScrap()V

    goto :goto_e

    :cond_15
    invoke-virtual {v12}, Landroid/support/v7/widget/Ob;->wasReturnedFromScrap()Z

    move-result v7

    if-eqz v7, :cond_16

    invoke-virtual {v12}, Landroid/support/v7/widget/Ob;->clearReturnedFromScrapFlag()V

    :cond_16
    :goto_e
    invoke-virtual {v0, v12}, Landroid/support/v7/widget/Hb;->h(Landroid/support/v7/widget/Ob;)V

    :cond_17
    move-object v12, v8

    goto :goto_f

    :cond_18
    move v2, v9

    goto :goto_f

    .line 14
    :cond_19
    new-instance v1, Ljava/lang/IndexOutOfBoundsException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Inconsistency detected. Invalid view holder adapter position"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    iget-object v0, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    invoke-virtual {v0}, Landroid/support/v7/widget/RecyclerView;->Bb()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_1a
    move-object v12, v7

    :cond_1b
    :goto_f
    const-wide v13, 0x7fffffffffffffffL

    if-nez v12, :cond_2b

    .line 15
    iget-object v7, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v7, v7, Landroid/support/v7/widget/RecyclerView;->mAdapterHelper:Landroid/support/v7/widget/w;

    .line 16
    invoke-virtual {v7, v1, v10}, Landroid/support/v7/widget/w;->findPositionOffset(II)I

    move-result v7

    if-ltz v7, :cond_2a

    .line 17
    iget-object v11, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v11, v11, Landroid/support/v7/widget/RecyclerView;->mAdapter:Landroid/support/v7/widget/ob;

    invoke-virtual {v11}, Landroid/support/v7/widget/ob;->getItemCount()I

    move-result v11

    if-ge v7, v11, :cond_2a

    iget-object v11, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v11, v11, Landroid/support/v7/widget/RecyclerView;->mAdapter:Landroid/support/v7/widget/ob;

    invoke-virtual {v11, v7}, Landroid/support/v7/widget/ob;->getItemViewType(I)I

    iget-object v11, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v11, v11, Landroid/support/v7/widget/RecyclerView;->mAdapter:Landroid/support/v7/widget/ob;

    invoke-virtual {v11}, Landroid/support/v7/widget/ob;->hasStableIds()Z

    move-result v11

    if-eqz v11, :cond_24

    iget-object v11, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v11, v11, Landroid/support/v7/widget/RecyclerView;->mAdapter:Landroid/support/v7/widget/ob;

    invoke-virtual {v11, v7}, Landroid/support/v7/widget/ob;->getItemId(I)J

    .line 18
    iget-object v11, v0, Landroid/support/v7/widget/Hb;->mAttachedScrap:Ljava/util/ArrayList;

    invoke-virtual {v11}, Ljava/util/ArrayList;->size()I

    move-result v11

    add-int/2addr v11, v6

    :goto_10
    if-ltz v11, :cond_1e

    iget-object v12, v0, Landroid/support/v7/widget/Hb;->mAttachedScrap:Ljava/util/ArrayList;

    invoke-virtual {v12, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Landroid/support/v7/widget/Ob;

    invoke-virtual {v12}, Landroid/support/v7/widget/Ob;->getItemId()J

    move-result-wide v15

    cmp-long v15, v15, v3

    if-nez v15, :cond_1d

    invoke-virtual {v12}, Landroid/support/v7/widget/Ob;->wasReturnedFromScrap()Z

    move-result v15

    if-nez v15, :cond_1d

    invoke-virtual {v12}, Landroid/support/v7/widget/Ob;->getItemViewType()I

    move-result v15

    if-nez v15, :cond_1c

    invoke-virtual {v12, v5}, Landroid/support/v7/widget/Ob;->addFlags(I)V

    invoke-virtual {v12}, Landroid/support/v7/widget/Ob;->isRemoved()Z

    move-result v3

    if-eqz v3, :cond_23

    iget-object v3, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v3, v3, Landroid/support/v7/widget/RecyclerView;->mState:Landroid/support/v7/widget/Mb;

    .line 19
    iget-boolean v3, v3, Landroid/support/v7/widget/Mb;->mInPreLayout:Z

    if-nez v3, :cond_23

    const/4 v3, 0x2

    const/16 v4, 0xe

    .line 20
    invoke-virtual {v12, v3, v4}, Landroid/support/v7/widget/Ob;->setFlags(II)V

    goto :goto_13

    :cond_1c
    if-nez p2, :cond_1d

    iget-object v15, v0, Landroid/support/v7/widget/Hb;->mAttachedScrap:Ljava/util/ArrayList;

    invoke-virtual {v15, v11}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    iget-object v15, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v5, v12, Landroid/support/v7/widget/Ob;->itemView:Landroid/view/View;

    invoke-virtual {v15, v5, v10}, Landroid/support/v7/widget/RecyclerView;->removeDetachedView(Landroid/view/View;Z)V

    iget-object v5, v12, Landroid/support/v7/widget/Ob;->itemView:Landroid/view/View;

    invoke-virtual {v0, v5}, Landroid/support/v7/widget/Hb;->quickRecycleScrapView(Landroid/view/View;)V

    :cond_1d
    add-int/lit8 v11, v11, -0x1

    const/16 v5, 0x20

    goto :goto_10

    :cond_1e
    iget-object v5, v0, Landroid/support/v7/widget/Hb;->mCachedViews:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    add-int/2addr v5, v6

    :goto_11
    if-ltz v5, :cond_22

    iget-object v11, v0, Landroid/support/v7/widget/Hb;->mCachedViews:Ljava/util/ArrayList;

    invoke-virtual {v11, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Landroid/support/v7/widget/Ob;

    invoke-virtual {v11}, Landroid/support/v7/widget/Ob;->getItemId()J

    move-result-wide v15

    cmp-long v12, v15, v3

    if-nez v12, :cond_21

    invoke-virtual {v11}, Landroid/support/v7/widget/Ob;->getItemViewType()I

    move-result v12

    if-nez v12, :cond_20

    if-nez p2, :cond_1f

    iget-object v3, v0, Landroid/support/v7/widget/Hb;->mCachedViews:Ljava/util/ArrayList;

    invoke-virtual {v3, v5}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    :cond_1f
    move-object v12, v11

    goto :goto_13

    :cond_20
    if-nez p2, :cond_21

    invoke-virtual {v0, v5}, Landroid/support/v7/widget/Hb;->recycleCachedViewAt(I)V

    goto :goto_12

    :cond_21
    add-int/lit8 v5, v5, -0x1

    goto :goto_11

    :cond_22
    :goto_12
    move-object v12, v8

    :cond_23
    :goto_13
    if-eqz v12, :cond_24

    .line 21
    iput v7, v12, Landroid/support/v7/widget/Ob;->mPosition:I

    move v11, v9

    goto :goto_14

    :cond_24
    move v11, v2

    :goto_14
    if-nez v12, :cond_27

    invoke-virtual/range {p0 .. p0}, Landroid/support/v7/widget/Hb;->getRecycledViewPool()Landroid/support/v7/widget/Gb;

    move-result-object v2

    .line 22
    iget-object v2, v2, Landroid/support/v7/widget/Gb;->mScrap:Landroid/util/SparseArray;

    invoke-virtual {v2, v10}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/support/v7/widget/Fb;

    if-eqz v2, :cond_25

    iget-object v3, v2, Landroid/support/v7/widget/Fb;->mScrapHeap:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_25

    iget-object v2, v2, Landroid/support/v7/widget/Fb;->mScrapHeap:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v3

    add-int/2addr v3, v6

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/support/v7/widget/Ob;

    goto :goto_15

    :cond_25
    move-object v2, v8

    :goto_15
    if-eqz v2, :cond_26

    .line 23
    invoke-virtual {v2}, Landroid/support/v7/widget/Ob;->resetInternal()V

    sget-boolean v3, Landroid/support/v7/widget/RecyclerView;->FORCE_INVALIDATE_DISPLAY_LIST:Z

    if-eqz v3, :cond_26

    .line 24
    iget-object v3, v2, Landroid/support/v7/widget/Ob;->itemView:Landroid/view/View;

    instance-of v4, v3, Landroid/view/ViewGroup;

    if-eqz v4, :cond_26

    check-cast v3, Landroid/view/ViewGroup;

    invoke-direct {v0, v3, v10}, Landroid/support/v7/widget/Hb;->a(Landroid/view/ViewGroup;Z)V

    :cond_26
    move-object v12, v2

    :cond_27
    if-nez v12, :cond_2c

    .line 25
    iget-object v2, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    invoke-virtual {v2}, Landroid/support/v7/widget/RecyclerView;->getNanoTime()J

    move-result-wide v15

    cmp-long v2, p3, v13

    if-eqz v2, :cond_28

    iget-object v2, v0, Landroid/support/v7/widget/Hb;->mRecyclerPool:Landroid/support/v7/widget/Gb;

    const/4 v3, 0x0

    move-wide v4, v15

    move-wide/from16 v6, p3

    invoke-virtual/range {v2 .. v7}, Landroid/support/v7/widget/Gb;->willCreateInTime(IJJ)Z

    move-result v2

    if-nez v2, :cond_28

    return-object v8

    :cond_28
    iget-object v2, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v3, v2, Landroid/support/v7/widget/RecyclerView;->mAdapter:Landroid/support/v7/widget/ob;

    invoke-virtual {v3, v2, v10}, Landroid/support/v7/widget/ob;->createViewHolder(Landroid/view/ViewGroup;I)Landroid/support/v7/widget/Ob;

    move-result-object v12

    invoke-static {}, Landroid/support/v7/widget/RecyclerView;->Ab()Z

    move-result v2

    if-eqz v2, :cond_29

    iget-object v2, v12, Landroid/support/v7/widget/Ob;->itemView:Landroid/view/View;

    invoke-static {v2}, Landroid/support/v7/widget/RecyclerView;->findNestedRecyclerView(Landroid/view/View;)Landroid/support/v7/widget/RecyclerView;

    move-result-object v2

    if-eqz v2, :cond_29

    new-instance v3, Ljava/lang/ref/WeakReference;

    invoke-direct {v3, v2}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v3, v12, Landroid/support/v7/widget/Ob;->mNestedRecyclerView:Ljava/lang/ref/WeakReference;

    :cond_29
    iget-object v2, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    invoke-virtual {v2}, Landroid/support/v7/widget/RecyclerView;->getNanoTime()J

    move-result-wide v2

    iget-object v4, v0, Landroid/support/v7/widget/Hb;->mRecyclerPool:Landroid/support/v7/widget/Gb;

    sub-long/2addr v2, v15

    invoke-virtual {v4, v10, v2, v3}, Landroid/support/v7/widget/Gb;->factorInCreateTime(IJ)V

    goto :goto_16

    :cond_2a
    new-instance v2, Ljava/lang/IndexOutOfBoundsException;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Inconsistency detected. Invalid item position "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "(offset:"

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ")."

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "state:"

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v1, v1, Landroid/support/v7/widget/RecyclerView;->mState:Landroid/support/v7/widget/Mb;

    invoke-virtual {v1}, Landroid/support/v7/widget/Mb;->getItemCount()I

    move-result v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    iget-object v0, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    invoke-virtual {v0}, Landroid/support/v7/widget/RecyclerView;->Bb()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v2, v0}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    throw v2

    :cond_2b
    move v11, v2

    :cond_2c
    :goto_16
    if-eqz v11, :cond_2d

    iget-object v2, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v2, v2, Landroid/support/v7/widget/RecyclerView;->mState:Landroid/support/v7/widget/Mb;

    .line 26
    iget-boolean v2, v2, Landroid/support/v7/widget/Mb;->mInPreLayout:Z

    if-nez v2, :cond_2d

    const/16 v2, 0x2000

    .line 27
    invoke-virtual {v12, v2}, Landroid/support/v7/widget/Ob;->hasAnyOfTheFlags(I)Z

    move-result v3

    if-eqz v3, :cond_2d

    invoke-virtual {v12, v10, v2}, Landroid/support/v7/widget/Ob;->setFlags(II)V

    iget-object v2, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v2, v2, Landroid/support/v7/widget/RecyclerView;->mState:Landroid/support/v7/widget/Mb;

    iget-boolean v2, v2, Landroid/support/v7/widget/Mb;->mRunSimpleAnimations:Z

    if-eqz v2, :cond_2d

    invoke-static {v12}, Landroid/support/v7/widget/Vb;->p(Landroid/support/v7/widget/Ob;)I

    move-result v2

    or-int/lit16 v2, v2, 0x1000

    iget-object v3, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v4, v3, Landroid/support/v7/widget/RecyclerView;->mItemAnimator:Landroid/support/v7/widget/Vb;

    iget-object v3, v3, Landroid/support/v7/widget/RecyclerView;->mState:Landroid/support/v7/widget/Mb;

    invoke-virtual {v12}, Landroid/support/v7/widget/Ob;->getUnmodifiedPayloads()Ljava/util/List;

    move-result-object v5

    invoke-virtual {v4, v3, v12, v2, v5}, Landroid/support/v7/widget/Vb;->a(Landroid/support/v7/widget/Mb;Landroid/support/v7/widget/Ob;ILjava/util/List;)Landroid/support/v7/widget/tb;

    move-result-object v2

    iget-object v3, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    invoke-virtual {v3, v12, v2}, Landroid/support/v7/widget/RecyclerView;->d(Landroid/support/v7/widget/Ob;Landroid/support/v7/widget/tb;)V

    :cond_2d
    iget-object v2, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v2, v2, Landroid/support/v7/widget/RecyclerView;->mState:Landroid/support/v7/widget/Mb;

    .line 28
    iget-boolean v2, v2, Landroid/support/v7/widget/Mb;->mInPreLayout:Z

    if-eqz v2, :cond_2e

    .line 29
    invoke-virtual {v12}, Landroid/support/v7/widget/Ob;->isBound()Z

    move-result v2

    if-eqz v2, :cond_2e

    iput v1, v12, Landroid/support/v7/widget/Ob;->mPreLayoutPosition:I

    goto :goto_17

    :cond_2e
    invoke-virtual {v12}, Landroid/support/v7/widget/Ob;->isBound()Z

    move-result v2

    if-eqz v2, :cond_30

    invoke-virtual {v12}, Landroid/support/v7/widget/Ob;->needsUpdate()Z

    move-result v2

    if-nez v2, :cond_30

    invoke-virtual {v12}, Landroid/support/v7/widget/Ob;->isInvalid()Z

    move-result v2

    if-eqz v2, :cond_2f

    goto :goto_18

    :cond_2f
    :goto_17
    move v1, v10

    goto/16 :goto_19

    :cond_30
    :goto_18
    iget-object v2, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v2, v2, Landroid/support/v7/widget/RecyclerView;->mAdapterHelper:Landroid/support/v7/widget/w;

    .line 30
    invoke-virtual {v2, v1, v10}, Landroid/support/v7/widget/w;->findPositionOffset(II)I

    move-result v8

    .line 31
    iget-object v2, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iput-object v2, v12, Landroid/support/v7/widget/Ob;->mOwnerRecyclerView:Landroid/support/v7/widget/RecyclerView;

    invoke-virtual {v12}, Landroid/support/v7/widget/Ob;->getItemViewType()I

    move-result v3

    iget-object v2, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    invoke-virtual {v2}, Landroid/support/v7/widget/RecyclerView;->getNanoTime()J

    move-result-wide v15

    cmp-long v2, p3, v13

    if-eqz v2, :cond_31

    iget-object v2, v0, Landroid/support/v7/widget/Hb;->mRecyclerPool:Landroid/support/v7/widget/Gb;

    move-wide v4, v15

    move-wide/from16 v6, p3

    invoke-virtual/range {v2 .. v7}, Landroid/support/v7/widget/Gb;->willBindInTime(IJJ)Z

    move-result v2

    if-nez v2, :cond_31

    goto :goto_17

    :cond_31
    iget-object v2, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v2, v2, Landroid/support/v7/widget/RecyclerView;->mAdapter:Landroid/support/v7/widget/ob;

    invoke-virtual {v2, v12, v8}, Landroid/support/v7/widget/ob;->a(Landroid/support/v7/widget/Ob;I)V

    iget-object v2, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    invoke-virtual {v2}, Landroid/support/v7/widget/RecyclerView;->getNanoTime()J

    move-result-wide v2

    iget-object v4, v0, Landroid/support/v7/widget/Hb;->mRecyclerPool:Landroid/support/v7/widget/Gb;

    invoke-virtual {v12}, Landroid/support/v7/widget/Ob;->getItemViewType()I

    move-result v5

    sub-long/2addr v2, v15

    invoke-virtual {v4, v5, v2, v3}, Landroid/support/v7/widget/Gb;->factorInBindTime(IJ)V

    .line 32
    iget-object v2, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    invoke-virtual {v2}, Landroid/support/v7/widget/RecyclerView;->isAccessibilityEnabled()Z

    move-result v2

    if-eqz v2, :cond_33

    iget-object v2, v12, Landroid/support/v7/widget/Ob;->itemView:Landroid/view/View;

    invoke-static {v2}, Landroid/support/v4/view/r;->m(Landroid/view/View;)I

    move-result v3

    if-nez v3, :cond_32

    .line 33
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-virtual {v2, v9}, Landroid/view/View;->setImportantForAccessibility(I)V

    .line 34
    :cond_32
    invoke-static {v2}, Landroid/support/v4/view/r;->t(Landroid/view/View;)Z

    move-result v3

    if-nez v3, :cond_33

    const/16 v3, 0x4000

    invoke-virtual {v12, v3}, Landroid/support/v7/widget/Ob;->addFlags(I)V

    iget-object v3, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v3, v3, Landroid/support/v7/widget/RecyclerView;->mAccessibilityDelegate:Landroid/support/v7/widget/Qb;

    .line 35
    iget-object v3, v3, Landroid/support/v7/widget/Qb;->mItemDelegate:Landroid/support/v4/view/c;

    .line 36
    invoke-static {v2, v3}, Landroid/support/v4/view/r;->a(Landroid/view/View;Landroid/support/v4/view/c;)V

    .line 37
    :cond_33
    iget-object v2, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v2, v2, Landroid/support/v7/widget/RecyclerView;->mState:Landroid/support/v7/widget/Mb;

    .line 38
    iget-boolean v2, v2, Landroid/support/v7/widget/Mb;->mInPreLayout:Z

    if-eqz v2, :cond_34

    .line 39
    iput v1, v12, Landroid/support/v7/widget/Ob;->mPreLayoutPosition:I

    :cond_34
    move v1, v9

    .line 40
    :goto_19
    iget-object v2, v12, Landroid/support/v7/widget/Ob;->itemView:Landroid/view/View;

    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    if-nez v2, :cond_35

    iget-object v0, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    invoke-virtual {v0}, Landroid/support/v7/widget/RecyclerView;->generateDefaultLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    :goto_1a
    check-cast v0, Landroid/support/v7/widget/Bb;

    iget-object v2, v12, Landroid/support/v7/widget/Ob;->itemView:Landroid/view/View;

    invoke-virtual {v2, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    goto :goto_1b

    :cond_35
    iget-object v3, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    invoke-virtual {v3, v2}, Landroid/support/v7/widget/RecyclerView;->checkLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Z

    move-result v3

    if-nez v3, :cond_36

    iget-object v0, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    invoke-virtual {v0, v2}, Landroid/support/v7/widget/RecyclerView;->generateLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    goto :goto_1a

    :cond_36
    move-object v0, v2

    check-cast v0, Landroid/support/v7/widget/Bb;

    :goto_1b
    iput-object v12, v0, Landroid/support/v7/widget/Bb;->mViewHolder:Landroid/support/v7/widget/Ob;

    if-eqz v11, :cond_37

    if-eqz v1, :cond_37

    goto :goto_1c

    :cond_37
    move v9, v10

    :goto_1c
    iput-boolean v9, v0, Landroid/support/v7/widget/Bb;->mPendingInvalidate:Z

    return-object v12

    :cond_38
    new-instance v2, Ljava/lang/IndexOutOfBoundsException;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Invalid item position "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v4, "("

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "). Item count:"

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v1, v1, Landroid/support/v7/widget/RecyclerView;->mState:Landroid/support/v7/widget/Mb;

    invoke-virtual {v1}, Landroid/support/v7/widget/Mb;->getItemCount()I

    move-result v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    iget-object v0, v0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    invoke-virtual {v0}, Landroid/support/v7/widget/RecyclerView;->Bb()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v2, v0}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    throw v2
.end method

.method updateViewCacheSize()V
    .locals 3

    iget-object v0, p0, Landroid/support/v7/widget/Hb;->n:Landroid/support/v7/widget/RecyclerView;

    iget-object v0, v0, Landroid/support/v7/widget/RecyclerView;->mLayout:Landroid/support/v7/widget/Ab;

    if-eqz v0, :cond_0

    iget v0, v0, Landroid/support/v7/widget/Ab;->mPrefetchMaxCountObserved:I

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    iget v1, p0, Landroid/support/v7/widget/Hb;->gr:I

    add-int/2addr v1, v0

    iput v1, p0, Landroid/support/v7/widget/Hb;->mViewCacheMax:I

    iget-object v0, p0, Landroid/support/v7/widget/Hb;->mCachedViews:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    :goto_1
    if-ltz v0, :cond_1

    iget-object v1, p0, Landroid/support/v7/widget/Hb;->mCachedViews:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    iget v2, p0, Landroid/support/v7/widget/Hb;->mViewCacheMax:I

    if-le v1, v2, :cond_1

    invoke-virtual {p0, v0}, Landroid/support/v7/widget/Hb;->recycleCachedViewAt(I)V

    add-int/lit8 v0, v0, -0x1

    goto :goto_1

    :cond_1
    return-void
.end method
