.class Landroid/support/v7/widget/bc;
.super Ljava/lang/Object;
.source ""


# instance fields
.field cs:Ljava/util/ArrayList;

.field ds:I

.field es:I

.field fs:I

.field final mIndex:I

.field final synthetic n:Landroid/support/v7/widget/StaggeredGridLayoutManager;


# direct methods
.method constructor <init>(Landroid/support/v7/widget/StaggeredGridLayoutManager;I)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/widget/bc;->n:Landroid/support/v7/widget/StaggeredGridLayoutManager;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, Landroid/support/v7/widget/bc;->cs:Ljava/util/ArrayList;

    const/high16 p1, -0x80000000

    iput p1, p0, Landroid/support/v7/widget/bc;->ds:I

    iput p1, p0, Landroid/support/v7/widget/bc;->es:I

    const/4 p1, 0x0

    iput p1, p0, Landroid/support/v7/widget/bc;->fs:I

    iput p2, p0, Landroid/support/v7/widget/bc;->mIndex:I

    return-void
.end method


# virtual methods
.method D(Landroid/view/View;)V
    .locals 4

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/bc;->getLayoutParams(Landroid/view/View;)Landroid/support/v7/widget/Yb;

    move-result-object v0

    iput-object p0, v0, Landroid/support/v7/widget/Yb;->_w:Landroid/support/v7/widget/bc;

    iget-object v1, p0, Landroid/support/v7/widget/bc;->cs:Ljava/util/ArrayList;

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/high16 v1, -0x80000000

    iput v1, p0, Landroid/support/v7/widget/bc;->es:I

    iget-object v2, p0, Landroid/support/v7/widget/bc;->cs:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v3, 0x1

    if-ne v2, v3, :cond_0

    iput v1, p0, Landroid/support/v7/widget/bc;->ds:I

    :cond_0
    invoke-virtual {v0}, Landroid/support/v7/widget/Bb;->isItemRemoved()Z

    move-result v1

    if-nez v1, :cond_1

    invoke-virtual {v0}, Landroid/support/v7/widget/Bb;->isItemChanged()Z

    move-result v0

    if-eqz v0, :cond_2

    :cond_1
    iget v0, p0, Landroid/support/v7/widget/bc;->fs:I

    iget-object v1, p0, Landroid/support/v7/widget/bc;->n:Landroid/support/v7/widget/StaggeredGridLayoutManager;

    iget-object v1, v1, Landroid/support/v7/widget/StaggeredGridLayoutManager;->Tq:Landroid/support/v7/widget/hb;

    invoke-virtual {v1, p1}, Landroid/support/v7/widget/hb;->getDecoratedMeasurement(Landroid/view/View;)I

    move-result p1

    add-int/2addr p1, v0

    iput p1, p0, Landroid/support/v7/widget/bc;->fs:I

    :cond_2
    return-void
.end method

.method E(Landroid/view/View;)V
    .locals 4

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/bc;->getLayoutParams(Landroid/view/View;)Landroid/support/v7/widget/Yb;

    move-result-object v0

    iput-object p0, v0, Landroid/support/v7/widget/Yb;->_w:Landroid/support/v7/widget/bc;

    iget-object v1, p0, Landroid/support/v7/widget/bc;->cs:Ljava/util/ArrayList;

    const/4 v2, 0x0

    invoke-virtual {v1, v2, p1}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    const/high16 v1, -0x80000000

    iput v1, p0, Landroid/support/v7/widget/bc;->ds:I

    iget-object v2, p0, Landroid/support/v7/widget/bc;->cs:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v3, 0x1

    if-ne v2, v3, :cond_0

    iput v1, p0, Landroid/support/v7/widget/bc;->es:I

    :cond_0
    invoke-virtual {v0}, Landroid/support/v7/widget/Bb;->isItemRemoved()Z

    move-result v1

    if-nez v1, :cond_1

    invoke-virtual {v0}, Landroid/support/v7/widget/Bb;->isItemChanged()Z

    move-result v0

    if-eqz v0, :cond_2

    :cond_1
    iget v0, p0, Landroid/support/v7/widget/bc;->fs:I

    iget-object v1, p0, Landroid/support/v7/widget/bc;->n:Landroid/support/v7/widget/StaggeredGridLayoutManager;

    iget-object v1, v1, Landroid/support/v7/widget/StaggeredGridLayoutManager;->Tq:Landroid/support/v7/widget/hb;

    invoke-virtual {v1, p1}, Landroid/support/v7/widget/hb;->getDecoratedMeasurement(Landroid/view/View;)I

    move-result p1

    add-int/2addr p1, v0

    iput p1, p0, Landroid/support/v7/widget/bc;->fs:I

    :cond_2
    return-void
.end method

.method a(IIZ)I
    .locals 10

    .line 1
    iget-object v0, p0, Landroid/support/v7/widget/bc;->n:Landroid/support/v7/widget/StaggeredGridLayoutManager;

    iget-object v0, v0, Landroid/support/v7/widget/StaggeredGridLayoutManager;->Tq:Landroid/support/v7/widget/hb;

    invoke-virtual {v0}, Landroid/support/v7/widget/hb;->getStartAfterPadding()I

    move-result v0

    iget-object v1, p0, Landroid/support/v7/widget/bc;->n:Landroid/support/v7/widget/StaggeredGridLayoutManager;

    iget-object v1, v1, Landroid/support/v7/widget/StaggeredGridLayoutManager;->Tq:Landroid/support/v7/widget/hb;

    invoke-virtual {v1}, Landroid/support/v7/widget/hb;->getEndAfterPadding()I

    move-result v1

    const/4 v2, -0x1

    const/4 v3, 0x1

    if-le p2, p1, :cond_0

    move v4, v3

    goto :goto_0

    :cond_0
    move v4, v2

    :goto_0
    if-eq p1, p2, :cond_7

    iget-object v5, p0, Landroid/support/v7/widget/bc;->cs:Ljava/util/ArrayList;

    invoke-virtual {v5, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/view/View;

    iget-object v6, p0, Landroid/support/v7/widget/bc;->n:Landroid/support/v7/widget/StaggeredGridLayoutManager;

    iget-object v6, v6, Landroid/support/v7/widget/StaggeredGridLayoutManager;->Tq:Landroid/support/v7/widget/hb;

    invoke-virtual {v6, v5}, Landroid/support/v7/widget/hb;->getDecoratedStart(Landroid/view/View;)I

    move-result v6

    iget-object v7, p0, Landroid/support/v7/widget/bc;->n:Landroid/support/v7/widget/StaggeredGridLayoutManager;

    iget-object v7, v7, Landroid/support/v7/widget/StaggeredGridLayoutManager;->Tq:Landroid/support/v7/widget/hb;

    invoke-virtual {v7, v5}, Landroid/support/v7/widget/hb;->getDecoratedEnd(Landroid/view/View;)I

    move-result v7

    const/4 v8, 0x0

    if-eqz p3, :cond_1

    if-gt v6, v1, :cond_2

    goto :goto_1

    :cond_1
    if-ge v6, v1, :cond_2

    :goto_1
    move v9, v3

    goto :goto_2

    :cond_2
    move v9, v8

    :goto_2
    if-eqz p3, :cond_3

    if-lt v7, v0, :cond_4

    goto :goto_3

    :cond_3
    if-le v7, v0, :cond_4

    :goto_3
    move v8, v3

    :cond_4
    if-eqz v9, :cond_6

    if-eqz v8, :cond_6

    if-lt v6, v0, :cond_5

    if-le v7, v1, :cond_6

    :cond_5
    iget-object p0, p0, Landroid/support/v7/widget/bc;->n:Landroid/support/v7/widget/StaggeredGridLayoutManager;

    invoke-virtual {p0, v5}, Landroid/support/v7/widget/Ab;->getPosition(Landroid/view/View;)I

    move-result v2

    goto :goto_4

    :cond_6
    add-int/2addr p1, v4

    goto :goto_0

    :cond_7
    :goto_4
    return v2
.end method

.method clear()V
    .locals 1

    iget-object v0, p0, Landroid/support/v7/widget/bc;->cs:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/high16 v0, -0x80000000

    .line 1
    iput v0, p0, Landroid/support/v7/widget/bc;->ds:I

    iput v0, p0, Landroid/support/v7/widget/bc;->es:I

    const/4 v0, 0x0

    .line 2
    iput v0, p0, Landroid/support/v7/widget/bc;->fs:I

    return-void
.end method

.method ga(I)I
    .locals 2

    iget v0, p0, Landroid/support/v7/widget/bc;->es:I

    const/high16 v1, -0x80000000

    if-eq v0, v1, :cond_0

    return v0

    :cond_0
    iget-object v0, p0, Landroid/support/v7/widget/bc;->cs:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-nez v0, :cond_1

    return p1

    :cond_1
    invoke-virtual {p0}, Landroid/support/v7/widget/bc;->nb()V

    iget p0, p0, Landroid/support/v7/widget/bc;->es:I

    return p0
.end method

.method getLayoutParams(Landroid/view/View;)Landroid/support/v7/widget/Yb;
    .locals 0

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p0

    check-cast p0, Landroid/support/v7/widget/Yb;

    return-object p0
.end method

.method ha(I)I
    .locals 2

    iget v0, p0, Landroid/support/v7/widget/bc;->ds:I

    const/high16 v1, -0x80000000

    if-eq v0, v1, :cond_0

    return v0

    :cond_0
    iget-object v0, p0, Landroid/support/v7/widget/bc;->cs:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-nez v0, :cond_1

    return p1

    :cond_1
    invoke-virtual {p0}, Landroid/support/v7/widget/bc;->ob()V

    iget p0, p0, Landroid/support/v7/widget/bc;->ds:I

    return p0
.end method

.method nb()V
    .locals 4

    iget-object v0, p0, Landroid/support/v7/widget/bc;->cs:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v2, 0x1

    sub-int/2addr v1, v2

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    invoke-virtual {p0, v0}, Landroid/support/v7/widget/bc;->getLayoutParams(Landroid/view/View;)Landroid/support/v7/widget/Yb;

    move-result-object v1

    iget-object v3, p0, Landroid/support/v7/widget/bc;->n:Landroid/support/v7/widget/StaggeredGridLayoutManager;

    iget-object v3, v3, Landroid/support/v7/widget/StaggeredGridLayoutManager;->Tq:Landroid/support/v7/widget/hb;

    invoke-virtual {v3, v0}, Landroid/support/v7/widget/hb;->getDecoratedEnd(Landroid/view/View;)I

    move-result v0

    iput v0, p0, Landroid/support/v7/widget/bc;->es:I

    iget-boolean v0, v1, Landroid/support/v7/widget/Yb;->ax:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroid/support/v7/widget/bc;->n:Landroid/support/v7/widget/StaggeredGridLayoutManager;

    iget-object v0, v0, Landroid/support/v7/widget/StaggeredGridLayoutManager;->Xq:Landroid/support/v7/widget/_b;

    invoke-virtual {v1}, Landroid/support/v7/widget/Bb;->getViewLayoutPosition()I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/support/v7/widget/_b;->ea(I)Landroid/support/v7/widget/StaggeredGridLayoutManager$LazySpanLookup$FullSpanItem;

    move-result-object v0

    if-eqz v0, :cond_0

    iget v1, v0, Landroid/support/v7/widget/StaggeredGridLayoutManager$LazySpanLookup$FullSpanItem;->Ur:I

    if-ne v1, v2, :cond_0

    iget v1, p0, Landroid/support/v7/widget/bc;->es:I

    iget v2, p0, Landroid/support/v7/widget/bc;->mIndex:I

    invoke-virtual {v0, v2}, Landroid/support/v7/widget/StaggeredGridLayoutManager$LazySpanLookup$FullSpanItem;->ba(I)I

    move-result v0

    add-int/2addr v1, v0

    iput v1, p0, Landroid/support/v7/widget/bc;->es:I

    :cond_0
    return-void
.end method

.method public o(II)Landroid/view/View;
    .locals 5

    const/4 v0, -0x1

    const/4 v1, 0x0

    if-ne p2, v0, :cond_2

    iget-object p2, p0, Landroid/support/v7/widget/bc;->cs:Ljava/util/ArrayList;

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    const/4 v0, 0x0

    :goto_0
    if-ge v0, p2, :cond_5

    iget-object v2, p0, Landroid/support/v7/widget/bc;->cs:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/view/View;

    iget-object v3, p0, Landroid/support/v7/widget/bc;->n:Landroid/support/v7/widget/StaggeredGridLayoutManager;

    iget-boolean v4, v3, Landroid/support/v7/widget/StaggeredGridLayoutManager;->Fq:Z

    if-eqz v4, :cond_0

    invoke-virtual {v3, v2}, Landroid/support/v7/widget/Ab;->getPosition(Landroid/view/View;)I

    move-result v3

    if-le v3, p1, :cond_5

    :cond_0
    iget-object v3, p0, Landroid/support/v7/widget/bc;->n:Landroid/support/v7/widget/StaggeredGridLayoutManager;

    iget-boolean v4, v3, Landroid/support/v7/widget/StaggeredGridLayoutManager;->Fq:Z

    if-nez v4, :cond_1

    invoke-virtual {v3, v2}, Landroid/support/v7/widget/Ab;->getPosition(Landroid/view/View;)I

    move-result v3

    if-lt v3, p1, :cond_1

    goto :goto_2

    :cond_1
    invoke-virtual {v2}, Landroid/view/View;->hasFocusable()Z

    move-result v3

    if-eqz v3, :cond_5

    add-int/lit8 v0, v0, 0x1

    move-object v1, v2

    goto :goto_0

    :cond_2
    iget-object p2, p0, Landroid/support/v7/widget/bc;->cs:Ljava/util/ArrayList;

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    add-int/lit8 p2, p2, -0x1

    :goto_1
    if-ltz p2, :cond_5

    iget-object v0, p0, Landroid/support/v7/widget/bc;->cs:Ljava/util/ArrayList;

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    iget-object v2, p0, Landroid/support/v7/widget/bc;->n:Landroid/support/v7/widget/StaggeredGridLayoutManager;

    iget-boolean v3, v2, Landroid/support/v7/widget/StaggeredGridLayoutManager;->Fq:Z

    if-eqz v3, :cond_3

    invoke-virtual {v2, v0}, Landroid/support/v7/widget/Ab;->getPosition(Landroid/view/View;)I

    move-result v2

    if-ge v2, p1, :cond_5

    :cond_3
    iget-object v2, p0, Landroid/support/v7/widget/bc;->n:Landroid/support/v7/widget/StaggeredGridLayoutManager;

    iget-boolean v3, v2, Landroid/support/v7/widget/StaggeredGridLayoutManager;->Fq:Z

    if-nez v3, :cond_4

    invoke-virtual {v2, v0}, Landroid/support/v7/widget/Ab;->getPosition(Landroid/view/View;)I

    move-result v2

    if-gt v2, p1, :cond_4

    goto :goto_2

    :cond_4
    invoke-virtual {v0}, Landroid/view/View;->hasFocusable()Z

    move-result v2

    if-eqz v2, :cond_5

    add-int/lit8 p2, p2, -0x1

    move-object v1, v0

    goto :goto_1

    :cond_5
    :goto_2
    return-object v1
.end method

.method ob()V
    .locals 3

    iget-object v0, p0, Landroid/support/v7/widget/bc;->cs:Ljava/util/ArrayList;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    invoke-virtual {p0, v0}, Landroid/support/v7/widget/bc;->getLayoutParams(Landroid/view/View;)Landroid/support/v7/widget/Yb;

    move-result-object v1

    iget-object v2, p0, Landroid/support/v7/widget/bc;->n:Landroid/support/v7/widget/StaggeredGridLayoutManager;

    iget-object v2, v2, Landroid/support/v7/widget/StaggeredGridLayoutManager;->Tq:Landroid/support/v7/widget/hb;

    invoke-virtual {v2, v0}, Landroid/support/v7/widget/hb;->getDecoratedStart(Landroid/view/View;)I

    move-result v0

    iput v0, p0, Landroid/support/v7/widget/bc;->ds:I

    iget-boolean v0, v1, Landroid/support/v7/widget/Yb;->ax:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroid/support/v7/widget/bc;->n:Landroid/support/v7/widget/StaggeredGridLayoutManager;

    iget-object v0, v0, Landroid/support/v7/widget/StaggeredGridLayoutManager;->Xq:Landroid/support/v7/widget/_b;

    invoke-virtual {v1}, Landroid/support/v7/widget/Bb;->getViewLayoutPosition()I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/support/v7/widget/_b;->ea(I)Landroid/support/v7/widget/StaggeredGridLayoutManager$LazySpanLookup$FullSpanItem;

    move-result-object v0

    if-eqz v0, :cond_0

    iget v1, v0, Landroid/support/v7/widget/StaggeredGridLayoutManager$LazySpanLookup$FullSpanItem;->Ur:I

    const/4 v2, -0x1

    if-ne v1, v2, :cond_0

    iget v1, p0, Landroid/support/v7/widget/bc;->ds:I

    iget v2, p0, Landroid/support/v7/widget/bc;->mIndex:I

    invoke-virtual {v0, v2}, Landroid/support/v7/widget/StaggeredGridLayoutManager$LazySpanLookup$FullSpanItem;->ba(I)I

    move-result v0

    sub-int/2addr v1, v0

    iput v1, p0, Landroid/support/v7/widget/bc;->ds:I

    :cond_0
    return-void
.end method

.method public pb()I
    .locals 3

    iget-object v0, p0, Landroid/support/v7/widget/bc;->n:Landroid/support/v7/widget/StaggeredGridLayoutManager;

    iget-boolean v0, v0, Landroid/support/v7/widget/StaggeredGridLayoutManager;->Fq:Z

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroid/support/v7/widget/bc;->cs:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    sub-int/2addr v0, v1

    const/4 v2, -0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    iget-object v2, p0, Landroid/support/v7/widget/bc;->cs:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    :goto_0
    invoke-virtual {p0, v0, v2, v1}, Landroid/support/v7/widget/bc;->a(IIZ)I

    move-result p0

    return p0
.end method

.method public qb()I
    .locals 3

    iget-object v0, p0, Landroid/support/v7/widget/bc;->n:Landroid/support/v7/widget/StaggeredGridLayoutManager;

    iget-boolean v0, v0, Landroid/support/v7/widget/StaggeredGridLayoutManager;->Fq:Z

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    iget-object v2, p0, Landroid/support/v7/widget/bc;->cs:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    goto :goto_0

    :cond_0
    iget-object v0, p0, Landroid/support/v7/widget/bc;->cs:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    sub-int/2addr v0, v1

    const/4 v2, -0x1

    :goto_0
    invoke-virtual {p0, v0, v2, v1}, Landroid/support/v7/widget/bc;->a(IIZ)I

    move-result p0

    return p0
.end method

.method rb()I
    .locals 2

    iget v0, p0, Landroid/support/v7/widget/bc;->es:I

    const/high16 v1, -0x80000000

    if-eq v0, v1, :cond_0

    return v0

    :cond_0
    invoke-virtual {p0}, Landroid/support/v7/widget/bc;->nb()V

    iget p0, p0, Landroid/support/v7/widget/bc;->es:I

    return p0
.end method

.method sb()I
    .locals 2

    iget v0, p0, Landroid/support/v7/widget/bc;->ds:I

    const/high16 v1, -0x80000000

    if-eq v0, v1, :cond_0

    return v0

    :cond_0
    invoke-virtual {p0}, Landroid/support/v7/widget/bc;->ob()V

    iget p0, p0, Landroid/support/v7/widget/bc;->ds:I

    return p0
.end method

.method tb()V
    .locals 4

    iget-object v0, p0, Landroid/support/v7/widget/bc;->cs:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    iget-object v1, p0, Landroid/support/v7/widget/bc;->cs:Ljava/util/ArrayList;

    add-int/lit8 v2, v0, -0x1

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/view/View;

    invoke-virtual {p0, v1}, Landroid/support/v7/widget/bc;->getLayoutParams(Landroid/view/View;)Landroid/support/v7/widget/Yb;

    move-result-object v2

    const/4 v3, 0x0

    iput-object v3, v2, Landroid/support/v7/widget/Yb;->_w:Landroid/support/v7/widget/bc;

    invoke-virtual {v2}, Landroid/support/v7/widget/Bb;->isItemRemoved()Z

    move-result v3

    if-nez v3, :cond_0

    invoke-virtual {v2}, Landroid/support/v7/widget/Bb;->isItemChanged()Z

    move-result v2

    if-eqz v2, :cond_1

    :cond_0
    iget v2, p0, Landroid/support/v7/widget/bc;->fs:I

    iget-object v3, p0, Landroid/support/v7/widget/bc;->n:Landroid/support/v7/widget/StaggeredGridLayoutManager;

    iget-object v3, v3, Landroid/support/v7/widget/StaggeredGridLayoutManager;->Tq:Landroid/support/v7/widget/hb;

    invoke-virtual {v3, v1}, Landroid/support/v7/widget/hb;->getDecoratedMeasurement(Landroid/view/View;)I

    move-result v1

    sub-int/2addr v2, v1

    iput v2, p0, Landroid/support/v7/widget/bc;->fs:I

    :cond_1
    const/high16 v1, -0x80000000

    const/4 v2, 0x1

    if-ne v0, v2, :cond_2

    iput v1, p0, Landroid/support/v7/widget/bc;->ds:I

    :cond_2
    iput v1, p0, Landroid/support/v7/widget/bc;->es:I

    return-void
.end method

.method ub()V
    .locals 4

    iget-object v0, p0, Landroid/support/v7/widget/bc;->cs:Ljava/util/ArrayList;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    invoke-virtual {p0, v0}, Landroid/support/v7/widget/bc;->getLayoutParams(Landroid/view/View;)Landroid/support/v7/widget/Yb;

    move-result-object v1

    const/4 v2, 0x0

    iput-object v2, v1, Landroid/support/v7/widget/Yb;->_w:Landroid/support/v7/widget/bc;

    iget-object v2, p0, Landroid/support/v7/widget/bc;->cs:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/high16 v3, -0x80000000

    if-nez v2, :cond_0

    iput v3, p0, Landroid/support/v7/widget/bc;->es:I

    :cond_0
    invoke-virtual {v1}, Landroid/support/v7/widget/Bb;->isItemRemoved()Z

    move-result v2

    if-nez v2, :cond_1

    invoke-virtual {v1}, Landroid/support/v7/widget/Bb;->isItemChanged()Z

    move-result v1

    if-eqz v1, :cond_2

    :cond_1
    iget v1, p0, Landroid/support/v7/widget/bc;->fs:I

    iget-object v2, p0, Landroid/support/v7/widget/bc;->n:Landroid/support/v7/widget/StaggeredGridLayoutManager;

    iget-object v2, v2, Landroid/support/v7/widget/StaggeredGridLayoutManager;->Tq:Landroid/support/v7/widget/hb;

    invoke-virtual {v2, v0}, Landroid/support/v7/widget/hb;->getDecoratedMeasurement(Landroid/view/View;)I

    move-result v0

    sub-int/2addr v1, v0

    iput v1, p0, Landroid/support/v7/widget/bc;->fs:I

    :cond_2
    iput v3, p0, Landroid/support/v7/widget/bc;->ds:I

    return-void
.end method
