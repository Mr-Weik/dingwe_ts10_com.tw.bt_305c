.class public final Landroid/support/v7/widget/F;
.super Ljava/lang/Object;
.source ""


# static fields
.field private static INSTANCE:Landroid/support/v7/widget/F;

.field private static final mo:Landroid/graphics/PorterDuff$Mode;

.field private static final oo:Landroid/support/v7/widget/D;

.field private static final po:[I

.field private static final qo:[I

.field private static final ro:[I

.field private static final so:[I

.field private static final uo:[I

.field private static final vo:[I


# instance fields
.field private fo:Ljava/util/WeakHashMap;

.field private go:La/b/c/f/b;

.field private ho:La/b/c/f/q;

.field private final io:Ljava/lang/Object;

.field private final jo:Ljava/util/WeakHashMap;

.field private ko:Landroid/util/TypedValue;

.field private lo:Z


# direct methods
.method static constructor <clinit>()V
    .locals 2

    sget-object v0, Landroid/graphics/PorterDuff$Mode;->SRC_IN:Landroid/graphics/PorterDuff$Mode;

    sput-object v0, Landroid/support/v7/widget/F;->mo:Landroid/graphics/PorterDuff$Mode;

    new-instance v0, Landroid/support/v7/widget/D;

    const/4 v1, 0x6

    invoke-direct {v0, v1}, Landroid/support/v7/widget/D;-><init>(I)V

    sput-object v0, Landroid/support/v7/widget/F;->oo:Landroid/support/v7/widget/D;

    const/4 v0, 0x3

    new-array v1, v0, [I

    fill-array-data v1, :array_0

    sput-object v1, Landroid/support/v7/widget/F;->po:[I

    const/4 v1, 0x7

    new-array v1, v1, [I

    fill-array-data v1, :array_1

    sput-object v1, Landroid/support/v7/widget/F;->qo:[I

    const/16 v1, 0xa

    new-array v1, v1, [I

    fill-array-data v1, :array_2

    sput-object v1, Landroid/support/v7/widget/F;->ro:[I

    new-array v0, v0, [I

    fill-array-data v0, :array_3

    sput-object v0, Landroid/support/v7/widget/F;->so:[I

    const/4 v0, 0x2

    new-array v1, v0, [I

    fill-array-data v1, :array_4

    sput-object v1, Landroid/support/v7/widget/F;->uo:[I

    new-array v0, v0, [I

    fill-array-data v0, :array_5

    sput-object v0, Landroid/support/v7/widget/F;->vo:[I

    return-void

    :array_0
    .array-data 4
        0x7f070053
        0x7f070051
        0x7f070002
    .end array-data

    :array_1
    .array-data 4
        0x7f070018
        0x7f070041
        0x7f07001f
        0x7f07001a
        0x7f07001b
        0x7f07001e
        0x7f07001d
    .end array-data

    :array_2
    .array-data 4
        0x7f070050
        0x7f070052
        0x7f070011
        0x7f070049
        0x7f07004a
        0x7f07004c
        0x7f07004e
        0x7f07004b
        0x7f07004d
        0x7f07004f
    .end array-data

    :array_3
    .array-data 4
        0x7f070037
        0x7f07000f
        0x7f070036
    .end array-data

    :array_4
    .array-data 4
        0x7f070047
        0x7f070054
    .end array-data

    :array_5
    .array-data 4
        0x7f070005
        0x7f07000a
    .end array-data
.end method

.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Landroid/support/v7/widget/F;->io:Ljava/lang/Object;

    new-instance v0, Ljava/util/WeakHashMap;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/util/WeakHashMap;-><init>(I)V

    iput-object v0, p0, Landroid/support/v7/widget/F;->jo:Ljava/util/WeakHashMap;

    return-void
.end method

.method private static a(Landroid/util/TypedValue;)J
    .locals 4

    iget v0, p0, Landroid/util/TypedValue;->assetCookie:I

    int-to-long v0, v0

    const/16 v2, 0x20

    shl-long/2addr v0, v2

    iget p0, p0, Landroid/util/TypedValue;->data:I

    int-to-long v2, p0

    or-long/2addr v0, v2

    return-wide v0
.end method

.method private a(Landroid/content/Context;IZLandroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;
    .locals 6

    invoke-virtual {p0, p1, p2}, Landroid/support/v7/widget/F;->c(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    move-result-object p0

    const/4 v0, 0x0

    if-eqz p0, :cond_2

    invoke-static {p4}, Landroid/support/v7/widget/ta;->e(Landroid/graphics/drawable/Drawable;)Z

    move-result p1

    if-eqz p1, :cond_0

    invoke-virtual {p4}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object p4

    .line 10
    :cond_0
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 11
    invoke-virtual {p4, p0}, Landroid/graphics/drawable/Drawable;->setTintList(Landroid/content/res/ColorStateList;)V

    const p0, 0x7f070045

    if-ne p2, p0, :cond_1

    .line 12
    sget-object v0, Landroid/graphics/PorterDuff$Mode;->MULTIPLY:Landroid/graphics/PorterDuff$Mode;

    :cond_1
    if-eqz v0, :cond_6

    .line 13
    sget p0, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-virtual {p4, v0}, Landroid/graphics/drawable/Drawable;->setTintMode(Landroid/graphics/PorterDuff$Mode;)V

    goto/16 :goto_2

    :cond_2
    const p0, 0x7f070042

    const v1, 0x102000d

    const v2, 0x102000f

    const/high16 v3, 0x1020000

    const v4, 0x7f03004f

    const v5, 0x7f030051

    if-ne p2, p0, :cond_3

    .line 14
    move-object p0, p4

    check-cast p0, Landroid/graphics/drawable/LayerDrawable;

    invoke-virtual {p0, v3}, Landroid/graphics/drawable/LayerDrawable;->findDrawableByLayerId(I)Landroid/graphics/drawable/Drawable;

    move-result-object p2

    invoke-static {p1, v5}, Landroid/support/v7/widget/cc;->f(Landroid/content/Context;I)I

    move-result p3

    sget-object v0, Landroid/support/v7/widget/F;->mo:Landroid/graphics/PorterDuff$Mode;

    invoke-static {p2, p3, v0}, Landroid/support/v7/widget/F;->a(Landroid/graphics/drawable/Drawable;ILandroid/graphics/PorterDuff$Mode;)V

    invoke-virtual {p0, v2}, Landroid/graphics/drawable/LayerDrawable;->findDrawableByLayerId(I)Landroid/graphics/drawable/Drawable;

    move-result-object p2

    invoke-static {p1, v5}, Landroid/support/v7/widget/cc;->f(Landroid/content/Context;I)I

    move-result p3

    :goto_0
    sget-object v0, Landroid/support/v7/widget/F;->mo:Landroid/graphics/PorterDuff$Mode;

    invoke-static {p2, p3, v0}, Landroid/support/v7/widget/F;->a(Landroid/graphics/drawable/Drawable;ILandroid/graphics/PorterDuff$Mode;)V

    invoke-virtual {p0, v1}, Landroid/graphics/drawable/LayerDrawable;->findDrawableByLayerId(I)Landroid/graphics/drawable/Drawable;

    move-result-object p0

    invoke-static {p1, v4}, Landroid/support/v7/widget/cc;->f(Landroid/content/Context;I)I

    move-result p1

    sget-object p2, Landroid/support/v7/widget/F;->mo:Landroid/graphics/PorterDuff$Mode;

    invoke-static {p0, p1, p2}, Landroid/support/v7/widget/F;->a(Landroid/graphics/drawable/Drawable;ILandroid/graphics/PorterDuff$Mode;)V

    goto :goto_2

    :cond_3
    const p0, 0x7f070039

    if-eq p2, p0, :cond_5

    const p0, 0x7f070038

    if-eq p2, p0, :cond_5

    const p0, 0x7f07003a

    if-ne p2, p0, :cond_4

    goto :goto_1

    :cond_4
    invoke-static {p1, p2, p4}, Landroid/support/v7/widget/F;->a(Landroid/content/Context;ILandroid/graphics/drawable/Drawable;)Z

    move-result p0

    if-nez p0, :cond_6

    if-eqz p3, :cond_6

    move-object p4, v0

    goto :goto_2

    :cond_5
    :goto_1
    move-object p0, p4

    check-cast p0, Landroid/graphics/drawable/LayerDrawable;

    invoke-virtual {p0, v3}, Landroid/graphics/drawable/LayerDrawable;->findDrawableByLayerId(I)Landroid/graphics/drawable/Drawable;

    move-result-object p2

    invoke-static {p1, v5}, Landroid/support/v7/widget/cc;->e(Landroid/content/Context;I)I

    move-result p3

    sget-object v0, Landroid/support/v7/widget/F;->mo:Landroid/graphics/PorterDuff$Mode;

    invoke-static {p2, p3, v0}, Landroid/support/v7/widget/F;->a(Landroid/graphics/drawable/Drawable;ILandroid/graphics/PorterDuff$Mode;)V

    invoke-virtual {p0, v2}, Landroid/graphics/drawable/LayerDrawable;->findDrawableByLayerId(I)Landroid/graphics/drawable/Drawable;

    move-result-object p2

    invoke-static {p1, v4}, Landroid/support/v7/widget/cc;->f(Landroid/content/Context;I)I

    move-result p3

    goto :goto_0

    :cond_6
    :goto_2
    return-object p4
.end method

.method private a(Landroid/content/Context;J)Landroid/graphics/drawable/Drawable;
    .locals 3

    iget-object v0, p0, Landroid/support/v7/widget/F;->io:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    iget-object p0, p0, Landroid/support/v7/widget/F;->jo:Ljava/util/WeakHashMap;

    invoke-virtual {p0, p1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, La/b/c/f/g;

    const/4 v1, 0x0

    if-nez p0, :cond_0

    monitor-exit v0

    return-object v1

    :cond_0
    invoke-virtual {p0, p2, p3}, La/b/c/f/g;->get(J)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/ref/WeakReference;

    if-eqz v2, :cond_2

    invoke-virtual {v2}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/graphics/drawable/Drawable$ConstantState;

    if-eqz v2, :cond_1

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {v2, p0}, Landroid/graphics/drawable/Drawable$ConstantState;->newDrawable(Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;

    move-result-object p0

    monitor-exit v0

    return-object p0

    :cond_1
    invoke-virtual {p0, p2, p3}, La/b/c/f/g;->delete(J)V

    :cond_2
    monitor-exit v0

    return-object v1

    :catchall_0
    move-exception p0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p0
.end method

.method private static a(Landroid/graphics/drawable/Drawable;ILandroid/graphics/PorterDuff$Mode;)V
    .locals 1

    invoke-static {p0}, Landroid/support/v7/widget/ta;->e(Landroid/graphics/drawable/Drawable;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object p0

    :cond_0
    if-nez p2, :cond_1

    sget-object p2, Landroid/support/v7/widget/F;->mo:Landroid/graphics/PorterDuff$Mode;

    :cond_1
    invoke-static {p1, p2}, Landroid/support/v7/widget/F;->b(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/graphics/drawable/Drawable;->setColorFilter(Landroid/graphics/ColorFilter;)V

    return-void
.end method

.method static a(Landroid/graphics/drawable/Drawable;Landroid/support/v7/widget/fc;[I)V
    .locals 3

    invoke-static {p0}, Landroid/support/v7/widget/ta;->e(Landroid/graphics/drawable/Drawable;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    if-eq v0, p0, :cond_0

    const-string p0, "AppCompatDrawableManag"

    const-string p1, "Mutated drawable is not the same instance as the input."

    invoke-static {p0, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    iget-boolean v0, p1, Landroid/support/v7/widget/fc;->mHasTintList:Z

    if-nez v0, :cond_2

    iget-boolean v0, p1, Landroid/support/v7/widget/fc;->mHasTintMode:Z

    if-eqz v0, :cond_1

    goto :goto_0

    :cond_1
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->clearColorFilter()V

    goto :goto_4

    :cond_2
    :goto_0
    iget-boolean v0, p1, Landroid/support/v7/widget/fc;->mHasTintList:Z

    const/4 v1, 0x0

    if-eqz v0, :cond_3

    iget-object v0, p1, Landroid/support/v7/widget/fc;->mTintList:Landroid/content/res/ColorStateList;

    goto :goto_1

    :cond_3
    move-object v0, v1

    :goto_1
    iget-boolean v2, p1, Landroid/support/v7/widget/fc;->mHasTintMode:Z

    if-eqz v2, :cond_4

    iget-object p1, p1, Landroid/support/v7/widget/fc;->is:Landroid/graphics/PorterDuff$Mode;

    goto :goto_2

    :cond_4
    sget-object p1, Landroid/support/v7/widget/F;->mo:Landroid/graphics/PorterDuff$Mode;

    :goto_2
    if-eqz v0, :cond_6

    if-nez p1, :cond_5

    goto :goto_3

    :cond_5
    const/4 v1, 0x0

    .line 15
    invoke-virtual {v0, p2, v1}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    move-result p2

    invoke-static {p2, p1}, Landroid/support/v7/widget/F;->b(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;

    move-result-object v1

    .line 16
    :cond_6
    :goto_3
    invoke-virtual {p0, v1}, Landroid/graphics/drawable/Drawable;->setColorFilter(Landroid/graphics/ColorFilter;)V

    :goto_4
    sget p0, Landroid/os/Build$VERSION;->SDK_INT:I

    return-void
.end method

.method static a(Landroid/content/Context;ILandroid/graphics/drawable/Drawable;)Z
    .locals 6

    sget-object v0, Landroid/support/v7/widget/F;->mo:Landroid/graphics/PorterDuff$Mode;

    sget-object v1, Landroid/support/v7/widget/F;->po:[I

    invoke-static {v1, p1}, Landroid/support/v7/widget/F;->a([II)Z

    move-result v1

    const v2, 0x1010031

    const/4 v3, -0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eqz v1, :cond_0

    const v2, 0x7f030051

    :goto_0
    move v1, v3

    :goto_1
    move p1, v5

    goto :goto_2

    :cond_0
    sget-object v1, Landroid/support/v7/widget/F;->ro:[I

    invoke-static {v1, p1}, Landroid/support/v7/widget/F;->a([II)Z

    move-result v1

    if-eqz v1, :cond_1

    const v2, 0x7f03004f

    goto :goto_0

    :cond_1
    sget-object v1, Landroid/support/v7/widget/F;->so:[I

    invoke-static {v1, p1}, Landroid/support/v7/widget/F;->a([II)Z

    move-result v1

    if-eqz v1, :cond_2

    sget-object v0, Landroid/graphics/PorterDuff$Mode;->MULTIPLY:Landroid/graphics/PorterDuff$Mode;

    goto :goto_0

    :cond_2
    const v1, 0x7f07002b

    if-ne p1, v1, :cond_3

    const v2, 0x1010030

    const p1, 0x42233333    # 40.8f

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    move v1, p1

    goto :goto_1

    :cond_3
    const v1, 0x7f070013

    if-ne p1, v1, :cond_4

    goto :goto_0

    :cond_4
    move v1, v3

    move p1, v4

    move v2, p1

    :goto_2
    if-eqz p1, :cond_7

    invoke-static {p2}, Landroid/support/v7/widget/ta;->e(Landroid/graphics/drawable/Drawable;)Z

    move-result p1

    if-eqz p1, :cond_5

    invoke-virtual {p2}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object p2

    :cond_5
    invoke-static {p0, v2}, Landroid/support/v7/widget/cc;->f(Landroid/content/Context;I)I

    move-result p0

    invoke-static {p0, v0}, Landroid/support/v7/widget/F;->b(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;

    move-result-object p0

    invoke-virtual {p2, p0}, Landroid/graphics/drawable/Drawable;->setColorFilter(Landroid/graphics/ColorFilter;)V

    if-eq v1, v3, :cond_6

    invoke-virtual {p2, v1}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    :cond_6
    return v5

    :cond_7
    return v4
.end method

.method private a(Landroid/content/Context;JLandroid/graphics/drawable/Drawable;)Z
    .locals 2

    invoke-virtual {p4}, Landroid/graphics/drawable/Drawable;->getConstantState()Landroid/graphics/drawable/Drawable$ConstantState;

    move-result-object p4

    if-eqz p4, :cond_1

    iget-object v0, p0, Landroid/support/v7/widget/F;->io:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, Landroid/support/v7/widget/F;->jo:Ljava/util/WeakHashMap;

    invoke-virtual {v1, p1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/b/c/f/g;

    if-nez v1, :cond_0

    new-instance v1, La/b/c/f/g;

    invoke-direct {v1}, La/b/c/f/g;-><init>()V

    iget-object p0, p0, Landroid/support/v7/widget/F;->jo:Ljava/util/WeakHashMap;

    invoke-virtual {p0, p1, v1}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    new-instance p0, Ljava/lang/ref/WeakReference;

    invoke-direct {p0, p4}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    invoke-virtual {v1, p2, p3, p0}, La/b/c/f/g;->put(JLjava/lang/Object;)V

    monitor-exit v0

    const/4 p0, 0x1

    return p0

    :catchall_0
    move-exception p0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p0

    :cond_1
    const/4 p0, 0x0

    return p0
.end method

.method private static a([II)Z
    .locals 4

    array-length v0, p0

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    if-ge v2, v0, :cond_1

    aget v3, p0, v2

    if-ne v3, p1, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    return v1
.end method

.method public static b(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;
    .locals 2

    sget-object v0, Landroid/support/v7/widget/F;->oo:Landroid/support/v7/widget/D;

    invoke-virtual {v0, p0, p1}, Landroid/support/v7/widget/D;->a(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;

    move-result-object v0

    if-nez v0, :cond_0

    new-instance v0, Landroid/graphics/PorterDuffColorFilter;

    invoke-direct {v0, p0, p1}, Landroid/graphics/PorterDuffColorFilter;-><init>(ILandroid/graphics/PorterDuff$Mode;)V

    sget-object v1, Landroid/support/v7/widget/F;->oo:Landroid/support/v7/widget/D;

    invoke-virtual {v1, p0, p1, v0}, Landroid/support/v7/widget/D;->a(ILandroid/graphics/PorterDuff$Mode;Landroid/graphics/PorterDuffColorFilter;)Landroid/graphics/PorterDuffColorFilter;

    :cond_0
    return-object v0
.end method

.method public static get()Landroid/support/v7/widget/F;
    .locals 1

    sget-object v0, Landroid/support/v7/widget/F;->INSTANCE:Landroid/support/v7/widget/F;

    if-nez v0, :cond_0

    new-instance v0, Landroid/support/v7/widget/F;

    invoke-direct {v0}, Landroid/support/v7/widget/F;-><init>()V

    sput-object v0, Landroid/support/v7/widget/F;->INSTANCE:Landroid/support/v7/widget/F;

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2
    :cond_0
    sget-object v0, Landroid/support/v7/widget/F;->INSTANCE:Landroid/support/v7/widget/F;

    return-object v0
.end method

.method private h(Landroid/content/Context;I)Landroid/content/res/ColorStateList;
    .locals 4

    const/4 p0, 0x4

    new-array v0, p0, [[I

    new-array p0, p0, [I

    const v1, 0x7f030050

    invoke-static {p1, v1}, Landroid/support/v7/widget/cc;->f(Landroid/content/Context;I)I

    move-result v1

    const v2, 0x7f03004e

    invoke-static {p1, v2}, Landroid/support/v7/widget/cc;->e(Landroid/content/Context;I)I

    move-result p1

    sget-object v2, Landroid/support/v7/widget/cc;->gs:[I

    const/4 v3, 0x0

    aput-object v2, v0, v3

    aput p1, p0, v3

    sget-object p1, Landroid/support/v7/widget/cc;->PRESSED_STATE_SET:[I

    const/4 v2, 0x1

    aput-object p1, v0, v2

    invoke-static {v1, p2}, La/b/c/b/a;->compositeColors(II)I

    move-result p1

    aput p1, p0, v2

    sget-object p1, Landroid/support/v7/widget/cc;->FOCUSED_STATE_SET:[I

    const/4 v2, 0x2

    aput-object p1, v0, v2

    invoke-static {v1, p2}, La/b/c/b/a;->compositeColors(II)I

    move-result p1

    aput p1, p0, v2

    sget-object p1, Landroid/support/v7/widget/cc;->EMPTY_STATE_SET:[I

    const/4 v1, 0x3

    aput-object p1, v0, v1

    aput p2, p0, v1

    new-instance p1, Landroid/content/res/ColorStateList;

    invoke-direct {p1, v0, p0}, Landroid/content/res/ColorStateList;-><init>([[I[I)V

    return-object p1
.end method

.method private i(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    .locals 10

    iget-object v0, p0, Landroid/support/v7/widget/F;->go:La/b/c/f/b;

    const/4 v1, 0x0

    if-eqz v0, :cond_a

    invoke-virtual {v0}, La/b/c/f/p;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_a

    iget-object v0, p0, Landroid/support/v7/widget/F;->ho:La/b/c/f/q;

    const-string v2, "appcompat_skip_skip"

    if-eqz v0, :cond_1

    invoke-virtual {v0, p2}, La/b/c/f/q;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_0

    if-eqz v0, :cond_2

    iget-object v3, p0, Landroid/support/v7/widget/F;->go:La/b/c/f/b;

    invoke-virtual {v3, v0}, La/b/c/f/p;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_2

    :cond_0
    return-object v1

    :cond_1
    new-instance v0, La/b/c/f/q;

    const/16 v1, 0xa

    .line 1
    invoke-direct {v0, v1}, La/b/c/f/q;-><init>(I)V

    .line 2
    iput-object v0, p0, Landroid/support/v7/widget/F;->ho:La/b/c/f/q;

    :cond_2
    iget-object v0, p0, Landroid/support/v7/widget/F;->ko:Landroid/util/TypedValue;

    if-nez v0, :cond_3

    new-instance v0, Landroid/util/TypedValue;

    invoke-direct {v0}, Landroid/util/TypedValue;-><init>()V

    iput-object v0, p0, Landroid/support/v7/widget/F;->ko:Landroid/util/TypedValue;

    :cond_3
    iget-object v0, p0, Landroid/support/v7/widget/F;->ko:Landroid/util/TypedValue;

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const/4 v3, 0x1

    invoke-virtual {v1, p2, v0, v3}, Landroid/content/res/Resources;->getValue(ILandroid/util/TypedValue;Z)V

    .line 3
    iget v4, v0, Landroid/util/TypedValue;->assetCookie:I

    int-to-long v4, v4

    const/16 v6, 0x20

    shl-long/2addr v4, v6

    iget v6, v0, Landroid/util/TypedValue;->data:I

    int-to-long v6, v6

    or-long/2addr v4, v6

    .line 4
    invoke-direct {p0, p1, v4, v5}, Landroid/support/v7/widget/F;->a(Landroid/content/Context;J)Landroid/graphics/drawable/Drawable;

    move-result-object v6

    if-eqz v6, :cond_4

    return-object v6

    :cond_4
    iget-object v7, v0, Landroid/util/TypedValue;->string:Ljava/lang/CharSequence;

    if-eqz v7, :cond_8

    invoke-interface {v7}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v7

    const-string v8, ".xml"

    invoke-virtual {v7, v8}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_8

    :try_start_0
    invoke-virtual {v1, p2}, Landroid/content/res/Resources;->getXml(I)Landroid/content/res/XmlResourceParser;

    move-result-object v1

    invoke-static {v1}, Landroid/util/Xml;->asAttributeSet(Lorg/xmlpull/v1/XmlPullParser;)Landroid/util/AttributeSet;

    move-result-object v7

    :goto_0
    invoke-interface {v1}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    move-result v8

    const/4 v9, 0x2

    if-eq v8, v9, :cond_5

    if-eq v8, v3, :cond_5

    goto :goto_0

    :cond_5
    if-ne v8, v9, :cond_7

    invoke-interface {v1}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v3

    iget-object v8, p0, Landroid/support/v7/widget/F;->ho:La/b/c/f/q;

    invoke-virtual {v8, p2, v3}, La/b/c/f/q;->append(ILjava/lang/Object;)V

    iget-object v8, p0, Landroid/support/v7/widget/F;->go:La/b/c/f/b;

    invoke-virtual {v8, v3}, La/b/c/f/p;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/support/v7/widget/E;

    if-eqz v3, :cond_6

    invoke-virtual {p1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v8

    invoke-interface {v3, p1, v1, v7, v8}, Landroid/support/v7/widget/E;->a(Landroid/content/Context;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    move-result-object v6

    :cond_6
    if-eqz v6, :cond_8

    iget v0, v0, Landroid/util/TypedValue;->changingConfigurations:I

    invoke-virtual {v6, v0}, Landroid/graphics/drawable/Drawable;->setChangingConfigurations(I)V

    invoke-direct {p0, p1, v4, v5, v6}, Landroid/support/v7/widget/F;->a(Landroid/content/Context;JLandroid/graphics/drawable/Drawable;)Z

    goto :goto_1

    :cond_7
    new-instance p1, Lorg/xmlpull/v1/XmlPullParserException;

    const-string v0, "No start tag found"

    invoke-direct {p1, v0}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    move-exception p1

    const-string v0, "AppCompatDrawableManag"

    const-string v1, "Exception while inflating drawable"

    invoke-static {v0, v1, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_8
    :goto_1
    if-nez v6, :cond_9

    iget-object p0, p0, Landroid/support/v7/widget/F;->ho:La/b/c/f/q;

    invoke-virtual {p0, p2, v2}, La/b/c/f/q;->append(ILjava/lang/Object;)V

    :cond_9
    return-object v6

    :cond_a
    return-object v1
.end method


# virtual methods
.method public a(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    .locals 1

    const/4 v0, 0x0

    invoke-virtual {p0, p1, p2, v0}, Landroid/support/v7/widget/F;->a(Landroid/content/Context;IZ)Landroid/graphics/drawable/Drawable;

    move-result-object p0

    return-object p0
.end method

.method a(Landroid/content/Context;IZ)Landroid/graphics/drawable/Drawable;
    .locals 8

    .line 1
    iget-boolean v0, p0, Landroid/support/v7/widget/F;->lo:Z

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    goto :goto_2

    :cond_0
    iput-boolean v2, p0, Landroid/support/v7/widget/F;->lo:Z

    const v0, 0x7f070055

    .line 2
    invoke-virtual {p0, p1, v0, v1}, Landroid/support/v7/widget/F;->a(Landroid/content/Context;IZ)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    if-eqz v0, :cond_b

    .line 3
    instance-of v3, v0, La/b/b/a/b;

    if-nez v3, :cond_2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    const-string v3, "android.graphics.drawable.VectorDrawable"

    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    goto :goto_0

    :cond_1
    move v0, v1

    goto :goto_1

    :cond_2
    :goto_0
    move v0, v2

    :goto_1
    if-eqz v0, :cond_b

    .line 4
    :goto_2
    invoke-direct {p0, p1, p2}, Landroid/support/v7/widget/F;->i(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    if-nez v0, :cond_7

    .line 5
    iget-object v0, p0, Landroid/support/v7/widget/F;->ko:Landroid/util/TypedValue;

    if-nez v0, :cond_3

    new-instance v0, Landroid/util/TypedValue;

    invoke-direct {v0}, Landroid/util/TypedValue;-><init>()V

    iput-object v0, p0, Landroid/support/v7/widget/F;->ko:Landroid/util/TypedValue;

    :cond_3
    iget-object v0, p0, Landroid/support/v7/widget/F;->ko:Landroid/util/TypedValue;

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {v3, p2, v0, v2}, Landroid/content/res/Resources;->getValue(ILandroid/util/TypedValue;Z)V

    invoke-static {v0}, Landroid/support/v7/widget/F;->a(Landroid/util/TypedValue;)J

    move-result-wide v3

    invoke-direct {p0, p1, v3, v4}, Landroid/support/v7/widget/F;->a(Landroid/content/Context;J)Landroid/graphics/drawable/Drawable;

    move-result-object v5

    if-eqz v5, :cond_5

    :cond_4
    :goto_3
    move-object v0, v5

    goto :goto_4

    :cond_5
    const v6, 0x7f070010

    if-ne p2, v6, :cond_6

    new-instance v5, Landroid/graphics/drawable/LayerDrawable;

    const/4 v6, 0x2

    new-array v6, v6, [Landroid/graphics/drawable/Drawable;

    const v7, 0x7f07000f

    .line 6
    invoke-virtual {p0, p1, v7, v1}, Landroid/support/v7/widget/F;->a(Landroid/content/Context;IZ)Landroid/graphics/drawable/Drawable;

    move-result-object v7

    aput-object v7, v6, v1

    const v7, 0x7f070011

    invoke-virtual {p0, p1, v7, v1}, Landroid/support/v7/widget/F;->a(Landroid/content/Context;IZ)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    aput-object v1, v6, v2

    .line 7
    invoke-direct {v5, v6}, Landroid/graphics/drawable/LayerDrawable;-><init>([Landroid/graphics/drawable/Drawable;)V

    :cond_6
    if-eqz v5, :cond_4

    iget v0, v0, Landroid/util/TypedValue;->changingConfigurations:I

    invoke-virtual {v5, v0}, Landroid/graphics/drawable/Drawable;->setChangingConfigurations(I)V

    invoke-direct {p0, p1, v3, v4, v5}, Landroid/support/v7/widget/F;->a(Landroid/content/Context;JLandroid/graphics/drawable/Drawable;)Z

    goto :goto_3

    :cond_7
    :goto_4
    if-nez v0, :cond_8

    .line 8
    invoke-static {p1, p2}, La/b/c/a/a;->a(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    :cond_8
    if-eqz v0, :cond_9

    invoke-direct {p0, p1, p2, p3, v0}, Landroid/support/v7/widget/F;->a(Landroid/content/Context;IZLandroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    :cond_9
    if-eqz v0, :cond_a

    invoke-static {v0}, Landroid/support/v7/widget/ta;->f(Landroid/graphics/drawable/Drawable;)V

    :cond_a
    return-object v0

    .line 9
    :cond_b
    iput-boolean v1, p0, Landroid/support/v7/widget/F;->lo:Z

    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "This app has been built with an incorrect configuration. Please configure your build for VectorDrawableCompat."

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method c(Landroid/content/Context;I)Landroid/content/res/ColorStateList;
    .locals 9

    .line 1
    iget-object v0, p0, Landroid/support/v7/widget/F;->fo:Ljava/util/WeakHashMap;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/b/c/f/q;

    if-eqz v0, :cond_0

    invoke-virtual {v0, p2}, La/b/c/f/q;->get(I)Ljava/lang/Object;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Landroid/content/res/ColorStateList;

    :cond_0
    if-nez v1, :cond_10

    const v0, 0x7f070014

    if-ne p2, v0, :cond_1

    const v0, 0x7f050014

    .line 2
    :goto_0
    invoke-static {p1, v0}, La/b/d/b/a/a;->b(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    move-result-object v1

    goto/16 :goto_3

    :cond_1
    const v0, 0x7f070046

    if-ne p2, v0, :cond_2

    const v0, 0x7f050017

    goto :goto_0

    :cond_2
    const v0, 0x7f070045

    const/4 v2, 0x0

    if-ne p2, v0, :cond_4

    const/4 v0, 0x3

    new-array v1, v0, [[I

    new-array v0, v0, [I

    const v3, 0x7f030055

    .line 3
    invoke-static {p1, v3}, Landroid/support/v7/widget/cc;->g(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    move-result-object v4

    const/4 v5, 0x2

    const v6, 0x7f03004f

    const/4 v7, 0x1

    if-eqz v4, :cond_3

    invoke-virtual {v4}, Landroid/content/res/ColorStateList;->isStateful()Z

    move-result v8

    if-eqz v8, :cond_3

    sget-object v3, Landroid/support/v7/widget/cc;->gs:[I

    aput-object v3, v1, v2

    aget-object v3, v1, v2

    invoke-virtual {v4, v3, v2}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    move-result v3

    aput v3, v0, v2

    sget-object v2, Landroid/support/v7/widget/cc;->hs:[I

    aput-object v2, v1, v7

    invoke-static {p1, v6}, Landroid/support/v7/widget/cc;->f(Landroid/content/Context;I)I

    move-result v2

    aput v2, v0, v7

    sget-object v2, Landroid/support/v7/widget/cc;->EMPTY_STATE_SET:[I

    aput-object v2, v1, v5

    invoke-virtual {v4}, Landroid/content/res/ColorStateList;->getDefaultColor()I

    move-result v2

    aput v2, v0, v5

    goto :goto_1

    :cond_3
    sget-object v4, Landroid/support/v7/widget/cc;->gs:[I

    aput-object v4, v1, v2

    invoke-static {p1, v3}, Landroid/support/v7/widget/cc;->e(Landroid/content/Context;I)I

    move-result v4

    aput v4, v0, v2

    sget-object v2, Landroid/support/v7/widget/cc;->hs:[I

    aput-object v2, v1, v7

    invoke-static {p1, v6}, Landroid/support/v7/widget/cc;->f(Landroid/content/Context;I)I

    move-result v2

    aput v2, v0, v7

    sget-object v2, Landroid/support/v7/widget/cc;->EMPTY_STATE_SET:[I

    aput-object v2, v1, v5

    invoke-static {p1, v3}, Landroid/support/v7/widget/cc;->f(Landroid/content/Context;I)I

    move-result v2

    aput v2, v0, v5

    :goto_1
    new-instance v2, Landroid/content/res/ColorStateList;

    invoke-direct {v2, v1, v0}, Landroid/content/res/ColorStateList;-><init>([[I[I)V

    move-object v1, v2

    goto/16 :goto_3

    :cond_4
    const v0, 0x7f070009

    if-ne p2, v0, :cond_5

    const v0, 0x7f03004e

    .line 4
    invoke-static {p1, v0}, Landroid/support/v7/widget/cc;->f(Landroid/content/Context;I)I

    move-result v0

    invoke-direct {p0, p1, v0}, Landroid/support/v7/widget/F;->h(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    move-result-object v1

    goto :goto_3

    :cond_5
    const v0, 0x7f070004

    if-ne p2, v0, :cond_6

    .line 5
    invoke-direct {p0, p1, v2}, Landroid/support/v7/widget/F;->h(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    move-result-object v1

    goto :goto_3

    :cond_6
    const v0, 0x7f070008

    if-ne p2, v0, :cond_7

    const v0, 0x7f03004c

    .line 6
    invoke-static {p1, v0}, Landroid/support/v7/widget/cc;->f(Landroid/content/Context;I)I

    move-result v0

    invoke-direct {p0, p1, v0}, Landroid/support/v7/widget/F;->h(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    move-result-object v1

    goto :goto_3

    :cond_7
    const v0, 0x7f070043

    if-eq p2, v0, :cond_c

    const v0, 0x7f070044

    if-ne p2, v0, :cond_8

    goto :goto_2

    .line 7
    :cond_8
    sget-object v0, Landroid/support/v7/widget/F;->qo:[I

    invoke-static {v0, p2}, Landroid/support/v7/widget/F;->a([II)Z

    move-result v0

    if-eqz v0, :cond_9

    const v0, 0x7f030051

    invoke-static {p1, v0}, Landroid/support/v7/widget/cc;->g(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    move-result-object v1

    goto :goto_3

    :cond_9
    sget-object v0, Landroid/support/v7/widget/F;->uo:[I

    invoke-static {v0, p2}, Landroid/support/v7/widget/F;->a([II)Z

    move-result v0

    if-eqz v0, :cond_a

    const v0, 0x7f050013

    goto/16 :goto_0

    :cond_a
    sget-object v0, Landroid/support/v7/widget/F;->vo:[I

    invoke-static {v0, p2}, Landroid/support/v7/widget/F;->a([II)Z

    move-result v0

    if-eqz v0, :cond_b

    const v0, 0x7f050012

    goto/16 :goto_0

    :cond_b
    const v0, 0x7f070040

    if-ne p2, v0, :cond_d

    const v0, 0x7f050015

    goto/16 :goto_0

    :cond_c
    :goto_2
    const v0, 0x7f050016

    goto/16 :goto_0

    :cond_d
    :goto_3
    if-eqz v1, :cond_10

    .line 8
    iget-object v0, p0, Landroid/support/v7/widget/F;->fo:Ljava/util/WeakHashMap;

    if-nez v0, :cond_e

    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    iput-object v0, p0, Landroid/support/v7/widget/F;->fo:Ljava/util/WeakHashMap;

    :cond_e
    iget-object v0, p0, Landroid/support/v7/widget/F;->fo:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/b/c/f/q;

    if-nez v0, :cond_f

    new-instance v0, La/b/c/f/q;

    const/16 v2, 0xa

    .line 9
    invoke-direct {v0, v2}, La/b/c/f/q;-><init>(I)V

    .line 10
    iget-object p0, p0, Landroid/support/v7/widget/F;->fo:Ljava/util/WeakHashMap;

    invoke-virtual {p0, p1, v0}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_f
    invoke-virtual {v0, p2, v1}, La/b/c/f/q;->append(ILjava/lang/Object;)V

    :cond_10
    return-object v1
.end method

.method public e(Landroid/content/Context;)V
    .locals 1

    iget-object v0, p0, Landroid/support/v7/widget/F;->io:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    iget-object p0, p0, Landroid/support/v7/widget/F;->jo:Ljava/util/WeakHashMap;

    invoke-virtual {p0, p1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, La/b/c/f/g;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, La/b/c/f/g;->clear()V

    :cond_0
    monitor-exit v0

    return-void

    :catchall_0
    move-exception p0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p0
.end method
