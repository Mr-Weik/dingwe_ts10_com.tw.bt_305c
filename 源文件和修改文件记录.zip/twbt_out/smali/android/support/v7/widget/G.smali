.class public Landroid/support/v7/widget/G;
.super Landroid/widget/EditText;
.source ""

# interfaces
.implements Landroid/support/v4/view/p;


# instance fields
.field private final Hv:Landroid/support/v7/widget/y;

.field private final Kw:Landroid/support/v7/widget/aa;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 1

    .line 1
    invoke-static {p1}, Landroid/support/v7/widget/ec;->b(Landroid/content/Context;)Landroid/content/Context;

    const v0, 0x7f030071

    invoke-direct {p0, p1, p2, v0}, Landroid/widget/EditText;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    new-instance p1, Landroid/support/v7/widget/y;

    invoke-direct {p1, p0}, Landroid/support/v7/widget/y;-><init>(Landroid/view/View;)V

    iput-object p1, p0, Landroid/support/v7/widget/G;->Hv:Landroid/support/v7/widget/y;

    iget-object p1, p0, Landroid/support/v7/widget/G;->Hv:Landroid/support/v7/widget/y;

    invoke-virtual {p1, p2, v0}, Landroid/support/v7/widget/y;->a(Landroid/util/AttributeSet;I)V

    new-instance p1, Landroid/support/v7/widget/aa;

    invoke-direct {p1, p0}, Landroid/support/v7/widget/aa;-><init>(Landroid/widget/TextView;)V

    iput-object p1, p0, Landroid/support/v7/widget/G;->Kw:Landroid/support/v7/widget/aa;

    iget-object p1, p0, Landroid/support/v7/widget/G;->Kw:Landroid/support/v7/widget/aa;

    invoke-virtual {p1, p2, v0}, Landroid/support/v7/widget/aa;->a(Landroid/util/AttributeSet;I)V

    iget-object p0, p0, Landroid/support/v7/widget/G;->Kw:Landroid/support/v7/widget/aa;

    invoke-virtual {p0}, Landroid/support/v7/widget/aa;->Za()V

    return-void
.end method


# virtual methods
.method protected drawableStateChanged()V
    .locals 1

    invoke-super {p0}, Landroid/widget/EditText;->drawableStateChanged()V

    iget-object v0, p0, Landroid/support/v7/widget/G;->Hv:Landroid/support/v7/widget/y;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/support/v7/widget/y;->Va()V

    :cond_0
    iget-object p0, p0, Landroid/support/v7/widget/G;->Kw:Landroid/support/v7/widget/aa;

    if-eqz p0, :cond_1

    invoke-virtual {p0}, Landroid/support/v7/widget/aa;->Za()V

    :cond_1
    return-void
.end method

.method public getText()Landroid/text/Editable;
    .locals 1

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2
    invoke-super {p0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p0

    return-object p0
.end method

.method public getText()Ljava/lang/CharSequence;
    .locals 1

    .line 3
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 4
    invoke-super {p0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p0

    return-object p0
.end method

.method public onCreateInputConnection(Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;
    .locals 1

    invoke-super {p0, p1}, Landroid/widget/EditText;->onCreateInputConnection(Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;

    move-result-object v0

    invoke-static {v0, p1, p0}, Landroid/support/v7/widget/rc;->a(Landroid/view/inputmethod/InputConnection;Landroid/view/inputmethod/EditorInfo;Landroid/view/View;)Landroid/view/inputmethod/InputConnection;

    return-object v0
.end method

.method public setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V
    .locals 0

    invoke-super {p0, p1}, Landroid/widget/EditText;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    iget-object p0, p0, Landroid/support/v7/widget/G;->Hv:Landroid/support/v7/widget/y;

    if-eqz p0, :cond_0

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/y;->d(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    return-void
.end method

.method public setBackgroundResource(I)V
    .locals 0

    invoke-super {p0, p1}, Landroid/widget/EditText;->setBackgroundResource(I)V

    iget-object p0, p0, Landroid/support/v7/widget/G;->Hv:Landroid/support/v7/widget/y;

    if-eqz p0, :cond_0

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/y;->W(I)V

    :cond_0
    return-void
.end method

.method public setCustomSelectionActionModeCallback(Landroid/view/ActionMode$Callback;)V
    .locals 1

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2
    invoke-super {p0, p1}, Landroid/widget/EditText;->setCustomSelectionActionModeCallback(Landroid/view/ActionMode$Callback;)V

    return-void
.end method

.method public setTextAppearance(Landroid/content/Context;I)V
    .locals 0

    invoke-super {p0, p1, p2}, Landroid/widget/EditText;->setTextAppearance(Landroid/content/Context;I)V

    iget-object p0, p0, Landroid/support/v7/widget/G;->Kw:Landroid/support/v7/widget/aa;

    if-eqz p0, :cond_0

    invoke-virtual {p0, p1, p2}, Landroid/support/v7/widget/aa;->d(Landroid/content/Context;I)V

    :cond_0
    return-void
.end method
