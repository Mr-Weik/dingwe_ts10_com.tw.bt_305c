.class final Landroid/support/v7/widget/gb;
.super Landroid/support/v7/widget/hb;
.source ""


# direct methods
.method constructor <init>(Landroid/support/v7/widget/Ab;)V
    .locals 1

    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, Landroid/support/v7/widget/hb;-><init>(Landroid/support/v7/widget/Ab;Landroid/support/v7/widget/fb;)V

    return-void
.end method


# virtual methods
.method public getDecoratedEnd(Landroid/view/View;)I
    .locals 1

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroid/support/v7/widget/Bb;

    iget-object p0, p0, Landroid/support/v7/widget/hb;->mLayoutManager:Landroid/support/v7/widget/Ab;

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/Ab;->getDecoratedBottom(Landroid/view/View;)I

    move-result p0

    iget p1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    add-int/2addr p0, p1

    return p0
.end method

.method public getDecoratedMeasurement(Landroid/view/View;)I
    .locals 1

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroid/support/v7/widget/Bb;

    iget-object p0, p0, Landroid/support/v7/widget/hb;->mLayoutManager:Landroid/support/v7/widget/Ab;

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/Ab;->getDecoratedMeasuredHeight(Landroid/view/View;)I

    move-result p0

    iget p1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    add-int/2addr p0, p1

    iget p1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    add-int/2addr p0, p1

    return p0
.end method

.method public getDecoratedMeasurementInOther(Landroid/view/View;)I
    .locals 1

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroid/support/v7/widget/Bb;

    iget-object p0, p0, Landroid/support/v7/widget/hb;->mLayoutManager:Landroid/support/v7/widget/Ab;

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/Ab;->getDecoratedMeasuredWidth(Landroid/view/View;)I

    move-result p0

    iget p1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    add-int/2addr p0, p1

    iget p1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    add-int/2addr p0, p1

    return p0
.end method

.method public getDecoratedStart(Landroid/view/View;)I
    .locals 1

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroid/support/v7/widget/Bb;

    iget-object p0, p0, Landroid/support/v7/widget/hb;->mLayoutManager:Landroid/support/v7/widget/Ab;

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/Ab;->getDecoratedTop(Landroid/view/View;)I

    move-result p0

    iget p1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    sub-int/2addr p0, p1

    return p0
.end method

.method public getEnd()I
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/hb;->mLayoutManager:Landroid/support/v7/widget/Ab;

    invoke-virtual {p0}, Landroid/support/v7/widget/Ab;->getHeight()I

    move-result p0

    return p0
.end method

.method public getEndAfterPadding()I
    .locals 1

    iget-object v0, p0, Landroid/support/v7/widget/hb;->mLayoutManager:Landroid/support/v7/widget/Ab;

    invoke-virtual {v0}, Landroid/support/v7/widget/Ab;->getHeight()I

    move-result v0

    iget-object p0, p0, Landroid/support/v7/widget/hb;->mLayoutManager:Landroid/support/v7/widget/Ab;

    invoke-virtual {p0}, Landroid/support/v7/widget/Ab;->getPaddingBottom()I

    move-result p0

    sub-int/2addr v0, p0

    return v0
.end method

.method public getEndPadding()I
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/hb;->mLayoutManager:Landroid/support/v7/widget/Ab;

    invoke-virtual {p0}, Landroid/support/v7/widget/Ab;->getPaddingBottom()I

    move-result p0

    return p0
.end method

.method public getMode()I
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/hb;->mLayoutManager:Landroid/support/v7/widget/Ab;

    invoke-virtual {p0}, Landroid/support/v7/widget/Ab;->getHeightMode()I

    move-result p0

    return p0
.end method

.method public getModeInOther()I
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/hb;->mLayoutManager:Landroid/support/v7/widget/Ab;

    invoke-virtual {p0}, Landroid/support/v7/widget/Ab;->getWidthMode()I

    move-result p0

    return p0
.end method

.method public getStartAfterPadding()I
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/hb;->mLayoutManager:Landroid/support/v7/widget/Ab;

    invoke-virtual {p0}, Landroid/support/v7/widget/Ab;->getPaddingTop()I

    move-result p0

    return p0
.end method

.method public getTotalSpace()I
    .locals 2

    iget-object v0, p0, Landroid/support/v7/widget/hb;->mLayoutManager:Landroid/support/v7/widget/Ab;

    invoke-virtual {v0}, Landroid/support/v7/widget/Ab;->getHeight()I

    move-result v0

    iget-object v1, p0, Landroid/support/v7/widget/hb;->mLayoutManager:Landroid/support/v7/widget/Ab;

    invoke-virtual {v1}, Landroid/support/v7/widget/Ab;->getPaddingTop()I

    move-result v1

    sub-int/2addr v0, v1

    iget-object p0, p0, Landroid/support/v7/widget/hb;->mLayoutManager:Landroid/support/v7/widget/Ab;

    invoke-virtual {p0}, Landroid/support/v7/widget/Ab;->getPaddingBottom()I

    move-result p0

    sub-int/2addr v0, p0

    return v0
.end method

.method public getTransformedEndWithDecoration(Landroid/view/View;)I
    .locals 3

    iget-object v0, p0, Landroid/support/v7/widget/hb;->mLayoutManager:Landroid/support/v7/widget/Ab;

    iget-object v1, p0, Landroid/support/v7/widget/hb;->mTmpRect:Landroid/graphics/Rect;

    const/4 v2, 0x1

    invoke-virtual {v0, p1, v2, v1}, Landroid/support/v7/widget/Ab;->getTransformedBoundingBox(Landroid/view/View;ZLandroid/graphics/Rect;)V

    iget-object p0, p0, Landroid/support/v7/widget/hb;->mTmpRect:Landroid/graphics/Rect;

    iget p0, p0, Landroid/graphics/Rect;->bottom:I

    return p0
.end method

.method public getTransformedStartWithDecoration(Landroid/view/View;)I
    .locals 3

    iget-object v0, p0, Landroid/support/v7/widget/hb;->mLayoutManager:Landroid/support/v7/widget/Ab;

    iget-object v1, p0, Landroid/support/v7/widget/hb;->mTmpRect:Landroid/graphics/Rect;

    const/4 v2, 0x1

    invoke-virtual {v0, p1, v2, v1}, Landroid/support/v7/widget/Ab;->getTransformedBoundingBox(Landroid/view/View;ZLandroid/graphics/Rect;)V

    iget-object p0, p0, Landroid/support/v7/widget/hb;->mTmpRect:Landroid/graphics/Rect;

    iget p0, p0, Landroid/graphics/Rect;->top:I

    return p0
.end method

.method public offsetChildren(I)V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/hb;->mLayoutManager:Landroid/support/v7/widget/Ab;

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/Ab;->offsetChildrenVertical(I)V

    return-void
.end method
