.class public Landroid/support/v7/widget/Bb;
.super Landroid/view/ViewGroup$MarginLayoutParams;
.source ""


# instance fields
.field final mDecorInsets:Landroid/graphics/Rect;

.field mInsetsDirty:Z

.field mPendingInvalidate:Z

.field mViewHolder:Landroid/support/v7/widget/Ob;


# direct methods
.method public constructor <init>(II)V
    .locals 0

    invoke-direct {p0, p1, p2}, Landroid/view/ViewGroup$MarginLayoutParams;-><init>(II)V

    new-instance p1, Landroid/graphics/Rect;

    invoke-direct {p1}, Landroid/graphics/Rect;-><init>()V

    iput-object p1, p0, Landroid/support/v7/widget/Bb;->mDecorInsets:Landroid/graphics/Rect;

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroid/support/v7/widget/Bb;->mInsetsDirty:Z

    const/4 p1, 0x0

    iput-boolean p1, p0, Landroid/support/v7/widget/Bb;->mPendingInvalidate:Z

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Landroid/view/ViewGroup$MarginLayoutParams;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    new-instance p1, Landroid/graphics/Rect;

    invoke-direct {p1}, Landroid/graphics/Rect;-><init>()V

    iput-object p1, p0, Landroid/support/v7/widget/Bb;->mDecorInsets:Landroid/graphics/Rect;

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroid/support/v7/widget/Bb;->mInsetsDirty:Z

    const/4 p1, 0x0

    iput-boolean p1, p0, Landroid/support/v7/widget/Bb;->mPendingInvalidate:Z

    return-void
.end method

.method public constructor <init>(Landroid/support/v7/widget/Bb;)V
    .locals 0

    invoke-direct {p0, p1}, Landroid/view/ViewGroup$MarginLayoutParams;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    new-instance p1, Landroid/graphics/Rect;

    invoke-direct {p1}, Landroid/graphics/Rect;-><init>()V

    iput-object p1, p0, Landroid/support/v7/widget/Bb;->mDecorInsets:Landroid/graphics/Rect;

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroid/support/v7/widget/Bb;->mInsetsDirty:Z

    const/4 p1, 0x0

    iput-boolean p1, p0, Landroid/support/v7/widget/Bb;->mPendingInvalidate:Z

    return-void
.end method

.method public constructor <init>(Landroid/view/ViewGroup$LayoutParams;)V
    .locals 0

    invoke-direct {p0, p1}, Landroid/view/ViewGroup$MarginLayoutParams;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    new-instance p1, Landroid/graphics/Rect;

    invoke-direct {p1}, Landroid/graphics/Rect;-><init>()V

    iput-object p1, p0, Landroid/support/v7/widget/Bb;->mDecorInsets:Landroid/graphics/Rect;

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroid/support/v7/widget/Bb;->mInsetsDirty:Z

    const/4 p1, 0x0

    iput-boolean p1, p0, Landroid/support/v7/widget/Bb;->mPendingInvalidate:Z

    return-void
.end method

.method public constructor <init>(Landroid/view/ViewGroup$MarginLayoutParams;)V
    .locals 0

    invoke-direct {p0, p1}, Landroid/view/ViewGroup$MarginLayoutParams;-><init>(Landroid/view/ViewGroup$MarginLayoutParams;)V

    new-instance p1, Landroid/graphics/Rect;

    invoke-direct {p1}, Landroid/graphics/Rect;-><init>()V

    iput-object p1, p0, Landroid/support/v7/widget/Bb;->mDecorInsets:Landroid/graphics/Rect;

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroid/support/v7/widget/Bb;->mInsetsDirty:Z

    const/4 p1, 0x0

    iput-boolean p1, p0, Landroid/support/v7/widget/Bb;->mPendingInvalidate:Z

    return-void
.end method


# virtual methods
.method public getViewLayoutPosition()I
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/Bb;->mViewHolder:Landroid/support/v7/widget/Ob;

    invoke-virtual {p0}, Landroid/support/v7/widget/Ob;->getLayoutPosition()I

    move-result p0

    return p0
.end method

.method public isItemChanged()Z
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/Bb;->mViewHolder:Landroid/support/v7/widget/Ob;

    invoke-virtual {p0}, Landroid/support/v7/widget/Ob;->isUpdated()Z

    move-result p0

    return p0
.end method

.method public isItemRemoved()Z
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/Bb;->mViewHolder:Landroid/support/v7/widget/Ob;

    invoke-virtual {p0}, Landroid/support/v7/widget/Ob;->isRemoved()Z

    move-result p0

    return p0
.end method
