.class public Landroid/support/v7/widget/Gb;
.super Ljava/lang/Object;
.source ""


# instance fields
.field private er:I

.field mScrap:Landroid/util/SparseArray;


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Landroid/util/SparseArray;

    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    iput-object v0, p0, Landroid/support/v7/widget/Gb;->mScrap:Landroid/util/SparseArray;

    const/4 v0, 0x0

    iput v0, p0, Landroid/support/v7/widget/Gb;->er:I

    return-void
.end method

.method private Va(I)Landroid/support/v7/widget/Fb;
    .locals 1

    iget-object v0, p0, Landroid/support/v7/widget/Gb;->mScrap:Landroid/util/SparseArray;

    invoke-virtual {v0, p1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v7/widget/Fb;

    if-nez v0, :cond_0

    new-instance v0, Landroid/support/v7/widget/Fb;

    invoke-direct {v0}, Landroid/support/v7/widget/Fb;-><init>()V

    iget-object p0, p0, Landroid/support/v7/widget/Gb;->mScrap:Landroid/util/SparseArray;

    invoke-virtual {p0, p1, v0}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    :cond_0
    return-object v0
.end method


# virtual methods
.method a(Landroid/support/v7/widget/ob;Landroid/support/v7/widget/ob;Z)V
    .locals 0

    if-eqz p1, :cond_0

    .line 1
    iget p1, p0, Landroid/support/v7/widget/Gb;->er:I

    add-int/lit8 p1, p1, -0x1

    iput p1, p0, Landroid/support/v7/widget/Gb;->er:I

    :cond_0
    if-nez p3, :cond_1

    .line 2
    iget p1, p0, Landroid/support/v7/widget/Gb;->er:I

    if-nez p1, :cond_1

    const/4 p1, 0x0

    .line 3
    :goto_0
    iget-object p3, p0, Landroid/support/v7/widget/Gb;->mScrap:Landroid/util/SparseArray;

    invoke-virtual {p3}, Landroid/util/SparseArray;->size()I

    move-result p3

    if-ge p1, p3, :cond_1

    iget-object p3, p0, Landroid/support/v7/widget/Gb;->mScrap:Landroid/util/SparseArray;

    invoke-virtual {p3, p1}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Landroid/support/v7/widget/Fb;

    iget-object p3, p3, Landroid/support/v7/widget/Fb;->mScrapHeap:Ljava/util/ArrayList;

    invoke-virtual {p3}, Ljava/util/ArrayList;->clear()V

    add-int/lit8 p1, p1, 0x1

    goto :goto_0

    :cond_1
    if-eqz p2, :cond_2

    .line 4
    iget p1, p0, Landroid/support/v7/widget/Gb;->er:I

    add-int/lit8 p1, p1, 0x1

    iput p1, p0, Landroid/support/v7/widget/Gb;->er:I

    :cond_2
    return-void
.end method

.method factorInBindTime(IJ)V
    .locals 2

    invoke-direct {p0, p1}, Landroid/support/v7/widget/Gb;->Va(I)Landroid/support/v7/widget/Fb;

    move-result-object p1

    iget-wide v0, p1, Landroid/support/v7/widget/Fb;->mBindRunningAverageNs:J

    invoke-virtual {p0, v0, v1, p2, p3}, Landroid/support/v7/widget/Gb;->runningAverage(JJ)J

    move-result-wide p2

    iput-wide p2, p1, Landroid/support/v7/widget/Fb;->mBindRunningAverageNs:J

    return-void
.end method

.method factorInCreateTime(IJ)V
    .locals 2

    invoke-direct {p0, p1}, Landroid/support/v7/widget/Gb;->Va(I)Landroid/support/v7/widget/Fb;

    move-result-object p1

    iget-wide v0, p1, Landroid/support/v7/widget/Fb;->mCreateRunningAverageNs:J

    invoke-virtual {p0, v0, v1, p2, p3}, Landroid/support/v7/widget/Gb;->runningAverage(JJ)J

    move-result-wide p2

    iput-wide p2, p1, Landroid/support/v7/widget/Fb;->mCreateRunningAverageNs:J

    return-void
.end method

.method public g(Landroid/support/v7/widget/Ob;)V
    .locals 2

    invoke-virtual {p1}, Landroid/support/v7/widget/Ob;->getItemViewType()I

    move-result v0

    invoke-direct {p0, v0}, Landroid/support/v7/widget/Gb;->Va(I)Landroid/support/v7/widget/Fb;

    move-result-object v1

    iget-object v1, v1, Landroid/support/v7/widget/Fb;->mScrapHeap:Ljava/util/ArrayList;

    iget-object p0, p0, Landroid/support/v7/widget/Gb;->mScrap:Landroid/util/SparseArray;

    invoke-virtual {p0, v0}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/support/v7/widget/Fb;

    iget p0, p0, Landroid/support/v7/widget/Fb;->mMaxScrap:I

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-gt p0, v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {p1}, Landroid/support/v7/widget/Ob;->resetInternal()V

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method runningAverage(JJ)J
    .locals 4

    const-wide/16 v0, 0x0

    cmp-long p0, p1, v0

    if-nez p0, :cond_0

    return-wide p3

    :cond_0
    const-wide/16 v0, 0x4

    div-long/2addr p1, v0

    const-wide/16 v2, 0x3

    mul-long/2addr p1, v2

    div-long/2addr p3, v0

    add-long/2addr p3, p1

    return-wide p3
.end method

.method willBindInTime(IJJ)Z
    .locals 2

    invoke-direct {p0, p1}, Landroid/support/v7/widget/Gb;->Va(I)Landroid/support/v7/widget/Fb;

    move-result-object p0

    iget-wide p0, p0, Landroid/support/v7/widget/Fb;->mBindRunningAverageNs:J

    const-wide/16 v0, 0x0

    cmp-long v0, p0, v0

    if-eqz v0, :cond_1

    add-long/2addr p2, p0

    cmp-long p0, p2, p4

    if-gez p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 p0, 0x1

    :goto_1
    return p0
.end method

.method willCreateInTime(IJJ)Z
    .locals 2

    invoke-direct {p0, p1}, Landroid/support/v7/widget/Gb;->Va(I)Landroid/support/v7/widget/Fb;

    move-result-object p0

    iget-wide p0, p0, Landroid/support/v7/widget/Fb;->mCreateRunningAverageNs:J

    const-wide/16 v0, 0x0

    cmp-long v0, p0, v0

    if-eqz v0, :cond_1

    add-long/2addr p2, p0

    cmp-long p0, p2, p4

    if-gez p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 p0, 0x1

    :goto_1
    return p0
.end method
