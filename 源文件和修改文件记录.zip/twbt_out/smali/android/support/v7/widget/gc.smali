.class Landroid/support/v7/widget/gc;
.super Landroid/content/res/Resources;
.source ""
