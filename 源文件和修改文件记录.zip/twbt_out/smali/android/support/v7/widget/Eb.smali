.class public abstract Landroid/support/v7/widget/Eb;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public b(Landroid/support/v7/widget/RecyclerView;I)V
    .locals 0

    return-void
.end method

.method public e(Landroid/support/v7/widget/RecyclerView;II)V
    .locals 0

    return-void
.end method
