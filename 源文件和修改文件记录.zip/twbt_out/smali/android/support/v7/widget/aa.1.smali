.class Landroid/support/v7/widget/aa;
.super Ljava/lang/Object;
.source ""


# instance fields
.field private Ho:Landroid/support/v7/widget/fc;

.field private Io:Landroid/support/v7/widget/fc;

.field private Jo:Landroid/support/v7/widget/fc;

.field private Ko:Landroid/support/v7/widget/fc;

.field private Lo:Landroid/support/v7/widget/fc;

.field private Mo:Landroid/support/v7/widget/fc;

.field private final No:Landroid/support/v7/widget/ca;

.field private Oo:Z

.field private mFontTypeface:Landroid/graphics/Typeface;

.field private mStyle:I

.field private final mView:Landroid/widget/TextView;


# direct methods
.method constructor <init>(Landroid/widget/TextView;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, Landroid/support/v7/widget/aa;->mStyle:I

    iput-object p1, p0, Landroid/support/v7/widget/aa;->mView:Landroid/widget/TextView;

    new-instance p1, Landroid/support/v7/widget/ca;

    iget-object v0, p0, Landroid/support/v7/widget/aa;->mView:Landroid/widget/TextView;

    invoke-direct {p1, v0}, Landroid/support/v7/widget/ca;-><init>(Landroid/widget/TextView;)V

    iput-object p1, p0, Landroid/support/v7/widget/aa;->No:Landroid/support/v7/widget/ca;

    return-void
.end method

.method private static a(Landroid/content/Context;Landroid/support/v7/widget/F;I)Landroid/support/v7/widget/fc;
    .locals 0

    invoke-virtual {p1, p0, p2}, Landroid/support/v7/widget/F;->c(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    move-result-object p0

    if-eqz p0, :cond_0

    new-instance p1, Landroid/support/v7/widget/fc;

    invoke-direct {p1}, Landroid/support/v7/widget/fc;-><init>()V

    const/4 p2, 0x1

    iput-boolean p2, p1, Landroid/support/v7/widget/fc;->mHasTintList:Z

    iput-object p0, p1, Landroid/support/v7/widget/fc;->mTintList:Landroid/content/res/ColorStateList;

    return-object p1

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method private a(Landroid/content/Context;Landroid/support/v7/widget/hc;)V
    .locals 6

    iget v0, p0, Landroid/support/v7/widget/aa;->mStyle:I

    const/4 v1, 0x2

    invoke-virtual {p2, v1, v0}, Landroid/support/v7/widget/hc;->getInt(II)I

    move-result v0

    iput v0, p0, Landroid/support/v7/widget/aa;->mStyle:I

    const/16 v0, 0xa

    invoke-virtual {p2, v0}, Landroid/support/v7/widget/hc;->hasValue(I)Z

    move-result v2

    const/4 v3, 0x0

    const/16 v4, 0xb

    const/4 v5, 0x1

    if-nez v2, :cond_5

    invoke-virtual {p2, v4}, Landroid/support/v7/widget/hc;->hasValue(I)Z

    move-result v2

    if-eqz v2, :cond_0

    goto :goto_2

    :cond_0
    invoke-virtual {p2, v5}, Landroid/support/v7/widget/hc;->hasValue(I)Z

    move-result p1

    if-eqz p1, :cond_4

    iput-boolean v3, p0, Landroid/support/v7/widget/aa;->Oo:Z

    invoke-virtual {p2, v5, v5}, Landroid/support/v7/widget/hc;->getInt(II)I

    move-result p1

    if-eq p1, v5, :cond_3

    if-eq p1, v1, :cond_2

    const/4 p2, 0x3

    if-eq p1, p2, :cond_1

    goto :goto_1

    :cond_1
    sget-object p1, Landroid/graphics/Typeface;->MONOSPACE:Landroid/graphics/Typeface;

    goto :goto_0

    :cond_2
    sget-object p1, Landroid/graphics/Typeface;->SERIF:Landroid/graphics/Typeface;

    goto :goto_0

    :cond_3
    sget-object p1, Landroid/graphics/Typeface;->SANS_SERIF:Landroid/graphics/Typeface;

    :goto_0
    iput-object p1, p0, Landroid/support/v7/widget/aa;->mFontTypeface:Landroid/graphics/Typeface;

    :cond_4
    :goto_1
    return-void

    :cond_5
    :goto_2
    const/4 v1, 0x0

    iput-object v1, p0, Landroid/support/v7/widget/aa;->mFontTypeface:Landroid/graphics/Typeface;

    invoke-virtual {p2, v4}, Landroid/support/v7/widget/hc;->hasValue(I)Z

    move-result v1

    if-eqz v1, :cond_6

    move v0, v4

    :cond_6
    invoke-virtual {p1}, Landroid/content/Context;->isRestricted()Z

    move-result p1

    if-nez p1, :cond_8

    new-instance p1, Ljava/lang/ref/WeakReference;

    iget-object v1, p0, Landroid/support/v7/widget/aa;->mView:Landroid/widget/TextView;

    invoke-direct {p1, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    new-instance v1, Landroid/support/v7/widget/Z;

    invoke-direct {v1, p0, p1}, Landroid/support/v7/widget/Z;-><init>(Landroid/support/v7/widget/aa;Ljava/lang/ref/WeakReference;)V

    :try_start_0
    iget p1, p0, Landroid/support/v7/widget/aa;->mStyle:I

    invoke-virtual {p2, v0, p1, v1}, Landroid/support/v7/widget/hc;->a(IILa/b/c/a/a/h;)Landroid/graphics/Typeface;

    move-result-object p1

    iput-object p1, p0, Landroid/support/v7/widget/aa;->mFontTypeface:Landroid/graphics/Typeface;

    iget-object p1, p0, Landroid/support/v7/widget/aa;->mFontTypeface:Landroid/graphics/Typeface;

    if-nez p1, :cond_7

    move v3, v5

    :cond_7
    iput-boolean v3, p0, Landroid/support/v7/widget/aa;->Oo:Z
    :try_end_0
    .catch Ljava/lang/UnsupportedOperationException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_8
    iget-object p1, p0, Landroid/support/v7/widget/aa;->mFontTypeface:Landroid/graphics/Typeface;

    if-nez p1, :cond_9

    invoke-virtual {p2, v0}, Landroid/support/v7/widget/hc;->getString(I)Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_9

    iget p2, p0, Landroid/support/v7/widget/aa;->mStyle:I

    invoke-static {p1, p2}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object p1

    iput-object p1, p0, Landroid/support/v7/widget/aa;->mFontTypeface:Landroid/graphics/Typeface;

    :cond_9
    return-void
.end method

.method private a(Landroid/graphics/drawable/Drawable;Landroid/support/v7/widget/fc;)V
    .locals 0

    if-eqz p1, :cond_0

    if-eqz p2, :cond_0

    iget-object p0, p0, Landroid/support/v7/widget/aa;->mView:Landroid/widget/TextView;

    invoke-virtual {p0}, Landroid/widget/TextView;->getDrawableState()[I

    move-result-object p0

    invoke-static {p1, p2, p0}, Landroid/support/v7/widget/F;->a(Landroid/graphics/drawable/Drawable;Landroid/support/v7/widget/fc;[I)V

    :cond_0
    return-void
.end method

.method static synthetic a(Landroid/support/v7/widget/aa;Ljava/lang/ref/WeakReference;Landroid/graphics/Typeface;)V
    .locals 1

    .line 1
    iget-boolean v0, p0, Landroid/support/v7/widget/aa;->Oo:Z

    if-eqz v0, :cond_0

    iput-object p2, p0, Landroid/support/v7/widget/aa;->mFontTypeface:Landroid/graphics/Typeface;

    invoke-virtual {p1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    if-eqz p1, :cond_0

    iget p0, p0, Landroid/support/v7/widget/aa;->mStyle:I

    invoke-virtual {p1, p2, p0}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    :cond_0
    return-void
.end method


# virtual methods
.method Za()V
    .locals 5

    iget-object v0, p0, Landroid/support/v7/widget/aa;->Ho:Landroid/support/v7/widget/fc;

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-nez v0, :cond_0

    iget-object v0, p0, Landroid/support/v7/widget/aa;->Io:Landroid/support/v7/widget/fc;

    if-nez v0, :cond_0

    iget-object v0, p0, Landroid/support/v7/widget/aa;->Jo:Landroid/support/v7/widget/fc;

    if-nez v0, :cond_0

    iget-object v0, p0, Landroid/support/v7/widget/aa;->Ko:Landroid/support/v7/widget/fc;

    if-eqz v0, :cond_1

    :cond_0
    iget-object v0, p0, Landroid/support/v7/widget/aa;->mView:Landroid/widget/TextView;

    invoke-virtual {v0}, Landroid/widget/TextView;->getCompoundDrawables()[Landroid/graphics/drawable/Drawable;

    move-result-object v0

    aget-object v3, v0, v2

    iget-object v4, p0, Landroid/support/v7/widget/aa;->Ho:Landroid/support/v7/widget/fc;

    invoke-direct {p0, v3, v4}, Landroid/support/v7/widget/aa;->a(Landroid/graphics/drawable/Drawable;Landroid/support/v7/widget/fc;)V

    const/4 v3, 0x1

    aget-object v3, v0, v3

    iget-object v4, p0, Landroid/support/v7/widget/aa;->Io:Landroid/support/v7/widget/fc;

    invoke-direct {p0, v3, v4}, Landroid/support/v7/widget/aa;->a(Landroid/graphics/drawable/Drawable;Landroid/support/v7/widget/fc;)V

    aget-object v3, v0, v1

    iget-object v4, p0, Landroid/support/v7/widget/aa;->Jo:Landroid/support/v7/widget/fc;

    invoke-direct {p0, v3, v4}, Landroid/support/v7/widget/aa;->a(Landroid/graphics/drawable/Drawable;Landroid/support/v7/widget/fc;)V

    const/4 v3, 0x3

    aget-object v0, v0, v3

    iget-object v3, p0, Landroid/support/v7/widget/aa;->Ko:Landroid/support/v7/widget/fc;

    invoke-direct {p0, v0, v3}, Landroid/support/v7/widget/aa;->a(Landroid/graphics/drawable/Drawable;Landroid/support/v7/widget/fc;)V

    :cond_1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    iget-object v0, p0, Landroid/support/v7/widget/aa;->Lo:Landroid/support/v7/widget/fc;

    if-nez v0, :cond_2

    iget-object v0, p0, Landroid/support/v7/widget/aa;->Mo:Landroid/support/v7/widget/fc;

    if-eqz v0, :cond_3

    :cond_2
    iget-object v0, p0, Landroid/support/v7/widget/aa;->mView:Landroid/widget/TextView;

    invoke-virtual {v0}, Landroid/widget/TextView;->getCompoundDrawablesRelative()[Landroid/graphics/drawable/Drawable;

    move-result-object v0

    aget-object v2, v0, v2

    iget-object v3, p0, Landroid/support/v7/widget/aa;->Lo:Landroid/support/v7/widget/fc;

    invoke-direct {p0, v2, v3}, Landroid/support/v7/widget/aa;->a(Landroid/graphics/drawable/Drawable;Landroid/support/v7/widget/fc;)V

    aget-object v0, v0, v1

    iget-object v1, p0, Landroid/support/v7/widget/aa;->Mo:Landroid/support/v7/widget/fc;

    invoke-direct {p0, v0, v1}, Landroid/support/v7/widget/aa;->a(Landroid/graphics/drawable/Drawable;Landroid/support/v7/widget/fc;)V

    :cond_3
    return-void
.end method

.method _a()V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/aa;->No:Landroid/support/v7/widget/ca;

    invoke-virtual {p0}, Landroid/support/v7/widget/ca;->_a()V

    return-void
.end method

.method a(Landroid/util/AttributeSet;I)V
    .locals 11
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "NewApi"
        }
    .end annotation

    iget-object v0, p0, Landroid/support/v7/widget/aa;->mView:Landroid/widget/TextView;

    invoke-virtual {v0}, Landroid/widget/TextView;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {}, Landroid/support/v7/widget/F;->get()Landroid/support/v7/widget/F;

    move-result-object v1

    sget-object v2, La/b/d/a/b;->kk:[I

    const/4 v3, 0x0

    invoke-static {v0, p1, v2, p2, v3}, Landroid/support/v7/widget/hc;->a(Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroid/support/v7/widget/hc;

    move-result-object v2

    sget v4, La/b/d/a/b;->lk:I

    const/4 v5, -0x1

    invoke-virtual {v2, v4, v5}, Landroid/support/v7/widget/hc;->getResourceId(II)I

    move-result v4

    const/4 v6, 0x3

    invoke-virtual {v2, v6}, Landroid/support/v7/widget/hc;->hasValue(I)Z

    move-result v7

    if-eqz v7, :cond_0

    invoke-virtual {v2, v6, v3}, Landroid/support/v7/widget/hc;->getResourceId(II)I

    move-result v6

    invoke-static {v0, v1, v6}, Landroid/support/v7/widget/aa;->a(Landroid/content/Context;Landroid/support/v7/widget/F;I)Landroid/support/v7/widget/fc;

    move-result-object v6

    iput-object v6, p0, Landroid/support/v7/widget/aa;->Ho:Landroid/support/v7/widget/fc;

    :cond_0
    const/4 v6, 0x1

    invoke-virtual {v2, v6}, Landroid/support/v7/widget/hc;->hasValue(I)Z

    move-result v7

    if-eqz v7, :cond_1

    invoke-virtual {v2, v6, v3}, Landroid/support/v7/widget/hc;->getResourceId(II)I

    move-result v7

    invoke-static {v0, v1, v7}, Landroid/support/v7/widget/aa;->a(Landroid/content/Context;Landroid/support/v7/widget/F;I)Landroid/support/v7/widget/fc;

    move-result-object v7

    iput-object v7, p0, Landroid/support/v7/widget/aa;->Io:Landroid/support/v7/widget/fc;

    :cond_1
    const/4 v7, 0x4

    invoke-virtual {v2, v7}, Landroid/support/v7/widget/hc;->hasValue(I)Z

    move-result v8

    if-eqz v8, :cond_2

    invoke-virtual {v2, v7, v3}, Landroid/support/v7/widget/hc;->getResourceId(II)I

    move-result v7

    invoke-static {v0, v1, v7}, Landroid/support/v7/widget/aa;->a(Landroid/content/Context;Landroid/support/v7/widget/F;I)Landroid/support/v7/widget/fc;

    move-result-object v7

    iput-object v7, p0, Landroid/support/v7/widget/aa;->Jo:Landroid/support/v7/widget/fc;

    :cond_2
    const/4 v7, 0x2

    invoke-virtual {v2, v7}, Landroid/support/v7/widget/hc;->hasValue(I)Z

    move-result v8

    if-eqz v8, :cond_3

    invoke-virtual {v2, v7, v3}, Landroid/support/v7/widget/hc;->getResourceId(II)I

    move-result v7

    invoke-static {v0, v1, v7}, Landroid/support/v7/widget/aa;->a(Landroid/content/Context;Landroid/support/v7/widget/F;I)Landroid/support/v7/widget/fc;

    move-result-object v7

    iput-object v7, p0, Landroid/support/v7/widget/aa;->Ko:Landroid/support/v7/widget/fc;

    :cond_3
    sget v7, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v7, 0x5

    invoke-virtual {v2, v7}, Landroid/support/v7/widget/hc;->hasValue(I)Z

    move-result v8

    if-eqz v8, :cond_4

    invoke-virtual {v2, v7, v3}, Landroid/support/v7/widget/hc;->getResourceId(II)I

    move-result v7

    invoke-static {v0, v1, v7}, Landroid/support/v7/widget/aa;->a(Landroid/content/Context;Landroid/support/v7/widget/F;I)Landroid/support/v7/widget/fc;

    move-result-object v7

    iput-object v7, p0, Landroid/support/v7/widget/aa;->Lo:Landroid/support/v7/widget/fc;

    :cond_4
    const/4 v7, 0x6

    invoke-virtual {v2, v7}, Landroid/support/v7/widget/hc;->hasValue(I)Z

    move-result v8

    if-eqz v8, :cond_5

    invoke-virtual {v2, v7, v3}, Landroid/support/v7/widget/hc;->getResourceId(II)I

    move-result v8

    invoke-static {v0, v1, v8}, Landroid/support/v7/widget/aa;->a(Landroid/content/Context;Landroid/support/v7/widget/F;I)Landroid/support/v7/widget/fc;

    move-result-object v1

    iput-object v1, p0, Landroid/support/v7/widget/aa;->Mo:Landroid/support/v7/widget/fc;

    :cond_5
    invoke-virtual {v2}, Landroid/support/v7/widget/hc;->recycle()V

    iget-object v1, p0, Landroid/support/v7/widget/aa;->mView:Landroid/widget/TextView;

    invoke-virtual {v1}, Landroid/widget/TextView;->getTransformationMethod()Landroid/text/method/TransformationMethod;

    move-result-object v1

    instance-of v1, v1, Landroid/text/method/PasswordTransformationMethod;

    const/16 v2, 0xc

    if-eq v4, v5, :cond_7

    sget-object v8, La/b/d/a/b;->TextAppearance:[I

    invoke-static {v0, v4, v8}, Landroid/support/v7/widget/hc;->a(Landroid/content/Context;I[I)Landroid/support/v7/widget/hc;

    move-result-object v4

    if-nez v1, :cond_6

    invoke-virtual {v4, v2}, Landroid/support/v7/widget/hc;->hasValue(I)Z

    move-result v8

    if-eqz v8, :cond_6

    invoke-virtual {v4, v2, v3}, Landroid/support/v7/widget/hc;->getBoolean(IZ)Z

    move-result v8

    move v9, v8

    move v8, v6

    goto :goto_0

    :cond_6
    move v8, v3

    move v9, v8

    :goto_0
    invoke-direct {p0, v0, v4}, Landroid/support/v7/widget/aa;->a(Landroid/content/Context;Landroid/support/v7/widget/hc;)V

    sget v10, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-virtual {v4}, Landroid/support/v7/widget/hc;->recycle()V

    goto :goto_1

    :cond_7
    move v8, v3

    move v9, v8

    :goto_1
    sget-object v4, La/b/d/a/b;->TextAppearance:[I

    invoke-static {v0, p1, v4, p2, v3}, Landroid/support/v7/widget/hc;->a(Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroid/support/v7/widget/hc;

    move-result-object v4

    if-nez v1, :cond_8

    invoke-virtual {v4, v2}, Landroid/support/v7/widget/hc;->hasValue(I)Z

    move-result v10

    if-eqz v10, :cond_8

    invoke-virtual {v4, v2, v3}, Landroid/support/v7/widget/hc;->getBoolean(IZ)Z

    move-result v9

    goto :goto_2

    :cond_8
    move v6, v8

    :goto_2
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-direct {p0, v0, v4}, Landroid/support/v7/widget/aa;->a(Landroid/content/Context;Landroid/support/v7/widget/hc;)V

    invoke-virtual {v4}, Landroid/support/v7/widget/hc;->recycle()V

    if-nez v1, :cond_9

    if-eqz v6, :cond_9

    .line 2
    iget-object v1, p0, Landroid/support/v7/widget/aa;->mView:Landroid/widget/TextView;

    invoke-virtual {v1, v9}, Landroid/widget/TextView;->setAllCaps(Z)V

    .line 3
    :cond_9
    iget-object v1, p0, Landroid/support/v7/widget/aa;->mFontTypeface:Landroid/graphics/Typeface;

    if-eqz v1, :cond_a

    iget-object v2, p0, Landroid/support/v7/widget/aa;->mView:Landroid/widget/TextView;

    iget v4, p0, Landroid/support/v7/widget/aa;->mStyle:I

    invoke-virtual {v2, v1, v4}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    :cond_a
    iget-object v1, p0, Landroid/support/v7/widget/aa;->No:Landroid/support/v7/widget/ca;

    invoke-virtual {v1, p1, p2}, Landroid/support/v7/widget/ca;->a(Landroid/util/AttributeSet;I)V

    sget-boolean p2, Landroid/support/v4/widget/c;->zE:Z

    if-eqz p2, :cond_c

    iget-object p2, p0, Landroid/support/v7/widget/aa;->No:Landroid/support/v7/widget/ca;

    invoke-virtual {p2}, Landroid/support/v7/widget/ca;->getAutoSizeTextType()I

    move-result p2

    if-eqz p2, :cond_c

    iget-object p2, p0, Landroid/support/v7/widget/aa;->No:Landroid/support/v7/widget/ca;

    invoke-virtual {p2}, Landroid/support/v7/widget/ca;->getAutoSizeTextAvailableSizes()[I

    move-result-object p2

    array-length v1, p2

    if-lez v1, :cond_c

    iget-object v1, p0, Landroid/support/v7/widget/aa;->mView:Landroid/widget/TextView;

    invoke-virtual {v1}, Landroid/widget/TextView;->getAutoSizeStepGranularity()I

    move-result v1

    int-to-float v1, v1

    const/high16 v2, -0x40800000    # -1.0f

    cmpl-float v1, v1, v2

    if-eqz v1, :cond_b

    iget-object p2, p0, Landroid/support/v7/widget/aa;->mView:Landroid/widget/TextView;

    iget-object v1, p0, Landroid/support/v7/widget/aa;->No:Landroid/support/v7/widget/ca;

    invoke-virtual {v1}, Landroid/support/v7/widget/ca;->getAutoSizeMinTextSize()I

    move-result v1

    iget-object v2, p0, Landroid/support/v7/widget/aa;->No:Landroid/support/v7/widget/ca;

    invoke-virtual {v2}, Landroid/support/v7/widget/ca;->getAutoSizeMaxTextSize()I

    move-result v2

    iget-object v4, p0, Landroid/support/v7/widget/aa;->No:Landroid/support/v7/widget/ca;

    invoke-virtual {v4}, Landroid/support/v7/widget/ca;->getAutoSizeStepGranularity()I

    move-result v4

    invoke-virtual {p2, v1, v2, v4, v3}, Landroid/widget/TextView;->setAutoSizeTextTypeUniformWithConfiguration(IIII)V

    goto :goto_3

    :cond_b
    iget-object v1, p0, Landroid/support/v7/widget/aa;->mView:Landroid/widget/TextView;

    invoke-virtual {v1, p2, v3}, Landroid/widget/TextView;->setAutoSizeTextTypeUniformWithPresetSizes([II)V

    :cond_c
    :goto_3
    sget-object p2, La/b/d/a/b;->mk:[I

    invoke-static {v0, p1, p2}, Landroid/support/v7/widget/hc;->a(Landroid/content/Context;Landroid/util/AttributeSet;[I)Landroid/support/v7/widget/hc;

    move-result-object p1

    invoke-virtual {p1, v7, v5}, Landroid/support/v7/widget/hc;->getDimensionPixelSize(II)I

    move-result p2

    const/16 v0, 0x8

    invoke-virtual {p1, v0, v5}, Landroid/support/v7/widget/hc;->getDimensionPixelSize(II)I

    move-result v0

    const/16 v1, 0x9

    invoke-virtual {p1, v1, v5}, Landroid/support/v7/widget/hc;->getDimensionPixelSize(II)I

    move-result v1

    invoke-virtual {p1}, Landroid/support/v7/widget/hc;->recycle()V

    if-eq p2, v5, :cond_d

    iget-object p1, p0, Landroid/support/v7/widget/aa;->mView:Landroid/widget/TextView;

    .line 4
    invoke-static {p2}, La/b/a/a;->checkArgumentNonnegative(I)I

    .line 5
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 6
    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setFirstBaselineToTopHeight(I)V

    :cond_d
    if-eq v0, v5, :cond_e

    .line 7
    iget-object p1, p0, Landroid/support/v7/widget/aa;->mView:Landroid/widget/TextView;

    invoke-static {p1, v0}, Landroid/support/v4/widget/d;->a(Landroid/widget/TextView;I)V

    :cond_e
    if-eq v1, v5, :cond_f

    iget-object p0, p0, Landroid/support/v7/widget/aa;->mView:Landroid/widget/TextView;

    invoke-static {p0, v1}, Landroid/support/v4/widget/d;->b(Landroid/widget/TextView;I)V

    :cond_f
    return-void
.end method

.method ab()Z
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/aa;->No:Landroid/support/v7/widget/ca;

    invoke-virtual {p0}, Landroid/support/v7/widget/ca;->ab()Z

    move-result p0

    return p0
.end method

.method d(Landroid/content/Context;I)V
    .locals 2

    sget-object v0, La/b/d/a/b;->TextAppearance:[I

    invoke-static {p1, p2, v0}, Landroid/support/v7/widget/hc;->a(Landroid/content/Context;I[I)Landroid/support/v7/widget/hc;

    move-result-object p2

    const/16 v0, 0xc

    invoke-virtual {p2, v0}, Landroid/support/v7/widget/hc;->hasValue(I)Z

    move-result v1

    if-eqz v1, :cond_0

    const/4 v1, 0x0

    invoke-virtual {p2, v0, v1}, Landroid/support/v7/widget/hc;->getBoolean(IZ)Z

    move-result v0

    .line 1
    iget-object v1, p0, Landroid/support/v7/widget/aa;->mView:Landroid/widget/TextView;

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setAllCaps(Z)V

    .line 2
    :cond_0
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-direct {p0, p1, p2}, Landroid/support/v7/widget/aa;->a(Landroid/content/Context;Landroid/support/v7/widget/hc;)V

    invoke-virtual {p2}, Landroid/support/v7/widget/hc;->recycle()V

    iget-object p1, p0, Landroid/support/v7/widget/aa;->mFontTypeface:Landroid/graphics/Typeface;

    if-eqz p1, :cond_1

    iget-object p2, p0, Landroid/support/v7/widget/aa;->mView:Landroid/widget/TextView;

    iget p0, p0, Landroid/support/v7/widget/aa;->mStyle:I

    invoke-virtual {p2, p1, p0}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    :cond_1
    return-void
.end method

.method getAutoSizeMaxTextSize()I
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/aa;->No:Landroid/support/v7/widget/ca;

    invoke-virtual {p0}, Landroid/support/v7/widget/ca;->getAutoSizeMaxTextSize()I

    move-result p0

    return p0
.end method

.method getAutoSizeMinTextSize()I
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/aa;->No:Landroid/support/v7/widget/ca;

    invoke-virtual {p0}, Landroid/support/v7/widget/ca;->getAutoSizeMinTextSize()I

    move-result p0

    return p0
.end method

.method getAutoSizeStepGranularity()I
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/aa;->No:Landroid/support/v7/widget/ca;

    invoke-virtual {p0}, Landroid/support/v7/widget/ca;->getAutoSizeStepGranularity()I

    move-result p0

    return p0
.end method

.method getAutoSizeTextAvailableSizes()[I
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/aa;->No:Landroid/support/v7/widget/ca;

    invoke-virtual {p0}, Landroid/support/v7/widget/ca;->getAutoSizeTextAvailableSizes()[I

    move-result-object p0

    return-object p0
.end method

.method getAutoSizeTextType()I
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/aa;->No:Landroid/support/v7/widget/ca;

    invoke-virtual {p0}, Landroid/support/v7/widget/ca;->getAutoSizeTextType()I

    move-result p0

    return p0
.end method

.method onLayout(ZIIII)V
    .locals 0

    sget-boolean p1, Landroid/support/v4/widget/c;->zE:Z

    if-nez p1, :cond_0

    .line 1
    iget-object p0, p0, Landroid/support/v7/widget/aa;->No:Landroid/support/v7/widget/ca;

    invoke-virtual {p0}, Landroid/support/v7/widget/ca;->_a()V

    :cond_0
    return-void
.end method

.method setAutoSizeTextTypeUniformWithConfiguration(IIII)V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/aa;->No:Landroid/support/v7/widget/ca;

    invoke-virtual {p0, p1, p2, p3, p4}, Landroid/support/v7/widget/ca;->setAutoSizeTextTypeUniformWithConfiguration(IIII)V

    return-void
.end method

.method setAutoSizeTextTypeUniformWithPresetSizes([II)V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/aa;->No:Landroid/support/v7/widget/ca;

    invoke-virtual {p0, p1, p2}, Landroid/support/v7/widget/ca;->setAutoSizeTextTypeUniformWithPresetSizes([II)V

    return-void
.end method

.method setAutoSizeTextTypeWithDefaults(I)V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/aa;->No:Landroid/support/v7/widget/ca;

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/ca;->setAutoSizeTextTypeWithDefaults(I)V

    return-void
.end method

.method setTextSize(IF)V
    .locals 1

    sget-boolean v0, Landroid/support/v4/widget/c;->zE:Z

    if-nez v0, :cond_0

    invoke-virtual {p0}, Landroid/support/v7/widget/aa;->ab()Z

    move-result v0

    if-nez v0, :cond_0

    .line 1
    iget-object p0, p0, Landroid/support/v7/widget/aa;->No:Landroid/support/v7/widget/ca;

    invoke-virtual {p0, p1, p2}, Landroid/support/v7/widget/ca;->a(IF)V

    :cond_0
    return-void
.end method
