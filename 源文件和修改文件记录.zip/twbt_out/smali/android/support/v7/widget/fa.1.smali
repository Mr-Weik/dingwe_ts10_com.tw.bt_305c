.class public interface abstract Landroid/support/v7/widget/fa;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract onDetachedFromWindow()V
.end method

.method public abstract t()V
.end method
