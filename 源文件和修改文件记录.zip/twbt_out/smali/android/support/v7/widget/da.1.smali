.class Landroid/support/v7/widget/da;
.super Ljava/lang/Object;
.source ""


# instance fields
.field mData:J

.field mNext:Landroid/support/v7/widget/da;


# direct methods
.method constructor <init>()V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-wide/16 v0, 0x0

    iput-wide v0, p0, Landroid/support/v7/widget/da;->mData:J

    return-void
.end method

.method private fg()V
    .locals 1

    iget-object v0, p0, Landroid/support/v7/widget/da;->mNext:Landroid/support/v7/widget/da;

    if-nez v0, :cond_0

    new-instance v0, Landroid/support/v7/widget/da;

    invoke-direct {v0}, Landroid/support/v7/widget/da;-><init>()V

    iput-object v0, p0, Landroid/support/v7/widget/da;->mNext:Landroid/support/v7/widget/da;

    :cond_0
    return-void
.end method


# virtual methods
.method clear(I)V
    .locals 4

    const/16 v0, 0x40

    if-lt p1, v0, :cond_0

    iget-object p0, p0, Landroid/support/v7/widget/da;->mNext:Landroid/support/v7/widget/da;

    if-eqz p0, :cond_1

    sub-int/2addr p1, v0

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/da;->clear(I)V

    goto :goto_0

    :cond_0
    iget-wide v0, p0, Landroid/support/v7/widget/da;->mData:J

    const-wide/16 v2, 0x1

    shl-long/2addr v2, p1

    not-long v2, v2

    and-long/2addr v0, v2

    iput-wide v0, p0, Landroid/support/v7/widget/da;->mData:J

    :cond_1
    :goto_0
    return-void
.end method

.method countOnesBefore(I)I
    .locals 4

    iget-object v0, p0, Landroid/support/v7/widget/da;->mNext:Landroid/support/v7/widget/da;

    const/16 v1, 0x40

    const-wide/16 v2, 0x1

    if-nez v0, :cond_1

    if-lt p1, v1, :cond_0

    iget-wide p0, p0, Landroid/support/v7/widget/da;->mData:J

    invoke-static {p0, p1}, Ljava/lang/Long;->bitCount(J)I

    move-result p0

    return p0

    :cond_0
    iget-wide v0, p0, Landroid/support/v7/widget/da;->mData:J

    shl-long p0, v2, p1

    sub-long/2addr p0, v2

    and-long/2addr p0, v0

    invoke-static {p0, p1}, Ljava/lang/Long;->bitCount(J)I

    move-result p0

    return p0

    :cond_1
    if-ge p1, v1, :cond_2

    iget-wide v0, p0, Landroid/support/v7/widget/da;->mData:J

    shl-long p0, v2, p1

    sub-long/2addr p0, v2

    and-long/2addr p0, v0

    invoke-static {p0, p1}, Ljava/lang/Long;->bitCount(J)I

    move-result p0

    return p0

    :cond_2
    sub-int/2addr p1, v1

    invoke-virtual {v0, p1}, Landroid/support/v7/widget/da;->countOnesBefore(I)I

    move-result p1

    iget-wide v0, p0, Landroid/support/v7/widget/da;->mData:J

    invoke-static {v0, v1}, Ljava/lang/Long;->bitCount(J)I

    move-result p0

    add-int/2addr p0, p1

    return p0
.end method

.method get(I)Z
    .locals 4

    const/16 v0, 0x40

    if-lt p1, v0, :cond_0

    invoke-direct {p0}, Landroid/support/v7/widget/da;->fg()V

    iget-object p0, p0, Landroid/support/v7/widget/da;->mNext:Landroid/support/v7/widget/da;

    sub-int/2addr p1, v0

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/da;->get(I)Z

    move-result p0

    return p0

    :cond_0
    iget-wide v0, p0, Landroid/support/v7/widget/da;->mData:J

    const-wide/16 v2, 0x1

    shl-long p0, v2, p1

    and-long/2addr p0, v0

    const-wide/16 v0, 0x0

    cmp-long p0, p0, v0

    if-eqz p0, :cond_1

    const/4 p0, 0x1

    goto :goto_0

    :cond_1
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method insert(IZ)V
    .locals 9

    const/16 v0, 0x40

    if-lt p1, v0, :cond_0

    invoke-direct {p0}, Landroid/support/v7/widget/da;->fg()V

    iget-object p0, p0, Landroid/support/v7/widget/da;->mNext:Landroid/support/v7/widget/da;

    sub-int/2addr p1, v0

    invoke-virtual {p0, p1, p2}, Landroid/support/v7/widget/da;->insert(IZ)V

    goto :goto_2

    :cond_0
    iget-wide v0, p0, Landroid/support/v7/widget/da;->mData:J

    const-wide/high16 v2, -0x8000000000000000L

    and-long/2addr v0, v2

    const-wide/16 v2, 0x0

    cmp-long v0, v0, v2

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    move v0, v1

    goto :goto_0

    :cond_1
    move v0, v2

    :goto_0
    const-wide/16 v3, 0x1

    shl-long v5, v3, p1

    sub-long/2addr v5, v3

    iget-wide v3, p0, Landroid/support/v7/widget/da;->mData:J

    and-long v7, v3, v5

    not-long v5, v5

    and-long/2addr v3, v5

    shl-long/2addr v3, v1

    or-long/2addr v3, v7

    iput-wide v3, p0, Landroid/support/v7/widget/da;->mData:J

    if-eqz p2, :cond_2

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/da;->set(I)V

    goto :goto_1

    :cond_2
    invoke-virtual {p0, p1}, Landroid/support/v7/widget/da;->clear(I)V

    :goto_1
    if-nez v0, :cond_3

    iget-object p1, p0, Landroid/support/v7/widget/da;->mNext:Landroid/support/v7/widget/da;

    if-eqz p1, :cond_4

    :cond_3
    invoke-direct {p0}, Landroid/support/v7/widget/da;->fg()V

    iget-object p0, p0, Landroid/support/v7/widget/da;->mNext:Landroid/support/v7/widget/da;

    invoke-virtual {p0, v2, v0}, Landroid/support/v7/widget/da;->insert(IZ)V

    :cond_4
    :goto_2
    return-void
.end method

.method remove(I)Z
    .locals 10

    const/16 v0, 0x40

    if-lt p1, v0, :cond_0

    invoke-direct {p0}, Landroid/support/v7/widget/da;->fg()V

    iget-object p0, p0, Landroid/support/v7/widget/da;->mNext:Landroid/support/v7/widget/da;

    sub-int/2addr p1, v0

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/da;->remove(I)Z

    move-result p0

    return p0

    :cond_0
    const-wide/16 v0, 0x1

    shl-long v2, v0, p1

    iget-wide v4, p0, Landroid/support/v7/widget/da;->mData:J

    and-long/2addr v4, v2

    const-wide/16 v6, 0x0

    cmp-long p1, v4, v6

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz p1, :cond_1

    move p1, v4

    goto :goto_0

    :cond_1
    move p1, v5

    :goto_0
    iget-wide v6, p0, Landroid/support/v7/widget/da;->mData:J

    not-long v8, v2

    and-long/2addr v6, v8

    iput-wide v6, p0, Landroid/support/v7/widget/da;->mData:J

    sub-long/2addr v2, v0

    iget-wide v0, p0, Landroid/support/v7/widget/da;->mData:J

    and-long v6, v0, v2

    not-long v2, v2

    and-long/2addr v0, v2

    invoke-static {v0, v1, v4}, Ljava/lang/Long;->rotateRight(JI)J

    move-result-wide v0

    or-long/2addr v0, v6

    iput-wide v0, p0, Landroid/support/v7/widget/da;->mData:J

    iget-object v0, p0, Landroid/support/v7/widget/da;->mNext:Landroid/support/v7/widget/da;

    if-eqz v0, :cond_3

    invoke-virtual {v0, v5}, Landroid/support/v7/widget/da;->get(I)Z

    move-result v0

    if-eqz v0, :cond_2

    const/16 v0, 0x3f

    invoke-virtual {p0, v0}, Landroid/support/v7/widget/da;->set(I)V

    :cond_2
    iget-object p0, p0, Landroid/support/v7/widget/da;->mNext:Landroid/support/v7/widget/da;

    invoke-virtual {p0, v5}, Landroid/support/v7/widget/da;->remove(I)Z

    :cond_3
    return p1
.end method

.method reset()V
    .locals 2

    const-wide/16 v0, 0x0

    iput-wide v0, p0, Landroid/support/v7/widget/da;->mData:J

    iget-object p0, p0, Landroid/support/v7/widget/da;->mNext:Landroid/support/v7/widget/da;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroid/support/v7/widget/da;->reset()V

    :cond_0
    return-void
.end method

.method set(I)V
    .locals 4

    const/16 v0, 0x40

    if-lt p1, v0, :cond_0

    invoke-direct {p0}, Landroid/support/v7/widget/da;->fg()V

    iget-object p0, p0, Landroid/support/v7/widget/da;->mNext:Landroid/support/v7/widget/da;

    sub-int/2addr p1, v0

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/da;->set(I)V

    goto :goto_0

    :cond_0
    iget-wide v0, p0, Landroid/support/v7/widget/da;->mData:J

    const-wide/16 v2, 0x1

    shl-long/2addr v2, p1

    or-long/2addr v0, v2

    iput-wide v0, p0, Landroid/support/v7/widget/da;->mData:J

    :goto_0
    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    iget-object v0, p0, Landroid/support/v7/widget/da;->mNext:Landroid/support/v7/widget/da;

    if-nez v0, :cond_0

    iget-wide v0, p0, Landroid/support/v7/widget/da;->mData:J

    invoke-static {v0, v1}, Ljava/lang/Long;->toBinaryString(J)Ljava/lang/String;

    move-result-object p0

    goto :goto_0

    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Landroid/support/v7/widget/da;->mNext:Landroid/support/v7/widget/da;

    invoke-virtual {v1}, Landroid/support/v7/widget/da;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "xx"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v1, p0, Landroid/support/v7/widget/da;->mData:J

    invoke-static {v1, v2}, Ljava/lang/Long;->toBinaryString(J)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    :goto_0
    return-object p0
.end method
