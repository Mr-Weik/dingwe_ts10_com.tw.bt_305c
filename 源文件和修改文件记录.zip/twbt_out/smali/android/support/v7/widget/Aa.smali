.class Landroid/support/v7/widget/Aa;
.super Landroid/animation/AnimatorListenerAdapter;
.source ""


# instance fields
.field private mCanceled:Z

.field final synthetic n:Landroid/support/v7/widget/FastScroller;


# direct methods
.method synthetic constructor <init>(Landroid/support/v7/widget/FastScroller;Landroid/support/v7/widget/ya;)V
    .locals 0

    .line 1
    iput-object p1, p0, Landroid/support/v7/widget/Aa;->n:Landroid/support/v7/widget/FastScroller;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    const/4 p1, 0x0

    iput-boolean p1, p0, Landroid/support/v7/widget/Aa;->mCanceled:Z

    return-void
.end method


# virtual methods
.method public onAnimationCancel(Landroid/animation/Animator;)V
    .locals 0

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroid/support/v7/widget/Aa;->mCanceled:Z

    return-void
.end method

.method public onAnimationEnd(Landroid/animation/Animator;)V
    .locals 2

    iget-boolean p1, p0, Landroid/support/v7/widget/Aa;->mCanceled:Z

    const/4 v0, 0x0

    if-eqz p1, :cond_0

    iput-boolean v0, p0, Landroid/support/v7/widget/Aa;->mCanceled:Z

    return-void

    :cond_0
    iget-object p1, p0, Landroid/support/v7/widget/Aa;->n:Landroid/support/v7/widget/FastScroller;

    invoke-static {p1}, Landroid/support/v7/widget/FastScroller;->a(Landroid/support/v7/widget/FastScroller;)Landroid/animation/ValueAnimator;

    move-result-object p1

    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->getAnimatedValue()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Float;

    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    move-result p1

    const/4 v1, 0x0

    cmpl-float p1, p1, v1

    if-nez p1, :cond_1

    iget-object p1, p0, Landroid/support/v7/widget/Aa;->n:Landroid/support/v7/widget/FastScroller;

    invoke-static {p1, v0}, Landroid/support/v7/widget/FastScroller;->a(Landroid/support/v7/widget/FastScroller;I)I

    iget-object p0, p0, Landroid/support/v7/widget/Aa;->n:Landroid/support/v7/widget/FastScroller;

    invoke-static {p0, v0}, Landroid/support/v7/widget/FastScroller;->b(Landroid/support/v7/widget/FastScroller;I)V

    goto :goto_0

    :cond_1
    iget-object p1, p0, Landroid/support/v7/widget/Aa;->n:Landroid/support/v7/widget/FastScroller;

    const/4 v0, 0x2

    invoke-static {p1, v0}, Landroid/support/v7/widget/FastScroller;->a(Landroid/support/v7/widget/FastScroller;I)I

    iget-object p0, p0, Landroid/support/v7/widget/Aa;->n:Landroid/support/v7/widget/FastScroller;

    invoke-static {p0}, Landroid/support/v7/widget/FastScroller;->b(Landroid/support/v7/widget/FastScroller;)V

    :goto_0
    return-void
.end method
