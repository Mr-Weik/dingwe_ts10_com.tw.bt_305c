.class Landroid/support/v7/widget/Ea;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic n:Landroid/support/v7/widget/Ga;


# direct methods
.method constructor <init>(Landroid/support/v7/widget/Ga;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/widget/Ea;->n:Landroid/support/v7/widget/Ga;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    iget-object p0, p0, Landroid/support/v7/widget/Ea;->n:Landroid/support/v7/widget/Ga;

    iget-object p0, p0, Landroid/support/v7/widget/Ga;->fp:Landroid/view/View;

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p0

    if-eqz p0, :cond_0

    const/4 v0, 0x1

    invoke-interface {p0, v0}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    :cond_0
    return-void
.end method
