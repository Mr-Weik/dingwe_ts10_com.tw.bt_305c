.class public interface abstract Landroid/support/v7/widget/bb;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract a(Landroid/support/v7/view/menu/r;Landroid/view/MenuItem;)V
.end method

.method public abstract b(Landroid/support/v7/view/menu/r;Landroid/view/MenuItem;)V
.end method
