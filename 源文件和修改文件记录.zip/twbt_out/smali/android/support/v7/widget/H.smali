.class public Landroid/support/v7/widget/H;
.super Landroid/widget/ImageButton;
.source ""

# interfaces
.implements Landroid/support/v4/view/p;
.implements Landroid/support/v4/widget/l;


# instance fields
.field private final Cw:Landroid/support/v7/widget/I;

.field private final Hv:Landroid/support/v7/widget/y;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 0

    invoke-static {p1}, Landroid/support/v7/widget/ec;->b(Landroid/content/Context;)Landroid/content/Context;

    invoke-direct {p0, p1, p2, p3}, Landroid/widget/ImageButton;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    new-instance p1, Landroid/support/v7/widget/y;

    invoke-direct {p1, p0}, Landroid/support/v7/widget/y;-><init>(Landroid/view/View;)V

    iput-object p1, p0, Landroid/support/v7/widget/H;->Hv:Landroid/support/v7/widget/y;

    iget-object p1, p0, Landroid/support/v7/widget/H;->Hv:Landroid/support/v7/widget/y;

    invoke-virtual {p1, p2, p3}, Landroid/support/v7/widget/y;->a(Landroid/util/AttributeSet;I)V

    new-instance p1, Landroid/support/v7/widget/I;

    invoke-direct {p1, p0}, Landroid/support/v7/widget/I;-><init>(Landroid/widget/ImageView;)V

    iput-object p1, p0, Landroid/support/v7/widget/H;->Cw:Landroid/support/v7/widget/I;

    iget-object p0, p0, Landroid/support/v7/widget/H;->Cw:Landroid/support/v7/widget/I;

    invoke-virtual {p0, p2, p3}, Landroid/support/v7/widget/I;->a(Landroid/util/AttributeSet;I)V

    return-void
.end method


# virtual methods
.method protected drawableStateChanged()V
    .locals 1

    invoke-super {p0}, Landroid/widget/ImageButton;->drawableStateChanged()V

    iget-object v0, p0, Landroid/support/v7/widget/H;->Hv:Landroid/support/v7/widget/y;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/support/v7/widget/y;->Va()V

    :cond_0
    iget-object p0, p0, Landroid/support/v7/widget/H;->Cw:Landroid/support/v7/widget/I;

    if-eqz p0, :cond_1

    invoke-virtual {p0}, Landroid/support/v7/widget/I;->Ya()V

    :cond_1
    return-void
.end method

.method public hasOverlappingRendering()Z
    .locals 1

    iget-object v0, p0, Landroid/support/v7/widget/H;->Cw:Landroid/support/v7/widget/I;

    invoke-virtual {v0}, Landroid/support/v7/widget/I;->hasOverlappingRendering()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-super {p0}, Landroid/widget/ImageButton;->hasOverlappingRendering()Z

    move-result p0

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V
    .locals 0

    invoke-super {p0, p1}, Landroid/widget/ImageButton;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    iget-object p0, p0, Landroid/support/v7/widget/H;->Hv:Landroid/support/v7/widget/y;

    if-eqz p0, :cond_0

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/y;->d(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    return-void
.end method

.method public setBackgroundResource(I)V
    .locals 0

    invoke-super {p0, p1}, Landroid/widget/ImageButton;->setBackgroundResource(I)V

    iget-object p0, p0, Landroid/support/v7/widget/H;->Hv:Landroid/support/v7/widget/y;

    if-eqz p0, :cond_0

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/y;->W(I)V

    :cond_0
    return-void
.end method

.method public setImageBitmap(Landroid/graphics/Bitmap;)V
    .locals 0

    invoke-super {p0, p1}, Landroid/widget/ImageButton;->setImageBitmap(Landroid/graphics/Bitmap;)V

    iget-object p0, p0, Landroid/support/v7/widget/H;->Cw:Landroid/support/v7/widget/I;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroid/support/v7/widget/I;->Ya()V

    :cond_0
    return-void
.end method

.method public setImageDrawable(Landroid/graphics/drawable/Drawable;)V
    .locals 0

    invoke-super {p0, p1}, Landroid/widget/ImageButton;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    iget-object p0, p0, Landroid/support/v7/widget/H;->Cw:Landroid/support/v7/widget/I;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroid/support/v7/widget/I;->Ya()V

    :cond_0
    return-void
.end method

.method public setImageResource(I)V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/H;->Cw:Landroid/support/v7/widget/I;

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/I;->setImageResource(I)V

    return-void
.end method

.method public setImageURI(Landroid/net/Uri;)V
    .locals 0

    invoke-super {p0, p1}, Landroid/widget/ImageButton;->setImageURI(Landroid/net/Uri;)V

    iget-object p0, p0, Landroid/support/v7/widget/H;->Cw:Landroid/support/v7/widget/I;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroid/support/v7/widget/I;->Ya()V

    :cond_0
    return-void
.end method
