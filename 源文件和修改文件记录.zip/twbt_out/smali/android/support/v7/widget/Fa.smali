.class Landroid/support/v7/widget/Fa;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic n:Landroid/support/v7/widget/Ga;


# direct methods
.method constructor <init>(Landroid/support/v7/widget/Ga;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/widget/Fa;->n:Landroid/support/v7/widget/Ga;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/Fa;->n:Landroid/support/v7/widget/Ga;

    invoke-virtual {p0}, Landroid/support/v7/widget/Ga;->onLongPress()V

    return-void
.end method
