.class public Landroid/support/v7/widget/ab;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/support/v7/view/menu/L;


# static fields
.field private static Np:Ljava/lang/reflect/Method;

.field private static Op:Ljava/lang/reflect/Method;

.field private static Pp:Ljava/lang/reflect/Method;


# instance fields
.field private Ap:Z

.field private Bp:Z

.field private Cp:Landroid/view/View;

.field private Dp:I

.field private En:I

.field private Ep:Landroid/view/View;

.field private Fp:Landroid/graphics/drawable/Drawable;

.field private Gp:Landroid/widget/AdapterView$OnItemClickListener;

.field private Hp:Landroid/widget/AdapterView$OnItemSelectedListener;

.field final Ip:Landroid/support/v7/widget/_a;

.field private final Jp:Landroid/support/v7/widget/Za;

.field private final Kp:Landroid/support/v7/widget/Ya;

.field private final Lp:Landroid/support/v7/widget/Wa;

.field private Mp:Z

.field private mAdapter:Landroid/widget/ListAdapter;

.field private mContext:Landroid/content/Context;

.field private mDropDownWidth:I

.field final mHandler:Landroid/os/Handler;

.field mListItemExpandMaximum:I

.field private mObserver:Landroid/database/DataSetObserver;

.field mPopup:Landroid/widget/PopupWindow;

.field private final mTempRect:Landroid/graphics/Rect;

.field rp:Landroid/support/v7/widget/xa;

.field private sn:Landroid/graphics/Rect;

.field private sp:I

.field private tp:I

.field private vp:I

.field private wp:I

.field private xp:Z

.field private yp:Z

.field private zp:Z


# direct methods
.method static constructor <clinit>()V
    .locals 7

    const-string v0, "ListPopupWindow"

    const/4 v1, 0x0

    const/4 v2, 0x1

    :try_start_0
    const-class v3, Landroid/widget/PopupWindow;

    new-array v4, v2, [Ljava/lang/Class;

    sget-object v5, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    aput-object v5, v4, v1
    :try_end_0
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_0

    const-string v5, "setClipToScreenEnabled"

    :try_start_1
    invoke-virtual {v3, v5, v4}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v3

    sput-object v3, Landroid/support/v7/widget/ab;->Np:Ljava/lang/reflect/Method;
    :try_end_1
    .catch Ljava/lang/NoSuchMethodException; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_0

    :catch_0
    const-string v3, "Could not find method setClipToScreenEnabled() on PopupWindow. Oh well."

    invoke-static {v0, v3}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    :goto_0
    :try_start_2
    const-class v3, Landroid/widget/PopupWindow;

    const/4 v4, 0x3

    new-array v4, v4, [Ljava/lang/Class;

    const-class v5, Landroid/view/View;

    aput-object v5, v4, v1

    sget-object v5, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    aput-object v5, v4, v2

    const/4 v5, 0x2

    sget-object v6, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    aput-object v6, v4, v5
    :try_end_2
    .catch Ljava/lang/NoSuchMethodException; {:try_start_2 .. :try_end_2} :catch_1

    const-string v5, "getMaxAvailableHeight"

    :try_start_3
    invoke-virtual {v3, v5, v4}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v3

    sput-object v3, Landroid/support/v7/widget/ab;->Op:Ljava/lang/reflect/Method;
    :try_end_3
    .catch Ljava/lang/NoSuchMethodException; {:try_start_3 .. :try_end_3} :catch_1

    goto :goto_1

    :catch_1
    const-string v3, "Could not find method getMaxAvailableHeight(View, int, boolean) on PopupWindow. Oh well."

    invoke-static {v0, v3}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    :goto_1
    :try_start_4
    const-class v3, Landroid/widget/PopupWindow;

    new-array v2, v2, [Ljava/lang/Class;

    const-class v4, Landroid/graphics/Rect;

    aput-object v4, v2, v1
    :try_end_4
    .catch Ljava/lang/NoSuchMethodException; {:try_start_4 .. :try_end_4} :catch_2

    const-string v1, "setEpicenterBounds"

    :try_start_5
    invoke-virtual {v3, v1, v2}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    sput-object v1, Landroid/support/v7/widget/ab;->Pp:Ljava/lang/reflect/Method;
    :try_end_5
    .catch Ljava/lang/NoSuchMethodException; {:try_start_5 .. :try_end_5} :catch_2

    goto :goto_2

    :catch_2
    const-string v1, "Could not find method setEpicenterBounds(Rect) on PopupWindow. Oh well."

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    :goto_2
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V
    .locals 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x2

    iput v0, p0, Landroid/support/v7/widget/ab;->sp:I

    iput v0, p0, Landroid/support/v7/widget/ab;->mDropDownWidth:I

    const/16 v0, 0x3ea

    iput v0, p0, Landroid/support/v7/widget/ab;->wp:I

    const/4 v0, 0x0

    iput v0, p0, Landroid/support/v7/widget/ab;->En:I

    iput-boolean v0, p0, Landroid/support/v7/widget/ab;->Ap:Z

    iput-boolean v0, p0, Landroid/support/v7/widget/ab;->Bp:Z

    const v1, 0x7fffffff

    iput v1, p0, Landroid/support/v7/widget/ab;->mListItemExpandMaximum:I

    iput v0, p0, Landroid/support/v7/widget/ab;->Dp:I

    new-instance v1, Landroid/support/v7/widget/_a;

    invoke-direct {v1, p0}, Landroid/support/v7/widget/_a;-><init>(Landroid/support/v7/widget/ab;)V

    iput-object v1, p0, Landroid/support/v7/widget/ab;->Ip:Landroid/support/v7/widget/_a;

    new-instance v1, Landroid/support/v7/widget/Za;

    invoke-direct {v1, p0}, Landroid/support/v7/widget/Za;-><init>(Landroid/support/v7/widget/ab;)V

    iput-object v1, p0, Landroid/support/v7/widget/ab;->Jp:Landroid/support/v7/widget/Za;

    new-instance v1, Landroid/support/v7/widget/Ya;

    invoke-direct {v1, p0}, Landroid/support/v7/widget/Ya;-><init>(Landroid/support/v7/widget/ab;)V

    iput-object v1, p0, Landroid/support/v7/widget/ab;->Kp:Landroid/support/v7/widget/Ya;

    new-instance v1, Landroid/support/v7/widget/Wa;

    invoke-direct {v1, p0}, Landroid/support/v7/widget/Wa;-><init>(Landroid/support/v7/widget/ab;)V

    iput-object v1, p0, Landroid/support/v7/widget/ab;->Lp:Landroid/support/v7/widget/Wa;

    new-instance v1, Landroid/graphics/Rect;

    invoke-direct {v1}, Landroid/graphics/Rect;-><init>()V

    iput-object v1, p0, Landroid/support/v7/widget/ab;->mTempRect:Landroid/graphics/Rect;

    iput-object p1, p0, Landroid/support/v7/widget/ab;->mContext:Landroid/content/Context;

    new-instance v1, Landroid/os/Handler;

    invoke-virtual {p1}, Landroid/content/Context;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v1, p0, Landroid/support/v7/widget/ab;->mHandler:Landroid/os/Handler;

    sget-object v1, La/b/d/a/b;->ListPopupWindow:[I

    invoke-virtual {p1, p2, v1, p3, p4}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    move-result-object v1

    sget v2, La/b/d/a/b;->vk:I

    invoke-virtual {v1, v2, v0}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v2

    iput v2, p0, Landroid/support/v7/widget/ab;->tp:I

    const/4 v2, 0x1

    invoke-virtual {v1, v2, v0}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v0

    iput v0, p0, Landroid/support/v7/widget/ab;->vp:I

    iget v0, p0, Landroid/support/v7/widget/ab;->vp:I

    if-eqz v0, :cond_0

    iput-boolean v2, p0, Landroid/support/v7/widget/ab;->xp:Z

    :cond_0
    invoke-virtual {v1}, Landroid/content/res/TypedArray;->recycle()V

    new-instance v0, Landroid/support/v7/widget/L;

    invoke-direct {v0, p1, p2, p3, p4}, Landroid/support/v7/widget/L;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    iput-object v0, p0, Landroid/support/v7/widget/ab;->mPopup:Landroid/widget/PopupWindow;

    iget-object p0, p0, Landroid/support/v7/widget/ab;->mPopup:Landroid/widget/PopupWindow;

    invoke-virtual {p0, v2}, Landroid/widget/PopupWindow;->setInputMethodMode(I)V

    return-void
.end method


# virtual methods
.method createDropDownListView(Landroid/content/Context;Z)Landroid/support/v7/widget/xa;
    .locals 0

    new-instance p0, Landroid/support/v7/widget/xa;

    invoke-direct {p0, p1, p2}, Landroid/support/v7/widget/xa;-><init>(Landroid/content/Context;Z)V

    return-object p0
.end method

.method public dismiss()V
    .locals 2

    iget-object v0, p0, Landroid/support/v7/widget/ab;->mPopup:Landroid/widget/PopupWindow;

    invoke-virtual {v0}, Landroid/widget/PopupWindow;->dismiss()V

    .line 1
    iget-object v0, p0, Landroid/support/v7/widget/ab;->Cp:Landroid/view/View;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    instance-of v1, v0, Landroid/view/ViewGroup;

    if-eqz v1, :cond_0

    check-cast v0, Landroid/view/ViewGroup;

    iget-object v1, p0, Landroid/support/v7/widget/ab;->Cp:Landroid/view/View;

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 2
    :cond_0
    iget-object v0, p0, Landroid/support/v7/widget/ab;->mPopup:Landroid/widget/PopupWindow;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/PopupWindow;->setContentView(Landroid/view/View;)V

    iput-object v1, p0, Landroid/support/v7/widget/ab;->rp:Landroid/support/v7/widget/xa;

    iget-object v0, p0, Landroid/support/v7/widget/ab;->mHandler:Landroid/os/Handler;

    iget-object p0, p0, Landroid/support/v7/widget/ab;->Ip:Landroid/support/v7/widget/_a;

    invoke-virtual {v0, p0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    return-void
.end method

.method public getAnchorView()Landroid/view/View;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/ab;->Ep:Landroid/view/View;

    return-object p0
.end method

.method public getBackground()Landroid/graphics/drawable/Drawable;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/ab;->mPopup:Landroid/widget/PopupWindow;

    invoke-virtual {p0}, Landroid/widget/PopupWindow;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object p0

    return-object p0
.end method

.method public getHorizontalOffset()I
    .locals 0

    iget p0, p0, Landroid/support/v7/widget/ab;->tp:I

    return p0
.end method

.method public getListView()Landroid/widget/ListView;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/ab;->rp:Landroid/support/v7/widget/xa;

    return-object p0
.end method

.method public getVerticalOffset()I
    .locals 1

    iget-boolean v0, p0, Landroid/support/v7/widget/ab;->xp:Z

    if-nez v0, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    iget p0, p0, Landroid/support/v7/widget/ab;->vp:I

    return p0
.end method

.method public getWidth()I
    .locals 0

    iget p0, p0, Landroid/support/v7/widget/ab;->mDropDownWidth:I

    return p0
.end method

.method public isModal()Z
    .locals 0

    iget-boolean p0, p0, Landroid/support/v7/widget/ab;->Mp:Z

    return p0
.end method

.method public isShowing()Z
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/ab;->mPopup:Landroid/widget/PopupWindow;

    invoke-virtual {p0}, Landroid/widget/PopupWindow;->isShowing()Z

    move-result p0

    return p0
.end method

.method public setAdapter(Landroid/widget/ListAdapter;)V
    .locals 2

    iget-object v0, p0, Landroid/support/v7/widget/ab;->mObserver:Landroid/database/DataSetObserver;

    if-nez v0, :cond_0

    new-instance v0, Landroid/support/v7/widget/Xa;

    invoke-direct {v0, p0}, Landroid/support/v7/widget/Xa;-><init>(Landroid/support/v7/widget/ab;)V

    iput-object v0, p0, Landroid/support/v7/widget/ab;->mObserver:Landroid/database/DataSetObserver;

    goto :goto_0

    :cond_0
    iget-object v1, p0, Landroid/support/v7/widget/ab;->mAdapter:Landroid/widget/ListAdapter;

    if-eqz v1, :cond_1

    invoke-interface {v1, v0}, Landroid/widget/ListAdapter;->unregisterDataSetObserver(Landroid/database/DataSetObserver;)V

    :cond_1
    :goto_0
    iput-object p1, p0, Landroid/support/v7/widget/ab;->mAdapter:Landroid/widget/ListAdapter;

    if-eqz p1, :cond_2

    iget-object v0, p0, Landroid/support/v7/widget/ab;->mObserver:Landroid/database/DataSetObserver;

    invoke-interface {p1, v0}, Landroid/widget/ListAdapter;->registerDataSetObserver(Landroid/database/DataSetObserver;)V

    :cond_2
    iget-object p1, p0, Landroid/support/v7/widget/ab;->rp:Landroid/support/v7/widget/xa;

    if-eqz p1, :cond_3

    iget-object p0, p0, Landroid/support/v7/widget/ab;->mAdapter:Landroid/widget/ListAdapter;

    invoke-virtual {p1, p0}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    :cond_3
    return-void
.end method

.method public setAnchorView(Landroid/view/View;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/widget/ab;->Ep:Landroid/view/View;

    return-void
.end method

.method public setAnimationStyle(I)V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/ab;->mPopup:Landroid/widget/PopupWindow;

    invoke-virtual {p0, p1}, Landroid/widget/PopupWindow;->setAnimationStyle(I)V

    return-void
.end method

.method public setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/ab;->mPopup:Landroid/widget/PopupWindow;

    invoke-virtual {p0, p1}, Landroid/widget/PopupWindow;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    return-void
.end method

.method public setContentWidth(I)V
    .locals 2

    iget-object v0, p0, Landroid/support/v7/widget/ab;->mPopup:Landroid/widget/PopupWindow;

    invoke-virtual {v0}, Landroid/widget/PopupWindow;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-object v1, p0, Landroid/support/v7/widget/ab;->mTempRect:Landroid/graphics/Rect;

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable;->getPadding(Landroid/graphics/Rect;)Z

    iget-object v0, p0, Landroid/support/v7/widget/ab;->mTempRect:Landroid/graphics/Rect;

    iget v1, v0, Landroid/graphics/Rect;->left:I

    iget v0, v0, Landroid/graphics/Rect;->right:I

    add-int/2addr v1, v0

    add-int/2addr v1, p1

    iput v1, p0, Landroid/support/v7/widget/ab;->mDropDownWidth:I

    goto :goto_0

    .line 1
    :cond_0
    iput p1, p0, Landroid/support/v7/widget/ab;->mDropDownWidth:I

    :goto_0
    return-void
.end method

.method public setDropDownGravity(I)V
    .locals 0

    iput p1, p0, Landroid/support/v7/widget/ab;->En:I

    return-void
.end method

.method public setEpicenterBounds(Landroid/graphics/Rect;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/widget/ab;->sn:Landroid/graphics/Rect;

    return-void
.end method

.method public setHorizontalOffset(I)V
    .locals 0

    iput p1, p0, Landroid/support/v7/widget/ab;->tp:I

    return-void
.end method

.method public setInputMethodMode(I)V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/ab;->mPopup:Landroid/widget/PopupWindow;

    invoke-virtual {p0, p1}, Landroid/widget/PopupWindow;->setInputMethodMode(I)V

    return-void
.end method

.method public setModal(Z)V
    .locals 0

    iput-boolean p1, p0, Landroid/support/v7/widget/ab;->Mp:Z

    iget-object p0, p0, Landroid/support/v7/widget/ab;->mPopup:Landroid/widget/PopupWindow;

    invoke-virtual {p0, p1}, Landroid/widget/PopupWindow;->setFocusable(Z)V

    return-void
.end method

.method public setOnDismissListener(Landroid/widget/PopupWindow$OnDismissListener;)V
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/ab;->mPopup:Landroid/widget/PopupWindow;

    invoke-virtual {p0, p1}, Landroid/widget/PopupWindow;->setOnDismissListener(Landroid/widget/PopupWindow$OnDismissListener;)V

    return-void
.end method

.method public setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/widget/ab;->Gp:Landroid/widget/AdapterView$OnItemClickListener;

    return-void
.end method

.method public setOverlapAnchor(Z)V
    .locals 1

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v7/widget/ab;->zp:Z

    iput-boolean p1, p0, Landroid/support/v7/widget/ab;->yp:Z

    return-void
.end method

.method public setPromptPosition(I)V
    .locals 0

    iput p1, p0, Landroid/support/v7/widget/ab;->Dp:I

    return-void
.end method

.method public setVerticalOffset(I)V
    .locals 0

    iput p1, p0, Landroid/support/v7/widget/ab;->vp:I

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroid/support/v7/widget/ab;->xp:Z

    return-void
.end method

.method public show()V
    .locals 18

    move-object/from16 v1, p0

    .line 1
    iget-object v0, v1, Landroid/support/v7/widget/ab;->rp:Landroid/support/v7/widget/xa;

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/high16 v4, -0x80000000

    const-string v5, "ListPopupWindow"

    const/4 v6, -0x1

    if-nez v0, :cond_6

    iget-object v0, v1, Landroid/support/v7/widget/ab;->mContext:Landroid/content/Context;

    new-instance v7, Landroid/support/v7/widget/Ua;

    invoke-direct {v7, v1}, Landroid/support/v7/widget/Ua;-><init>(Landroid/support/v7/widget/ab;)V

    iget-boolean v7, v1, Landroid/support/v7/widget/ab;->Mp:Z

    xor-int/2addr v7, v3

    invoke-virtual {v1, v0, v7}, Landroid/support/v7/widget/ab;->createDropDownListView(Landroid/content/Context;Z)Landroid/support/v7/widget/xa;

    move-result-object v7

    iput-object v7, v1, Landroid/support/v7/widget/ab;->rp:Landroid/support/v7/widget/xa;

    iget-object v7, v1, Landroid/support/v7/widget/ab;->Fp:Landroid/graphics/drawable/Drawable;

    if-eqz v7, :cond_0

    iget-object v8, v1, Landroid/support/v7/widget/ab;->rp:Landroid/support/v7/widget/xa;

    invoke-virtual {v8, v7}, Landroid/support/v7/widget/xa;->setSelector(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    iget-object v7, v1, Landroid/support/v7/widget/ab;->rp:Landroid/support/v7/widget/xa;

    iget-object v8, v1, Landroid/support/v7/widget/ab;->mAdapter:Landroid/widget/ListAdapter;

    invoke-virtual {v7, v8}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    iget-object v7, v1, Landroid/support/v7/widget/ab;->rp:Landroid/support/v7/widget/xa;

    iget-object v8, v1, Landroid/support/v7/widget/ab;->Gp:Landroid/widget/AdapterView$OnItemClickListener;

    invoke-virtual {v7, v8}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    iget-object v7, v1, Landroid/support/v7/widget/ab;->rp:Landroid/support/v7/widget/xa;

    invoke-virtual {v7, v3}, Landroid/widget/ListView;->setFocusable(Z)V

    iget-object v7, v1, Landroid/support/v7/widget/ab;->rp:Landroid/support/v7/widget/xa;

    invoke-virtual {v7, v3}, Landroid/widget/ListView;->setFocusableInTouchMode(Z)V

    iget-object v7, v1, Landroid/support/v7/widget/ab;->rp:Landroid/support/v7/widget/xa;

    new-instance v8, Landroid/support/v7/widget/Va;

    invoke-direct {v8, v1}, Landroid/support/v7/widget/Va;-><init>(Landroid/support/v7/widget/ab;)V

    invoke-virtual {v7, v8}, Landroid/widget/ListView;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    iget-object v7, v1, Landroid/support/v7/widget/ab;->rp:Landroid/support/v7/widget/xa;

    iget-object v8, v1, Landroid/support/v7/widget/ab;->Kp:Landroid/support/v7/widget/Ya;

    invoke-virtual {v7, v8}, Landroid/widget/ListView;->setOnScrollListener(Landroid/widget/AbsListView$OnScrollListener;)V

    iget-object v7, v1, Landroid/support/v7/widget/ab;->Hp:Landroid/widget/AdapterView$OnItemSelectedListener;

    if-eqz v7, :cond_1

    iget-object v8, v1, Landroid/support/v7/widget/ab;->rp:Landroid/support/v7/widget/xa;

    invoke-virtual {v8, v7}, Landroid/widget/ListView;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    :cond_1
    iget-object v7, v1, Landroid/support/v7/widget/ab;->rp:Landroid/support/v7/widget/xa;

    iget-object v8, v1, Landroid/support/v7/widget/ab;->Cp:Landroid/view/View;

    if-eqz v8, :cond_5

    new-instance v9, Landroid/widget/LinearLayout;

    invoke-direct {v9, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    invoke-virtual {v9, v3}, Landroid/widget/LinearLayout;->setOrientation(I)V

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v10, 0x3f800000    # 1.0f

    invoke-direct {v0, v6, v2, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    iget v10, v1, Landroid/support/v7/widget/ab;->Dp:I

    if-eqz v10, :cond_3

    if-eq v10, v3, :cond_2

    const-string v0, "Invalid hint position "

    invoke-static {v0}, Lb/a/a/a/a;->x(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v7, v1, Landroid/support/v7/widget/ab;->Dp:I

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v5, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :cond_2
    invoke-virtual {v9, v7, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v9, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    goto :goto_0

    :cond_3
    invoke-virtual {v9, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    invoke-virtual {v9, v7, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :goto_0
    iget v0, v1, Landroid/support/v7/widget/ab;->mDropDownWidth:I

    if-ltz v0, :cond_4

    move v7, v4

    goto :goto_1

    :cond_4
    move v0, v2

    move v7, v0

    :goto_1
    invoke-static {v0, v7}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v0

    invoke-virtual {v8, v0, v2}, Landroid/view/View;->measure(II)V

    invoke-virtual {v8}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {v8}, Landroid/view/View;->getMeasuredHeight()I

    move-result v7

    iget v8, v0, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    add-int/2addr v7, v8

    iget v0, v0, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    add-int/2addr v0, v7

    move-object v7, v9

    goto :goto_2

    :cond_5
    move v0, v2

    :goto_2
    iget-object v8, v1, Landroid/support/v7/widget/ab;->mPopup:Landroid/widget/PopupWindow;

    invoke-virtual {v8, v7}, Landroid/widget/PopupWindow;->setContentView(Landroid/view/View;)V

    goto :goto_3

    :cond_6
    iget-object v0, v1, Landroid/support/v7/widget/ab;->mPopup:Landroid/widget/PopupWindow;

    invoke-virtual {v0}, Landroid/widget/PopupWindow;->getContentView()Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/view/ViewGroup;

    iget-object v0, v1, Landroid/support/v7/widget/ab;->Cp:Landroid/view/View;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v7

    check-cast v7, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {v0}, Landroid/view/View;->getMeasuredHeight()I

    move-result v0

    iget v8, v7, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    add-int/2addr v0, v8

    iget v7, v7, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    add-int/2addr v0, v7

    goto :goto_3

    :cond_7
    move v0, v2

    :goto_3
    iget-object v7, v1, Landroid/support/v7/widget/ab;->mPopup:Landroid/widget/PopupWindow;

    invoke-virtual {v7}, Landroid/widget/PopupWindow;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v7

    if-eqz v7, :cond_8

    iget-object v8, v1, Landroid/support/v7/widget/ab;->mTempRect:Landroid/graphics/Rect;

    invoke-virtual {v7, v8}, Landroid/graphics/drawable/Drawable;->getPadding(Landroid/graphics/Rect;)Z

    iget-object v7, v1, Landroid/support/v7/widget/ab;->mTempRect:Landroid/graphics/Rect;

    iget v8, v7, Landroid/graphics/Rect;->top:I

    iget v7, v7, Landroid/graphics/Rect;->bottom:I

    add-int/2addr v7, v8

    iget-boolean v9, v1, Landroid/support/v7/widget/ab;->xp:Z

    if-nez v9, :cond_9

    neg-int v8, v8

    iput v8, v1, Landroid/support/v7/widget/ab;->vp:I

    goto :goto_4

    :cond_8
    iget-object v7, v1, Landroid/support/v7/widget/ab;->mTempRect:Landroid/graphics/Rect;

    invoke-virtual {v7}, Landroid/graphics/Rect;->setEmpty()V

    move v7, v2

    :cond_9
    :goto_4
    iget-object v8, v1, Landroid/support/v7/widget/ab;->mPopup:Landroid/widget/PopupWindow;

    invoke-virtual {v8}, Landroid/widget/PopupWindow;->getInputMethodMode()I

    move-result v8

    const/4 v9, 0x2

    if-ne v8, v9, :cond_a

    move v8, v3

    goto :goto_5

    :cond_a
    move v8, v2

    .line 2
    :goto_5
    iget-object v10, v1, Landroid/support/v7/widget/ab;->Ep:Landroid/view/View;

    .line 3
    iget v11, v1, Landroid/support/v7/widget/ab;->vp:I

    .line 4
    sget-object v12, Landroid/support/v7/widget/ab;->Op:Ljava/lang/reflect/Method;

    if-eqz v12, :cond_b

    :try_start_0
    iget-object v13, v1, Landroid/support/v7/widget/ab;->mPopup:Landroid/widget/PopupWindow;

    const/4 v14, 0x3

    new-array v14, v14, [Ljava/lang/Object;

    aput-object v10, v14, v2

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v15

    aput-object v15, v14, v3

    invoke-static {v8}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v8

    aput-object v8, v14, v9

    invoke-virtual {v12, v13, v14}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/Integer;

    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    move-result v8
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_6

    :catch_0
    const-string v8, "Could not call getMaxAvailableHeightMethod(View, int, boolean) on PopupWindow. Using the public version."

    invoke-static {v5, v8}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    :cond_b
    iget-object v8, v1, Landroid/support/v7/widget/ab;->mPopup:Landroid/widget/PopupWindow;

    invoke-virtual {v8, v10, v11}, Landroid/widget/PopupWindow;->getMaxAvailableHeight(Landroid/view/View;I)I

    move-result v8

    .line 5
    :goto_6
    iget-boolean v10, v1, Landroid/support/v7/widget/ab;->Ap:Z

    const/4 v11, -0x2

    if-nez v10, :cond_f

    iget v10, v1, Landroid/support/v7/widget/ab;->sp:I

    if-ne v10, v6, :cond_c

    goto :goto_8

    :cond_c
    iget v10, v1, Landroid/support/v7/widget/ab;->mDropDownWidth:I

    if-eq v10, v11, :cond_d

    const/high16 v4, 0x40000000    # 2.0f

    if-eq v10, v6, :cond_d

    goto :goto_7

    :cond_d
    iget-object v10, v1, Landroid/support/v7/widget/ab;->mContext:Landroid/content/Context;

    invoke-virtual {v10}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v10

    invoke-virtual {v10}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v10

    iget v10, v10, Landroid/util/DisplayMetrics;->widthPixels:I

    iget-object v12, v1, Landroid/support/v7/widget/ab;->mTempRect:Landroid/graphics/Rect;

    iget v13, v12, Landroid/graphics/Rect;->left:I

    iget v12, v12, Landroid/graphics/Rect;->right:I

    add-int/2addr v13, v12

    sub-int/2addr v10, v13

    :goto_7
    invoke-static {v10, v4}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v13

    iget-object v12, v1, Landroid/support/v7/widget/ab;->rp:Landroid/support/v7/widget/xa;

    const/4 v14, 0x0

    const/4 v15, -0x1

    sub-int v16, v8, v0

    const/16 v17, -0x1

    invoke-virtual/range {v12 .. v17}, Landroid/support/v7/widget/xa;->c(IIIII)I

    move-result v4

    if-lez v4, :cond_e

    iget-object v8, v1, Landroid/support/v7/widget/ab;->rp:Landroid/support/v7/widget/xa;

    invoke-virtual {v8}, Landroid/widget/ListView;->getPaddingTop()I

    move-result v8

    iget-object v10, v1, Landroid/support/v7/widget/ab;->rp:Landroid/support/v7/widget/xa;

    invoke-virtual {v10}, Landroid/widget/ListView;->getPaddingBottom()I

    move-result v10

    add-int/2addr v10, v8

    add-int/2addr v10, v7

    add-int/2addr v0, v10

    :cond_e
    add-int/2addr v4, v0

    goto :goto_9

    :cond_f
    :goto_8
    add-int/2addr v8, v7

    move v4, v8

    .line 6
    :goto_9
    iget-object v0, v1, Landroid/support/v7/widget/ab;->mPopup:Landroid/widget/PopupWindow;

    invoke-virtual {v0}, Landroid/widget/PopupWindow;->getInputMethodMode()I

    move-result v0

    if-ne v0, v9, :cond_10

    move v0, v3

    goto :goto_a

    :cond_10
    move v0, v2

    .line 7
    :goto_a
    iget-object v7, v1, Landroid/support/v7/widget/ab;->mPopup:Landroid/widget/PopupWindow;

    iget v8, v1, Landroid/support/v7/widget/ab;->wp:I

    .line 8
    sget v9, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-virtual {v7, v8}, Landroid/widget/PopupWindow;->setWindowLayoutType(I)V

    .line 9
    iget-object v7, v1, Landroid/support/v7/widget/ab;->mPopup:Landroid/widget/PopupWindow;

    invoke-virtual {v7}, Landroid/widget/PopupWindow;->isShowing()Z

    move-result v7

    if-eqz v7, :cond_1d

    .line 10
    iget-object v5, v1, Landroid/support/v7/widget/ab;->Ep:Landroid/view/View;

    .line 11
    invoke-static {v5}, Landroid/support/v4/view/r;->x(Landroid/view/View;)Z

    move-result v5

    if-nez v5, :cond_11

    return-void

    :cond_11
    iget v5, v1, Landroid/support/v7/widget/ab;->mDropDownWidth:I

    if-ne v5, v6, :cond_12

    move v5, v6

    goto :goto_b

    :cond_12
    if-ne v5, v11, :cond_13

    .line 12
    iget-object v5, v1, Landroid/support/v7/widget/ab;->Ep:Landroid/view/View;

    .line 13
    invoke-virtual {v5}, Landroid/view/View;->getWidth()I

    move-result v5

    :cond_13
    :goto_b
    iget v7, v1, Landroid/support/v7/widget/ab;->sp:I

    if-ne v7, v6, :cond_18

    if-eqz v0, :cond_14

    goto :goto_c

    :cond_14
    move v4, v6

    :goto_c
    if-eqz v0, :cond_16

    iget-object v0, v1, Landroid/support/v7/widget/ab;->mPopup:Landroid/widget/PopupWindow;

    iget v7, v1, Landroid/support/v7/widget/ab;->mDropDownWidth:I

    if-ne v7, v6, :cond_15

    move v7, v6

    goto :goto_d

    :cond_15
    move v7, v2

    :goto_d
    invoke-virtual {v0, v7}, Landroid/widget/PopupWindow;->setWidth(I)V

    iget-object v0, v1, Landroid/support/v7/widget/ab;->mPopup:Landroid/widget/PopupWindow;

    invoke-virtual {v0, v2}, Landroid/widget/PopupWindow;->setHeight(I)V

    goto :goto_f

    :cond_16
    iget-object v0, v1, Landroid/support/v7/widget/ab;->mPopup:Landroid/widget/PopupWindow;

    iget v7, v1, Landroid/support/v7/widget/ab;->mDropDownWidth:I

    if-ne v7, v6, :cond_17

    move v7, v6

    goto :goto_e

    :cond_17
    move v7, v2

    :goto_e
    invoke-virtual {v0, v7}, Landroid/widget/PopupWindow;->setWidth(I)V

    iget-object v0, v1, Landroid/support/v7/widget/ab;->mPopup:Landroid/widget/PopupWindow;

    invoke-virtual {v0, v6}, Landroid/widget/PopupWindow;->setHeight(I)V

    goto :goto_f

    :cond_18
    if-ne v7, v11, :cond_19

    goto :goto_f

    :cond_19
    move v4, v7

    :goto_f
    iget-object v0, v1, Landroid/support/v7/widget/ab;->mPopup:Landroid/widget/PopupWindow;

    iget-boolean v7, v1, Landroid/support/v7/widget/ab;->Bp:Z

    if-nez v7, :cond_1a

    iget-boolean v7, v1, Landroid/support/v7/widget/ab;->Ap:Z

    if-nez v7, :cond_1a

    move v2, v3

    :cond_1a
    invoke-virtual {v0, v2}, Landroid/widget/PopupWindow;->setOutsideTouchable(Z)V

    iget-object v7, v1, Landroid/support/v7/widget/ab;->mPopup:Landroid/widget/PopupWindow;

    .line 14
    iget-object v8, v1, Landroid/support/v7/widget/ab;->Ep:Landroid/view/View;

    .line 15
    iget v9, v1, Landroid/support/v7/widget/ab;->tp:I

    iget v10, v1, Landroid/support/v7/widget/ab;->vp:I

    if-gez v5, :cond_1b

    move v11, v6

    goto :goto_10

    :cond_1b
    move v11, v5

    :goto_10
    if-gez v4, :cond_1c

    move v12, v6

    goto :goto_11

    :cond_1c
    move v12, v4

    :goto_11
    invoke-virtual/range {v7 .. v12}, Landroid/widget/PopupWindow;->update(Landroid/view/View;IIII)V

    goto/16 :goto_17

    :cond_1d
    iget v0, v1, Landroid/support/v7/widget/ab;->mDropDownWidth:I

    if-ne v0, v6, :cond_1e

    move v0, v6

    goto :goto_12

    :cond_1e
    if-ne v0, v11, :cond_1f

    .line 16
    iget-object v0, v1, Landroid/support/v7/widget/ab;->Ep:Landroid/view/View;

    .line 17
    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v0

    :cond_1f
    :goto_12
    iget v7, v1, Landroid/support/v7/widget/ab;->sp:I

    if-ne v7, v6, :cond_20

    move v4, v6

    goto :goto_13

    :cond_20
    if-ne v7, v11, :cond_21

    goto :goto_13

    :cond_21
    move v4, v7

    :goto_13
    iget-object v7, v1, Landroid/support/v7/widget/ab;->mPopup:Landroid/widget/PopupWindow;

    invoke-virtual {v7, v0}, Landroid/widget/PopupWindow;->setWidth(I)V

    iget-object v0, v1, Landroid/support/v7/widget/ab;->mPopup:Landroid/widget/PopupWindow;

    invoke-virtual {v0, v4}, Landroid/widget/PopupWindow;->setHeight(I)V

    .line 18
    sget-object v0, Landroid/support/v7/widget/ab;->Np:Ljava/lang/reflect/Method;

    if-eqz v0, :cond_22

    :try_start_1
    iget-object v4, v1, Landroid/support/v7/widget/ab;->mPopup:Landroid/widget/PopupWindow;

    new-array v7, v3, [Ljava/lang/Object;

    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v8

    aput-object v8, v7, v2

    invoke-virtual {v0, v4, v7}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_14

    :catch_1
    const-string v0, "Could not call setClipToScreenEnabled() on PopupWindow. Oh well."

    invoke-static {v5, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 19
    :cond_22
    :goto_14
    iget-object v0, v1, Landroid/support/v7/widget/ab;->mPopup:Landroid/widget/PopupWindow;

    iget-boolean v4, v1, Landroid/support/v7/widget/ab;->Bp:Z

    if-nez v4, :cond_23

    iget-boolean v4, v1, Landroid/support/v7/widget/ab;->Ap:Z

    if-nez v4, :cond_23

    move v4, v3

    goto :goto_15

    :cond_23
    move v4, v2

    :goto_15
    invoke-virtual {v0, v4}, Landroid/widget/PopupWindow;->setOutsideTouchable(Z)V

    iget-object v0, v1, Landroid/support/v7/widget/ab;->mPopup:Landroid/widget/PopupWindow;

    iget-object v4, v1, Landroid/support/v7/widget/ab;->Jp:Landroid/support/v7/widget/Za;

    invoke-virtual {v0, v4}, Landroid/widget/PopupWindow;->setTouchInterceptor(Landroid/view/View$OnTouchListener;)V

    iget-boolean v0, v1, Landroid/support/v7/widget/ab;->zp:Z

    if-eqz v0, :cond_24

    iget-object v0, v1, Landroid/support/v7/widget/ab;->mPopup:Landroid/widget/PopupWindow;

    iget-boolean v4, v1, Landroid/support/v7/widget/ab;->yp:Z

    .line 20
    sget v7, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-virtual {v0, v4}, Landroid/widget/PopupWindow;->setOverlapAnchor(Z)V

    .line 21
    :cond_24
    sget-object v0, Landroid/support/v7/widget/ab;->Pp:Ljava/lang/reflect/Method;

    if-eqz v0, :cond_25

    :try_start_2
    iget-object v4, v1, Landroid/support/v7/widget/ab;->mPopup:Landroid/widget/PopupWindow;

    new-array v7, v3, [Ljava/lang/Object;

    iget-object v8, v1, Landroid/support/v7/widget/ab;->sn:Landroid/graphics/Rect;

    aput-object v8, v7, v2

    invoke-virtual {v0, v4, v7}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2

    goto :goto_16

    :catch_2
    move-exception v0

    const-string v2, "Could not invoke setEpicenterBounds on PopupWindow"

    invoke-static {v5, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_25
    :goto_16
    iget-object v0, v1, Landroid/support/v7/widget/ab;->mPopup:Landroid/widget/PopupWindow;

    .line 22
    iget-object v2, v1, Landroid/support/v7/widget/ab;->Ep:Landroid/view/View;

    .line 23
    iget v4, v1, Landroid/support/v7/widget/ab;->tp:I

    iget v5, v1, Landroid/support/v7/widget/ab;->vp:I

    iget v7, v1, Landroid/support/v7/widget/ab;->En:I

    .line 24
    sget v8, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-virtual {v0, v2, v4, v5, v7}, Landroid/widget/PopupWindow;->showAsDropDown(Landroid/view/View;III)V

    .line 25
    iget-object v0, v1, Landroid/support/v7/widget/ab;->rp:Landroid/support/v7/widget/xa;

    invoke-virtual {v0, v6}, Landroid/widget/ListView;->setSelection(I)V

    iget-boolean v0, v1, Landroid/support/v7/widget/ab;->Mp:Z

    if-eqz v0, :cond_26

    iget-object v0, v1, Landroid/support/v7/widget/ab;->rp:Landroid/support/v7/widget/xa;

    invoke-virtual {v0}, Landroid/support/v7/widget/xa;->isInTouchMode()Z

    move-result v0

    if-eqz v0, :cond_27

    .line 26
    :cond_26
    iget-object v0, v1, Landroid/support/v7/widget/ab;->rp:Landroid/support/v7/widget/xa;

    if-eqz v0, :cond_27

    invoke-virtual {v0, v3}, Landroid/support/v7/widget/xa;->setListSelectionHidden(Z)V

    invoke-virtual {v0}, Landroid/widget/ListView;->requestLayout()V

    .line 27
    :cond_27
    iget-boolean v0, v1, Landroid/support/v7/widget/ab;->Mp:Z

    if-nez v0, :cond_28

    iget-object v0, v1, Landroid/support/v7/widget/ab;->mHandler:Landroid/os/Handler;

    iget-object v1, v1, Landroid/support/v7/widget/ab;->Lp:Landroid/support/v7/widget/Wa;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_28
    :goto_17
    return-void
.end method
