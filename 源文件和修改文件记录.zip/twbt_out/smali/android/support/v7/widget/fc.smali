.class Landroid/support/v7/widget/fc;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public is:Landroid/graphics/PorterDuff$Mode;

.field public mHasTintList:Z

.field public mHasTintMode:Z

.field public mTintList:Landroid/content/res/ColorStateList;


# direct methods
.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method clear()V
    .locals 2

    const/4 v0, 0x0

    iput-object v0, p0, Landroid/support/v7/widget/fc;->mTintList:Landroid/content/res/ColorStateList;

    const/4 v1, 0x0

    iput-boolean v1, p0, Landroid/support/v7/widget/fc;->mHasTintList:Z

    iput-object v0, p0, Landroid/support/v7/widget/fc;->is:Landroid/graphics/PorterDuff$Mode;

    iput-boolean v1, p0, Landroid/support/v7/widget/fc;->mHasTintMode:Z

    return-void
.end method
