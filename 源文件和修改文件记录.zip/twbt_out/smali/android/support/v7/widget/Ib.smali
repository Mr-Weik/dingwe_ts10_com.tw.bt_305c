.class Landroid/support/v7/widget/Ib;
.super Landroid/support/v7/widget/qb;
.source ""


# instance fields
.field final synthetic n:Landroid/support/v7/widget/RecyclerView;


# direct methods
.method constructor <init>(Landroid/support/v7/widget/RecyclerView;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v7/widget/Ib;->n:Landroid/support/v7/widget/RecyclerView;

    invoke-direct {p0}, Landroid/support/v7/widget/qb;-><init>()V

    return-void
.end method
