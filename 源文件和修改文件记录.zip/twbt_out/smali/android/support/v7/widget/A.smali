.class public Landroid/support/v7/widget/A;
.super Landroid/widget/CheckBox;
.source ""

# interfaces
.implements Landroid/support/v4/widget/k;


# instance fields
.field private final Rw:Landroid/support/v7/widget/C;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 1

    .line 1
    invoke-static {p1}, Landroid/support/v7/widget/ec;->b(Landroid/content/Context;)Landroid/content/Context;

    const v0, 0x7f030045

    invoke-direct {p0, p1, p2, v0}, Landroid/widget/CheckBox;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    new-instance p1, Landroid/support/v7/widget/C;

    invoke-direct {p1, p0}, Landroid/support/v7/widget/C;-><init>(Landroid/widget/CompoundButton;)V

    iput-object p1, p0, Landroid/support/v7/widget/A;->Rw:Landroid/support/v7/widget/C;

    iget-object p0, p0, Landroid/support/v7/widget/A;->Rw:Landroid/support/v7/widget/C;

    invoke-virtual {p0, p2, v0}, Landroid/support/v7/widget/C;->a(Landroid/util/AttributeSet;I)V

    return-void
.end method


# virtual methods
.method public getCompoundPaddingLeft()I
    .locals 1

    invoke-super {p0}, Landroid/widget/CheckBox;->getCompoundPaddingLeft()I

    move-result v0

    iget-object p0, p0, Landroid/support/v7/widget/A;->Rw:Landroid/support/v7/widget/C;

    if-eqz p0, :cond_0

    invoke-virtual {p0, v0}, Landroid/support/v7/widget/C;->X(I)I

    :cond_0
    return v0
.end method

.method public setButtonDrawable(I)V
    .locals 1

    invoke-virtual {p0}, Landroid/widget/CheckBox;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, p1}, La/b/d/b/a/a;->a(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    .line 1
    invoke-super {p0, p1}, Landroid/widget/CheckBox;->setButtonDrawable(Landroid/graphics/drawable/Drawable;)V

    iget-object p0, p0, Landroid/support/v7/widget/A;->Rw:Landroid/support/v7/widget/C;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroid/support/v7/widget/C;->Xa()V

    :cond_0
    return-void
.end method

.method public setButtonDrawable(Landroid/graphics/drawable/Drawable;)V
    .locals 0

    invoke-super {p0, p1}, Landroid/widget/CheckBox;->setButtonDrawable(Landroid/graphics/drawable/Drawable;)V

    iget-object p0, p0, Landroid/support/v7/widget/A;->Rw:Landroid/support/v7/widget/C;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroid/support/v7/widget/C;->Xa()V

    :cond_0
    return-void
.end method
