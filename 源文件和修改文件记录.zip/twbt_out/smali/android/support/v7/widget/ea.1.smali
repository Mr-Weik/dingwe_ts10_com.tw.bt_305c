.class Landroid/support/v7/widget/ea;
.super Ljava/lang/Object;
.source ""


# instance fields
.field final mBucket:Landroid/support/v7/widget/da;

.field final mCallback:Landroid/support/v7/widget/mb;

.field final mHiddenViews:Ljava/util/List;


# direct methods
.method constructor <init>(Landroid/support/v7/widget/mb;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroid/support/v7/widget/ea;->mCallback:Landroid/support/v7/widget/mb;

    new-instance p1, Landroid/support/v7/widget/da;

    invoke-direct {p1}, Landroid/support/v7/widget/da;-><init>()V

    iput-object p1, p0, Landroid/support/v7/widget/ea;->mBucket:Landroid/support/v7/widget/da;

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, Landroid/support/v7/widget/ea;->mHiddenViews:Ljava/util/List;

    return-void
.end method

.method private I(Landroid/view/View;)Z
    .locals 1

    iget-object v0, p0, Landroid/support/v7/widget/ea;->mHiddenViews:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object p0, p0, Landroid/support/v7/widget/ea;->mCallback:Landroid/support/v7/widget/mb;

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/mb;->onLeftHiddenState(Landroid/view/View;)V

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method private Pa(I)I
    .locals 4

    const/4 v0, -0x1

    if-gez p1, :cond_0

    return v0

    :cond_0
    iget-object v1, p0, Landroid/support/v7/widget/ea;->mCallback:Landroid/support/v7/widget/mb;

    invoke-virtual {v1}, Landroid/support/v7/widget/mb;->getChildCount()I

    move-result v1

    move v2, p1

    :goto_0
    if-ge v2, v1, :cond_3

    iget-object v3, p0, Landroid/support/v7/widget/ea;->mBucket:Landroid/support/v7/widget/da;

    invoke-virtual {v3, v2}, Landroid/support/v7/widget/da;->countOnesBefore(I)I

    move-result v3

    sub-int v3, v2, v3

    sub-int v3, p1, v3

    if-nez v3, :cond_2

    :goto_1
    iget-object p1, p0, Landroid/support/v7/widget/ea;->mBucket:Landroid/support/v7/widget/da;

    invoke-virtual {p1, v2}, Landroid/support/v7/widget/da;->get(I)Z

    move-result p1

    if-eqz p1, :cond_1

    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_1
    return v2

    :cond_2
    add-int/2addr v2, v3

    goto :goto_0

    :cond_3
    return v0
.end method


# virtual methods
.method addView(Landroid/view/View;IZ)V
    .locals 1

    if-gez p2, :cond_0

    iget-object p2, p0, Landroid/support/v7/widget/ea;->mCallback:Landroid/support/v7/widget/mb;

    invoke-virtual {p2}, Landroid/support/v7/widget/mb;->getChildCount()I

    move-result p2

    goto :goto_0

    :cond_0
    invoke-direct {p0, p2}, Landroid/support/v7/widget/ea;->Pa(I)I

    move-result p2

    :goto_0
    iget-object v0, p0, Landroid/support/v7/widget/ea;->mBucket:Landroid/support/v7/widget/da;

    invoke-virtual {v0, p2, p3}, Landroid/support/v7/widget/da;->insert(IZ)V

    if-eqz p3, :cond_1

    .line 1
    iget-object p3, p0, Landroid/support/v7/widget/ea;->mHiddenViews:Ljava/util/List;

    invoke-interface {p3, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    iget-object p3, p0, Landroid/support/v7/widget/ea;->mCallback:Landroid/support/v7/widget/mb;

    invoke-virtual {p3, p1}, Landroid/support/v7/widget/mb;->onEnteredHiddenState(Landroid/view/View;)V

    .line 2
    :cond_1
    iget-object p0, p0, Landroid/support/v7/widget/ea;->mCallback:Landroid/support/v7/widget/mb;

    .line 3
    iget-object p3, p0, Landroid/support/v7/widget/mb;->n:Landroid/support/v7/widget/RecyclerView;

    invoke-virtual {p3, p1, p2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V

    iget-object p0, p0, Landroid/support/v7/widget/mb;->n:Landroid/support/v7/widget/RecyclerView;

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/RecyclerView;->dispatchChildAttached(Landroid/view/View;)V

    return-void
.end method

.method attachViewToParent(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;Z)V
    .locals 1

    if-gez p2, :cond_0

    iget-object p2, p0, Landroid/support/v7/widget/ea;->mCallback:Landroid/support/v7/widget/mb;

    invoke-virtual {p2}, Landroid/support/v7/widget/mb;->getChildCount()I

    move-result p2

    goto :goto_0

    :cond_0
    invoke-direct {p0, p2}, Landroid/support/v7/widget/ea;->Pa(I)I

    move-result p2

    :goto_0
    iget-object v0, p0, Landroid/support/v7/widget/ea;->mBucket:Landroid/support/v7/widget/da;

    invoke-virtual {v0, p2, p4}, Landroid/support/v7/widget/da;->insert(IZ)V

    if-eqz p4, :cond_1

    .line 1
    iget-object p4, p0, Landroid/support/v7/widget/ea;->mHiddenViews:Ljava/util/List;

    invoke-interface {p4, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    iget-object p4, p0, Landroid/support/v7/widget/ea;->mCallback:Landroid/support/v7/widget/mb;

    invoke-virtual {p4, p1}, Landroid/support/v7/widget/mb;->onEnteredHiddenState(Landroid/view/View;)V

    .line 2
    :cond_1
    iget-object p0, p0, Landroid/support/v7/widget/ea;->mCallback:Landroid/support/v7/widget/mb;

    invoke-virtual {p0, p1, p2, p3}, Landroid/support/v7/widget/mb;->attachViewToParent(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method detachViewFromParent(I)V
    .locals 3

    invoke-direct {p0, p1}, Landroid/support/v7/widget/ea;->Pa(I)I

    move-result p1

    iget-object v0, p0, Landroid/support/v7/widget/ea;->mBucket:Landroid/support/v7/widget/da;

    invoke-virtual {v0, p1}, Landroid/support/v7/widget/da;->remove(I)Z

    iget-object p0, p0, Landroid/support/v7/widget/ea;->mCallback:Landroid/support/v7/widget/mb;

    .line 1
    iget-object v0, p0, Landroid/support/v7/widget/mb;->n:Landroid/support/v7/widget/RecyclerView;

    invoke-virtual {v0, p1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_2

    .line 2
    invoke-static {v0}, Landroid/support/v7/widget/RecyclerView;->getChildViewHolderInt(Landroid/view/View;)Landroid/support/v7/widget/Ob;

    move-result-object v0

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Landroid/support/v7/widget/Ob;->isTmpDetached()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-virtual {v0}, Landroid/support/v7/widget/Ob;->shouldIgnore()Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_0

    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "called detach on an already detached child "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    iget-object p0, p0, Landroid/support/v7/widget/mb;->n:Landroid/support/v7/widget/RecyclerView;

    invoke-virtual {p0}, Landroid/support/v7/widget/RecyclerView;->Bb()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    :goto_0
    const/16 v1, 0x100

    invoke-virtual {v0, v1}, Landroid/support/v7/widget/Ob;->addFlags(I)V

    :cond_2
    iget-object p0, p0, Landroid/support/v7/widget/mb;->n:Landroid/support/v7/widget/RecyclerView;

    invoke-static {p0, p1}, Landroid/support/v7/widget/RecyclerView;->c(Landroid/support/v7/widget/RecyclerView;I)V

    return-void
.end method

.method getChildAt(I)Landroid/view/View;
    .locals 0

    invoke-direct {p0, p1}, Landroid/support/v7/widget/ea;->Pa(I)I

    move-result p1

    iget-object p0, p0, Landroid/support/v7/widget/ea;->mCallback:Landroid/support/v7/widget/mb;

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/mb;->getChildAt(I)Landroid/view/View;

    move-result-object p0

    return-object p0
.end method

.method getChildCount()I
    .locals 1

    iget-object v0, p0, Landroid/support/v7/widget/ea;->mCallback:Landroid/support/v7/widget/mb;

    invoke-virtual {v0}, Landroid/support/v7/widget/mb;->getChildCount()I

    move-result v0

    iget-object p0, p0, Landroid/support/v7/widget/ea;->mHiddenViews:Ljava/util/List;

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result p0

    sub-int/2addr v0, p0

    return v0
.end method

.method getUnfilteredChildAt(I)Landroid/view/View;
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/ea;->mCallback:Landroid/support/v7/widget/mb;

    .line 1
    iget-object p0, p0, Landroid/support/v7/widget/mb;->n:Landroid/support/v7/widget/RecyclerView;

    invoke-virtual {p0, p1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object p0

    return-object p0
.end method

.method getUnfilteredChildCount()I
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/ea;->mCallback:Landroid/support/v7/widget/mb;

    invoke-virtual {p0}, Landroid/support/v7/widget/mb;->getChildCount()I

    move-result p0

    return p0
.end method

.method indexOfChild(Landroid/view/View;)I
    .locals 2

    iget-object v0, p0, Landroid/support/v7/widget/ea;->mCallback:Landroid/support/v7/widget/mb;

    .line 1
    iget-object v0, v0, Landroid/support/v7/widget/mb;->n:Landroid/support/v7/widget/RecyclerView;

    invoke-virtual {v0, p1}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    move-result p1

    const/4 v0, -0x1

    if-ne p1, v0, :cond_0

    return v0

    .line 2
    :cond_0
    iget-object v1, p0, Landroid/support/v7/widget/ea;->mBucket:Landroid/support/v7/widget/da;

    invoke-virtual {v1, p1}, Landroid/support/v7/widget/da;->get(I)Z

    move-result v1

    if-eqz v1, :cond_1

    return v0

    :cond_1
    iget-object p0, p0, Landroid/support/v7/widget/ea;->mBucket:Landroid/support/v7/widget/da;

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/da;->countOnesBefore(I)I

    move-result p0

    sub-int/2addr p1, p0

    return p1
.end method

.method isHidden(Landroid/view/View;)Z
    .locals 0

    iget-object p0, p0, Landroid/support/v7/widget/ea;->mHiddenViews:Ljava/util/List;

    invoke-interface {p0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result p0

    return p0
.end method

.method removeView(Landroid/view/View;)V
    .locals 2

    iget-object v0, p0, Landroid/support/v7/widget/ea;->mCallback:Landroid/support/v7/widget/mb;

    .line 1
    iget-object v0, v0, Landroid/support/v7/widget/mb;->n:Landroid/support/v7/widget/RecyclerView;

    invoke-virtual {v0, p1}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    move-result v0

    if-gez v0, :cond_0

    return-void

    .line 2
    :cond_0
    iget-object v1, p0, Landroid/support/v7/widget/ea;->mBucket:Landroid/support/v7/widget/da;

    invoke-virtual {v1, v0}, Landroid/support/v7/widget/da;->remove(I)Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-direct {p0, p1}, Landroid/support/v7/widget/ea;->I(Landroid/view/View;)Z

    :cond_1
    iget-object p0, p0, Landroid/support/v7/widget/ea;->mCallback:Landroid/support/v7/widget/mb;

    invoke-virtual {p0, v0}, Landroid/support/v7/widget/mb;->removeViewAt(I)V

    return-void
.end method

.method removeViewAt(I)V
    .locals 2

    invoke-direct {p0, p1}, Landroid/support/v7/widget/ea;->Pa(I)I

    move-result p1

    iget-object v0, p0, Landroid/support/v7/widget/ea;->mCallback:Landroid/support/v7/widget/mb;

    invoke-virtual {v0, p1}, Landroid/support/v7/widget/mb;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    iget-object v1, p0, Landroid/support/v7/widget/ea;->mBucket:Landroid/support/v7/widget/da;

    invoke-virtual {v1, p1}, Landroid/support/v7/widget/da;->remove(I)Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-direct {p0, v0}, Landroid/support/v7/widget/ea;->I(Landroid/view/View;)Z

    :cond_1
    iget-object p0, p0, Landroid/support/v7/widget/ea;->mCallback:Landroid/support/v7/widget/mb;

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/mb;->removeViewAt(I)V

    return-void
.end method

.method removeViewIfHidden(Landroid/view/View;)Z
    .locals 3

    iget-object v0, p0, Landroid/support/v7/widget/ea;->mCallback:Landroid/support/v7/widget/mb;

    .line 1
    iget-object v0, v0, Landroid/support/v7/widget/mb;->n:Landroid/support/v7/widget/RecyclerView;

    invoke-virtual {v0, p1}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    move-result v0

    const/4 v1, -0x1

    const/4 v2, 0x1

    if-ne v0, v1, :cond_0

    .line 2
    invoke-direct {p0, p1}, Landroid/support/v7/widget/ea;->I(Landroid/view/View;)Z

    return v2

    :cond_0
    iget-object v1, p0, Landroid/support/v7/widget/ea;->mBucket:Landroid/support/v7/widget/da;

    invoke-virtual {v1, v0}, Landroid/support/v7/widget/da;->get(I)Z

    move-result v1

    if-eqz v1, :cond_1

    iget-object v1, p0, Landroid/support/v7/widget/ea;->mBucket:Landroid/support/v7/widget/da;

    invoke-virtual {v1, v0}, Landroid/support/v7/widget/da;->remove(I)Z

    invoke-direct {p0, p1}, Landroid/support/v7/widget/ea;->I(Landroid/view/View;)Z

    iget-object p0, p0, Landroid/support/v7/widget/ea;->mCallback:Landroid/support/v7/widget/mb;

    invoke-virtual {p0, v0}, Landroid/support/v7/widget/mb;->removeViewAt(I)V

    return v2

    :cond_1
    const/4 p0, 0x0

    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Landroid/support/v7/widget/ea;->mBucket:Landroid/support/v7/widget/da;

    invoke-virtual {v1}, Landroid/support/v7/widget/da;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ", hidden list:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, Landroid/support/v7/widget/ea;->mHiddenViews:Ljava/util/List;

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method unhide(Landroid/view/View;)V
    .locals 2

    iget-object v0, p0, Landroid/support/v7/widget/ea;->mCallback:Landroid/support/v7/widget/mb;

    .line 1
    iget-object v0, v0, Landroid/support/v7/widget/mb;->n:Landroid/support/v7/widget/RecyclerView;

    invoke-virtual {v0, p1}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    move-result v0

    if-ltz v0, :cond_1

    .line 2
    iget-object v1, p0, Landroid/support/v7/widget/ea;->mBucket:Landroid/support/v7/widget/da;

    invoke-virtual {v1, v0}, Landroid/support/v7/widget/da;->get(I)Z

    move-result v1

    if-eqz v1, :cond_0

    iget-object v1, p0, Landroid/support/v7/widget/ea;->mBucket:Landroid/support/v7/widget/da;

    invoke-virtual {v1, v0}, Landroid/support/v7/widget/da;->clear(I)V

    invoke-direct {p0, p1}, Landroid/support/v7/widget/ea;->I(Landroid/view/View;)Z

    return-void

    :cond_0
    new-instance p0, Ljava/lang/RuntimeException;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "trying to unhide a view that was not hidden"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    new-instance p0, Ljava/lang/IllegalArgumentException;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "view is not a child, cannot hide "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method
