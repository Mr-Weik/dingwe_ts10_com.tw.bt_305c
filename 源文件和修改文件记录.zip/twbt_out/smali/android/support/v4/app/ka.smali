.class public abstract Landroid/support/v4/app/ka;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static g(Landroid/arch/lifecycle/e;)Landroid/support/v4/app/ka;
    .locals 2

    new-instance v0, Landroid/support/v4/app/na;

    move-object v1, p0

    check-cast v1, Landroid/arch/lifecycle/s;

    invoke-interface {v1}, Landroid/arch/lifecycle/s;->j()Landroid/arch/lifecycle/r;

    move-result-object v1

    invoke-direct {v0, p0, v1}, Landroid/support/v4/app/na;-><init>(Landroid/arch/lifecycle/e;Landroid/arch/lifecycle/r;)V

    return-object v0
.end method


# virtual methods
.method public abstract M()V
.end method

.method public abstract dump(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end method
