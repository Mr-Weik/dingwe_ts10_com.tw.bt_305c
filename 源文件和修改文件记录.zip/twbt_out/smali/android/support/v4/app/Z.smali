.class Landroid/support/v4/app/Z;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public firstOut:Landroid/support/v4/app/n;

.field public firstOutIsPop:Z

.field public firstOutTransaction:Landroid/support/v4/app/e;

.field public lastIn:Landroid/support/v4/app/n;

.field public lastInIsPop:Z

.field public lastInTransaction:Landroid/support/v4/app/e;


# direct methods
.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
