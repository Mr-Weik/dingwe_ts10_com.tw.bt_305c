.class Landroid/support/v4/app/N;
.super Ljava/lang/Object;
.source ""


# instance fields
.field private final Te:Z

.field private final Ue:Landroid/support/v4/app/e;

.field private Ve:I


# direct methods
.method constructor <init>(Landroid/support/v4/app/e;Z)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p2, p0, Landroid/support/v4/app/N;->Te:Z

    iput-object p1, p0, Landroid/support/v4/app/N;->Ue:Landroid/support/v4/app/e;

    return-void
.end method

.method static synthetic b(Landroid/support/v4/app/N;)Z
    .locals 0

    iget-boolean p0, p0, Landroid/support/v4/app/N;->Te:Z

    return p0
.end method

.method static synthetic c(Landroid/support/v4/app/N;)Landroid/support/v4/app/e;
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/N;->Ue:Landroid/support/v4/app/e;

    return-object p0
.end method


# virtual methods
.method public cancelTransaction()V
    .locals 3

    iget-object v0, p0, Landroid/support/v4/app/N;->Ue:Landroid/support/v4/app/e;

    iget-object v1, v0, Landroid/support/v4/app/e;->mManager:Landroid/support/v4/app/O;

    iget-boolean p0, p0, Landroid/support/v4/app/N;->Te:Z

    const/4 v2, 0x0

    invoke-static {v1, v0, p0, v2, v2}, Landroid/support/v4/app/O;->a(Landroid/support/v4/app/O;Landroid/support/v4/app/e;ZZZ)V

    return-void
.end method

.method public completeTransaction()V
    .locals 8

    iget v0, p0, Landroid/support/v4/app/N;->Ve:I

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-lez v0, :cond_0

    move v0, v1

    goto :goto_0

    :cond_0
    move v0, v2

    :goto_0
    iget-object v3, p0, Landroid/support/v4/app/N;->Ue:Landroid/support/v4/app/e;

    iget-object v3, v3, Landroid/support/v4/app/e;->mManager:Landroid/support/v4/app/O;

    iget-object v4, v3, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    move v5, v2

    :goto_1
    if-ge v5, v4, :cond_3

    iget-object v6, v3, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroid/support/v4/app/n;

    const/4 v7, 0x0

    invoke-virtual {v6, v7}, Landroid/support/v4/app/n;->a(Landroid/support/v4/app/N;)V

    if-eqz v0, :cond_2

    .line 1
    iget-object v7, v6, Landroid/support/v4/app/n;->mAnimationInfo:Landroid/support/v4/app/l;

    if-nez v7, :cond_1

    move v7, v2

    goto :goto_2

    :cond_1
    iget-boolean v7, v7, Landroid/support/v4/app/l;->mEnterTransitionPostponed:Z

    :goto_2
    if-eqz v7, :cond_2

    .line 2
    invoke-virtual {v6}, Landroid/support/v4/app/n;->startPostponedEnterTransition()V

    :cond_2
    add-int/lit8 v5, v5, 0x1

    goto :goto_1

    :cond_3
    iget-object v2, p0, Landroid/support/v4/app/N;->Ue:Landroid/support/v4/app/e;

    iget-object v3, v2, Landroid/support/v4/app/e;->mManager:Landroid/support/v4/app/O;

    iget-boolean p0, p0, Landroid/support/v4/app/N;->Te:Z

    xor-int/2addr v0, v1

    invoke-static {v3, v2, p0, v0, v1}, Landroid/support/v4/app/O;->a(Landroid/support/v4/app/O;Landroid/support/v4/app/e;ZZZ)V

    return-void
.end method

.method public isReady()Z
    .locals 0

    iget p0, p0, Landroid/support/v4/app/N;->Ve:I

    if-nez p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public onStartEnterTransition()V
    .locals 1

    iget v0, p0, Landroid/support/v4/app/N;->Ve:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Landroid/support/v4/app/N;->Ve:I

    iget v0, p0, Landroid/support/v4/app/N;->Ve:I

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iget-object p0, p0, Landroid/support/v4/app/N;->Ue:Landroid/support/v4/app/e;

    iget-object p0, p0, Landroid/support/v4/app/e;->mManager:Landroid/support/v4/app/O;

    invoke-static {p0}, Landroid/support/v4/app/O;->b(Landroid/support/v4/app/O;)V

    return-void
.end method

.method public startListening()V
    .locals 1

    iget v0, p0, Landroid/support/v4/app/N;->Ve:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Landroid/support/v4/app/N;->Ve:I

    return-void
.end method
