.class Landroid/support/v4/app/D;
.super Landroid/animation/AnimatorListenerAdapter;
.source ""


# instance fields
.field final synthetic j:Landroid/view/ViewGroup;

.field final synthetic m:Landroid/support/v4/app/n;

.field final synthetic o:Landroid/view/View;


# direct methods
.method constructor <init>(Landroid/support/v4/app/O;Landroid/view/ViewGroup;Landroid/view/View;Landroid/support/v4/app/n;)V
    .locals 0

    iput-object p2, p0, Landroid/support/v4/app/D;->j:Landroid/view/ViewGroup;

    iput-object p3, p0, Landroid/support/v4/app/D;->o:Landroid/view/View;

    iput-object p4, p0, Landroid/support/v4/app/D;->m:Landroid/support/v4/app/n;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public onAnimationEnd(Landroid/animation/Animator;)V
    .locals 2

    iget-object v0, p0, Landroid/support/v4/app/D;->j:Landroid/view/ViewGroup;

    iget-object v1, p0, Landroid/support/v4/app/D;->o:Landroid/view/View;

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->endViewTransition(Landroid/view/View;)V

    invoke-virtual {p1, p0}, Landroid/animation/Animator;->removeListener(Landroid/animation/Animator$AnimatorListener;)V

    iget-object p0, p0, Landroid/support/v4/app/D;->m:Landroid/support/v4/app/n;

    iget-object p0, p0, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    if-eqz p0, :cond_0

    const/16 p1, 0x8

    invoke-virtual {p0, p1}, Landroid/view/View;->setVisibility(I)V

    :cond_0
    return-void
.end method
