.class public Landroid/support/v4/app/t;
.super Ljava/lang/Object;
.source ""


# instance fields
.field private final mHost:Landroid/support/v4/app/u;


# direct methods
.method private constructor <init>(Landroid/support/v4/app/u;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroid/support/v4/app/t;->mHost:Landroid/support/v4/app/u;

    return-void
.end method

.method public static a(Landroid/support/v4/app/u;)Landroid/support/v4/app/t;
    .locals 1

    new-instance v0, Landroid/support/v4/app/t;

    invoke-direct {v0, p0}, Landroid/support/v4/app/t;-><init>(Landroid/support/v4/app/u;)V

    return-object v0
.end method


# virtual methods
.method public T()Landroid/support/v4/app/y;
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/t;->mHost:Landroid/support/v4/app/u;

    .line 1
    iget-object p0, p0, Landroid/support/v4/app/u;->mFragmentManager:Landroid/support/v4/app/O;

    return-object p0
.end method

.method public a(Landroid/os/Parcelable;Landroid/support/v4/app/P;)V
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/t;->mHost:Landroid/support/v4/app/u;

    iget-object p0, p0, Landroid/support/v4/app/u;->mFragmentManager:Landroid/support/v4/app/O;

    invoke-virtual {p0, p1, p2}, Landroid/support/v4/app/O;->a(Landroid/os/Parcelable;Landroid/support/v4/app/P;)V

    return-void
.end method

.method public d(Landroid/support/v4/app/n;)V
    .locals 2

    iget-object p0, p0, Landroid/support/v4/app/t;->mHost:Landroid/support/v4/app/u;

    iget-object v0, p0, Landroid/support/v4/app/u;->mFragmentManager:Landroid/support/v4/app/O;

    .line 1
    iget-object v1, v0, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    if-nez v1, :cond_0

    iput-object p0, v0, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    iput-object p0, v0, Landroid/support/v4/app/O;->mContainer:Landroid/support/v4/app/s;

    iput-object p1, v0, Landroid/support/v4/app/O;->mParent:Landroid/support/v4/app/n;

    return-void

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "Already attached"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public dispatchActivityCreated()V
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/t;->mHost:Landroid/support/v4/app/u;

    iget-object p0, p0, Landroid/support/v4/app/u;->mFragmentManager:Landroid/support/v4/app/O;

    invoke-virtual {p0}, Landroid/support/v4/app/O;->dispatchActivityCreated()V

    return-void
.end method

.method public dispatchConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/t;->mHost:Landroid/support/v4/app/u;

    iget-object p0, p0, Landroid/support/v4/app/u;->mFragmentManager:Landroid/support/v4/app/O;

    invoke-virtual {p0, p1}, Landroid/support/v4/app/O;->dispatchConfigurationChanged(Landroid/content/res/Configuration;)V

    return-void
.end method

.method public dispatchContextItemSelected(Landroid/view/MenuItem;)Z
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/t;->mHost:Landroid/support/v4/app/u;

    iget-object p0, p0, Landroid/support/v4/app/u;->mFragmentManager:Landroid/support/v4/app/O;

    invoke-virtual {p0, p1}, Landroid/support/v4/app/O;->dispatchContextItemSelected(Landroid/view/MenuItem;)Z

    move-result p0

    return p0
.end method

.method public dispatchCreate()V
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/t;->mHost:Landroid/support/v4/app/u;

    iget-object p0, p0, Landroid/support/v4/app/u;->mFragmentManager:Landroid/support/v4/app/O;

    invoke-virtual {p0}, Landroid/support/v4/app/O;->dispatchCreate()V

    return-void
.end method

.method public dispatchCreateOptionsMenu(Landroid/view/Menu;Landroid/view/MenuInflater;)Z
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/t;->mHost:Landroid/support/v4/app/u;

    iget-object p0, p0, Landroid/support/v4/app/u;->mFragmentManager:Landroid/support/v4/app/O;

    invoke-virtual {p0, p1, p2}, Landroid/support/v4/app/O;->dispatchCreateOptionsMenu(Landroid/view/Menu;Landroid/view/MenuInflater;)Z

    move-result p0

    return p0
.end method

.method public dispatchDestroy()V
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/t;->mHost:Landroid/support/v4/app/u;

    iget-object p0, p0, Landroid/support/v4/app/u;->mFragmentManager:Landroid/support/v4/app/O;

    invoke-virtual {p0}, Landroid/support/v4/app/O;->dispatchDestroy()V

    return-void
.end method

.method public dispatchLowMemory()V
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/t;->mHost:Landroid/support/v4/app/u;

    iget-object p0, p0, Landroid/support/v4/app/u;->mFragmentManager:Landroid/support/v4/app/O;

    invoke-virtual {p0}, Landroid/support/v4/app/O;->dispatchLowMemory()V

    return-void
.end method

.method public dispatchMultiWindowModeChanged(Z)V
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/t;->mHost:Landroid/support/v4/app/u;

    iget-object p0, p0, Landroid/support/v4/app/u;->mFragmentManager:Landroid/support/v4/app/O;

    invoke-virtual {p0, p1}, Landroid/support/v4/app/O;->dispatchMultiWindowModeChanged(Z)V

    return-void
.end method

.method public dispatchOptionsItemSelected(Landroid/view/MenuItem;)Z
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/t;->mHost:Landroid/support/v4/app/u;

    iget-object p0, p0, Landroid/support/v4/app/u;->mFragmentManager:Landroid/support/v4/app/O;

    invoke-virtual {p0, p1}, Landroid/support/v4/app/O;->dispatchOptionsItemSelected(Landroid/view/MenuItem;)Z

    move-result p0

    return p0
.end method

.method public dispatchOptionsMenuClosed(Landroid/view/Menu;)V
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/t;->mHost:Landroid/support/v4/app/u;

    iget-object p0, p0, Landroid/support/v4/app/u;->mFragmentManager:Landroid/support/v4/app/O;

    invoke-virtual {p0, p1}, Landroid/support/v4/app/O;->dispatchOptionsMenuClosed(Landroid/view/Menu;)V

    return-void
.end method

.method public dispatchPause()V
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/t;->mHost:Landroid/support/v4/app/u;

    iget-object p0, p0, Landroid/support/v4/app/u;->mFragmentManager:Landroid/support/v4/app/O;

    invoke-virtual {p0}, Landroid/support/v4/app/O;->dispatchPause()V

    return-void
.end method

.method public dispatchPictureInPictureModeChanged(Z)V
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/t;->mHost:Landroid/support/v4/app/u;

    iget-object p0, p0, Landroid/support/v4/app/u;->mFragmentManager:Landroid/support/v4/app/O;

    invoke-virtual {p0, p1}, Landroid/support/v4/app/O;->dispatchPictureInPictureModeChanged(Z)V

    return-void
.end method

.method public dispatchPrepareOptionsMenu(Landroid/view/Menu;)Z
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/t;->mHost:Landroid/support/v4/app/u;

    iget-object p0, p0, Landroid/support/v4/app/u;->mFragmentManager:Landroid/support/v4/app/O;

    invoke-virtual {p0, p1}, Landroid/support/v4/app/O;->dispatchPrepareOptionsMenu(Landroid/view/Menu;)Z

    move-result p0

    return p0
.end method

.method public dispatchResume()V
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/t;->mHost:Landroid/support/v4/app/u;

    iget-object p0, p0, Landroid/support/v4/app/u;->mFragmentManager:Landroid/support/v4/app/O;

    invoke-virtual {p0}, Landroid/support/v4/app/O;->dispatchResume()V

    return-void
.end method

.method public dispatchStart()V
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/t;->mHost:Landroid/support/v4/app/u;

    iget-object p0, p0, Landroid/support/v4/app/u;->mFragmentManager:Landroid/support/v4/app/O;

    invoke-virtual {p0}, Landroid/support/v4/app/O;->dispatchStart()V

    return-void
.end method

.method public dispatchStop()V
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/t;->mHost:Landroid/support/v4/app/u;

    iget-object p0, p0, Landroid/support/v4/app/u;->mFragmentManager:Landroid/support/v4/app/O;

    invoke-virtual {p0}, Landroid/support/v4/app/O;->dispatchStop()V

    return-void
.end method

.method public execPendingActions()Z
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/t;->mHost:Landroid/support/v4/app/u;

    iget-object p0, p0, Landroid/support/v4/app/u;->mFragmentManager:Landroid/support/v4/app/O;

    invoke-virtual {p0}, Landroid/support/v4/app/O;->execPendingActions()Z

    move-result p0

    return p0
.end method

.method public findFragmentByWho(Ljava/lang/String;)Landroid/support/v4/app/n;
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/t;->mHost:Landroid/support/v4/app/u;

    iget-object p0, p0, Landroid/support/v4/app/u;->mFragmentManager:Landroid/support/v4/app/O;

    invoke-virtual {p0, p1}, Landroid/support/v4/app/O;->findFragmentByWho(Ljava/lang/String;)Landroid/support/v4/app/n;

    move-result-object p0

    return-object p0
.end method

.method public noteStateNotSaved()V
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/t;->mHost:Landroid/support/v4/app/u;

    iget-object p0, p0, Landroid/support/v4/app/u;->mFragmentManager:Landroid/support/v4/app/O;

    invoke-virtual {p0}, Landroid/support/v4/app/O;->noteStateNotSaved()V

    return-void
.end method

.method public onCreateView(Landroid/view/View;Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/t;->mHost:Landroid/support/v4/app/u;

    iget-object p0, p0, Landroid/support/v4/app/u;->mFragmentManager:Landroid/support/v4/app/O;

    invoke-virtual {p0, p1, p2, p3, p4}, Landroid/support/v4/app/O;->onCreateView(Landroid/view/View;Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;

    move-result-object p0

    return-object p0
.end method

.method public retainNestedNonConfig()Landroid/support/v4/app/P;
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/t;->mHost:Landroid/support/v4/app/u;

    iget-object p0, p0, Landroid/support/v4/app/u;->mFragmentManager:Landroid/support/v4/app/O;

    invoke-virtual {p0}, Landroid/support/v4/app/O;->retainNonConfig()Landroid/support/v4/app/P;

    move-result-object p0

    return-object p0
.end method

.method public sa()V
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/t;->mHost:Landroid/support/v4/app/u;

    iget-object p0, p0, Landroid/support/v4/app/u;->mFragmentManager:Landroid/support/v4/app/O;

    invoke-virtual {p0}, Landroid/support/v4/app/O;->sa()V

    return-void
.end method

.method public saveAllState()Landroid/os/Parcelable;
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/t;->mHost:Landroid/support/v4/app/u;

    iget-object p0, p0, Landroid/support/v4/app/u;->mFragmentManager:Landroid/support/v4/app/O;

    invoke-virtual {p0}, Landroid/support/v4/app/O;->saveAllState()Landroid/os/Parcelable;

    move-result-object p0

    return-object p0
.end method
