.class public interface abstract Landroid/support/v4/app/x;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract onBackStackChanged()V
.end method
