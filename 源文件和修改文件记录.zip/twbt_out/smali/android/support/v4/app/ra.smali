.class public interface abstract Landroid/support/v4/app/ra;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract h()Landroid/content/Intent;
.end method
