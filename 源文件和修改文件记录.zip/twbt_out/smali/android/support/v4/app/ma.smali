.class final Landroid/support/v4/app/ma;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/arch/lifecycle/p;


# direct methods
.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Ljava/lang/Class;)Landroid/arch/lifecycle/o;
    .locals 0

    new-instance p0, Landroid/support/v4/app/LoaderManagerImpl$LoaderViewModel;

    invoke-direct {p0}, Landroid/support/v4/app/LoaderManagerImpl$LoaderViewModel;-><init>()V

    return-object p0
.end method
