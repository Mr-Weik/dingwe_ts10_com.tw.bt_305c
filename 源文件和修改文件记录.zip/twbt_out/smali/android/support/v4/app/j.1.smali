.class Landroid/support/v4/app/j;
.super Landroid/support/v4/app/s;
.source ""


# instance fields
.field final synthetic n:Landroid/support/v4/app/n;


# direct methods
.method constructor <init>(Landroid/support/v4/app/n;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v4/app/j;->n:Landroid/support/v4/app/n;

    invoke-direct {p0}, Landroid/support/v4/app/s;-><init>()V

    return-void
.end method


# virtual methods
.method public instantiate(Landroid/content/Context;Ljava/lang/String;Landroid/os/Bundle;)Landroid/support/v4/app/n;
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/j;->n:Landroid/support/v4/app/n;

    iget-object p0, p0, Landroid/support/v4/app/n;->mHost:Landroid/support/v4/app/u;

    invoke-virtual {p0, p1, p2, p3}, Landroid/support/v4/app/s;->instantiate(Landroid/content/Context;Ljava/lang/String;Landroid/os/Bundle;)Landroid/support/v4/app/n;

    move-result-object p0

    return-object p0
.end method

.method public onFindViewById(I)Landroid/view/View;
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/j;->n:Landroid/support/v4/app/n;

    iget-object p0, p0, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    if-eqz p0, :cond_0

    invoke-virtual {p0, p1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p0

    return-object p0

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "Fragment does not have a view"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public onHasView()Z
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/j;->n:Landroid/support/v4/app/n;

    iget-object p0, p0, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method
