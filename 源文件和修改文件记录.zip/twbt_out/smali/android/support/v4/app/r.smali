.class public Landroid/support/v4/app/r;
.super Landroid/support/v4/app/qa;
.source ""

# interfaces
.implements Landroid/arch/lifecycle/s;
.implements Landroid/support/v4/app/a;
.implements Landroid/support/v4/app/b;


# instance fields
.field private Gc:Landroid/arch/lifecycle/r;

.field bd:Z

.field cd:Z

.field dd:Z

.field ed:I

.field gd:La/b/c/f/q;

.field mCreated:Z

.field final mFragments:Landroid/support/v4/app/t;

.field final mHandler:Landroid/os/Handler;

.field mResumed:Z

.field mRetaining:Z

.field mStopped:Z


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/support/v4/app/qa;-><init>()V

    new-instance v0, Landroid/support/v4/app/o;

    invoke-direct {v0, p0}, Landroid/support/v4/app/o;-><init>(Landroid/support/v4/app/r;)V

    iput-object v0, p0, Landroid/support/v4/app/r;->mHandler:Landroid/os/Handler;

    new-instance v0, Landroid/support/v4/app/p;

    invoke-direct {v0, p0}, Landroid/support/v4/app/p;-><init>(Landroid/support/v4/app/r;)V

    invoke-static {v0}, Landroid/support/v4/app/t;->a(Landroid/support/v4/app/u;)Landroid/support/v4/app/t;

    move-result-object v0

    iput-object v0, p0, Landroid/support/v4/app/r;->mFragments:Landroid/support/v4/app/t;

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v4/app/r;->mStopped:Z

    iput-boolean v0, p0, Landroid/support/v4/app/r;->bd:Z

    return-void
.end method

.method static D(I)V
    .locals 1

    const/high16 v0, -0x10000

    and-int/2addr p0, v0

    if-nez p0, :cond_0

    return-void

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "Can only use lower 16 bits for requestCode"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private static a(Landroid/support/v4/app/y;Landroid/arch/lifecycle/Lifecycle$State;)Z
    .locals 5

    invoke-virtual {p0}, Landroid/support/v4/app/y;->getFragments()Ljava/util/List;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object p0

    const/4 v0, 0x0

    move v1, v0

    :cond_0
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_4

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/support/v4/app/n;

    if-nez v2, :cond_1

    goto :goto_0

    .line 1
    :cond_1
    iget-object v3, v2, Landroid/support/v4/app/n;->ad:Landroid/arch/lifecycle/g;

    .line 2
    invoke-virtual {v3}, Landroid/arch/lifecycle/c;->getCurrentState()Landroid/arch/lifecycle/Lifecycle$State;

    move-result-object v3

    sget-object v4, Landroid/arch/lifecycle/Lifecycle$State;->STARTED:Landroid/arch/lifecycle/Lifecycle$State;

    .line 3
    invoke-virtual {v3, v4}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    move-result v3

    const/4 v4, 0x1

    if-ltz v3, :cond_2

    move v3, v4

    goto :goto_1

    :cond_2
    move v3, v0

    :goto_1
    if-eqz v3, :cond_3

    .line 4
    iget-object v1, v2, Landroid/support/v4/app/n;->ad:Landroid/arch/lifecycle/g;

    invoke-virtual {v1, p1}, Landroid/arch/lifecycle/g;->a(Landroid/arch/lifecycle/Lifecycle$State;)V

    move v1, v4

    .line 5
    :cond_3
    iget-object v2, v2, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    if-eqz v2, :cond_0

    .line 6
    invoke-static {v2, p1}, Landroid/support/v4/app/r;->a(Landroid/support/v4/app/y;Landroid/arch/lifecycle/Lifecycle$State;)Z

    move-result v2

    or-int/2addr v1, v2

    goto :goto_0

    :cond_4
    return v1
.end method


# virtual methods
.method public T()Landroid/support/v4/app/y;
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/r;->mFragments:Landroid/support/v4/app/t;

    invoke-virtual {p0}, Landroid/support/v4/app/t;->T()Landroid/support/v4/app/y;

    move-result-object p0

    return-object p0
.end method

.method U()V
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/r;->mFragments:Landroid/support/v4/app/t;

    invoke-virtual {p0}, Landroid/support/v4/app/t;->sa()V

    return-void
.end method

.method protected V()V
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/r;->mFragments:Landroid/support/v4/app/t;

    invoke-virtual {p0}, Landroid/support/v4/app/t;->dispatchResume()V

    return-void
.end method

.method public W()Ljava/lang/Object;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public X()V
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    invoke-virtual {p0}, Landroid/app/Activity;->invalidateOptionsMenu()V

    return-void
.end method

.method final a(Landroid/view/View;Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/r;->mFragments:Landroid/support/v4/app/t;

    invoke-virtual {p0, p1, p2, p3, p4}, Landroid/support/v4/app/t;->onCreateView(Landroid/view/View;Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;

    move-result-object p0

    return-object p0
.end method

.method public a(Landroid/support/v4/app/n;)V
    .locals 0

    return-void
.end method

.method protected a(Landroid/view/View;Landroid/view/Menu;)Z
    .locals 1

    const/4 v0, 0x0

    invoke-super {p0, v0, p1, p2}, Landroid/app/Activity;->onPreparePanel(ILandroid/view/View;Landroid/view/Menu;)Z

    move-result p0

    return p0
.end method

.method public dump(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    .locals 2

    invoke-super {p0, p1, p2, p3, p4}, Landroid/app/Activity;->dump(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V

    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "Local FragmentActivity "

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, " State:"

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "  "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v1, "mCreated="

    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v1, p0, Landroid/support/v4/app/r;->mCreated:Z

    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->print(Z)V

    const-string v1, " mResumed="

    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v1, p0, Landroid/support/v4/app/r;->mResumed:Z

    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->print(Z)V

    const-string v1, " mStopped="

    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v1, p0, Landroid/support/v4/app/r;->mStopped:Z

    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->print(Z)V

    const-string v1, " mReallyStopped="

    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v1, p0, Landroid/support/v4/app/r;->bd:Z

    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->println(Z)V

    invoke-static {p0}, Landroid/support/v4/app/ka;->g(Landroid/arch/lifecycle/e;)Landroid/support/v4/app/ka;

    move-result-object v1

    invoke-virtual {v1, v0, p2, p3, p4}, Landroid/support/v4/app/ka;->dump(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V

    iget-object p0, p0, Landroid/support/v4/app/r;->mFragments:Landroid/support/v4/app/t;

    invoke-virtual {p0}, Landroid/support/v4/app/t;->T()Landroid/support/v4/app/y;

    move-result-object p0

    invoke-virtual {p0, p1, p2, p3, p4}, Landroid/support/v4/app/y;->dump(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V

    return-void
.end method

.method public j()Landroid/arch/lifecycle/r;
    .locals 1

    invoke-virtual {p0}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    move-result-object v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Landroid/support/v4/app/r;->Gc:Landroid/arch/lifecycle/r;

    if-nez v0, :cond_0

    new-instance v0, Landroid/arch/lifecycle/r;

    invoke-direct {v0}, Landroid/arch/lifecycle/r;-><init>()V

    iput-object v0, p0, Landroid/support/v4/app/r;->Gc:Landroid/arch/lifecycle/r;

    :cond_0
    iget-object p0, p0, Landroid/support/v4/app/r;->Gc:Landroid/arch/lifecycle/r;

    return-object p0

    :cond_1
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string v0, "Your activity is not yet attached to the Application instance. You can\'t request ViewModel before onCreate call."

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method protected onActivityResult(IILandroid/content/Intent;)V
    .locals 1

    iget-object v0, p0, Landroid/support/v4/app/r;->mFragments:Landroid/support/v4/app/t;

    invoke-virtual {v0}, Landroid/support/v4/app/t;->noteStateNotSaved()V

    shr-int/lit8 v0, p1, 0x10

    if-eqz v0, :cond_2

    add-int/lit8 v0, v0, -0x1

    iget-object p1, p0, Landroid/support/v4/app/r;->gd:La/b/c/f/q;

    invoke-virtual {p1, v0}, La/b/c/f/q;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    iget-object p2, p0, Landroid/support/v4/app/r;->gd:La/b/c/f/q;

    invoke-virtual {p2, v0}, La/b/c/f/q;->remove(I)V

    const-string p2, "FragmentActivity"

    if-nez p1, :cond_0

    const-string p0, "Activity result delivered for unknown Fragment."

    invoke-static {p2, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    iget-object p0, p0, Landroid/support/v4/app/r;->mFragments:Landroid/support/v4/app/t;

    invoke-virtual {p0, p1}, Landroid/support/v4/app/t;->findFragmentByWho(Ljava/lang/String;)Landroid/support/v4/app/n;

    move-result-object p0

    if-nez p0, :cond_1

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const-string p3, "Activity result no fragment exists for who: "

    invoke-virtual {p0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {p2, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    :cond_1
    return-void

    :cond_2
    invoke-static {}, Landroid/support/v4/app/c;->ua()V

    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onActivityResult(IILandroid/content/Intent;)V

    return-void
.end method

.method public onBackPressed()V
    .locals 3

    iget-object v0, p0, Landroid/support/v4/app/r;->mFragments:Landroid/support/v4/app/t;

    invoke-virtual {v0}, Landroid/support/v4/app/t;->T()Landroid/support/v4/app/y;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/v4/app/y;->isStateSaved()Z

    move-result v1

    if-eqz v1, :cond_0

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    :cond_0
    if-nez v1, :cond_1

    invoke-virtual {v0}, Landroid/support/v4/app/y;->popBackStackImmediate()Z

    move-result v0

    if-nez v0, :cond_2

    :cond_1
    invoke-super {p0}, Landroid/app/Activity;->onBackPressed()V

    :cond_2
    return-void
.end method

.method public onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 1

    invoke-super {p0, p1}, Landroid/app/Activity;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    iget-object v0, p0, Landroid/support/v4/app/r;->mFragments:Landroid/support/v4/app/t;

    invoke-virtual {v0}, Landroid/support/v4/app/t;->noteStateNotSaved()V

    iget-object p0, p0, Landroid/support/v4/app/r;->mFragments:Landroid/support/v4/app/t;

    invoke-virtual {p0, p1}, Landroid/support/v4/app/t;->dispatchConfigurationChanged(Landroid/content/res/Configuration;)V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 6

    iget-object v0, p0, Landroid/support/v4/app/r;->mFragments:Landroid/support/v4/app/t;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/support/v4/app/t;->d(Landroid/support/v4/app/n;)V

    invoke-super {p0, p1}, Landroid/support/v4/app/qa;->onCreate(Landroid/os/Bundle;)V

    invoke-virtual {p0}, Landroid/app/Activity;->getLastNonConfigurationInstance()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v4/app/q;

    if-eqz v0, :cond_0

    iget-object v2, v0, Landroid/support/v4/app/q;->Oe:Landroid/arch/lifecycle/r;

    iput-object v2, p0, Landroid/support/v4/app/r;->Gc:Landroid/arch/lifecycle/r;

    :cond_0
    const/4 v2, 0x0

    if-eqz p1, :cond_4

    const-string v3, "android:support:fragments"

    invoke-virtual {p1, v3}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v3

    iget-object v4, p0, Landroid/support/v4/app/r;->mFragments:Landroid/support/v4/app/t;

    if-eqz v0, :cond_1

    iget-object v1, v0, Landroid/support/v4/app/q;->fragments:Landroid/support/v4/app/P;

    :cond_1
    invoke-virtual {v4, v3, v1}, Landroid/support/v4/app/t;->a(Landroid/os/Parcelable;Landroid/support/v4/app/P;)V

    const-string v0, "android:support:next_request_index"

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->containsKey(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_4

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getInt(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/support/v4/app/r;->ed:I

    const-string v0, "android:support:request_indicies"

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getIntArray(Ljava/lang/String;)[I

    move-result-object v0

    const-string v1, "android:support:request_fragment_who"

    invoke-virtual {p1, v1}, Landroid/os/Bundle;->getStringArray(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    if-eqz v0, :cond_3

    if-eqz p1, :cond_3

    array-length v1, v0

    array-length v3, p1

    if-eq v1, v3, :cond_2

    goto :goto_1

    :cond_2
    new-instance v1, La/b/c/f/q;

    array-length v3, v0

    invoke-direct {v1, v3}, La/b/c/f/q;-><init>(I)V

    iput-object v1, p0, Landroid/support/v4/app/r;->gd:La/b/c/f/q;

    move v1, v2

    :goto_0
    array-length v3, v0

    if-ge v1, v3, :cond_4

    iget-object v3, p0, Landroid/support/v4/app/r;->gd:La/b/c/f/q;

    aget v4, v0, v1

    aget-object v5, p1, v1

    invoke-virtual {v3, v4, v5}, La/b/c/f/q;->put(ILjava/lang/Object;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_3
    :goto_1
    const-string p1, "FragmentActivity"

    const-string v0, "Invalid requestCode mapping in savedInstanceState."

    invoke-static {p1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    :cond_4
    iget-object p1, p0, Landroid/support/v4/app/r;->gd:La/b/c/f/q;

    if-nez p1, :cond_5

    new-instance p1, La/b/c/f/q;

    const/16 v0, 0xa

    .line 1
    invoke-direct {p1, v0}, La/b/c/f/q;-><init>(I)V

    .line 2
    iput-object p1, p0, Landroid/support/v4/app/r;->gd:La/b/c/f/q;

    iput v2, p0, Landroid/support/v4/app/r;->ed:I

    :cond_5
    iget-object p0, p0, Landroid/support/v4/app/r;->mFragments:Landroid/support/v4/app/t;

    invoke-virtual {p0}, Landroid/support/v4/app/t;->dispatchCreate()V

    return-void
.end method

.method public onCreatePanelMenu(ILandroid/view/Menu;)Z
    .locals 1

    if-nez p1, :cond_0

    invoke-super {p0, p1, p2}, Landroid/app/Activity;->onCreatePanelMenu(ILandroid/view/Menu;)Z

    move-result p1

    iget-object v0, p0, Landroid/support/v4/app/r;->mFragments:Landroid/support/v4/app/t;

    invoke-virtual {p0}, Landroid/app/Activity;->getMenuInflater()Landroid/view/MenuInflater;

    move-result-object p0

    invoke-virtual {v0, p2, p0}, Landroid/support/v4/app/t;->dispatchCreateOptionsMenu(Landroid/view/Menu;Landroid/view/MenuInflater;)Z

    move-result p0

    or-int/2addr p0, p1

    return p0

    :cond_0
    invoke-super {p0, p1, p2}, Landroid/app/Activity;->onCreatePanelMenu(ILandroid/view/Menu;)Z

    move-result p0

    return p0
.end method

.method public onCreateView(Landroid/view/View;Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;
    .locals 1

    invoke-virtual {p0, p1, p2, p3, p4}, Landroid/support/v4/app/r;->a(Landroid/view/View;Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;

    move-result-object v0

    if-nez v0, :cond_0

    invoke-super {p0, p1, p2, p3, p4}, Landroid/app/Activity;->onCreateView(Landroid/view/View;Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;

    move-result-object p0

    return-object p0

    :cond_0
    return-object v0
.end method

.method public onCreateView(Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;
    .locals 1

    const/4 v0, 0x0

    invoke-virtual {p0, v0, p1, p2, p3}, Landroid/support/v4/app/r;->a(Landroid/view/View;Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;

    move-result-object v0

    if-nez v0, :cond_0

    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onCreateView(Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;

    move-result-object p0

    return-object p0

    :cond_0
    return-object v0
.end method

.method protected onDestroy()V
    .locals 2

    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroid/support/v4/app/r;->v(Z)V

    iget-object v0, p0, Landroid/support/v4/app/r;->Gc:Landroid/arch/lifecycle/r;

    if-eqz v0, :cond_0

    iget-boolean v1, p0, Landroid/support/v4/app/r;->mRetaining:Z

    if-nez v1, :cond_0

    invoke-virtual {v0}, Landroid/arch/lifecycle/r;->clear()V

    :cond_0
    iget-object p0, p0, Landroid/support/v4/app/r;->mFragments:Landroid/support/v4/app/t;

    invoke-virtual {p0}, Landroid/support/v4/app/t;->dispatchDestroy()V

    return-void
.end method

.method public onLowMemory()V
    .locals 0

    invoke-super {p0}, Landroid/app/Activity;->onLowMemory()V

    iget-object p0, p0, Landroid/support/v4/app/r;->mFragments:Landroid/support/v4/app/t;

    invoke-virtual {p0}, Landroid/support/v4/app/t;->dispatchLowMemory()V

    return-void
.end method

.method public onMenuItemSelected(ILandroid/view/MenuItem;)Z
    .locals 1

    invoke-super {p0, p1, p2}, Landroid/app/Activity;->onMenuItemSelected(ILandroid/view/MenuItem;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    if-eqz p1, :cond_2

    const/4 v0, 0x6

    if-eq p1, v0, :cond_1

    const/4 p0, 0x0

    return p0

    :cond_1
    iget-object p0, p0, Landroid/support/v4/app/r;->mFragments:Landroid/support/v4/app/t;

    invoke-virtual {p0, p2}, Landroid/support/v4/app/t;->dispatchContextItemSelected(Landroid/view/MenuItem;)Z

    move-result p0

    return p0

    :cond_2
    iget-object p0, p0, Landroid/support/v4/app/r;->mFragments:Landroid/support/v4/app/t;

    invoke-virtual {p0, p2}, Landroid/support/v4/app/t;->dispatchOptionsItemSelected(Landroid/view/MenuItem;)Z

    move-result p0

    return p0
.end method

.method public onMultiWindowModeChanged(Z)V
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/r;->mFragments:Landroid/support/v4/app/t;

    invoke-virtual {p0, p1}, Landroid/support/v4/app/t;->dispatchMultiWindowModeChanged(Z)V

    return-void
.end method

.method protected onNewIntent(Landroid/content/Intent;)V
    .locals 0

    invoke-super {p0, p1}, Landroid/app/Activity;->onNewIntent(Landroid/content/Intent;)V

    iget-object p0, p0, Landroid/support/v4/app/r;->mFragments:Landroid/support/v4/app/t;

    invoke-virtual {p0}, Landroid/support/v4/app/t;->noteStateNotSaved()V

    return-void
.end method

.method public onPanelClosed(ILandroid/view/Menu;)V
    .locals 1

    if-eqz p1, :cond_0

    goto :goto_0

    :cond_0
    iget-object v0, p0, Landroid/support/v4/app/r;->mFragments:Landroid/support/v4/app/t;

    invoke-virtual {v0, p2}, Landroid/support/v4/app/t;->dispatchOptionsMenuClosed(Landroid/view/Menu;)V

    :goto_0
    invoke-super {p0, p1, p2}, Landroid/app/Activity;->onPanelClosed(ILandroid/view/Menu;)V

    return-void
.end method

.method protected onPause()V
    .locals 2

    invoke-super {p0}, Landroid/app/Activity;->onPause()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/support/v4/app/r;->mResumed:Z

    iget-object v0, p0, Landroid/support/v4/app/r;->mHandler:Landroid/os/Handler;

    const/4 v1, 0x2

    invoke-virtual {v0, v1}, Landroid/os/Handler;->hasMessages(I)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroid/support/v4/app/r;->mHandler:Landroid/os/Handler;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeMessages(I)V

    invoke-virtual {p0}, Landroid/support/v4/app/r;->V()V

    :cond_0
    iget-object p0, p0, Landroid/support/v4/app/r;->mFragments:Landroid/support/v4/app/t;

    invoke-virtual {p0}, Landroid/support/v4/app/t;->dispatchPause()V

    return-void
.end method

.method public onPictureInPictureModeChanged(Z)V
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/r;->mFragments:Landroid/support/v4/app/t;

    invoke-virtual {p0, p1}, Landroid/support/v4/app/t;->dispatchPictureInPictureModeChanged(Z)V

    return-void
.end method

.method protected onPostResume()V
    .locals 2

    invoke-super {p0}, Landroid/app/Activity;->onPostResume()V

    iget-object v0, p0, Landroid/support/v4/app/r;->mHandler:Landroid/os/Handler;

    const/4 v1, 0x2

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeMessages(I)V

    invoke-virtual {p0}, Landroid/support/v4/app/r;->V()V

    iget-object p0, p0, Landroid/support/v4/app/r;->mFragments:Landroid/support/v4/app/t;

    invoke-virtual {p0}, Landroid/support/v4/app/t;->execPendingActions()Z

    return-void
.end method

.method public onPreparePanel(ILandroid/view/View;Landroid/view/Menu;)Z
    .locals 0

    if-nez p1, :cond_0

    if-eqz p3, :cond_0

    invoke-virtual {p0, p2, p3}, Landroid/support/v4/app/r;->a(Landroid/view/View;Landroid/view/Menu;)Z

    move-result p1

    iget-object p0, p0, Landroid/support/v4/app/r;->mFragments:Landroid/support/v4/app/t;

    invoke-virtual {p0, p3}, Landroid/support/v4/app/t;->dispatchPrepareOptionsMenu(Landroid/view/Menu;)Z

    move-result p0

    or-int/2addr p0, p1

    return p0

    :cond_0
    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onPreparePanel(ILandroid/view/View;Landroid/view/Menu;)Z

    move-result p0

    return p0
.end method

.method public onRequestPermissionsResult(I[Ljava/lang/String;[I)V
    .locals 0

    iget-object p2, p0, Landroid/support/v4/app/r;->mFragments:Landroid/support/v4/app/t;

    invoke-virtual {p2}, Landroid/support/v4/app/t;->noteStateNotSaved()V

    shr-int/lit8 p1, p1, 0x10

    const p2, 0xffff

    and-int/2addr p1, p2

    if-eqz p1, :cond_1

    add-int/lit8 p1, p1, -0x1

    iget-object p2, p0, Landroid/support/v4/app/r;->gd:La/b/c/f/q;

    invoke-virtual {p2, p1}, La/b/c/f/q;->get(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/String;

    iget-object p3, p0, Landroid/support/v4/app/r;->gd:La/b/c/f/q;

    invoke-virtual {p3, p1}, La/b/c/f/q;->remove(I)V

    const-string p1, "FragmentActivity"

    if-nez p2, :cond_0

    const-string p0, "Activity result delivered for unknown Fragment."

    invoke-static {p1, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    iget-object p0, p0, Landroid/support/v4/app/r;->mFragments:Landroid/support/v4/app/t;

    invoke-virtual {p0, p2}, Landroid/support/v4/app/t;->findFragmentByWho(Ljava/lang/String;)Landroid/support/v4/app/n;

    move-result-object p0

    if-nez p0, :cond_1

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const-string p3, "Activity result no fragment exists for who: "

    invoke-virtual {p0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {p1, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    :cond_1
    return-void
.end method

.method protected onResume()V
    .locals 2

    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    iget-object v0, p0, Landroid/support/v4/app/r;->mHandler:Landroid/os/Handler;

    const/4 v1, 0x2

    invoke-virtual {v0, v1}, Landroid/os/Handler;->sendEmptyMessage(I)Z

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v4/app/r;->mResumed:Z

    iget-object p0, p0, Landroid/support/v4/app/r;->mFragments:Landroid/support/v4/app/t;

    invoke-virtual {p0}, Landroid/support/v4/app/t;->execPendingActions()Z

    return-void
.end method

.method public final onRetainNonConfigurationInstance()Ljava/lang/Object;
    .locals 3

    iget-boolean v0, p0, Landroid/support/v4/app/r;->mStopped:Z

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Landroid/support/v4/app/r;->v(Z)V

    :cond_0
    invoke-virtual {p0}, Landroid/support/v4/app/r;->W()Ljava/lang/Object;

    move-result-object v0

    iget-object v1, p0, Landroid/support/v4/app/r;->mFragments:Landroid/support/v4/app/t;

    invoke-virtual {v1}, Landroid/support/v4/app/t;->retainNestedNonConfig()Landroid/support/v4/app/P;

    move-result-object v1

    if-nez v1, :cond_1

    iget-object v2, p0, Landroid/support/v4/app/r;->Gc:Landroid/arch/lifecycle/r;

    if-nez v2, :cond_1

    if-nez v0, :cond_1

    const/4 p0, 0x0

    return-object p0

    :cond_1
    new-instance v0, Landroid/support/v4/app/q;

    invoke-direct {v0}, Landroid/support/v4/app/q;-><init>()V

    iget-object p0, p0, Landroid/support/v4/app/r;->Gc:Landroid/arch/lifecycle/r;

    iput-object p0, v0, Landroid/support/v4/app/q;->Oe:Landroid/arch/lifecycle/r;

    iput-object v1, v0, Landroid/support/v4/app/q;->fragments:Landroid/support/v4/app/P;

    return-object v0
.end method

.method protected onSaveInstanceState(Landroid/os/Bundle;)V
    .locals 4

    invoke-super {p0, p1}, Landroid/support/v4/app/qa;->onSaveInstanceState(Landroid/os/Bundle;)V

    .line 1
    :cond_0
    invoke-virtual {p0}, Landroid/support/v4/app/r;->T()Landroid/support/v4/app/y;

    move-result-object v0

    sget-object v1, Landroid/arch/lifecycle/Lifecycle$State;->CREATED:Landroid/arch/lifecycle/Lifecycle$State;

    invoke-static {v0, v1}, Landroid/support/v4/app/r;->a(Landroid/support/v4/app/y;Landroid/arch/lifecycle/Lifecycle$State;)Z

    move-result v0

    if-nez v0, :cond_0

    .line 2
    iget-object v0, p0, Landroid/support/v4/app/r;->mFragments:Landroid/support/v4/app/t;

    invoke-virtual {v0}, Landroid/support/v4/app/t;->saveAllState()Landroid/os/Parcelable;

    move-result-object v0

    if-eqz v0, :cond_1

    const-string v1, "android:support:fragments"

    invoke-virtual {p1, v1, v0}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    :cond_1
    iget-object v0, p0, Landroid/support/v4/app/r;->gd:La/b/c/f/q;

    invoke-virtual {v0}, La/b/c/f/q;->size()I

    move-result v0

    if-lez v0, :cond_3

    iget v0, p0, Landroid/support/v4/app/r;->ed:I

    const-string v1, "android:support:next_request_index"

    invoke-virtual {p1, v1, v0}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    iget-object v0, p0, Landroid/support/v4/app/r;->gd:La/b/c/f/q;

    invoke-virtual {v0}, La/b/c/f/q;->size()I

    move-result v0

    new-array v0, v0, [I

    iget-object v1, p0, Landroid/support/v4/app/r;->gd:La/b/c/f/q;

    invoke-virtual {v1}, La/b/c/f/q;->size()I

    move-result v1

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    :goto_0
    iget-object v3, p0, Landroid/support/v4/app/r;->gd:La/b/c/f/q;

    invoke-virtual {v3}, La/b/c/f/q;->size()I

    move-result v3

    if-ge v2, v3, :cond_2

    iget-object v3, p0, Landroid/support/v4/app/r;->gd:La/b/c/f/q;

    invoke-virtual {v3, v2}, La/b/c/f/q;->keyAt(I)I

    move-result v3

    aput v3, v0, v2

    iget-object v3, p0, Landroid/support/v4/app/r;->gd:La/b/c/f/q;

    invoke-virtual {v3, v2}, La/b/c/f/q;->valueAt(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    aput-object v3, v1, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_2
    const-string p0, "android:support:request_indicies"

    invoke-virtual {p1, p0, v0}, Landroid/os/Bundle;->putIntArray(Ljava/lang/String;[I)V

    const-string p0, "android:support:request_fragment_who"

    invoke-virtual {p1, p0, v1}, Landroid/os/Bundle;->putStringArray(Ljava/lang/String;[Ljava/lang/String;)V

    :cond_3
    return-void
.end method

.method protected onStart()V
    .locals 2

    invoke-super {p0}, Landroid/app/Activity;->onStart()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/support/v4/app/r;->mStopped:Z

    iput-boolean v0, p0, Landroid/support/v4/app/r;->bd:Z

    iget-object v0, p0, Landroid/support/v4/app/r;->mHandler:Landroid/os/Handler;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeMessages(I)V

    iget-boolean v0, p0, Landroid/support/v4/app/r;->mCreated:Z

    if-nez v0, :cond_0

    iput-boolean v1, p0, Landroid/support/v4/app/r;->mCreated:Z

    iget-object v0, p0, Landroid/support/v4/app/r;->mFragments:Landroid/support/v4/app/t;

    invoke-virtual {v0}, Landroid/support/v4/app/t;->dispatchActivityCreated()V

    :cond_0
    iget-object v0, p0, Landroid/support/v4/app/r;->mFragments:Landroid/support/v4/app/t;

    invoke-virtual {v0}, Landroid/support/v4/app/t;->noteStateNotSaved()V

    iget-object v0, p0, Landroid/support/v4/app/r;->mFragments:Landroid/support/v4/app/t;

    invoke-virtual {v0}, Landroid/support/v4/app/t;->execPendingActions()Z

    iget-object p0, p0, Landroid/support/v4/app/r;->mFragments:Landroid/support/v4/app/t;

    invoke-virtual {p0}, Landroid/support/v4/app/t;->dispatchStart()V

    return-void
.end method

.method public onStateNotSaved()V
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/r;->mFragments:Landroid/support/v4/app/t;

    invoke-virtual {p0}, Landroid/support/v4/app/t;->noteStateNotSaved()V

    return-void
.end method

.method protected onStop()V
    .locals 3

    invoke-super {p0}, Landroid/app/Activity;->onStop()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v4/app/r;->mStopped:Z

    .line 1
    :cond_0
    invoke-virtual {p0}, Landroid/support/v4/app/r;->T()Landroid/support/v4/app/y;

    move-result-object v1

    sget-object v2, Landroid/arch/lifecycle/Lifecycle$State;->CREATED:Landroid/arch/lifecycle/Lifecycle$State;

    invoke-static {v1, v2}, Landroid/support/v4/app/r;->a(Landroid/support/v4/app/y;Landroid/arch/lifecycle/Lifecycle$State;)Z

    move-result v1

    if-nez v1, :cond_0

    .line 2
    iget-object v1, p0, Landroid/support/v4/app/r;->mHandler:Landroid/os/Handler;

    invoke-virtual {v1, v0}, Landroid/os/Handler;->sendEmptyMessage(I)Z

    iget-object p0, p0, Landroid/support/v4/app/r;->mFragments:Landroid/support/v4/app/t;

    invoke-virtual {p0}, Landroid/support/v4/app/t;->dispatchStop()V

    return-void
.end method

.method public startActivityForResult(Landroid/content/Intent;I)V
    .locals 1

    iget-boolean v0, p0, Landroid/support/v4/app/r;->dd:Z

    if-nez v0, :cond_0

    const/4 v0, -0x1

    if-eq p2, v0, :cond_0

    invoke-static {p2}, Landroid/support/v4/app/r;->D(I)V

    :cond_0
    invoke-super {p0, p1, p2}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V

    return-void
.end method

.method public startActivityForResult(Landroid/content/Intent;ILandroid/os/Bundle;)V
    .locals 1

    iget-boolean v0, p0, Landroid/support/v4/app/r;->dd:Z

    if-nez v0, :cond_0

    const/4 v0, -0x1

    if-eq p2, v0, :cond_0

    invoke-static {p2}, Landroid/support/v4/app/r;->D(I)V

    :cond_0
    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;ILandroid/os/Bundle;)V

    return-void
.end method

.method public startIntentSenderForResult(Landroid/content/IntentSender;ILandroid/content/Intent;III)V
    .locals 1

    iget-boolean v0, p0, Landroid/support/v4/app/r;->cd:Z

    if-nez v0, :cond_0

    const/4 v0, -0x1

    if-eq p2, v0, :cond_0

    invoke-static {p2}, Landroid/support/v4/app/r;->D(I)V

    :cond_0
    invoke-super/range {p0 .. p6}, Landroid/app/Activity;->startIntentSenderForResult(Landroid/content/IntentSender;ILandroid/content/Intent;III)V

    return-void
.end method

.method public startIntentSenderForResult(Landroid/content/IntentSender;ILandroid/content/Intent;IIILandroid/os/Bundle;)V
    .locals 1

    iget-boolean v0, p0, Landroid/support/v4/app/r;->cd:Z

    if-nez v0, :cond_0

    const/4 v0, -0x1

    if-eq p2, v0, :cond_0

    invoke-static {p2}, Landroid/support/v4/app/r;->D(I)V

    :cond_0
    invoke-super/range {p0 .. p7}, Landroid/app/Activity;->startIntentSenderForResult(Landroid/content/IntentSender;ILandroid/content/Intent;IIILandroid/os/Bundle;)V

    return-void
.end method

.method v(Z)V
    .locals 1

    iget-boolean v0, p0, Landroid/support/v4/app/r;->bd:Z

    if-nez v0, :cond_0

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v4/app/r;->bd:Z

    iput-boolean p1, p0, Landroid/support/v4/app/r;->mRetaining:Z

    iget-object p1, p0, Landroid/support/v4/app/r;->mHandler:Landroid/os/Handler;

    invoke-virtual {p1, v0}, Landroid/os/Handler;->removeMessages(I)V

    invoke-virtual {p0}, Landroid/support/v4/app/r;->U()V

    :cond_0
    return-void
.end method

.method public y()Landroid/arch/lifecycle/c;
    .locals 0

    invoke-super {p0}, Landroid/support/v4/app/qa;->y()Landroid/arch/lifecycle/c;

    move-result-object p0

    return-object p0
.end method
