.class final Landroid/support/v4/app/q;
.super Ljava/lang/Object;
.source ""


# instance fields
.field Oe:Landroid/arch/lifecycle/r;

.field fragments:Landroid/support/v4/app/P;


# direct methods
.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
