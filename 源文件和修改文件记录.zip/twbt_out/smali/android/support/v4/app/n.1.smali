.class public Landroid/support/v4/app/n;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/content/ComponentCallbacks;
.implements Landroid/view/View$OnCreateContextMenuListener;
.implements Landroid/arch/lifecycle/e;
.implements Landroid/arch/lifecycle/s;


# static fields
.field private static final Me:La/b/c/f/p;

.field static final Ne:Ljava/lang/Object;


# instance fields
.field Gc:Landroid/arch/lifecycle/r;

.field Ge:Ljava/lang/Boolean;

.field He:Landroid/view/View;

.field Ie:F

.field private Je:Landroid/arch/lifecycle/g;

.field Ke:Landroid/arch/lifecycle/e;

.field Le:Landroid/arch/lifecycle/l;

.field ad:Landroid/arch/lifecycle/g;

.field mAdded:Z

.field mAnimationInfo:Landroid/support/v4/app/l;

.field mArguments:Landroid/os/Bundle;

.field mBackStackNesting:I

.field mCalled:Z

.field mChildFragmentManager:Landroid/support/v4/app/O;

.field mChildNonConfig:Landroid/support/v4/app/P;

.field mContainer:Landroid/view/ViewGroup;

.field mContainerId:I

.field mDeferStart:Z

.field mDetached:Z

.field mFragmentId:I

.field mFragmentManager:Landroid/support/v4/app/O;

.field mFromLayout:Z

.field mHasMenu:Z

.field mHidden:Z

.field mHiddenChanged:Z

.field mHost:Landroid/support/v4/app/u;

.field mInLayout:Z

.field mIndex:I

.field mIsCreated:Z

.field mIsNewlyAdded:Z

.field mLayoutInflater:Landroid/view/LayoutInflater;

.field mMenuVisible:Z

.field mParentFragment:Landroid/support/v4/app/n;

.field mPerformedCreateView:Z

.field mRemoving:Z

.field mRestored:Z

.field mRetainInstance:Z

.field mRetaining:Z

.field mSavedFragmentState:Landroid/os/Bundle;

.field mSavedViewState:Landroid/util/SparseArray;

.field mState:I

.field mTag:Ljava/lang/String;

.field mTarget:Landroid/support/v4/app/n;

.field mTargetIndex:I

.field mTargetRequestCode:I

.field mUserVisibleHint:Z

.field mView:Landroid/view/View;

.field mWho:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, La/b/c/f/p;

    invoke-direct {v0}, La/b/c/f/p;-><init>()V

    sput-object v0, Landroid/support/v4/app/n;->Me:La/b/c/f/p;

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Landroid/support/v4/app/n;->Ne:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, Landroid/support/v4/app/n;->mState:I

    const/4 v0, -0x1

    iput v0, p0, Landroid/support/v4/app/n;->mIndex:I

    iput v0, p0, Landroid/support/v4/app/n;->mTargetIndex:I

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v4/app/n;->mMenuVisible:Z

    iput-boolean v0, p0, Landroid/support/v4/app/n;->mUserVisibleHint:Z

    new-instance v0, Landroid/arch/lifecycle/g;

    invoke-direct {v0, p0}, Landroid/arch/lifecycle/g;-><init>(Landroid/arch/lifecycle/e;)V

    iput-object v0, p0, Landroid/support/v4/app/n;->ad:Landroid/arch/lifecycle/g;

    new-instance v0, Landroid/arch/lifecycle/l;

    invoke-direct {v0}, Landroid/arch/lifecycle/l;-><init>()V

    iput-object v0, p0, Landroid/support/v4/app/n;->Le:Landroid/arch/lifecycle/l;

    return-void
.end method

.method private Of()V
    .locals 2

    iget-object p0, p0, Landroid/support/v4/app/n;->mAnimationInfo:Landroid/support/v4/app/l;

    const/4 v0, 0x0

    if-nez p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    iput-boolean v1, p0, Landroid/support/v4/app/l;->mEnterTransitionPostponed:Z

    iget-object v1, p0, Landroid/support/v4/app/l;->mStartEnterTransitionListener:Landroid/support/v4/app/N;

    iput-object v0, p0, Landroid/support/v4/app/l;->mStartEnterTransitionListener:Landroid/support/v4/app/N;

    move-object v0, v1

    :goto_0
    if-eqz v0, :cond_1

    invoke-virtual {v0}, Landroid/support/v4/app/N;->onStartEnterTransition()V

    :cond_1
    return-void
.end method

.method private Pf()Landroid/support/v4/app/l;
    .locals 1

    iget-object v0, p0, Landroid/support/v4/app/n;->mAnimationInfo:Landroid/support/v4/app/l;

    if-nez v0, :cond_0

    new-instance v0, Landroid/support/v4/app/l;

    invoke-direct {v0}, Landroid/support/v4/app/l;-><init>()V

    iput-object v0, p0, Landroid/support/v4/app/n;->mAnimationInfo:Landroid/support/v4/app/l;

    :cond_0
    iget-object p0, p0, Landroid/support/v4/app/n;->mAnimationInfo:Landroid/support/v4/app/l;

    return-object p0
.end method

.method static synthetic a(Landroid/support/v4/app/n;Landroid/arch/lifecycle/g;)Landroid/arch/lifecycle/g;
    .locals 0

    iput-object p1, p0, Landroid/support/v4/app/n;->Je:Landroid/arch/lifecycle/g;

    return-object p1
.end method

.method static synthetic b(Landroid/support/v4/app/n;)V
    .locals 0

    invoke-direct {p0}, Landroid/support/v4/app/n;->Of()V

    return-void
.end method

.method static b(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 1

    :try_start_0
    sget-object v0, Landroid/support/v4/app/n;->Me:La/b/c/f/p;

    invoke-virtual {v0, p1}, La/b/c/f/p;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Class;

    if-nez v0, :cond_0

    invoke-virtual {p0}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object p0

    invoke-virtual {p0, p1}, Ljava/lang/ClassLoader;->loadClass(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    sget-object p0, Landroid/support/v4/app/n;->Me:La/b/c/f/p;

    invoke-virtual {p0, p1, v0}, La/b/c/f/p;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    const-class p0, Landroid/support/v4/app/n;

    invoke-virtual {p0, v0}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result p0
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    return p0

    :catch_0
    const/4 p0, 0x0

    return p0
.end method

.method static synthetic c(Landroid/support/v4/app/n;)Landroid/arch/lifecycle/g;
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/n;->Je:Landroid/arch/lifecycle/g;

    return-object p0
.end method

.method public static instantiate(Landroid/content/Context;Ljava/lang/String;Landroid/os/Bundle;)Landroid/support/v4/app/n;
    .locals 5

    const-string v0, " empty constructor that is public"

    const-string v1, ": make sure class name exists, is public, and has an"

    const-string v2, "Unable to instantiate fragment "

    :try_start_0
    sget-object v3, Landroid/support/v4/app/n;->Me:La/b/c/f/p;

    invoke-virtual {v3, p1}, La/b/c/f/p;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Class;

    if-nez v3, :cond_0

    invoke-virtual {p0}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object p0

    invoke-virtual {p0, p1}, Ljava/lang/ClassLoader;->loadClass(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v3

    sget-object p0, Landroid/support/v4/app/n;->Me:La/b/c/f/p;

    invoke-virtual {p0, p1, v3}, La/b/c/f/p;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    const/4 p0, 0x0

    new-array v4, p0, [Ljava/lang/Class;

    invoke-virtual {v3, v4}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object v3

    new-array p0, p0, [Ljava/lang/Object;

    invoke-virtual {v3, p0}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/support/v4/app/n;

    if-eqz p2, :cond_1

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v3

    invoke-virtual {p2, v3}, Landroid/os/Bundle;->setClassLoader(Ljava/lang/ClassLoader;)V

    invoke-virtual {p0, p2}, Landroid/support/v4/app/n;->setArguments(Landroid/os/Bundle;)V
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_4
    .catch Ljava/lang/InstantiationException; {:try_start_0 .. :try_end_0} :catch_3
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0

    :cond_1
    return-object p0

    :catch_0
    move-exception p0

    new-instance p2, Landroid/support/v4/app/Fragment$InstantiationException;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, ": calling Fragment constructor caused an exception"

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1, p0}, Landroid/support/v4/app/Fragment$InstantiationException;-><init>(Ljava/lang/String;Ljava/lang/Exception;)V

    throw p2

    :catch_1
    move-exception p0

    new-instance p2, Landroid/support/v4/app/Fragment$InstantiationException;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, ": could not find Fragment constructor"

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1, p0}, Landroid/support/v4/app/Fragment$InstantiationException;-><init>(Ljava/lang/String;Ljava/lang/Exception;)V

    throw p2

    :catch_2
    move-exception p0

    new-instance p2, Landroid/support/v4/app/Fragment$InstantiationException;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1, p0}, Landroid/support/v4/app/Fragment$InstantiationException;-><init>(Ljava/lang/String;Ljava/lang/Exception;)V

    throw p2

    :catch_3
    move-exception p0

    new-instance p2, Landroid/support/v4/app/Fragment$InstantiationException;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1, p0}, Landroid/support/v4/app/Fragment$InstantiationException;-><init>(Ljava/lang/String;Ljava/lang/Exception;)V

    throw p2

    :catch_4
    move-exception p0

    new-instance p2, Landroid/support/v4/app/Fragment$InstantiationException;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1, p0}, Landroid/support/v4/app/Fragment$InstantiationException;-><init>(Ljava/lang/String;Ljava/lang/Exception;)V

    throw p2
.end method


# virtual methods
.method final a(ILandroid/support/v4/app/n;)V
    .locals 0

    iput p1, p0, Landroid/support/v4/app/n;->mIndex:I

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    if-eqz p2, :cond_0

    iget-object p2, p2, Landroid/support/v4/app/n;->mWho:Ljava/lang/String;

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p2, ":"

    goto :goto_0

    :cond_0
    const-string p2, "android:fragment:"

    :goto_0
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget p2, p0, Landroid/support/v4/app/n;->mIndex:I

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Landroid/support/v4/app/n;->mWho:Ljava/lang/String;

    return-void
.end method

.method a(Landroid/animation/Animator;)V
    .locals 0

    invoke-direct {p0}, Landroid/support/v4/app/n;->Pf()Landroid/support/v4/app/l;

    move-result-object p0

    iput-object p1, p0, Landroid/support/v4/app/l;->mAnimator:Landroid/animation/Animator;

    return-void
.end method

.method a(Landroid/os/Bundle;)V
    .locals 2

    if-eqz p1, :cond_1

    const-string v0, "android:support:fragments"

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p1

    if-eqz p1, :cond_1

    iget-object v0, p0, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    if-nez v0, :cond_0

    invoke-virtual {p0}, Landroid/support/v4/app/n;->instantiateChildFragmentManager()V

    :cond_0
    iget-object v0, p0, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    iget-object v1, p0, Landroid/support/v4/app/n;->mChildNonConfig:Landroid/support/v4/app/P;

    invoke-virtual {v0, p1, v1}, Landroid/support/v4/app/O;->a(Landroid/os/Parcelable;Landroid/support/v4/app/P;)V

    const/4 p1, 0x0

    iput-object p1, p0, Landroid/support/v4/app/n;->mChildNonConfig:Landroid/support/v4/app/P;

    iget-object p0, p0, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    invoke-virtual {p0}, Landroid/support/v4/app/O;->dispatchCreate()V

    :cond_1
    return-void
.end method

.method a(Landroid/support/v4/app/N;)V
    .locals 2

    invoke-direct {p0}, Landroid/support/v4/app/n;->Pf()Landroid/support/v4/app/l;

    iget-object v0, p0, Landroid/support/v4/app/n;->mAnimationInfo:Landroid/support/v4/app/l;

    iget-object v0, v0, Landroid/support/v4/app/l;->mStartEnterTransitionListener:Landroid/support/v4/app/N;

    if-ne p1, v0, :cond_0

    return-void

    :cond_0
    if-eqz p1, :cond_2

    if-nez v0, :cond_1

    goto :goto_0

    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Trying to set a replacement startPostponedEnterTransition on "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_2
    :goto_0
    iget-object p0, p0, Landroid/support/v4/app/n;->mAnimationInfo:Landroid/support/v4/app/l;

    iget-boolean v0, p0, Landroid/support/v4/app/l;->mEnterTransitionPostponed:Z

    if-eqz v0, :cond_3

    iput-object p1, p0, Landroid/support/v4/app/l;->mStartEnterTransitionListener:Landroid/support/v4/app/N;

    :cond_3
    if-eqz p1, :cond_4

    invoke-virtual {p1}, Landroid/support/v4/app/N;->startListening()V

    :cond_4
    return-void
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 0

    invoke-super {p0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p0

    return p0
.end method

.method findFragmentByWho(Ljava/lang/String;)Landroid/support/v4/app/n;
    .locals 1

    iget-object v0, p0, Landroid/support/v4/app/n;->mWho:Ljava/lang/String;

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    return-object p0

    :cond_0
    iget-object p0, p0, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    if-eqz p0, :cond_1

    invoke-virtual {p0, p1}, Landroid/support/v4/app/O;->findFragmentByWho(Ljava/lang/String;)Landroid/support/v4/app/n;

    move-result-object p0

    return-object p0

    :cond_1
    const/4 p0, 0x0

    return-object p0
.end method

.method getAnimatingAway()Landroid/view/View;
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/n;->mAnimationInfo:Landroid/support/v4/app/l;

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    iget-object p0, p0, Landroid/support/v4/app/l;->mAnimatingAway:Landroid/view/View;

    return-object p0
.end method

.method getAnimator()Landroid/animation/Animator;
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/n;->mAnimationInfo:Landroid/support/v4/app/l;

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    iget-object p0, p0, Landroid/support/v4/app/l;->mAnimator:Landroid/animation/Animator;

    return-object p0
.end method

.method public getEnterTransition()Ljava/lang/Object;
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/n;->mAnimationInfo:Landroid/support/v4/app/l;

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    invoke-static {p0}, Landroid/support/v4/app/l;->a(Landroid/support/v4/app/l;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method getEnterTransitionCallback()V
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/n;->mAnimationInfo:Landroid/support/v4/app/l;

    if-nez p0, :cond_0

    return-void

    :cond_0
    iget-object p0, p0, Landroid/support/v4/app/l;->mEnterTransitionCallback:Landroid/support/v4/app/pa;

    return-void
.end method

.method public getExitTransition()Ljava/lang/Object;
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/n;->mAnimationInfo:Landroid/support/v4/app/l;

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    invoke-static {p0}, Landroid/support/v4/app/l;->c(Landroid/support/v4/app/l;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method getNextAnim()I
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/n;->mAnimationInfo:Landroid/support/v4/app/l;

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    iget p0, p0, Landroid/support/v4/app/l;->mNextAnim:I

    return p0
.end method

.method getNextTransition()I
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/n;->mAnimationInfo:Landroid/support/v4/app/l;

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    iget p0, p0, Landroid/support/v4/app/l;->mNextTransition:I

    return p0
.end method

.method getNextTransitionStyle()I
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/n;->mAnimationInfo:Landroid/support/v4/app/l;

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    iget p0, p0, Landroid/support/v4/app/l;->mNextTransitionStyle:I

    return p0
.end method

.method public getReenterTransition()Ljava/lang/Object;
    .locals 2

    iget-object v0, p0, Landroid/support/v4/app/n;->mAnimationInfo:Landroid/support/v4/app/l;

    if-nez v0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    invoke-static {v0}, Landroid/support/v4/app/l;->d(Landroid/support/v4/app/l;)Ljava/lang/Object;

    move-result-object v0

    sget-object v1, Landroid/support/v4/app/n;->Ne:Ljava/lang/Object;

    if-ne v0, v1, :cond_1

    invoke-virtual {p0}, Landroid/support/v4/app/n;->getExitTransition()Ljava/lang/Object;

    move-result-object p0

    goto :goto_0

    :cond_1
    iget-object p0, p0, Landroid/support/v4/app/n;->mAnimationInfo:Landroid/support/v4/app/l;

    invoke-static {p0}, Landroid/support/v4/app/l;->d(Landroid/support/v4/app/l;)Ljava/lang/Object;

    move-result-object p0

    :goto_0
    return-object p0
.end method

.method public getReturnTransition()Ljava/lang/Object;
    .locals 2

    iget-object v0, p0, Landroid/support/v4/app/n;->mAnimationInfo:Landroid/support/v4/app/l;

    if-nez v0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    invoke-static {v0}, Landroid/support/v4/app/l;->b(Landroid/support/v4/app/l;)Ljava/lang/Object;

    move-result-object v0

    sget-object v1, Landroid/support/v4/app/n;->Ne:Ljava/lang/Object;

    if-ne v0, v1, :cond_1

    invoke-virtual {p0}, Landroid/support/v4/app/n;->getEnterTransition()Ljava/lang/Object;

    move-result-object p0

    goto :goto_0

    :cond_1
    iget-object p0, p0, Landroid/support/v4/app/n;->mAnimationInfo:Landroid/support/v4/app/l;

    invoke-static {p0}, Landroid/support/v4/app/l;->b(Landroid/support/v4/app/l;)Ljava/lang/Object;

    move-result-object p0

    :goto_0
    return-object p0
.end method

.method public getSharedElementEnterTransition()Ljava/lang/Object;
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/n;->mAnimationInfo:Landroid/support/v4/app/l;

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    invoke-static {p0}, Landroid/support/v4/app/l;->e(Landroid/support/v4/app/l;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public getSharedElementReturnTransition()Ljava/lang/Object;
    .locals 2

    iget-object v0, p0, Landroid/support/v4/app/n;->mAnimationInfo:Landroid/support/v4/app/l;

    if-nez v0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    invoke-static {v0}, Landroid/support/v4/app/l;->f(Landroid/support/v4/app/l;)Ljava/lang/Object;

    move-result-object v0

    sget-object v1, Landroid/support/v4/app/n;->Ne:Ljava/lang/Object;

    if-ne v0, v1, :cond_1

    invoke-virtual {p0}, Landroid/support/v4/app/n;->getSharedElementEnterTransition()Ljava/lang/Object;

    move-result-object p0

    goto :goto_0

    :cond_1
    iget-object p0, p0, Landroid/support/v4/app/n;->mAnimationInfo:Landroid/support/v4/app/l;

    invoke-static {p0}, Landroid/support/v4/app/l;->f(Landroid/support/v4/app/l;)Ljava/lang/Object;

    move-result-object p0

    :goto_0
    return-object p0
.end method

.method getStateAfterAnimating()I
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/n;->mAnimationInfo:Landroid/support/v4/app/l;

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    iget p0, p0, Landroid/support/v4/app/l;->mStateAfterAnimating:I

    return p0
.end method

.method public final hashCode()I
    .locals 0

    invoke-super {p0}, Ljava/lang/Object;->hashCode()I

    move-result p0

    return p0
.end method

.method i(Landroid/view/View;)V
    .locals 0

    invoke-direct {p0}, Landroid/support/v4/app/n;->Pf()Landroid/support/v4/app/l;

    move-result-object p0

    iput-object p1, p0, Landroid/support/v4/app/l;->mAnimatingAway:Landroid/view/View;

    return-void
.end method

.method instantiateChildFragmentManager()V
    .locals 4

    iget-object v0, p0, Landroid/support/v4/app/n;->mHost:Landroid/support/v4/app/u;

    if-eqz v0, :cond_1

    new-instance v0, Landroid/support/v4/app/O;

    invoke-direct {v0}, Landroid/support/v4/app/O;-><init>()V

    iput-object v0, p0, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    iget-object v0, p0, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    iget-object v1, p0, Landroid/support/v4/app/n;->mHost:Landroid/support/v4/app/u;

    new-instance v2, Landroid/support/v4/app/j;

    invoke-direct {v2, p0}, Landroid/support/v4/app/j;-><init>(Landroid/support/v4/app/n;)V

    .line 1
    iget-object v3, v0, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    if-nez v3, :cond_0

    iput-object v1, v0, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    iput-object v2, v0, Landroid/support/v4/app/O;->mContainer:Landroid/support/v4/app/s;

    iput-object p0, v0, Landroid/support/v4/app/O;->mParent:Landroid/support/v4/app/n;

    return-void

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string v0, "Already attached"

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    .line 2
    :cond_1
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string v0, "Fragment has not been attached yet."

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method isHideReplaced()Z
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/n;->mAnimationInfo:Landroid/support/v4/app/l;

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    iget-boolean p0, p0, Landroid/support/v4/app/l;->mIsHideReplaced:Z

    return p0
.end method

.method final isInBackStack()Z
    .locals 0

    iget p0, p0, Landroid/support/v4/app/n;->mBackStackNesting:I

    if-lez p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public j()Landroid/arch/lifecycle/r;
    .locals 1

    .line 1
    iget-object v0, p0, Landroid/support/v4/app/n;->mHost:Landroid/support/v4/app/u;

    if-nez v0, :cond_0

    const/4 v0, 0x0

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Landroid/support/v4/app/u;->getContext()Landroid/content/Context;

    move-result-object v0

    :goto_0
    if-eqz v0, :cond_2

    .line 2
    iget-object v0, p0, Landroid/support/v4/app/n;->Gc:Landroid/arch/lifecycle/r;

    if-nez v0, :cond_1

    new-instance v0, Landroid/arch/lifecycle/r;

    invoke-direct {v0}, Landroid/arch/lifecycle/r;-><init>()V

    iput-object v0, p0, Landroid/support/v4/app/n;->Gc:Landroid/arch/lifecycle/r;

    :cond_1
    iget-object p0, p0, Landroid/support/v4/app/n;->Gc:Landroid/arch/lifecycle/r;

    return-object p0

    :cond_2
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string v0, "Can\'t access ViewModels from detached fragment"

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 0

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroid/support/v4/app/n;->mCalled:Z

    return-void
.end method

.method public onCreateContextMenu(Landroid/view/ContextMenu;Landroid/view/View;Landroid/view/ContextMenu$ContextMenuInfo;)V
    .locals 0

    .line 1
    iget-object p0, p0, Landroid/support/v4/app/n;->mHost:Landroid/support/v4/app/u;

    if-nez p0, :cond_0

    const/4 p0, 0x0

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Landroid/support/v4/app/u;->getActivity()Landroid/app/Activity;

    move-result-object p0

    check-cast p0, Landroid/support/v4/app/r;

    .line 2
    :goto_0
    invoke-virtual {p0, p1, p2, p3}, Landroid/app/Activity;->onCreateContextMenu(Landroid/view/ContextMenu;Landroid/view/View;Landroid/view/ContextMenu$ContextMenuInfo;)V

    return-void
.end method

.method public onDestroyOptionsMenu()V
    .locals 0

    return-void
.end method

.method public onInflate(Landroid/content/Context;Landroid/util/AttributeSet;Landroid/os/Bundle;)V
    .locals 0

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroid/support/v4/app/n;->mCalled:Z

    iget-object p2, p0, Landroid/support/v4/app/n;->mHost:Landroid/support/v4/app/u;

    if-nez p2, :cond_0

    const/4 p2, 0x0

    goto :goto_0

    :cond_0
    invoke-virtual {p2}, Landroid/support/v4/app/u;->getActivity()Landroid/app/Activity;

    move-result-object p2

    :goto_0
    if-eqz p2, :cond_1

    const/4 p2, 0x0

    iput-boolean p2, p0, Landroid/support/v4/app/n;->mCalled:Z

    .line 1
    iput-boolean p1, p0, Landroid/support/v4/app/n;->mCalled:Z

    :cond_1
    return-void
.end method

.method public onLowMemory()V
    .locals 1

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v4/app/n;->mCalled:Z

    return-void
.end method

.method performConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 1

    const/4 v0, 0x1

    .line 1
    iput-boolean v0, p0, Landroid/support/v4/app/n;->mCalled:Z

    .line 2
    iget-object p0, p0, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    if-eqz p0, :cond_0

    invoke-virtual {p0, p1}, Landroid/support/v4/app/O;->dispatchConfigurationChanged(Landroid/content/res/Configuration;)V

    :cond_0
    return-void
.end method

.method performContextItemSelected(Landroid/view/MenuItem;)Z
    .locals 1

    iget-boolean v0, p0, Landroid/support/v4/app/n;->mHidden:Z

    if-nez v0, :cond_0

    iget-object p0, p0, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    if-eqz p0, :cond_0

    invoke-virtual {p0, p1}, Landroid/support/v4/app/O;->dispatchContextItemSelected(Landroid/view/MenuItem;)Z

    move-result p0

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method performCreateOptionsMenu(Landroid/view/Menu;Landroid/view/MenuInflater;)Z
    .locals 2

    iget-boolean v0, p0, Landroid/support/v4/app/n;->mHidden:Z

    const/4 v1, 0x0

    if-nez v0, :cond_1

    iget-boolean v0, p0, Landroid/support/v4/app/n;->mHasMenu:Z

    if-eqz v0, :cond_0

    iget-boolean v0, p0, Landroid/support/v4/app/n;->mMenuVisible:Z

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    move v1, v0

    :cond_0
    iget-object p0, p0, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    if-eqz p0, :cond_1

    invoke-virtual {p0, p1, p2}, Landroid/support/v4/app/O;->dispatchCreateOptionsMenu(Landroid/view/Menu;Landroid/view/MenuInflater;)Z

    move-result p0

    or-int/2addr v1, p0

    :cond_1
    return v1
.end method

.method performCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)V
    .locals 0

    iget-object p1, p0, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    if-eqz p1, :cond_0

    invoke-virtual {p1}, Landroid/support/v4/app/O;->noteStateNotSaved()V

    :cond_0
    const/4 p1, 0x1

    iput-boolean p1, p0, Landroid/support/v4/app/n;->mPerformedCreateView:Z

    new-instance p1, Landroid/support/v4/app/k;

    invoke-direct {p1, p0}, Landroid/support/v4/app/k;-><init>(Landroid/support/v4/app/n;)V

    iput-object p1, p0, Landroid/support/v4/app/n;->Ke:Landroid/arch/lifecycle/e;

    const/4 p1, 0x0

    iput-object p1, p0, Landroid/support/v4/app/n;->Je:Landroid/arch/lifecycle/g;

    iput-object p1, p0, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    iget-object p2, p0, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    if-eqz p2, :cond_1

    iget-object p1, p0, Landroid/support/v4/app/n;->Ke:Landroid/arch/lifecycle/e;

    invoke-interface {p1}, Landroid/arch/lifecycle/e;->y()Landroid/arch/lifecycle/c;

    iget-object p1, p0, Landroid/support/v4/app/n;->Le:Landroid/arch/lifecycle/l;

    iget-object p0, p0, Landroid/support/v4/app/n;->Ke:Landroid/arch/lifecycle/e;

    invoke-virtual {p1, p0}, Landroid/arch/lifecycle/l;->setValue(Ljava/lang/Object;)V

    goto :goto_0

    :cond_1
    iget-object p2, p0, Landroid/support/v4/app/n;->Je:Landroid/arch/lifecycle/g;

    if-nez p2, :cond_2

    iput-object p1, p0, Landroid/support/v4/app/n;->Ke:Landroid/arch/lifecycle/e;

    :goto_0
    return-void

    :cond_2
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "Called getViewLifecycleOwner() but onCreateView() returned null"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method performDestroyView()V
    .locals 3

    iget-object v0, p0, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/support/v4/app/O;->dispatchDestroyView()V

    :cond_0
    const/4 v0, 0x1

    iput v0, p0, Landroid/support/v4/app/n;->mState:I

    const/4 v1, 0x0

    iput-boolean v1, p0, Landroid/support/v4/app/n;->mCalled:Z

    .line 1
    iput-boolean v0, p0, Landroid/support/v4/app/n;->mCalled:Z

    iget-object v0, p0, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    if-eqz v0, :cond_1

    iget-object v0, p0, Landroid/support/v4/app/n;->Je:Landroid/arch/lifecycle/g;

    sget-object v2, Landroid/arch/lifecycle/Lifecycle$Event;->ON_DESTROY:Landroid/arch/lifecycle/Lifecycle$Event;

    invoke-virtual {v0, v2}, Landroid/arch/lifecycle/g;->b(Landroid/arch/lifecycle/Lifecycle$Event;)V

    .line 2
    :cond_1
    iget-boolean v0, p0, Landroid/support/v4/app/n;->mCalled:Z

    if-eqz v0, :cond_2

    invoke-static {p0}, Landroid/support/v4/app/ka;->g(Landroid/arch/lifecycle/e;)Landroid/support/v4/app/ka;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/v4/app/ka;->M()V

    iput-boolean v1, p0, Landroid/support/v4/app/n;->mPerformedCreateView:Z

    return-void

    :cond_2
    new-instance v0, Landroid/support/v4/app/SuperNotCalledException;

    const-string v1, "Fragment "

    const-string v2, " did not call through to super.onDestroyView()"

    invoke-static {v1, p0, v2}, Lb/a/a/a/a;->a(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Landroid/support/v4/app/SuperNotCalledException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method performGetLayoutInflater(Landroid/os/Bundle;)Landroid/view/LayoutInflater;
    .locals 2

    .line 1
    iget-object p1, p0, Landroid/support/v4/app/n;->mHost:Landroid/support/v4/app/u;

    if-eqz p1, :cond_4

    check-cast p1, Landroid/support/v4/app/p;

    .line 2
    iget-object v0, p1, Landroid/support/v4/app/p;->n:Landroid/support/v4/app/r;

    invoke-virtual {v0}, Landroid/app/Activity;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v0

    iget-object p1, p1, Landroid/support/v4/app/p;->n:Landroid/support/v4/app/r;

    invoke-virtual {v0, p1}, Landroid/view/LayoutInflater;->cloneInContext(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object p1

    .line 3
    iget-object v0, p0, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    if-nez v0, :cond_3

    invoke-virtual {p0}, Landroid/support/v4/app/n;->instantiateChildFragmentManager()V

    iget v0, p0, Landroid/support/v4/app/n;->mState:I

    const/4 v1, 0x5

    if-lt v0, v1, :cond_0

    iget-object v0, p0, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    invoke-virtual {v0}, Landroid/support/v4/app/O;->dispatchResume()V

    goto :goto_0

    :cond_0
    const/4 v1, 0x4

    if-lt v0, v1, :cond_1

    iget-object v0, p0, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    invoke-virtual {v0}, Landroid/support/v4/app/O;->dispatchStart()V

    goto :goto_0

    :cond_1
    const/4 v1, 0x2

    if-lt v0, v1, :cond_2

    iget-object v0, p0, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    invoke-virtual {v0}, Landroid/support/v4/app/O;->dispatchActivityCreated()V

    goto :goto_0

    :cond_2
    const/4 v1, 0x1

    if-lt v0, v1, :cond_3

    iget-object v0, p0, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    invoke-virtual {v0}, Landroid/support/v4/app/O;->dispatchCreate()V

    :cond_3
    :goto_0
    iget-object v0, p0, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    .line 4
    invoke-virtual {v0}, Landroid/support/v4/app/O;->getLayoutInflaterFactory()Landroid/view/LayoutInflater$Factory2;

    invoke-static {p1, v0}, Landroid/support/v4/view/g;->a(Landroid/view/LayoutInflater;Landroid/view/LayoutInflater$Factory2;)V

    .line 5
    iput-object p1, p0, Landroid/support/v4/app/n;->mLayoutInflater:Landroid/view/LayoutInflater;

    iget-object p0, p0, Landroid/support/v4/app/n;->mLayoutInflater:Landroid/view/LayoutInflater;

    return-object p0

    .line 6
    :cond_4
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "onGetLayoutInflater() cannot be executed until the Fragment is attached to the FragmentManager."

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method performLowMemory()V
    .locals 1

    const/4 v0, 0x1

    .line 1
    iput-boolean v0, p0, Landroid/support/v4/app/n;->mCalled:Z

    .line 2
    iget-object p0, p0, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroid/support/v4/app/O;->dispatchLowMemory()V

    :cond_0
    return-void
.end method

.method performMultiWindowModeChanged(Z)V
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    if-eqz p0, :cond_0

    invoke-virtual {p0, p1}, Landroid/support/v4/app/O;->dispatchMultiWindowModeChanged(Z)V

    :cond_0
    return-void
.end method

.method performOptionsItemSelected(Landroid/view/MenuItem;)Z
    .locals 1

    iget-boolean v0, p0, Landroid/support/v4/app/n;->mHidden:Z

    if-nez v0, :cond_1

    iget-boolean v0, p0, Landroid/support/v4/app/n;->mHasMenu:Z

    if-eqz v0, :cond_0

    iget-boolean v0, p0, Landroid/support/v4/app/n;->mMenuVisible:Z

    :cond_0
    iget-object p0, p0, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    if-eqz p0, :cond_1

    invoke-virtual {p0, p1}, Landroid/support/v4/app/O;->dispatchOptionsItemSelected(Landroid/view/MenuItem;)Z

    move-result p0

    if-eqz p0, :cond_1

    const/4 p0, 0x1

    return p0

    :cond_1
    const/4 p0, 0x0

    return p0
.end method

.method performOptionsMenuClosed(Landroid/view/Menu;)V
    .locals 1

    iget-boolean v0, p0, Landroid/support/v4/app/n;->mHidden:Z

    if-nez v0, :cond_1

    iget-boolean v0, p0, Landroid/support/v4/app/n;->mHasMenu:Z

    if-eqz v0, :cond_0

    iget-boolean v0, p0, Landroid/support/v4/app/n;->mMenuVisible:Z

    :cond_0
    iget-object p0, p0, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    if-eqz p0, :cond_1

    invoke-virtual {p0, p1}, Landroid/support/v4/app/O;->dispatchOptionsMenuClosed(Landroid/view/Menu;)V

    :cond_1
    return-void
.end method

.method performPause()V
    .locals 3

    iget-object v0, p0, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroid/support/v4/app/n;->Je:Landroid/arch/lifecycle/g;

    sget-object v1, Landroid/arch/lifecycle/Lifecycle$Event;->ON_PAUSE:Landroid/arch/lifecycle/Lifecycle$Event;

    invoke-virtual {v0, v1}, Landroid/arch/lifecycle/g;->b(Landroid/arch/lifecycle/Lifecycle$Event;)V

    :cond_0
    iget-object v0, p0, Landroid/support/v4/app/n;->ad:Landroid/arch/lifecycle/g;

    sget-object v1, Landroid/arch/lifecycle/Lifecycle$Event;->ON_PAUSE:Landroid/arch/lifecycle/Lifecycle$Event;

    invoke-virtual {v0, v1}, Landroid/arch/lifecycle/g;->b(Landroid/arch/lifecycle/Lifecycle$Event;)V

    iget-object v0, p0, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Landroid/support/v4/app/O;->dispatchPause()V

    :cond_1
    const/4 v0, 0x4

    iput v0, p0, Landroid/support/v4/app/n;->mState:I

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/support/v4/app/n;->mCalled:Z

    const/4 v0, 0x1

    .line 1
    iput-boolean v0, p0, Landroid/support/v4/app/n;->mCalled:Z

    .line 2
    iget-boolean v0, p0, Landroid/support/v4/app/n;->mCalled:Z

    if-eqz v0, :cond_2

    return-void

    :cond_2
    new-instance v0, Landroid/support/v4/app/SuperNotCalledException;

    const-string v1, "Fragment "

    const-string v2, " did not call through to super.onPause()"

    invoke-static {v1, p0, v2}, Lb/a/a/a/a;->a(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Landroid/support/v4/app/SuperNotCalledException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method performPictureInPictureModeChanged(Z)V
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    if-eqz p0, :cond_0

    invoke-virtual {p0, p1}, Landroid/support/v4/app/O;->dispatchPictureInPictureModeChanged(Z)V

    :cond_0
    return-void
.end method

.method performPrepareOptionsMenu(Landroid/view/Menu;)Z
    .locals 2

    iget-boolean v0, p0, Landroid/support/v4/app/n;->mHidden:Z

    const/4 v1, 0x0

    if-nez v0, :cond_1

    iget-boolean v0, p0, Landroid/support/v4/app/n;->mHasMenu:Z

    if-eqz v0, :cond_0

    iget-boolean v0, p0, Landroid/support/v4/app/n;->mMenuVisible:Z

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    move v1, v0

    :cond_0
    iget-object p0, p0, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    if-eqz p0, :cond_1

    invoke-virtual {p0, p1}, Landroid/support/v4/app/O;->dispatchPrepareOptionsMenu(Landroid/view/Menu;)Z

    move-result p0

    or-int/2addr v1, p0

    :cond_1
    return v1
.end method

.method performResume()V
    .locals 3

    iget-object v0, p0, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/support/v4/app/O;->noteStateNotSaved()V

    iget-object v0, p0, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    invoke-virtual {v0}, Landroid/support/v4/app/O;->execPendingActions()Z

    :cond_0
    const/4 v0, 0x5

    iput v0, p0, Landroid/support/v4/app/n;->mState:I

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/support/v4/app/n;->mCalled:Z

    const/4 v0, 0x1

    .line 1
    iput-boolean v0, p0, Landroid/support/v4/app/n;->mCalled:Z

    .line 2
    iget-boolean v0, p0, Landroid/support/v4/app/n;->mCalled:Z

    if-eqz v0, :cond_3

    iget-object v0, p0, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Landroid/support/v4/app/O;->dispatchResume()V

    iget-object v0, p0, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    invoke-virtual {v0}, Landroid/support/v4/app/O;->execPendingActions()Z

    :cond_1
    iget-object v0, p0, Landroid/support/v4/app/n;->ad:Landroid/arch/lifecycle/g;

    sget-object v1, Landroid/arch/lifecycle/Lifecycle$Event;->ON_RESUME:Landroid/arch/lifecycle/Lifecycle$Event;

    invoke-virtual {v0, v1}, Landroid/arch/lifecycle/g;->b(Landroid/arch/lifecycle/Lifecycle$Event;)V

    iget-object v0, p0, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    if-eqz v0, :cond_2

    iget-object p0, p0, Landroid/support/v4/app/n;->Je:Landroid/arch/lifecycle/g;

    sget-object v0, Landroid/arch/lifecycle/Lifecycle$Event;->ON_RESUME:Landroid/arch/lifecycle/Lifecycle$Event;

    invoke-virtual {p0, v0}, Landroid/arch/lifecycle/g;->b(Landroid/arch/lifecycle/Lifecycle$Event;)V

    :cond_2
    return-void

    :cond_3
    new-instance v0, Landroid/support/v4/app/SuperNotCalledException;

    const-string v1, "Fragment "

    const-string v2, " did not call through to super.onResume()"

    invoke-static {v1, p0, v2}, Lb/a/a/a/a;->a(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Landroid/support/v4/app/SuperNotCalledException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method performSaveInstanceState(Landroid/os/Bundle;)V
    .locals 1

    iget-object p0, p0, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroid/support/v4/app/O;->saveAllState()Landroid/os/Parcelable;

    move-result-object p0

    if-eqz p0, :cond_0

    const-string v0, "android:support:fragments"

    invoke-virtual {p1, v0, p0}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    :cond_0
    return-void
.end method

.method performStart()V
    .locals 3

    iget-object v0, p0, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/support/v4/app/O;->noteStateNotSaved()V

    iget-object v0, p0, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    invoke-virtual {v0}, Landroid/support/v4/app/O;->execPendingActions()Z

    :cond_0
    const/4 v0, 0x4

    iput v0, p0, Landroid/support/v4/app/n;->mState:I

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/support/v4/app/n;->mCalled:Z

    const/4 v0, 0x1

    .line 1
    iput-boolean v0, p0, Landroid/support/v4/app/n;->mCalled:Z

    .line 2
    iget-boolean v0, p0, Landroid/support/v4/app/n;->mCalled:Z

    if-eqz v0, :cond_3

    iget-object v0, p0, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Landroid/support/v4/app/O;->dispatchStart()V

    :cond_1
    iget-object v0, p0, Landroid/support/v4/app/n;->ad:Landroid/arch/lifecycle/g;

    sget-object v1, Landroid/arch/lifecycle/Lifecycle$Event;->ON_START:Landroid/arch/lifecycle/Lifecycle$Event;

    invoke-virtual {v0, v1}, Landroid/arch/lifecycle/g;->b(Landroid/arch/lifecycle/Lifecycle$Event;)V

    iget-object v0, p0, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    if-eqz v0, :cond_2

    iget-object p0, p0, Landroid/support/v4/app/n;->Je:Landroid/arch/lifecycle/g;

    sget-object v0, Landroid/arch/lifecycle/Lifecycle$Event;->ON_START:Landroid/arch/lifecycle/Lifecycle$Event;

    invoke-virtual {p0, v0}, Landroid/arch/lifecycle/g;->b(Landroid/arch/lifecycle/Lifecycle$Event;)V

    :cond_2
    return-void

    :cond_3
    new-instance v0, Landroid/support/v4/app/SuperNotCalledException;

    const-string v1, "Fragment "

    const-string v2, " did not call through to super.onStart()"

    invoke-static {v1, p0, v2}, Lb/a/a/a/a;->a(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Landroid/support/v4/app/SuperNotCalledException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method ra()Landroid/support/v4/app/y;
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    return-object p0
.end method

.method final restoreViewState(Landroid/os/Bundle;)V
    .locals 2

    iget-object p1, p0, Landroid/support/v4/app/n;->mSavedViewState:Landroid/util/SparseArray;

    if-eqz p1, :cond_0

    iget-object v0, p0, Landroid/support/v4/app/n;->He:Landroid/view/View;

    invoke-virtual {v0, p1}, Landroid/view/View;->restoreHierarchyState(Landroid/util/SparseArray;)V

    const/4 p1, 0x0

    iput-object p1, p0, Landroid/support/v4/app/n;->mSavedViewState:Landroid/util/SparseArray;

    :cond_0
    const/4 p1, 0x0

    iput-boolean p1, p0, Landroid/support/v4/app/n;->mCalled:Z

    const/4 p1, 0x1

    .line 1
    iput-boolean p1, p0, Landroid/support/v4/app/n;->mCalled:Z

    iget-object p1, p0, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    if-eqz p1, :cond_1

    iget-object p1, p0, Landroid/support/v4/app/n;->Je:Landroid/arch/lifecycle/g;

    sget-object v0, Landroid/arch/lifecycle/Lifecycle$Event;->ON_CREATE:Landroid/arch/lifecycle/Lifecycle$Event;

    invoke-virtual {p1, v0}, Landroid/arch/lifecycle/g;->b(Landroid/arch/lifecycle/Lifecycle$Event;)V

    .line 2
    :cond_1
    iget-boolean p1, p0, Landroid/support/v4/app/n;->mCalled:Z

    if-eqz p1, :cond_2

    return-void

    :cond_2
    new-instance p1, Landroid/support/v4/app/SuperNotCalledException;

    const-string v0, "Fragment "

    const-string v1, " did not call through to super.onViewStateRestored()"

    invoke-static {v0, p0, v1}, Lb/a/a/a/a;->a(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Landroid/support/v4/app/SuperNotCalledException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public setArguments(Landroid/os/Bundle;)V
    .locals 1

    iget v0, p0, Landroid/support/v4/app/n;->mIndex:I

    if-ltz v0, :cond_2

    .line 1
    iget-object v0, p0, Landroid/support/v4/app/n;->mFragmentManager:Landroid/support/v4/app/O;

    if-nez v0, :cond_0

    const/4 v0, 0x0

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Landroid/support/v4/app/O;->isStateSaved()Z

    move-result v0

    :goto_0
    if-nez v0, :cond_1

    goto :goto_1

    .line 2
    :cond_1
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "Fragment already active and state has been saved"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_2
    :goto_1
    iput-object p1, p0, Landroid/support/v4/app/n;->mArguments:Landroid/os/Bundle;

    return-void
.end method

.method setHideReplaced(Z)V
    .locals 0

    invoke-direct {p0}, Landroid/support/v4/app/n;->Pf()Landroid/support/v4/app/l;

    move-result-object p0

    iput-boolean p1, p0, Landroid/support/v4/app/l;->mIsHideReplaced:Z

    return-void
.end method

.method setNextAnim(I)V
    .locals 1

    iget-object v0, p0, Landroid/support/v4/app/n;->mAnimationInfo:Landroid/support/v4/app/l;

    if-nez v0, :cond_0

    if-nez p1, :cond_0

    return-void

    :cond_0
    invoke-direct {p0}, Landroid/support/v4/app/n;->Pf()Landroid/support/v4/app/l;

    move-result-object p0

    iput p1, p0, Landroid/support/v4/app/l;->mNextAnim:I

    return-void
.end method

.method setNextTransition(II)V
    .locals 1

    iget-object v0, p0, Landroid/support/v4/app/n;->mAnimationInfo:Landroid/support/v4/app/l;

    if-nez v0, :cond_0

    if-nez p1, :cond_0

    if-nez p2, :cond_0

    return-void

    :cond_0
    invoke-direct {p0}, Landroid/support/v4/app/n;->Pf()Landroid/support/v4/app/l;

    iget-object p0, p0, Landroid/support/v4/app/n;->mAnimationInfo:Landroid/support/v4/app/l;

    iput p1, p0, Landroid/support/v4/app/l;->mNextTransition:I

    iput p2, p0, Landroid/support/v4/app/l;->mNextTransitionStyle:I

    return-void
.end method

.method setStateAfterAnimating(I)V
    .locals 0

    invoke-direct {p0}, Landroid/support/v4/app/n;->Pf()Landroid/support/v4/app/l;

    move-result-object p0

    iput p1, p0, Landroid/support/v4/app/l;->mStateAfterAnimating:I

    return-void
.end method

.method public startPostponedEnterTransition()V
    .locals 2

    iget-object v0, p0, Landroid/support/v4/app/n;->mFragmentManager:Landroid/support/v4/app/O;

    if-eqz v0, :cond_2

    iget-object v0, v0, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v0

    iget-object v1, p0, Landroid/support/v4/app/n;->mFragmentManager:Landroid/support/v4/app/O;

    iget-object v1, v1, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    invoke-virtual {v1}, Landroid/support/v4/app/u;->getHandler()Landroid/os/Handler;

    move-result-object v1

    invoke-virtual {v1}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    move-result-object v1

    if-eq v0, v1, :cond_1

    iget-object v0, p0, Landroid/support/v4/app/n;->mFragmentManager:Landroid/support/v4/app/O;

    iget-object v0, v0, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    invoke-virtual {v0}, Landroid/support/v4/app/u;->getHandler()Landroid/os/Handler;

    move-result-object v0

    new-instance v1, Landroid/support/v4/app/i;

    invoke-direct {v1, p0}, Landroid/support/v4/app/i;-><init>(Landroid/support/v4/app/n;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->postAtFrontOfQueue(Ljava/lang/Runnable;)Z

    goto :goto_1

    :cond_1
    invoke-direct {p0}, Landroid/support/v4/app/n;->Of()V

    goto :goto_1

    :cond_2
    :goto_0
    invoke-direct {p0}, Landroid/support/v4/app/n;->Pf()Landroid/support/v4/app/l;

    move-result-object p0

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/support/v4/app/l;->mEnterTransitionPostponed:Z

    :goto_1
    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    const/16 v1, 0x80

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    invoke-static {p0, v0}, La/b/a/a;->buildShortClassTag(Ljava/lang/Object;Ljava/lang/StringBuilder;)V

    iget v1, p0, Landroid/support/v4/app/n;->mIndex:I

    if-ltz v1, :cond_0

    const-string v1, " #"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroid/support/v4/app/n;->mIndex:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    :cond_0
    iget v1, p0, Landroid/support/v4/app/n;->mFragmentId:I

    if-eqz v1, :cond_1

    const-string v1, " id=0x"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroid/support/v4/app/n;->mFragmentId:I

    invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_1
    iget-object v1, p0, Landroid/support/v4/app/n;->mTag:Ljava/lang/String;

    if-eqz v1, :cond_2

    const-string v1, " "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, Landroid/support/v4/app/n;->mTag:Ljava/lang/String;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_2
    const/16 p0, 0x7d

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public y()Landroid/arch/lifecycle/c;
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/n;->ad:Landroid/arch/lifecycle/g;

    return-object p0
.end method
