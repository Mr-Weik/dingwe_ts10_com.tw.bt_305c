.class Landroid/support/v4/app/ba;
.super Landroid/transition/Transition$EpicenterCallback;
.source ""


# instance fields
.field final synthetic jf:Landroid/graphics/Rect;


# direct methods
.method constructor <init>(Landroid/support/v4/app/fa;Landroid/graphics/Rect;)V
    .locals 0

    iput-object p2, p0, Landroid/support/v4/app/ba;->jf:Landroid/graphics/Rect;

    invoke-direct {p0}, Landroid/transition/Transition$EpicenterCallback;-><init>()V

    return-void
.end method


# virtual methods
.method public onGetEpicenter(Landroid/transition/Transition;)Landroid/graphics/Rect;
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/ba;->jf:Landroid/graphics/Rect;

    return-object p0
.end method
