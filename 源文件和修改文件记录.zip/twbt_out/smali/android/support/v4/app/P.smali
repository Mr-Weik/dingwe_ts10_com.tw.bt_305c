.class public Landroid/support/v4/app/P;
.super Ljava/lang/Object;
.source ""


# instance fields
.field private final We:Ljava/util/List;

.field private final Xe:Ljava/util/List;

.field private final mFragments:Ljava/util/List;


# direct methods
.method constructor <init>(Ljava/util/List;Ljava/util/List;Ljava/util/List;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroid/support/v4/app/P;->mFragments:Ljava/util/List;

    iput-object p2, p0, Landroid/support/v4/app/P;->We:Ljava/util/List;

    iput-object p3, p0, Landroid/support/v4/app/P;->Xe:Ljava/util/List;

    return-void
.end method


# virtual methods
.method getChildNonConfigs()Ljava/util/List;
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/P;->We:Ljava/util/List;

    return-object p0
.end method

.method getFragments()Ljava/util/List;
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/P;->mFragments:Ljava/util/List;

    return-object p0
.end method

.method ta()Ljava/util/List;
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/P;->Xe:Ljava/util/List;

    return-object p0
.end method
