.class public Landroid/support/v4/app/c;
.super La/b/c/a/a;
.source ""


# direct methods
.method public static c(Landroid/app/Activity;)V
    .locals 1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-virtual {p0}, Landroid/app/Activity;->finishAffinity()V

    return-void
.end method

.method public static ua()V
    .locals 0

    return-void
.end method
