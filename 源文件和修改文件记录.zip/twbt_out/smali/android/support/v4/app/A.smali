.class Landroid/support/v4/app/A;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic Hc:Landroid/support/v4/app/B;


# direct methods
.method constructor <init>(Landroid/support/v4/app/B;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v4/app/A;->Hc:Landroid/support/v4/app/B;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    iget-object v0, p0, Landroid/support/v4/app/A;->Hc:Landroid/support/v4/app/B;

    iget-object v0, v0, Landroid/support/v4/app/B;->m:Landroid/support/v4/app/n;

    invoke-virtual {v0}, Landroid/support/v4/app/n;->getAnimatingAway()Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroid/support/v4/app/A;->Hc:Landroid/support/v4/app/B;

    iget-object v0, v0, Landroid/support/v4/app/B;->m:Landroid/support/v4/app/n;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/support/v4/app/n;->i(Landroid/view/View;)V

    iget-object p0, p0, Landroid/support/v4/app/A;->Hc:Landroid/support/v4/app/B;

    iget-object v0, p0, Landroid/support/v4/app/B;->n:Landroid/support/v4/app/O;

    iget-object v1, p0, Landroid/support/v4/app/B;->m:Landroid/support/v4/app/n;

    invoke-virtual {v1}, Landroid/support/v4/app/n;->getStateAfterAnimating()I

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual/range {v0 .. v5}, Landroid/support/v4/app/O;->a(Landroid/support/v4/app/n;IIIZ)V

    :cond_0
    return-void
.end method
