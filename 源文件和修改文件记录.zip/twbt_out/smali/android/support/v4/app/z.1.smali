.class Landroid/support/v4/app/z;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic n:Landroid/support/v4/app/O;


# direct methods
.method constructor <init>(Landroid/support/v4/app/O;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v4/app/z;->n:Landroid/support/v4/app/O;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/z;->n:Landroid/support/v4/app/O;

    invoke-virtual {p0}, Landroid/support/v4/app/O;->execPendingActions()Z

    return-void
.end method
