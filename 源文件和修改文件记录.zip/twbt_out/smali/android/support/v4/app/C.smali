.class Landroid/support/v4/app/C;
.super Landroid/animation/AnimatorListenerAdapter;
.source ""


# instance fields
.field final synthetic j:Landroid/view/ViewGroup;

.field final synthetic k:Landroid/view/View;

.field final synthetic m:Landroid/support/v4/app/n;

.field final synthetic n:Landroid/support/v4/app/O;


# direct methods
.method constructor <init>(Landroid/support/v4/app/O;Landroid/view/ViewGroup;Landroid/view/View;Landroid/support/v4/app/n;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v4/app/C;->n:Landroid/support/v4/app/O;

    iput-object p2, p0, Landroid/support/v4/app/C;->j:Landroid/view/ViewGroup;

    iput-object p3, p0, Landroid/support/v4/app/C;->k:Landroid/view/View;

    iput-object p4, p0, Landroid/support/v4/app/C;->m:Landroid/support/v4/app/n;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public onAnimationEnd(Landroid/animation/Animator;)V
    .locals 6

    iget-object p1, p0, Landroid/support/v4/app/C;->j:Landroid/view/ViewGroup;

    iget-object v0, p0, Landroid/support/v4/app/C;->k:Landroid/view/View;

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->endViewTransition(Landroid/view/View;)V

    iget-object p1, p0, Landroid/support/v4/app/C;->m:Landroid/support/v4/app/n;

    invoke-virtual {p1}, Landroid/support/v4/app/n;->getAnimator()Landroid/animation/Animator;

    move-result-object p1

    iget-object v0, p0, Landroid/support/v4/app/C;->m:Landroid/support/v4/app/n;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/support/v4/app/n;->a(Landroid/animation/Animator;)V

    if-eqz p1, :cond_0

    iget-object p1, p0, Landroid/support/v4/app/C;->j:Landroid/view/ViewGroup;

    iget-object v0, p0, Landroid/support/v4/app/C;->k:Landroid/view/View;

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    move-result p1

    if-gez p1, :cond_0

    iget-object v0, p0, Landroid/support/v4/app/C;->n:Landroid/support/v4/app/O;

    iget-object v1, p0, Landroid/support/v4/app/C;->m:Landroid/support/v4/app/n;

    invoke-virtual {v1}, Landroid/support/v4/app/n;->getStateAfterAnimating()I

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual/range {v0 .. v5}, Landroid/support/v4/app/O;->a(Landroid/support/v4/app/n;IIIZ)V

    :cond_0
    return-void
.end method
