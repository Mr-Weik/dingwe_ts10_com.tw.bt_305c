.class final Landroid/support/v4/app/e;
.super Landroid/support/v4/app/U;
.source ""

# interfaces
.implements Landroid/support/v4/app/v;
.implements Landroid/support/v4/app/M;


# instance fields
.field mAddToBackStack:Z

.field mBreadCrumbShortTitleRes:I

.field mBreadCrumbShortTitleText:Ljava/lang/CharSequence;

.field mBreadCrumbTitleRes:I

.field mBreadCrumbTitleText:Ljava/lang/CharSequence;

.field mCommitRunnables:Ljava/util/ArrayList;

.field mCommitted:Z

.field mEnterAnim:I

.field mExitAnim:I

.field mIndex:I

.field final mManager:Landroid/support/v4/app/O;

.field mName:Ljava/lang/String;

.field mOps:Ljava/util/ArrayList;

.field mPopEnterAnim:I

.field mPopExitAnim:I

.field mReorderingAllowed:Z

.field mSharedElementSourceNames:Ljava/util/ArrayList;

.field mSharedElementTargetNames:Ljava/util/ArrayList;

.field mTransition:I

.field mTransitionStyle:I


# direct methods
.method public constructor <init>(Landroid/support/v4/app/O;)V
    .locals 1

    invoke-direct {p0}, Landroid/support/v4/app/U;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroid/support/v4/app/e;->mOps:Ljava/util/ArrayList;

    const/4 v0, -0x1

    iput v0, p0, Landroid/support/v4/app/e;->mIndex:I

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/support/v4/app/e;->mReorderingAllowed:Z

    iput-object p1, p0, Landroid/support/v4/app/e;->mManager:Landroid/support/v4/app/O;

    return-void
.end method

.method private static a(Landroid/support/v4/app/d;)Z
    .locals 2

    iget-object p0, p0, Landroid/support/v4/app/d;->fragment:Landroid/support/v4/app/n;

    const/4 v0, 0x0

    if-eqz p0, :cond_1

    iget-boolean v1, p0, Landroid/support/v4/app/n;->mAdded:Z

    if-eqz v1, :cond_1

    iget-object v1, p0, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    if-eqz v1, :cond_1

    iget-boolean v1, p0, Landroid/support/v4/app/n;->mDetached:Z

    if-nez v1, :cond_1

    iget-boolean v1, p0, Landroid/support/v4/app/n;->mHidden:Z

    if-nez v1, :cond_1

    .line 1
    iget-object p0, p0, Landroid/support/v4/app/n;->mAnimationInfo:Landroid/support/v4/app/l;

    if-nez p0, :cond_0

    move p0, v0

    goto :goto_0

    :cond_0
    iget-boolean p0, p0, Landroid/support/v4/app/l;->mEnterTransitionPostponed:Z

    :goto_0
    if-eqz p0, :cond_1

    const/4 v0, 0x1

    :cond_1
    return v0
.end method


# virtual methods
.method bumpBackStackNesting(I)V
    .locals 4

    iget-boolean v0, p0, Landroid/support/v4/app/e;->mAddToBackStack:Z

    if-nez v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Landroid/support/v4/app/e;->mOps:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_2

    iget-object v2, p0, Landroid/support/v4/app/e;->mOps:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/support/v4/app/d;

    iget-object v2, v2, Landroid/support/v4/app/d;->fragment:Landroid/support/v4/app/n;

    if-eqz v2, :cond_1

    iget v3, v2, Landroid/support/v4/app/n;->mBackStackNesting:I

    add-int/2addr v3, p1

    iput v3, v2, Landroid/support/v4/app/n;->mBackStackNesting:I

    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_2
    return-void
.end method

.method d(Landroid/support/v4/app/N;)V
    .locals 3

    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, Landroid/support/v4/app/e;->mOps:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    iget-object v1, p0, Landroid/support/v4/app/e;->mOps:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/support/v4/app/d;

    invoke-static {v1}, Landroid/support/v4/app/e;->a(Landroid/support/v4/app/d;)Z

    move-result v2

    if-eqz v2, :cond_0

    iget-object v1, v1, Landroid/support/v4/app/d;->fragment:Landroid/support/v4/app/n;

    invoke-virtual {v1, p1}, Landroid/support/v4/app/n;->a(Landroid/support/v4/app/N;)V

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method public dump(Ljava/lang/String;Ljava/io/PrintWriter;Z)V
    .locals 5

    if-eqz p3, :cond_8

    invoke-virtual {p2, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "mName="

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object v0, p0, Landroid/support/v4/app/e;->mName:Ljava/lang/String;

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, " mIndex="

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget v0, p0, Landroid/support/v4/app/e;->mIndex:I

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->print(I)V

    const-string v0, " mCommitted="

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v0, p0, Landroid/support/v4/app/e;->mCommitted:Z

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->println(Z)V

    iget v0, p0, Landroid/support/v4/app/e;->mTransition:I

    if-eqz v0, :cond_0

    invoke-virtual {p2, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "mTransition=#"

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget v0, p0, Landroid/support/v4/app/e;->mTransition:I

    invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, " mTransitionStyle=#"

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget v0, p0, Landroid/support/v4/app/e;->mTransitionStyle:I

    invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    :cond_0
    iget v0, p0, Landroid/support/v4/app/e;->mEnterAnim:I

    if-nez v0, :cond_1

    iget v0, p0, Landroid/support/v4/app/e;->mExitAnim:I

    if-eqz v0, :cond_2

    :cond_1
    invoke-virtual {p2, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "mEnterAnim=#"

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget v0, p0, Landroid/support/v4/app/e;->mEnterAnim:I

    invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, " mExitAnim=#"

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget v0, p0, Landroid/support/v4/app/e;->mExitAnim:I

    invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    :cond_2
    iget v0, p0, Landroid/support/v4/app/e;->mPopEnterAnim:I

    if-nez v0, :cond_3

    iget v0, p0, Landroid/support/v4/app/e;->mPopExitAnim:I

    if-eqz v0, :cond_4

    :cond_3
    invoke-virtual {p2, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "mPopEnterAnim=#"

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget v0, p0, Landroid/support/v4/app/e;->mPopEnterAnim:I

    invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, " mPopExitAnim=#"

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget v0, p0, Landroid/support/v4/app/e;->mPopExitAnim:I

    invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    :cond_4
    iget v0, p0, Landroid/support/v4/app/e;->mBreadCrumbTitleRes:I

    if-nez v0, :cond_5

    iget-object v0, p0, Landroid/support/v4/app/e;->mBreadCrumbTitleText:Ljava/lang/CharSequence;

    if-eqz v0, :cond_6

    :cond_5
    invoke-virtual {p2, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "mBreadCrumbTitleRes=#"

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget v0, p0, Landroid/support/v4/app/e;->mBreadCrumbTitleRes:I

    invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, " mBreadCrumbTitleText="

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object v0, p0, Landroid/support/v4/app/e;->mBreadCrumbTitleText:Ljava/lang/CharSequence;

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    :cond_6
    iget v0, p0, Landroid/support/v4/app/e;->mBreadCrumbShortTitleRes:I

    if-nez v0, :cond_7

    iget-object v0, p0, Landroid/support/v4/app/e;->mBreadCrumbShortTitleText:Ljava/lang/CharSequence;

    if-eqz v0, :cond_8

    :cond_7
    invoke-virtual {p2, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "mBreadCrumbShortTitleRes=#"

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget v0, p0, Landroid/support/v4/app/e;->mBreadCrumbShortTitleRes:I

    invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, " mBreadCrumbShortTitleText="

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object v0, p0, Landroid/support/v4/app/e;->mBreadCrumbShortTitleText:Ljava/lang/CharSequence;

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    :cond_8
    iget-object v0, p0, Landroid/support/v4/app/e;->mOps:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_d

    invoke-virtual {p2, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "Operations:"

    invoke-virtual {p2, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "    "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    iget-object v0, p0, Landroid/support/v4/app/e;->mOps:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_d

    iget-object v2, p0, Landroid/support/v4/app/e;->mOps:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/support/v4/app/d;

    iget v3, v2, Landroid/support/v4/app/d;->cmd:I

    packed-switch v3, :pswitch_data_0

    const-string v3, "cmd="

    invoke-static {v3}, Lb/a/a/a/a;->x(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget v4, v2, Landroid/support/v4/app/d;->cmd:I

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    goto :goto_1

    :pswitch_0
    const-string v3, "UNSET_PRIMARY_NAV"

    goto :goto_1

    :pswitch_1
    const-string v3, "SET_PRIMARY_NAV"

    goto :goto_1

    :pswitch_2
    const-string v3, "ATTACH"

    goto :goto_1

    :pswitch_3
    const-string v3, "DETACH"

    goto :goto_1

    :pswitch_4
    const-string v3, "SHOW"

    goto :goto_1

    :pswitch_5
    const-string v3, "HIDE"

    goto :goto_1

    :pswitch_6
    const-string v3, "REMOVE"

    goto :goto_1

    :pswitch_7
    const-string v3, "REPLACE"

    goto :goto_1

    :pswitch_8
    const-string v3, "ADD"

    goto :goto_1

    :pswitch_9
    const-string v3, "NULL"

    :goto_1
    invoke-virtual {p2, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v4, "  Op #"

    invoke-virtual {p2, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    invoke-virtual {p2, v1}, Ljava/io/PrintWriter;->print(I)V

    const-string v4, ": "

    invoke-virtual {p2, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    invoke-virtual {p2, v3}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v3, " "

    invoke-virtual {p2, v3}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object v3, v2, Landroid/support/v4/app/d;->fragment:Landroid/support/v4/app/n;

    invoke-virtual {p2, v3}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    if-eqz p3, :cond_c

    iget v3, v2, Landroid/support/v4/app/d;->enterAnim:I

    if-nez v3, :cond_9

    iget v3, v2, Landroid/support/v4/app/d;->exitAnim:I

    if-eqz v3, :cond_a

    :cond_9
    invoke-virtual {p2, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v3, "enterAnim=#"

    invoke-virtual {p2, v3}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget v3, v2, Landroid/support/v4/app/d;->enterAnim:I

    invoke-static {v3}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p2, v3}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v3, " exitAnim=#"

    invoke-virtual {p2, v3}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget v3, v2, Landroid/support/v4/app/d;->exitAnim:I

    invoke-static {v3}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p2, v3}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    :cond_a
    iget v3, v2, Landroid/support/v4/app/d;->popEnterAnim:I

    if-nez v3, :cond_b

    iget v3, v2, Landroid/support/v4/app/d;->popExitAnim:I

    if-eqz v3, :cond_c

    :cond_b
    invoke-virtual {p2, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v3, "popEnterAnim=#"

    invoke-virtual {p2, v3}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget v3, v2, Landroid/support/v4/app/d;->popEnterAnim:I

    invoke-static {v3}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p2, v3}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v3, " popExitAnim=#"

    invoke-virtual {p2, v3}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget v2, v2, Landroid/support/v4/app/d;->popExitAnim:I

    invoke-static {v2}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p2, v2}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    :cond_c
    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_0

    :cond_d
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method executeOps()V
    .locals 8

    iget-object v0, p0, Landroid/support/v4/app/e;->mOps:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    const/4 v3, 0x1

    if-ge v2, v0, :cond_2

    iget-object v4, p0, Landroid/support/v4/app/e;->mOps:Ljava/util/ArrayList;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/support/v4/app/d;

    iget-object v5, v4, Landroid/support/v4/app/d;->fragment:Landroid/support/v4/app/n;

    if-eqz v5, :cond_0

    iget v6, p0, Landroid/support/v4/app/e;->mTransition:I

    iget v7, p0, Landroid/support/v4/app/e;->mTransitionStyle:I

    invoke-virtual {v5, v6, v7}, Landroid/support/v4/app/n;->setNextTransition(II)V

    :cond_0
    iget v6, v4, Landroid/support/v4/app/d;->cmd:I

    packed-switch v6, :pswitch_data_0

    :pswitch_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "Unknown cmd: "

    invoke-static {v0}, Lb/a/a/a/a;->x(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v1, v4, Landroid/support/v4/app/d;->cmd:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :pswitch_1
    iget-object v6, p0, Landroid/support/v4/app/e;->mManager:Landroid/support/v4/app/O;

    const/4 v7, 0x0

    invoke-virtual {v6, v7}, Landroid/support/v4/app/O;->l(Landroid/support/v4/app/n;)V

    goto :goto_1

    :pswitch_2
    iget-object v6, p0, Landroid/support/v4/app/e;->mManager:Landroid/support/v4/app/O;

    invoke-virtual {v6, v5}, Landroid/support/v4/app/O;->l(Landroid/support/v4/app/n;)V

    goto :goto_1

    :pswitch_3
    iget v6, v4, Landroid/support/v4/app/d;->enterAnim:I

    invoke-virtual {v5, v6}, Landroid/support/v4/app/n;->setNextAnim(I)V

    iget-object v6, p0, Landroid/support/v4/app/e;->mManager:Landroid/support/v4/app/O;

    invoke-virtual {v6, v5}, Landroid/support/v4/app/O;->e(Landroid/support/v4/app/n;)V

    goto :goto_1

    :pswitch_4
    iget v6, v4, Landroid/support/v4/app/d;->exitAnim:I

    invoke-virtual {v5, v6}, Landroid/support/v4/app/n;->setNextAnim(I)V

    iget-object v6, p0, Landroid/support/v4/app/e;->mManager:Landroid/support/v4/app/O;

    invoke-virtual {v6, v5}, Landroid/support/v4/app/O;->f(Landroid/support/v4/app/n;)V

    goto :goto_1

    :pswitch_5
    iget v6, v4, Landroid/support/v4/app/d;->enterAnim:I

    invoke-virtual {v5, v6}, Landroid/support/v4/app/n;->setNextAnim(I)V

    iget-object v6, p0, Landroid/support/v4/app/e;->mManager:Landroid/support/v4/app/O;

    invoke-virtual {v6, v5}, Landroid/support/v4/app/O;->m(Landroid/support/v4/app/n;)V

    goto :goto_1

    :pswitch_6
    iget v6, v4, Landroid/support/v4/app/d;->exitAnim:I

    invoke-virtual {v5, v6}, Landroid/support/v4/app/n;->setNextAnim(I)V

    iget-object v6, p0, Landroid/support/v4/app/e;->mManager:Landroid/support/v4/app/O;

    invoke-virtual {v6, v5}, Landroid/support/v4/app/O;->g(Landroid/support/v4/app/n;)V

    goto :goto_1

    :pswitch_7
    iget v6, v4, Landroid/support/v4/app/d;->exitAnim:I

    invoke-virtual {v5, v6}, Landroid/support/v4/app/n;->setNextAnim(I)V

    iget-object v6, p0, Landroid/support/v4/app/e;->mManager:Landroid/support/v4/app/O;

    invoke-virtual {v6, v5}, Landroid/support/v4/app/O;->j(Landroid/support/v4/app/n;)V

    goto :goto_1

    :pswitch_8
    iget v6, v4, Landroid/support/v4/app/d;->enterAnim:I

    invoke-virtual {v5, v6}, Landroid/support/v4/app/n;->setNextAnim(I)V

    iget-object v6, p0, Landroid/support/v4/app/e;->mManager:Landroid/support/v4/app/O;

    invoke-virtual {v6, v5, v1}, Landroid/support/v4/app/O;->a(Landroid/support/v4/app/n;Z)V

    :goto_1
    iget-boolean v6, p0, Landroid/support/v4/app/e;->mReorderingAllowed:Z

    if-nez v6, :cond_1

    iget v4, v4, Landroid/support/v4/app/d;->cmd:I

    if-eq v4, v3, :cond_1

    if-eqz v5, :cond_1

    iget-object v3, p0, Landroid/support/v4/app/e;->mManager:Landroid/support/v4/app/O;

    invoke-virtual {v3, v5}, Landroid/support/v4/app/O;->i(Landroid/support/v4/app/n;)V

    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_0

    :cond_2
    iget-boolean v0, p0, Landroid/support/v4/app/e;->mReorderingAllowed:Z

    if-nez v0, :cond_3

    iget-object p0, p0, Landroid/support/v4/app/e;->mManager:Landroid/support/v4/app/O;

    iget v0, p0, Landroid/support/v4/app/O;->mCurState:I

    invoke-virtual {p0, v0, v3}, Landroid/support/v4/app/O;->moveToState(IZ)V

    :cond_3
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_8
        :pswitch_0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
    .end packed-switch
.end method

.method executePopOps(Z)V
    .locals 6

    iget-object v0, p0, Landroid/support/v4/app/e;->mOps:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x1

    sub-int/2addr v0, v1

    :goto_0
    if-ltz v0, :cond_2

    iget-object v2, p0, Landroid/support/v4/app/e;->mOps:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/support/v4/app/d;

    iget-object v3, v2, Landroid/support/v4/app/d;->fragment:Landroid/support/v4/app/n;

    if-eqz v3, :cond_0

    iget v4, p0, Landroid/support/v4/app/e;->mTransition:I

    invoke-static {v4}, Landroid/support/v4/app/O;->reverseTransit(I)I

    move-result v4

    iget v5, p0, Landroid/support/v4/app/e;->mTransitionStyle:I

    invoke-virtual {v3, v4, v5}, Landroid/support/v4/app/n;->setNextTransition(II)V

    :cond_0
    iget v4, v2, Landroid/support/v4/app/d;->cmd:I

    packed-switch v4, :pswitch_data_0

    :pswitch_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "Unknown cmd: "

    invoke-static {p1}, Lb/a/a/a/a;->x(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    iget v0, v2, Landroid/support/v4/app/d;->cmd:I

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :pswitch_1
    iget-object v4, p0, Landroid/support/v4/app/e;->mManager:Landroid/support/v4/app/O;

    invoke-virtual {v4, v3}, Landroid/support/v4/app/O;->l(Landroid/support/v4/app/n;)V

    goto :goto_1

    :pswitch_2
    iget-object v4, p0, Landroid/support/v4/app/e;->mManager:Landroid/support/v4/app/O;

    const/4 v5, 0x0

    invoke-virtual {v4, v5}, Landroid/support/v4/app/O;->l(Landroid/support/v4/app/n;)V

    goto :goto_1

    :pswitch_3
    iget v4, v2, Landroid/support/v4/app/d;->popExitAnim:I

    invoke-virtual {v3, v4}, Landroid/support/v4/app/n;->setNextAnim(I)V

    iget-object v4, p0, Landroid/support/v4/app/e;->mManager:Landroid/support/v4/app/O;

    invoke-virtual {v4, v3}, Landroid/support/v4/app/O;->f(Landroid/support/v4/app/n;)V

    goto :goto_1

    :pswitch_4
    iget v4, v2, Landroid/support/v4/app/d;->popEnterAnim:I

    invoke-virtual {v3, v4}, Landroid/support/v4/app/n;->setNextAnim(I)V

    iget-object v4, p0, Landroid/support/v4/app/e;->mManager:Landroid/support/v4/app/O;

    invoke-virtual {v4, v3}, Landroid/support/v4/app/O;->e(Landroid/support/v4/app/n;)V

    goto :goto_1

    :pswitch_5
    iget v4, v2, Landroid/support/v4/app/d;->popExitAnim:I

    invoke-virtual {v3, v4}, Landroid/support/v4/app/n;->setNextAnim(I)V

    iget-object v4, p0, Landroid/support/v4/app/e;->mManager:Landroid/support/v4/app/O;

    invoke-virtual {v4, v3}, Landroid/support/v4/app/O;->g(Landroid/support/v4/app/n;)V

    goto :goto_1

    :pswitch_6
    iget v4, v2, Landroid/support/v4/app/d;->popEnterAnim:I

    invoke-virtual {v3, v4}, Landroid/support/v4/app/n;->setNextAnim(I)V

    iget-object v4, p0, Landroid/support/v4/app/e;->mManager:Landroid/support/v4/app/O;

    invoke-virtual {v4, v3}, Landroid/support/v4/app/O;->m(Landroid/support/v4/app/n;)V

    goto :goto_1

    :pswitch_7
    iget v4, v2, Landroid/support/v4/app/d;->popEnterAnim:I

    invoke-virtual {v3, v4}, Landroid/support/v4/app/n;->setNextAnim(I)V

    iget-object v4, p0, Landroid/support/v4/app/e;->mManager:Landroid/support/v4/app/O;

    const/4 v5, 0x0

    invoke-virtual {v4, v3, v5}, Landroid/support/v4/app/O;->a(Landroid/support/v4/app/n;Z)V

    goto :goto_1

    :pswitch_8
    iget v4, v2, Landroid/support/v4/app/d;->popExitAnim:I

    invoke-virtual {v3, v4}, Landroid/support/v4/app/n;->setNextAnim(I)V

    iget-object v4, p0, Landroid/support/v4/app/e;->mManager:Landroid/support/v4/app/O;

    invoke-virtual {v4, v3}, Landroid/support/v4/app/O;->j(Landroid/support/v4/app/n;)V

    :goto_1
    iget-boolean v4, p0, Landroid/support/v4/app/e;->mReorderingAllowed:Z

    if-nez v4, :cond_1

    iget v2, v2, Landroid/support/v4/app/d;->cmd:I

    const/4 v4, 0x3

    if-eq v2, v4, :cond_1

    if-eqz v3, :cond_1

    iget-object v2, p0, Landroid/support/v4/app/e;->mManager:Landroid/support/v4/app/O;

    invoke-virtual {v2, v3}, Landroid/support/v4/app/O;->i(Landroid/support/v4/app/n;)V

    :cond_1
    add-int/lit8 v0, v0, -0x1

    goto/16 :goto_0

    :cond_2
    iget-boolean v0, p0, Landroid/support/v4/app/e;->mReorderingAllowed:Z

    if-nez v0, :cond_3

    if-eqz p1, :cond_3

    iget-object p0, p0, Landroid/support/v4/app/e;->mManager:Landroid/support/v4/app/O;

    iget p1, p0, Landroid/support/v4/app/O;->mCurState:I

    invoke-virtual {p0, p1, v1}, Landroid/support/v4/app/O;->moveToState(IZ)V

    :cond_3
    return-void

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_8
        :pswitch_0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
    .end packed-switch
.end method

.method public generateOps(Ljava/util/ArrayList;Ljava/util/ArrayList;)Z
    .locals 0

    invoke-virtual {p1, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 p1, 0x0

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-boolean p1, p0, Landroid/support/v4/app/e;->mAddToBackStack:Z

    if-eqz p1, :cond_1

    iget-object p1, p0, Landroid/support/v4/app/e;->mManager:Landroid/support/v4/app/O;

    .line 1
    iget-object p2, p1, Landroid/support/v4/app/O;->mBackStack:Ljava/util/ArrayList;

    if-nez p2, :cond_0

    new-instance p2, Ljava/util/ArrayList;

    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    iput-object p2, p1, Landroid/support/v4/app/O;->mBackStack:Ljava/util/ArrayList;

    :cond_0
    iget-object p1, p1, Landroid/support/v4/app/O;->mBackStack:Ljava/util/ArrayList;

    invoke-virtual {p1, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1
    const/4 p0, 0x1

    return p0
.end method

.method interactsWith(I)Z
    .locals 4

    iget-object v0, p0, Landroid/support/v4/app/e;->mOps:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    if-ge v2, v0, :cond_2

    iget-object v3, p0, Landroid/support/v4/app/e;->mOps:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/support/v4/app/d;

    iget-object v3, v3, Landroid/support/v4/app/d;->fragment:Landroid/support/v4/app/n;

    if-eqz v3, :cond_0

    iget v3, v3, Landroid/support/v4/app/n;->mContainerId:I

    goto :goto_1

    :cond_0
    move v3, v1

    :goto_1
    if-eqz v3, :cond_1

    if-ne v3, p1, :cond_1

    const/4 p0, 0x1

    return p0

    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_2
    return v1
.end method

.method interactsWith(Ljava/util/ArrayList;II)Z
    .locals 9

    const/4 v0, 0x0

    if-ne p3, p2, :cond_0

    return v0

    :cond_0
    iget-object v1, p0, Landroid/support/v4/app/e;->mOps:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v2, -0x1

    move v3, v2

    move v2, v0

    :goto_0
    if-ge v2, v1, :cond_7

    iget-object v4, p0, Landroid/support/v4/app/e;->mOps:Ljava/util/ArrayList;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/support/v4/app/d;

    iget-object v4, v4, Landroid/support/v4/app/d;->fragment:Landroid/support/v4/app/n;

    if-eqz v4, :cond_1

    iget v4, v4, Landroid/support/v4/app/n;->mContainerId:I

    goto :goto_1

    :cond_1
    move v4, v0

    :goto_1
    if-eqz v4, :cond_6

    if-eq v4, v3, :cond_6

    move v3, p2

    :goto_2
    if-ge v3, p3, :cond_5

    invoke-virtual {p1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/support/v4/app/e;

    iget-object v6, v5, Landroid/support/v4/app/e;->mOps:Ljava/util/ArrayList;

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v6

    move v7, v0

    :goto_3
    if-ge v7, v6, :cond_4

    iget-object v8, v5, Landroid/support/v4/app/e;->mOps:Ljava/util/ArrayList;

    invoke-virtual {v8, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Landroid/support/v4/app/d;

    iget-object v8, v8, Landroid/support/v4/app/d;->fragment:Landroid/support/v4/app/n;

    if-eqz v8, :cond_2

    iget v8, v8, Landroid/support/v4/app/n;->mContainerId:I

    goto :goto_4

    :cond_2
    move v8, v0

    :goto_4
    if-ne v8, v4, :cond_3

    const/4 p0, 0x1

    return p0

    :cond_3
    add-int/lit8 v7, v7, 0x1

    goto :goto_3

    :cond_4
    add-int/lit8 v3, v3, 0x1

    goto :goto_2

    :cond_5
    move v3, v4

    :cond_6
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_7
    return v0
.end method

.method isPostponed()Z
    .locals 3

    const/4 v0, 0x0

    move v1, v0

    :goto_0
    iget-object v2, p0, Landroid/support/v4/app/e;->mOps:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_1

    iget-object v2, p0, Landroid/support/v4/app/e;->mOps:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/support/v4/app/d;

    invoke-static {v2}, Landroid/support/v4/app/e;->a(Landroid/support/v4/app/d;)Z

    move-result v2

    if-eqz v2, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    const/16 v1, 0x80

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string v1, "BackStackEntry{"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroid/support/v4/app/e;->mIndex:I

    if-ltz v1, :cond_0

    const-string v1, " #"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroid/support/v4/app/e;->mIndex:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    :cond_0
    iget-object v1, p0, Landroid/support/v4/app/e;->mName:Ljava/lang/String;

    if-eqz v1, :cond_1

    const-string v1, " "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, Landroid/support/v4/app/e;->mName:Ljava/lang/String;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_1
    const-string p0, "}"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
