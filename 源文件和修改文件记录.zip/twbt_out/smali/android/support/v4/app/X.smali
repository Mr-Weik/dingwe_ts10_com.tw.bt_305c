.class final Landroid/support/v4/app/X;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic _e:Landroid/support/v4/app/ja;

.field final synthetic bf:Landroid/support/v4/app/n;

.field final synthetic ff:Landroid/support/v4/app/n;

.field final synthetic gf:Z

.field final synthetic hf:La/b/c/f/b;

.field final synthetic if:Landroid/view/View;

.field final synthetic jf:Landroid/graphics/Rect;


# direct methods
.method constructor <init>(Landroid/support/v4/app/n;Landroid/support/v4/app/n;ZLa/b/c/f/b;Landroid/view/View;Landroid/support/v4/app/ja;Landroid/graphics/Rect;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v4/app/X;->bf:Landroid/support/v4/app/n;

    iput-object p2, p0, Landroid/support/v4/app/X;->ff:Landroid/support/v4/app/n;

    iput-boolean p3, p0, Landroid/support/v4/app/X;->gf:Z

    iput-object p4, p0, Landroid/support/v4/app/X;->hf:La/b/c/f/b;

    iput-object p5, p0, Landroid/support/v4/app/X;->if:Landroid/view/View;

    iput-object p6, p0, Landroid/support/v4/app/X;->_e:Landroid/support/v4/app/ja;

    iput-object p7, p0, Landroid/support/v4/app/X;->jf:Landroid/graphics/Rect;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    iget-object v0, p0, Landroid/support/v4/app/X;->bf:Landroid/support/v4/app/n;

    iget-object v1, p0, Landroid/support/v4/app/X;->ff:Landroid/support/v4/app/n;

    iget-boolean v2, p0, Landroid/support/v4/app/X;->gf:Z

    iget-object v3, p0, Landroid/support/v4/app/X;->hf:La/b/c/f/b;

    const/4 v4, 0x0

    invoke-static {v0, v1, v2, v3, v4}, Landroid/support/v4/app/aa;->a(Landroid/support/v4/app/n;Landroid/support/v4/app/n;ZLa/b/c/f/b;Z)V

    iget-object v0, p0, Landroid/support/v4/app/X;->if:Landroid/view/View;

    if-eqz v0, :cond_0

    iget-object v1, p0, Landroid/support/v4/app/X;->_e:Landroid/support/v4/app/ja;

    iget-object p0, p0, Landroid/support/v4/app/X;->jf:Landroid/graphics/Rect;

    invoke-virtual {v1, v0, p0}, Landroid/support/v4/app/ja;->a(Landroid/view/View;Landroid/graphics/Rect;)V

    :cond_0
    return-void
.end method
