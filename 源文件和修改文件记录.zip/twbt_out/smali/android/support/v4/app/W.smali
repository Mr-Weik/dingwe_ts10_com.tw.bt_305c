.class final Landroid/support/v4/app/W;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic Ye:Ljava/util/ArrayList;

.field final synthetic Ze:Ljava/lang/Object;

.field final synthetic _e:Landroid/support/v4/app/ja;

.field final synthetic af:Landroid/view/View;

.field final synthetic bf:Landroid/support/v4/app/n;

.field final synthetic cf:Ljava/util/ArrayList;

.field final synthetic df:Ljava/util/ArrayList;

.field final synthetic ef:Ljava/lang/Object;


# direct methods
.method constructor <init>(Ljava/lang/Object;Landroid/support/v4/app/ja;Landroid/view/View;Landroid/support/v4/app/n;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/lang/Object;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v4/app/W;->Ze:Ljava/lang/Object;

    iput-object p2, p0, Landroid/support/v4/app/W;->_e:Landroid/support/v4/app/ja;

    iput-object p3, p0, Landroid/support/v4/app/W;->af:Landroid/view/View;

    iput-object p4, p0, Landroid/support/v4/app/W;->bf:Landroid/support/v4/app/n;

    iput-object p5, p0, Landroid/support/v4/app/W;->cf:Ljava/util/ArrayList;

    iput-object p6, p0, Landroid/support/v4/app/W;->df:Ljava/util/ArrayList;

    iput-object p7, p0, Landroid/support/v4/app/W;->Ye:Ljava/util/ArrayList;

    iput-object p8, p0, Landroid/support/v4/app/W;->ef:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    iget-object v0, p0, Landroid/support/v4/app/W;->Ze:Ljava/lang/Object;

    if-eqz v0, :cond_0

    iget-object v1, p0, Landroid/support/v4/app/W;->_e:Landroid/support/v4/app/ja;

    iget-object v2, p0, Landroid/support/v4/app/W;->af:Landroid/view/View;

    invoke-virtual {v1, v0, v2}, Landroid/support/v4/app/ja;->a(Ljava/lang/Object;Landroid/view/View;)V

    iget-object v0, p0, Landroid/support/v4/app/W;->_e:Landroid/support/v4/app/ja;

    iget-object v1, p0, Landroid/support/v4/app/W;->Ze:Ljava/lang/Object;

    iget-object v2, p0, Landroid/support/v4/app/W;->bf:Landroid/support/v4/app/n;

    iget-object v3, p0, Landroid/support/v4/app/W;->cf:Ljava/util/ArrayList;

    iget-object v4, p0, Landroid/support/v4/app/W;->af:Landroid/view/View;

    invoke-static {v0, v1, v2, v3, v4}, Landroid/support/v4/app/aa;->a(Landroid/support/v4/app/ja;Ljava/lang/Object;Landroid/support/v4/app/n;Ljava/util/ArrayList;Landroid/view/View;)Ljava/util/ArrayList;

    move-result-object v0

    iget-object v1, p0, Landroid/support/v4/app/W;->df:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    :cond_0
    iget-object v0, p0, Landroid/support/v4/app/W;->Ye:Ljava/util/ArrayList;

    if-eqz v0, :cond_2

    iget-object v0, p0, Landroid/support/v4/app/W;->ef:Ljava/lang/Object;

    if-eqz v0, :cond_1

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iget-object v1, p0, Landroid/support/v4/app/W;->af:Landroid/view/View;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v1, p0, Landroid/support/v4/app/W;->_e:Landroid/support/v4/app/ja;

    iget-object v2, p0, Landroid/support/v4/app/W;->ef:Ljava/lang/Object;

    iget-object v3, p0, Landroid/support/v4/app/W;->Ye:Ljava/util/ArrayList;

    invoke-virtual {v1, v2, v3, v0}, Landroid/support/v4/app/ja;->a(Ljava/lang/Object;Ljava/util/ArrayList;Ljava/util/ArrayList;)V

    :cond_1
    iget-object v0, p0, Landroid/support/v4/app/W;->Ye:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p0, Landroid/support/v4/app/W;->Ye:Ljava/util/ArrayList;

    iget-object p0, p0, Landroid/support/v4/app/W;->af:Landroid/view/View;

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2
    return-void
.end method
