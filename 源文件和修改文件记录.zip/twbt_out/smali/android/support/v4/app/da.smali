.class Landroid/support/v4/app/da;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/transition/Transition$TransitionListener;


# instance fields
.field final synthetic Ye:Ljava/util/ArrayList;

.field final synthetic Ze:Ljava/lang/Object;

.field final synthetic cf:Ljava/util/ArrayList;

.field final synthetic df:Ljava/util/ArrayList;

.field final synthetic ef:Ljava/lang/Object;

.field final synthetic n:Landroid/support/v4/app/fa;

.field final synthetic tf:Ljava/lang/Object;


# direct methods
.method constructor <init>(Landroid/support/v4/app/fa;Ljava/lang/Object;Ljava/util/ArrayList;Ljava/lang/Object;Ljava/util/ArrayList;Ljava/lang/Object;Ljava/util/ArrayList;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v4/app/da;->n:Landroid/support/v4/app/fa;

    iput-object p2, p0, Landroid/support/v4/app/da;->Ze:Ljava/lang/Object;

    iput-object p3, p0, Landroid/support/v4/app/da;->df:Ljava/util/ArrayList;

    iput-object p4, p0, Landroid/support/v4/app/da;->ef:Ljava/lang/Object;

    iput-object p5, p0, Landroid/support/v4/app/da;->Ye:Ljava/util/ArrayList;

    iput-object p6, p0, Landroid/support/v4/app/da;->tf:Ljava/lang/Object;

    iput-object p7, p0, Landroid/support/v4/app/da;->cf:Ljava/util/ArrayList;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onTransitionCancel(Landroid/transition/Transition;)V
    .locals 0

    return-void
.end method

.method public onTransitionEnd(Landroid/transition/Transition;)V
    .locals 0

    return-void
.end method

.method public onTransitionPause(Landroid/transition/Transition;)V
    .locals 0

    return-void
.end method

.method public onTransitionResume(Landroid/transition/Transition;)V
    .locals 0

    return-void
.end method

.method public onTransitionStart(Landroid/transition/Transition;)V
    .locals 3

    iget-object p1, p0, Landroid/support/v4/app/da;->Ze:Ljava/lang/Object;

    const/4 v0, 0x0

    if-eqz p1, :cond_0

    iget-object v1, p0, Landroid/support/v4/app/da;->n:Landroid/support/v4/app/fa;

    iget-object v2, p0, Landroid/support/v4/app/da;->df:Ljava/util/ArrayList;

    invoke-virtual {v1, p1, v2, v0}, Landroid/support/v4/app/fa;->a(Ljava/lang/Object;Ljava/util/ArrayList;Ljava/util/ArrayList;)V

    :cond_0
    iget-object p1, p0, Landroid/support/v4/app/da;->ef:Ljava/lang/Object;

    if-eqz p1, :cond_1

    iget-object v1, p0, Landroid/support/v4/app/da;->n:Landroid/support/v4/app/fa;

    iget-object v2, p0, Landroid/support/v4/app/da;->Ye:Ljava/util/ArrayList;

    invoke-virtual {v1, p1, v2, v0}, Landroid/support/v4/app/fa;->a(Ljava/lang/Object;Ljava/util/ArrayList;Ljava/util/ArrayList;)V

    :cond_1
    iget-object p1, p0, Landroid/support/v4/app/da;->tf:Ljava/lang/Object;

    if-eqz p1, :cond_2

    iget-object v1, p0, Landroid/support/v4/app/da;->n:Landroid/support/v4/app/fa;

    iget-object p0, p0, Landroid/support/v4/app/da;->cf:Ljava/util/ArrayList;

    invoke-virtual {v1, p1, p0, v0}, Landroid/support/v4/app/fa;->a(Ljava/lang/Object;Ljava/util/ArrayList;Ljava/util/ArrayList;)V

    :cond_2
    return-void
.end method
