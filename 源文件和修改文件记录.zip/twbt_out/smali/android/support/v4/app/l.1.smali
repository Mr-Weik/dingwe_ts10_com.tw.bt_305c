.class Landroid/support/v4/app/l;
.super Ljava/lang/Object;
.source ""


# instance fields
.field private Ae:Ljava/lang/Object;

.field private Be:Ljava/lang/Object;

.field private Ce:Ljava/lang/Object;

.field private De:Ljava/lang/Object;

.field private Ee:Ljava/lang/Boolean;

.field private Fe:Ljava/lang/Boolean;

.field mAnimatingAway:Landroid/view/View;

.field mAnimator:Landroid/animation/Animator;

.field mEnterTransitionCallback:Landroid/support/v4/app/pa;

.field mEnterTransitionPostponed:Z

.field mExitTransitionCallback:Landroid/support/v4/app/pa;

.field mIsHideReplaced:Z

.field mNextAnim:I

.field mNextTransition:I

.field mNextTransitionStyle:I

.field mStartEnterTransitionListener:Landroid/support/v4/app/N;

.field mStateAfterAnimating:I

.field private ye:Ljava/lang/Object;

.field private ze:Ljava/lang/Object;


# direct methods
.method constructor <init>()V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, Landroid/support/v4/app/l;->ye:Ljava/lang/Object;

    sget-object v1, Landroid/support/v4/app/n;->Ne:Ljava/lang/Object;

    iput-object v1, p0, Landroid/support/v4/app/l;->ze:Ljava/lang/Object;

    iput-object v0, p0, Landroid/support/v4/app/l;->Ae:Ljava/lang/Object;

    iput-object v1, p0, Landroid/support/v4/app/l;->Be:Ljava/lang/Object;

    iput-object v0, p0, Landroid/support/v4/app/l;->Ce:Ljava/lang/Object;

    iput-object v1, p0, Landroid/support/v4/app/l;->De:Ljava/lang/Object;

    return-void
.end method

.method static synthetic a(Landroid/support/v4/app/l;)Ljava/lang/Object;
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/l;->ye:Ljava/lang/Object;

    return-object p0
.end method

.method static synthetic b(Landroid/support/v4/app/l;)Ljava/lang/Object;
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/l;->ze:Ljava/lang/Object;

    return-object p0
.end method

.method static synthetic c(Landroid/support/v4/app/l;)Ljava/lang/Object;
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/l;->Ae:Ljava/lang/Object;

    return-object p0
.end method

.method static synthetic d(Landroid/support/v4/app/l;)Ljava/lang/Object;
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/l;->Be:Ljava/lang/Object;

    return-object p0
.end method

.method static synthetic e(Landroid/support/v4/app/l;)Ljava/lang/Object;
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/l;->Ce:Ljava/lang/Object;

    return-object p0
.end method

.method static synthetic f(Landroid/support/v4/app/l;)Ljava/lang/Object;
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/l;->De:Ljava/lang/Object;

    return-object p0
.end method

.method static synthetic g(Landroid/support/v4/app/l;)Ljava/lang/Boolean;
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/l;->Fe:Ljava/lang/Boolean;

    return-object p0
.end method

.method static synthetic h(Landroid/support/v4/app/l;)Ljava/lang/Boolean;
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/l;->Ee:Ljava/lang/Boolean;

    return-object p0
.end method
