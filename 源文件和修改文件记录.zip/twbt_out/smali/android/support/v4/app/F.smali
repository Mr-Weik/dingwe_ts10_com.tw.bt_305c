.class Landroid/support/v4/app/F;
.super Landroid/support/v4/app/G;
.source ""


# instance fields
.field mView:Landroid/view/View;


# direct methods
.method constructor <init>(Landroid/view/View;Landroid/view/animation/Animation$AnimationListener;)V
    .locals 1

    const/4 v0, 0x0

    invoke-direct {p0, p2, v0}, Landroid/support/v4/app/G;-><init>(Landroid/view/animation/Animation$AnimationListener;Landroid/support/v4/app/z;)V

    iput-object p1, p0, Landroid/support/v4/app/F;->mView:Landroid/view/View;

    return-void
.end method


# virtual methods
.method public onAnimationEnd(Landroid/view/animation/Animation;)V
    .locals 2

    iget-object v0, p0, Landroid/support/v4/app/F;->mView:Landroid/view/View;

    invoke-static {v0}, Landroid/support/v4/view/r;->x(Landroid/view/View;)Z

    move-result v0

    if-nez v0, :cond_0

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    :cond_0
    iget-object v0, p0, Landroid/support/v4/app/F;->mView:Landroid/view/View;

    new-instance v1, Landroid/support/v4/app/E;

    invoke-direct {v1, p0}, Landroid/support/v4/app/E;-><init>(Landroid/support/v4/app/F;)V

    invoke-virtual {v0, v1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    invoke-super {p0, p1}, Landroid/support/v4/app/G;->onAnimationEnd(Landroid/view/animation/Animation;)V

    return-void
.end method
