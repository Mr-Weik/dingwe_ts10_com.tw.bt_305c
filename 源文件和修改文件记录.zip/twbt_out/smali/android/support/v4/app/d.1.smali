.class final Landroid/support/v4/app/d;
.super Ljava/lang/Object;
.source ""


# instance fields
.field cmd:I

.field enterAnim:I

.field exitAnim:I

.field fragment:Landroid/support/v4/app/n;

.field popEnterAnim:I

.field popExitAnim:I


# direct methods
.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method constructor <init>(ILandroid/support/v4/app/n;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Landroid/support/v4/app/d;->cmd:I

    iput-object p2, p0, Landroid/support/v4/app/d;->fragment:Landroid/support/v4/app/n;

    return-void
.end method
