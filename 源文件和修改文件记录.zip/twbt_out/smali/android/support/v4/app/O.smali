.class final Landroid/support/v4/app/O;
.super Landroid/support/v4/app/y;
.source ""

# interfaces
.implements Landroid/view/LayoutInflater$Factory2;


# static fields
.field static Pe:Ljava/lang/reflect/Field;

.field static final Qe:Landroid/view/animation/Interpolator;

.field static final Re:Landroid/view/animation/Interpolator;


# instance fields
.field mActive:Landroid/util/SparseArray;

.field final mAdded:Ljava/util/ArrayList;

.field mAvailBackStackIndices:Ljava/util/ArrayList;

.field mBackStack:Ljava/util/ArrayList;

.field mBackStackChangeListeners:Ljava/util/ArrayList;

.field mBackStackIndices:Ljava/util/ArrayList;

.field mContainer:Landroid/support/v4/app/s;

.field mCreatedMenus:Ljava/util/ArrayList;

.field mCurState:I

.field mDestroyed:Z

.field mExecCommit:Ljava/lang/Runnable;

.field mExecutingActions:Z

.field mHavePendingDeferredStart:Z

.field mHost:Landroid/support/v4/app/u;

.field private final mLifecycleCallbacks:Ljava/util/concurrent/CopyOnWriteArrayList;

.field mNeedMenuInvalidate:Z

.field mNextFragmentIndex:I

.field mNoTransactionsBecause:Ljava/lang/String;

.field mParent:Landroid/support/v4/app/n;

.field mPendingActions:Ljava/util/ArrayList;

.field mPostponedTransactions:Ljava/util/ArrayList;

.field mPrimaryNav:Landroid/support/v4/app/n;

.field mSavedNonConfig:Landroid/support/v4/app/P;

.field mStateArray:Landroid/util/SparseArray;

.field mStateBundle:Landroid/os/Bundle;

.field mStateSaved:Z

.field mStopped:Z

.field mTmpAddedFragments:Ljava/util/ArrayList;

.field mTmpIsPop:Ljava/util/ArrayList;

.field mTmpRecords:Ljava/util/ArrayList;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    new-instance v0, Landroid/view/animation/DecelerateInterpolator;

    const/high16 v1, 0x40200000    # 2.5f

    invoke-direct {v0, v1}, Landroid/view/animation/DecelerateInterpolator;-><init>(F)V

    sput-object v0, Landroid/support/v4/app/O;->Qe:Landroid/view/animation/Interpolator;

    new-instance v0, Landroid/view/animation/DecelerateInterpolator;

    const/high16 v2, 0x3fc00000    # 1.5f

    invoke-direct {v0, v2}, Landroid/view/animation/DecelerateInterpolator;-><init>(F)V

    sput-object v0, Landroid/support/v4/app/O;->Re:Landroid/view/animation/Interpolator;

    new-instance v0, Landroid/view/animation/AccelerateInterpolator;

    invoke-direct {v0, v1}, Landroid/view/animation/AccelerateInterpolator;-><init>(F)V

    new-instance v0, Landroid/view/animation/AccelerateInterpolator;

    invoke-direct {v0, v2}, Landroid/view/animation/AccelerateInterpolator;-><init>(F)V

    return-void
.end method

.method constructor <init>()V
    .locals 2

    invoke-direct {p0}, Landroid/support/v4/app/y;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, Landroid/support/v4/app/O;->mNextFragmentIndex:I

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    new-instance v1, Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-direct {v1}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    iput-object v1, p0, Landroid/support/v4/app/O;->mLifecycleCallbacks:Ljava/util/concurrent/CopyOnWriteArrayList;

    iput v0, p0, Landroid/support/v4/app/O;->mCurState:I

    const/4 v0, 0x0

    iput-object v0, p0, Landroid/support/v4/app/O;->mStateBundle:Landroid/os/Bundle;

    iput-object v0, p0, Landroid/support/v4/app/O;->mStateArray:Landroid/util/SparseArray;

    new-instance v0, Landroid/support/v4/app/z;

    invoke-direct {v0, p0}, Landroid/support/v4/app/z;-><init>(Landroid/support/v4/app/O;)V

    iput-object v0, p0, Landroid/support/v4/app/O;->mExecCommit:Ljava/lang/Runnable;

    return-void
.end method

.method private La(I)V
    .locals 2

    const/4 v0, 0x1

    const/4 v1, 0x0

    :try_start_0
    iput-boolean v0, p0, Landroid/support/v4/app/O;->mExecutingActions:Z

    invoke-virtual {p0, p1, v1}, Landroid/support/v4/app/O;->moveToState(IZ)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iput-boolean v1, p0, Landroid/support/v4/app/O;->mExecutingActions:Z

    invoke-virtual {p0}, Landroid/support/v4/app/O;->execPendingActions()Z

    return-void

    :catchall_0
    move-exception p1

    iput-boolean v1, p0, Landroid/support/v4/app/O;->mExecutingActions:Z

    throw p1
.end method

.method private Qf()V
    .locals 3

    iget-object v0, p0, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Landroid/util/SparseArray;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    :goto_0
    if-ltz v0, :cond_1

    iget-object v1, p0, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    invoke-virtual {v1, v0}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v1

    if-nez v1, :cond_0

    iget-object v1, p0, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    invoke-virtual {v1, v0}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/util/SparseArray;->delete(I)V

    :cond_0
    add-int/lit8 v0, v0, -0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method private Rf()V
    .locals 2

    invoke-virtual {p0}, Landroid/support/v4/app/O;->isStateSaved()Z

    move-result v0

    if-nez v0, :cond_1

    iget-object v0, p0, Landroid/support/v4/app/O;->mNoTransactionsBecause:Ljava/lang/String;

    if-nez v0, :cond_0

    return-void

    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "Can not perform this action inside of "

    invoke-static {v1}, Lb/a/a/a/a;->x(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object p0, p0, Landroid/support/v4/app/O;->mNoTransactionsBecause:Ljava/lang/String;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string v0, "Can not perform this action after onSaveInstanceState"

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private Sf()V
    .locals 1

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/support/v4/app/O;->mExecutingActions:Z

    iget-object v0, p0, Landroid/support/v4/app/O;->mTmpIsPop:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object p0, p0, Landroid/support/v4/app/O;->mTmpRecords:Ljava/util/ArrayList;

    invoke-virtual {p0}, Ljava/util/ArrayList;->clear()V

    return-void
.end method

.method private Tf()V
    .locals 4

    monitor-enter p0

    :try_start_0
    iget-object v0, p0, Landroid/support/v4/app/O;->mPostponedTransactions:Ljava/util/ArrayList;

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroid/support/v4/app/O;->mPostponedTransactions:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    move v0, v2

    goto :goto_0

    :cond_0
    move v0, v1

    :goto_0
    iget-object v3, p0, Landroid/support/v4/app/O;->mPendingActions:Ljava/util/ArrayList;

    if-eqz v3, :cond_1

    iget-object v3, p0, Landroid/support/v4/app/O;->mPendingActions:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ne v3, v2, :cond_1

    move v1, v2

    :cond_1
    if-nez v0, :cond_2

    if-eqz v1, :cond_3

    :cond_2
    iget-object v0, p0, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    invoke-virtual {v0}, Landroid/support/v4/app/u;->getHandler()Landroid/os/Handler;

    move-result-object v0

    iget-object v1, p0, Landroid/support/v4/app/O;->mExecCommit:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v0, p0, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    invoke-virtual {v0}, Landroid/support/v4/app/u;->getHandler()Landroid/os/Handler;

    move-result-object v0

    iget-object v1, p0, Landroid/support/v4/app/O;->mExecCommit:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_3
    monitor-exit p0

    return-void

    :catchall_0
    move-exception v0

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v0
.end method

.method private W(Z)V
    .locals 2

    iget-boolean v0, p0, Landroid/support/v4/app/O;->mExecutingActions:Z

    if-nez v0, :cond_4

    iget-object v0, p0, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    if-eqz v0, :cond_3

    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v0

    iget-object v1, p0, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    invoke-virtual {v1}, Landroid/support/v4/app/u;->getHandler()Landroid/os/Handler;

    move-result-object v1

    invoke-virtual {v1}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    move-result-object v1

    if-ne v0, v1, :cond_2

    if-nez p1, :cond_0

    invoke-direct {p0}, Landroid/support/v4/app/O;->Rf()V

    :cond_0
    iget-object p1, p0, Landroid/support/v4/app/O;->mTmpRecords:Ljava/util/ArrayList;

    if-nez p1, :cond_1

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, Landroid/support/v4/app/O;->mTmpRecords:Ljava/util/ArrayList;

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, Landroid/support/v4/app/O;->mTmpIsPop:Ljava/util/ArrayList;

    :cond_1
    const/4 p1, 0x1

    iput-boolean p1, p0, Landroid/support/v4/app/O;->mExecutingActions:Z

    const/4 p1, 0x0

    const/4 v0, 0x0

    :try_start_0
    invoke-direct {p0, v0, v0}, Landroid/support/v4/app/O;->a(Ljava/util/ArrayList;Ljava/util/ArrayList;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iput-boolean p1, p0, Landroid/support/v4/app/O;->mExecutingActions:Z

    return-void

    :catchall_0
    move-exception v0

    iput-boolean p1, p0, Landroid/support/v4/app/O;->mExecutingActions:Z

    throw v0

    :cond_2
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "Must be called from main thread of fragment host"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_3
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "Fragment host has been destroyed"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_4
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "FragmentManager is already executing transactions"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method static a(FFFF)Landroid/support/v4/app/H;
    .locals 11

    new-instance v0, Landroid/view/animation/AnimationSet;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Landroid/view/animation/AnimationSet;-><init>(Z)V

    new-instance v1, Landroid/view/animation/ScaleAnimation;

    const/4 v7, 0x1

    const/high16 v8, 0x3f000000    # 0.5f

    const/4 v9, 0x1

    const/high16 v10, 0x3f000000    # 0.5f

    move-object v2, v1

    move v3, p0

    move v4, p1

    move v5, p0

    move v6, p1

    invoke-direct/range {v2 .. v10}, Landroid/view/animation/ScaleAnimation;-><init>(FFFFIFIF)V

    sget-object p0, Landroid/support/v4/app/O;->Qe:Landroid/view/animation/Interpolator;

    invoke-virtual {v1, p0}, Landroid/view/animation/ScaleAnimation;->setInterpolator(Landroid/view/animation/Interpolator;)V

    const-wide/16 p0, 0xdc

    invoke-virtual {v1, p0, p1}, Landroid/view/animation/ScaleAnimation;->setDuration(J)V

    invoke-virtual {v0, v1}, Landroid/view/animation/AnimationSet;->addAnimation(Landroid/view/animation/Animation;)V

    new-instance v1, Landroid/view/animation/AlphaAnimation;

    invoke-direct {v1, p2, p3}, Landroid/view/animation/AlphaAnimation;-><init>(FF)V

    sget-object p2, Landroid/support/v4/app/O;->Re:Landroid/view/animation/Interpolator;

    invoke-virtual {v1, p2}, Landroid/view/animation/AlphaAnimation;->setInterpolator(Landroid/view/animation/Interpolator;)V

    invoke-virtual {v1, p0, p1}, Landroid/view/animation/AlphaAnimation;->setDuration(J)V

    invoke-virtual {v0, v1}, Landroid/view/animation/AnimationSet;->addAnimation(Landroid/view/animation/Animation;)V

    new-instance p0, Landroid/support/v4/app/H;

    const/4 p1, 0x0

    invoke-direct {p0, v0, p1}, Landroid/support/v4/app/H;-><init>(Landroid/view/animation/Animation;Landroid/support/v4/app/z;)V

    return-object p0
.end method

.method private static a(Landroid/view/animation/Animation;)Landroid/view/animation/Animation$AnimationListener;
    .locals 3

    const-string v0, "FragmentManager"

    :try_start_0
    sget-object v1, Landroid/support/v4/app/O;->Pe:Ljava/lang/reflect/Field;

    if-nez v1, :cond_0

    const-class v1, Landroid/view/animation/Animation;

    const-string v2, "mListener"

    invoke-virtual {v1, v2}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v1

    sput-object v1, Landroid/support/v4/app/O;->Pe:Ljava/lang/reflect/Field;

    sget-object v1, Landroid/support/v4/app/O;->Pe:Ljava/lang/reflect/Field;

    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/reflect/Field;->setAccessible(Z)V

    :cond_0
    sget-object v1, Landroid/support/v4/app/O;->Pe:Ljava/lang/reflect/Field;

    invoke-virtual {v1, p0}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/view/animation/Animation$AnimationListener;
    :try_end_0
    .catch Ljava/lang/NoSuchFieldException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    move-exception p0

    const-string v1, "Cannot access Animation\'s mListener field"

    goto :goto_0

    :catch_1
    move-exception p0

    const-string v1, "No field with the name mListener is found in Animation class"

    :goto_0
    invoke-static {v0, v1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 p0, 0x0

    :goto_1
    return-object p0
.end method

.method static synthetic a(Landroid/support/v4/app/O;Landroid/support/v4/app/e;ZZZ)V
    .locals 0

    invoke-direct {p0, p1, p2, p3, p4}, Landroid/support/v4/app/O;->a(Landroid/support/v4/app/e;ZZZ)V

    return-void
.end method

.method private static a(Landroid/support/v4/app/P;)V
    .locals 3

    if-nez p0, :cond_0

    return-void

    :cond_0
    invoke-virtual {p0}, Landroid/support/v4/app/P;->getFragments()Ljava/util/List;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/support/v4/app/n;

    const/4 v2, 0x1

    iput-boolean v2, v1, Landroid/support/v4/app/n;->mRetaining:Z

    goto :goto_0

    :cond_1
    invoke-virtual {p0}, Landroid/support/v4/app/P;->getChildNonConfigs()Ljava/util/List;

    move-result-object p0

    if-eqz p0, :cond_2

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_1
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v4/app/P;

    invoke-static {v0}, Landroid/support/v4/app/O;->a(Landroid/support/v4/app/P;)V

    goto :goto_1

    :cond_2
    return-void
.end method

.method private a(Landroid/support/v4/app/e;ZZZ)V
    .locals 7

    if-eqz p2, :cond_0

    invoke-virtual {p1, p4}, Landroid/support/v4/app/e;->executePopOps(Z)V

    goto :goto_0

    :cond_0
    invoke-virtual {p1}, Landroid/support/v4/app/e;->executeOps()V

    :goto_0
    new-instance v1, Ljava/util/ArrayList;

    const/4 v6, 0x1

    invoke-direct {v1, v6}, Ljava/util/ArrayList;-><init>(I)V

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2, v6}, Ljava/util/ArrayList;-><init>(I)V

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-static {p2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p2

    invoke-virtual {v2, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    if-eqz p3, :cond_1

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    move-object v0, p0

    invoke-static/range {v0 .. v5}, Landroid/support/v4/app/aa;->a(Landroid/support/v4/app/O;Ljava/util/ArrayList;Ljava/util/ArrayList;IIZ)V

    :cond_1
    if-eqz p4, :cond_2

    iget p2, p0, Landroid/support/v4/app/O;->mCurState:I

    invoke-virtual {p0, p2, v6}, Landroid/support/v4/app/O;->moveToState(IZ)V

    :cond_2
    iget-object p2, p0, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    if-eqz p2, :cond_6

    invoke-virtual {p2}, Landroid/util/SparseArray;->size()I

    move-result p2

    const/4 p3, 0x0

    move v0, p3

    :goto_1
    if-ge v0, p2, :cond_6

    iget-object v1, p0, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    invoke-virtual {v1, v0}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/support/v4/app/n;

    if-eqz v1, :cond_5

    iget-object v2, v1, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    if-eqz v2, :cond_5

    iget-boolean v2, v1, Landroid/support/v4/app/n;->mIsNewlyAdded:Z

    if-eqz v2, :cond_5

    iget v2, v1, Landroid/support/v4/app/n;->mContainerId:I

    invoke-virtual {p1, v2}, Landroid/support/v4/app/e;->interactsWith(I)Z

    move-result v2

    if-eqz v2, :cond_5

    iget v2, v1, Landroid/support/v4/app/n;->Ie:F

    const/4 v3, 0x0

    cmpl-float v4, v2, v3

    if-lez v4, :cond_3

    iget-object v4, v1, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    invoke-virtual {v4, v2}, Landroid/view/View;->setAlpha(F)V

    :cond_3
    if-eqz p4, :cond_4

    iput v3, v1, Landroid/support/v4/app/n;->Ie:F

    goto :goto_2

    :cond_4
    const/high16 v2, -0x40800000    # -1.0f

    iput v2, v1, Landroid/support/v4/app/n;->Ie:F

    iput-boolean p3, v1, Landroid/support/v4/app/n;->mIsNewlyAdded:Z

    :cond_5
    :goto_2
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_6
    return-void
.end method

.method private static a(Landroid/view/View;Landroid/support/v4/app/H;)V
    .locals 5

    if-eqz p0, :cond_7

    if-nez p1, :cond_0

    goto/16 :goto_3

    :cond_0
    const/4 v0, 0x0

    .line 91
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-virtual {p0}, Landroid/view/View;->getLayerType()I

    move-result v1

    const/4 v2, 0x1

    if-nez v1, :cond_5

    invoke-static {p0}, Landroid/support/v4/view/r;->v(Landroid/view/View;)Z

    move-result v1

    if-eqz v1, :cond_5

    .line 92
    iget-object v1, p1, Landroid/support/v4/app/H;->animation:Landroid/view/animation/Animation;

    instance-of v3, v1, Landroid/view/animation/AlphaAnimation;

    if-eqz v3, :cond_1

    goto :goto_1

    :cond_1
    instance-of v3, v1, Landroid/view/animation/AnimationSet;

    if-eqz v3, :cond_4

    check-cast v1, Landroid/view/animation/AnimationSet;

    invoke-virtual {v1}, Landroid/view/animation/AnimationSet;->getAnimations()Ljava/util/List;

    move-result-object v1

    move v3, v0

    :goto_0
    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v4

    if-ge v3, v4, :cond_3

    invoke-interface {v1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    instance-of v4, v4, Landroid/view/animation/AlphaAnimation;

    if-eqz v4, :cond_2

    :goto_1
    move v1, v2

    goto :goto_2

    :cond_2
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_3
    move v1, v0

    goto :goto_2

    :cond_4
    iget-object v1, p1, Landroid/support/v4/app/H;->animator:Landroid/animation/Animator;

    invoke-static {v1}, Landroid/support/v4/app/O;->modifiesAlpha(Landroid/animation/Animator;)Z

    move-result v1

    :goto_2
    if-eqz v1, :cond_5

    move v0, v2

    :cond_5
    if-eqz v0, :cond_7

    .line 93
    iget-object v0, p1, Landroid/support/v4/app/H;->animator:Landroid/animation/Animator;

    if-eqz v0, :cond_6

    new-instance p1, Landroid/support/v4/app/I;

    invoke-direct {p1, p0}, Landroid/support/v4/app/I;-><init>(Landroid/view/View;)V

    invoke-virtual {v0, p1}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    goto :goto_3

    :cond_6
    iget-object v0, p1, Landroid/support/v4/app/H;->animation:Landroid/view/animation/Animation;

    invoke-static {v0}, Landroid/support/v4/app/O;->a(Landroid/view/animation/Animation;)Landroid/view/animation/Animation$AnimationListener;

    move-result-object v0

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p0, v1, v2}, Landroid/view/View;->setLayerType(ILandroid/graphics/Paint;)V

    iget-object p1, p1, Landroid/support/v4/app/H;->animation:Landroid/view/animation/Animation;

    new-instance v1, Landroid/support/v4/app/F;

    invoke-direct {v1, p0, v0}, Landroid/support/v4/app/F;-><init>(Landroid/view/View;Landroid/view/animation/Animation$AnimationListener;)V

    invoke-virtual {p1, v1}, Landroid/view/animation/Animation;->setAnimationListener(Landroid/view/animation/Animation$AnimationListener;)V

    :cond_7
    :goto_3
    return-void
.end method

.method private a(Ljava/lang/RuntimeException;)V
    .locals 7

    invoke-virtual {p1}, Ljava/lang/RuntimeException;->getMessage()Ljava/lang/String;

    move-result-object v0

    const-string v1, "FragmentManager"

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const-string v0, "Activity state:"

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    new-instance v0, La/b/c/f/f;

    invoke-direct {v0, v1}, La/b/c/f/f;-><init>(Ljava/lang/String;)V

    new-instance v2, Ljava/io/PrintWriter;

    invoke-direct {v2, v0}, Ljava/io/PrintWriter;-><init>(Ljava/io/Writer;)V

    iget-object v0, p0, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    const-string v3, "Failed dumping state"

    const/4 v4, 0x0

    const/4 v5, 0x0

    const-string v6, "  "

    if-eqz v0, :cond_0

    :try_start_0
    new-array p0, v4, [Ljava/lang/String;

    check-cast v0, Landroid/support/v4/app/p;

    .line 94
    iget-object v0, v0, Landroid/support/v4/app/p;->n:Landroid/support/v4/app/r;

    invoke-virtual {v0, v6, v5, v2, p0}, Landroid/support/v4/app/r;->dump(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V

    goto :goto_0

    :cond_0
    new-array v0, v4, [Ljava/lang/String;

    .line 95
    invoke-virtual {p0, v6, v5, v2, v0}, Landroid/support/v4/app/O;->dump(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p0

    invoke-static {v1, v3, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_0
    throw p1
.end method

.method private a(Ljava/util/ArrayList;Ljava/util/ArrayList;)V
    .locals 7

    iget-object v0, p0, Landroid/support/v4/app/O;->mPostponedTransactions:Ljava/util/ArrayList;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    move v0, v1

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    :goto_0
    move v2, v0

    move v0, v1

    :goto_1
    if-ge v0, v2, :cond_5

    iget-object v3, p0, Landroid/support/v4/app/O;->mPostponedTransactions:Ljava/util/ArrayList;

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/support/v4/app/N;

    const/4 v4, -0x1

    if-eqz p1, :cond_1

    invoke-static {v3}, Landroid/support/v4/app/N;->b(Landroid/support/v4/app/N;)Z

    move-result v5

    if-nez v5, :cond_1

    invoke-static {v3}, Landroid/support/v4/app/N;->c(Landroid/support/v4/app/N;)Landroid/support/v4/app/e;

    move-result-object v5

    invoke-virtual {p1, v5}, Ljava/util/ArrayList;->indexOf(Ljava/lang/Object;)I

    move-result v5

    if-eq v5, v4, :cond_1

    invoke-virtual {p2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    if-eqz v5, :cond_1

    :goto_2
    invoke-virtual {v3}, Landroid/support/v4/app/N;->cancelTransaction()V

    goto :goto_3

    :cond_1
    invoke-virtual {v3}, Landroid/support/v4/app/N;->isReady()Z

    move-result v5

    if-nez v5, :cond_2

    if-eqz p1, :cond_4

    invoke-static {v3}, Landroid/support/v4/app/N;->c(Landroid/support/v4/app/N;)Landroid/support/v4/app/e;

    move-result-object v5

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v6

    invoke-virtual {v5, p1, v1, v6}, Landroid/support/v4/app/e;->interactsWith(Ljava/util/ArrayList;II)Z

    move-result v5

    if-eqz v5, :cond_4

    :cond_2
    iget-object v5, p0, Landroid/support/v4/app/O;->mPostponedTransactions:Ljava/util/ArrayList;

    invoke-virtual {v5, v0}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    add-int/lit8 v0, v0, -0x1

    add-int/lit8 v2, v2, -0x1

    if-eqz p1, :cond_3

    invoke-static {v3}, Landroid/support/v4/app/N;->b(Landroid/support/v4/app/N;)Z

    move-result v5

    if-nez v5, :cond_3

    invoke-static {v3}, Landroid/support/v4/app/N;->c(Landroid/support/v4/app/N;)Landroid/support/v4/app/e;

    move-result-object v5

    invoke-virtual {p1, v5}, Ljava/util/ArrayList;->indexOf(Ljava/lang/Object;)I

    move-result v5

    if-eq v5, v4, :cond_3

    invoke-virtual {p2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Boolean;

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    if-eqz v4, :cond_3

    goto :goto_2

    :cond_3
    invoke-virtual {v3}, Landroid/support/v4/app/N;->completeTransaction()V

    :cond_4
    :goto_3
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_5
    return-void
.end method

.method private a(Ljava/util/ArrayList;Ljava/util/ArrayList;II)V
    .locals 19

    move-object/from16 v6, p0

    move-object/from16 v7, p1

    move-object/from16 v8, p2

    move/from16 v9, p3

    move/from16 v10, p4

    invoke-virtual {v7, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v4/app/e;

    iget-boolean v11, v0, Landroid/support/v4/app/e;->mReorderingAllowed:Z

    iget-object v0, v6, Landroid/support/v4/app/O;->mTmpAddedFragments:Ljava/util/ArrayList;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, v6, Landroid/support/v4/app/O;->mTmpAddedFragments:Ljava/util/ArrayList;

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    :goto_0
    iget-object v0, v6, Landroid/support/v4/app/O;->mTmpAddedFragments:Ljava/util/ArrayList;

    iget-object v1, v6, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 9
    iget-object v0, v6, Landroid/support/v4/app/O;->mPrimaryNav:Landroid/support/v4/app/n;

    move-object v1, v0

    move v0, v9

    const/4 v13, 0x0

    :goto_1
    const/4 v15, 0x1

    if-ge v0, v10, :cond_13

    .line 10
    invoke-virtual {v7, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/support/v4/app/e;

    invoke-virtual {v8, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Boolean;

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    const/4 v4, 0x3

    if-nez v3, :cond_d

    iget-object v3, v6, Landroid/support/v4/app/O;->mTmpAddedFragments:Ljava/util/ArrayList;

    move-object v5, v1

    const/4 v1, 0x0

    .line 11
    :goto_2
    iget-object v14, v2, Landroid/support/v4/app/e;->mOps:Ljava/util/ArrayList;

    invoke-virtual {v14}, Ljava/util/ArrayList;->size()I

    move-result v14

    if-ge v1, v14, :cond_c

    iget-object v14, v2, Landroid/support/v4/app/e;->mOps:Ljava/util/ArrayList;

    invoke-virtual {v14, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Landroid/support/v4/app/d;

    iget v12, v14, Landroid/support/v4/app/d;->cmd:I

    if-eq v12, v15, :cond_b

    const/4 v15, 0x2

    const/16 v9, 0x9

    if-eq v12, v15, :cond_5

    if-eq v12, v4, :cond_3

    const/4 v15, 0x6

    if-eq v12, v15, :cond_3

    const/4 v15, 0x7

    if-eq v12, v15, :cond_2

    const/16 v15, 0x8

    if-eq v12, v15, :cond_1

    goto :goto_3

    :cond_1
    iget-object v12, v2, Landroid/support/v4/app/e;->mOps:Ljava/util/ArrayList;

    new-instance v15, Landroid/support/v4/app/d;

    invoke-direct {v15, v9, v5}, Landroid/support/v4/app/d;-><init>(ILandroid/support/v4/app/n;)V

    invoke-virtual {v12, v1, v15}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    add-int/lit8 v1, v1, 0x1

    iget-object v5, v14, Landroid/support/v4/app/d;->fragment:Landroid/support/v4/app/n;

    goto :goto_3

    :cond_2
    const/4 v7, 0x1

    goto/16 :goto_8

    :cond_3
    iget-object v12, v14, Landroid/support/v4/app/d;->fragment:Landroid/support/v4/app/n;

    invoke-virtual {v3, v12}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    iget-object v12, v14, Landroid/support/v4/app/d;->fragment:Landroid/support/v4/app/n;

    if-ne v12, v5, :cond_4

    iget-object v5, v2, Landroid/support/v4/app/e;->mOps:Ljava/util/ArrayList;

    new-instance v14, Landroid/support/v4/app/d;

    invoke-direct {v14, v9, v12}, Landroid/support/v4/app/d;-><init>(ILandroid/support/v4/app/n;)V

    invoke-virtual {v5, v1, v14}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x0

    :cond_4
    :goto_3
    const/4 v7, 0x1

    goto/16 :goto_9

    :cond_5
    iget-object v12, v14, Landroid/support/v4/app/d;->fragment:Landroid/support/v4/app/n;

    iget v15, v12, Landroid/support/v4/app/n;->mContainerId:I

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v17

    const/16 v16, 0x1

    add-int/lit8 v17, v17, -0x1

    move v4, v1

    move-object v9, v5

    move/from16 v1, v17

    const/4 v5, 0x0

    :goto_4
    if-ltz v1, :cond_9

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v18

    move-object/from16 v8, v18

    check-cast v8, Landroid/support/v4/app/n;

    iget v7, v8, Landroid/support/v4/app/n;->mContainerId:I

    if-ne v7, v15, :cond_8

    if-ne v8, v12, :cond_6

    move/from16 v18, v15

    const/4 v5, 0x1

    goto :goto_6

    :cond_6
    if-ne v8, v9, :cond_7

    iget-object v7, v2, Landroid/support/v4/app/e;->mOps:Ljava/util/ArrayList;

    new-instance v9, Landroid/support/v4/app/d;

    move/from16 v18, v15

    const/16 v15, 0x9

    invoke-direct {v9, v15, v8}, Landroid/support/v4/app/d;-><init>(ILandroid/support/v4/app/n;)V

    invoke-virtual {v7, v4, v9}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    add-int/lit8 v4, v4, 0x1

    const/4 v9, 0x0

    goto :goto_5

    :cond_7
    move/from16 v18, v15

    const/16 v15, 0x9

    :goto_5
    new-instance v7, Landroid/support/v4/app/d;

    const/4 v15, 0x3

    invoke-direct {v7, v15, v8}, Landroid/support/v4/app/d;-><init>(ILandroid/support/v4/app/n;)V

    iget v15, v14, Landroid/support/v4/app/d;->enterAnim:I

    iput v15, v7, Landroid/support/v4/app/d;->enterAnim:I

    iget v15, v14, Landroid/support/v4/app/d;->popEnterAnim:I

    iput v15, v7, Landroid/support/v4/app/d;->popEnterAnim:I

    iget v15, v14, Landroid/support/v4/app/d;->exitAnim:I

    iput v15, v7, Landroid/support/v4/app/d;->exitAnim:I

    iget v15, v14, Landroid/support/v4/app/d;->popExitAnim:I

    iput v15, v7, Landroid/support/v4/app/d;->popExitAnim:I

    iget-object v15, v2, Landroid/support/v4/app/e;->mOps:Ljava/util/ArrayList;

    invoke-virtual {v15, v4, v7}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    invoke-virtual {v3, v8}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    const/4 v7, 0x1

    add-int/2addr v4, v7

    goto :goto_6

    :cond_8
    move/from16 v18, v15

    :goto_6
    add-int/lit8 v1, v1, -0x1

    move-object/from16 v7, p1

    move-object/from16 v8, p2

    move/from16 v15, v18

    goto :goto_4

    :cond_9
    if-eqz v5, :cond_a

    iget-object v1, v2, Landroid/support/v4/app/e;->mOps:Ljava/util/ArrayList;

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    add-int/lit8 v4, v4, -0x1

    move v1, v4

    const/4 v7, 0x1

    goto :goto_7

    :cond_a
    const/4 v7, 0x1

    iput v7, v14, Landroid/support/v4/app/d;->cmd:I

    invoke-virtual {v3, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move v1, v4

    :goto_7
    move-object v5, v9

    goto :goto_9

    :cond_b
    move v7, v15

    :goto_8
    iget-object v4, v14, Landroid/support/v4/app/d;->fragment:Landroid/support/v4/app/n;

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_9
    add-int/2addr v1, v7

    move-object/from16 v8, p2

    move/from16 v9, p3

    move v15, v7

    const/4 v4, 0x3

    move-object/from16 v7, p1

    goto/16 :goto_2

    :cond_c
    move-object v1, v5

    goto :goto_c

    .line 12
    :cond_d
    iget-object v3, v6, Landroid/support/v4/app/O;->mTmpAddedFragments:Ljava/util/ArrayList;

    move-object v4, v1

    const/4 v1, 0x0

    .line 13
    :goto_a
    iget-object v5, v2, Landroid/support/v4/app/e;->mOps:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v1, v5, :cond_10

    iget-object v5, v2, Landroid/support/v4/app/e;->mOps:Ljava/util/ArrayList;

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/support/v4/app/d;

    iget v7, v5, Landroid/support/v4/app/d;->cmd:I

    const/4 v8, 0x1

    if-eq v7, v8, :cond_f

    const/4 v8, 0x3

    if-eq v7, v8, :cond_e

    packed-switch v7, :pswitch_data_0

    goto :goto_b

    :pswitch_0
    iget-object v4, v5, Landroid/support/v4/app/d;->fragment:Landroid/support/v4/app/n;

    goto :goto_b

    :pswitch_1
    const/4 v4, 0x0

    goto :goto_b

    :cond_e
    :pswitch_2
    iget-object v5, v5, Landroid/support/v4/app/d;->fragment:Landroid/support/v4/app/n;

    invoke-virtual {v3, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_b

    :cond_f
    const/4 v8, 0x3

    :pswitch_3
    iget-object v5, v5, Landroid/support/v4/app/d;->fragment:Landroid/support/v4/app/n;

    invoke-virtual {v3, v5}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    :goto_b
    add-int/lit8 v1, v1, 0x1

    goto :goto_a

    :cond_10
    move-object v1, v4

    :goto_c
    if-nez v13, :cond_12

    .line 14
    iget-boolean v2, v2, Landroid/support/v4/app/e;->mAddToBackStack:Z

    if-eqz v2, :cond_11

    goto :goto_d

    :cond_11
    const/4 v13, 0x0

    goto :goto_e

    :cond_12
    :goto_d
    const/4 v13, 0x1

    :goto_e
    add-int/lit8 v0, v0, 0x1

    move-object/from16 v7, p1

    move-object/from16 v8, p2

    move/from16 v9, p3

    goto/16 :goto_1

    :cond_13
    iget-object v0, v6, Landroid/support/v4/app/O;->mTmpAddedFragments:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    if-nez v11, :cond_14

    const/4 v5, 0x0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move/from16 v3, p3

    move/from16 v4, p4

    invoke-static/range {v0 .. v5}, Landroid/support/v4/app/aa;->a(Landroid/support/v4/app/O;Ljava/util/ArrayList;Ljava/util/ArrayList;IIZ)V

    :cond_14
    move/from16 v0, p3

    :goto_f
    const/4 v7, -0x1

    move-object/from16 v8, p1

    if-ge v0, v10, :cond_17

    .line 15
    invoke-virtual {v8, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/support/v4/app/e;

    move-object/from16 v9, p2

    invoke-virtual {v9, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Boolean;

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_16

    invoke-virtual {v1, v7}, Landroid/support/v4/app/e;->bumpBackStackNesting(I)V

    add-int/lit8 v2, v10, -0x1

    if-ne v0, v2, :cond_15

    const/4 v2, 0x1

    goto :goto_10

    :cond_15
    const/4 v2, 0x0

    :goto_10
    invoke-virtual {v1, v2}, Landroid/support/v4/app/e;->executePopOps(Z)V

    goto :goto_11

    :cond_16
    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Landroid/support/v4/app/e;->bumpBackStackNesting(I)V

    invoke-virtual {v1}, Landroid/support/v4/app/e;->executeOps()V

    :goto_11
    add-int/lit8 v0, v0, 0x1

    goto :goto_f

    :cond_17
    move-object/from16 v9, p2

    if-eqz v11, :cond_20

    .line 16
    new-instance v0, La/b/c/f/d;

    invoke-direct {v0}, La/b/c/f/d;-><init>()V

    invoke-direct {v6, v0}, Landroid/support/v4/app/O;->c(La/b/c/f/d;)V

    add-int/lit8 v1, v10, -0x1

    move/from16 v12, p3

    move v2, v10

    :goto_12
    if-lt v1, v12, :cond_1d

    .line 17
    invoke-virtual {v8, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/support/v4/app/e;

    invoke-virtual {v9, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Boolean;

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    invoke-virtual {v3}, Landroid/support/v4/app/e;->isPostponed()Z

    move-result v5

    if-eqz v5, :cond_18

    add-int/lit8 v5, v1, 0x1

    invoke-virtual {v3, v8, v5, v10}, Landroid/support/v4/app/e;->interactsWith(Ljava/util/ArrayList;II)Z

    move-result v5

    if-nez v5, :cond_18

    const/4 v5, 0x1

    goto :goto_13

    :cond_18
    const/4 v5, 0x0

    :goto_13
    if-eqz v5, :cond_1c

    iget-object v5, v6, Landroid/support/v4/app/O;->mPostponedTransactions:Ljava/util/ArrayList;

    if-nez v5, :cond_19

    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    iput-object v5, v6, Landroid/support/v4/app/O;->mPostponedTransactions:Ljava/util/ArrayList;

    :cond_19
    new-instance v5, Landroid/support/v4/app/N;

    invoke-direct {v5, v3, v4}, Landroid/support/v4/app/N;-><init>(Landroid/support/v4/app/e;Z)V

    iget-object v14, v6, Landroid/support/v4/app/O;->mPostponedTransactions:Ljava/util/ArrayList;

    invoke-virtual {v14, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v3, v5}, Landroid/support/v4/app/e;->d(Landroid/support/v4/app/N;)V

    if-eqz v4, :cond_1a

    invoke-virtual {v3}, Landroid/support/v4/app/e;->executeOps()V

    const/4 v14, 0x0

    goto :goto_14

    :cond_1a
    const/4 v14, 0x0

    invoke-virtual {v3, v14}, Landroid/support/v4/app/e;->executePopOps(Z)V

    :goto_14
    add-int/lit8 v2, v2, -0x1

    if-eq v1, v2, :cond_1b

    invoke-virtual {v8, v1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    invoke-virtual {v8, v2, v3}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    :cond_1b
    invoke-direct {v6, v0}, Landroid/support/v4/app/O;->c(La/b/c/f/d;)V

    goto :goto_15

    :cond_1c
    const/4 v14, 0x0

    :goto_15
    add-int/lit8 v1, v1, -0x1

    goto :goto_12

    :cond_1d
    const/4 v14, 0x0

    .line 18
    invoke-virtual {v0}, La/b/c/f/d;->size()I

    move-result v1

    move v3, v14

    :goto_16
    if-ge v3, v1, :cond_1f

    invoke-virtual {v0, v3}, La/b/c/f/d;->valueAt(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/support/v4/app/n;

    iget-boolean v5, v4, Landroid/support/v4/app/n;->mAdded:Z

    if-nez v5, :cond_1e

    .line 19
    iget-object v5, v4, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    .line 20
    invoke-virtual {v5}, Landroid/view/View;->getAlpha()F

    move-result v15

    iput v15, v4, Landroid/support/v4/app/n;->Ie:F

    const/4 v4, 0x0

    invoke-virtual {v5, v4}, Landroid/view/View;->setAlpha(F)V

    :cond_1e
    add-int/lit8 v3, v3, 0x1

    goto :goto_16

    :cond_1f
    move v4, v2

    goto :goto_17

    :cond_20
    move/from16 v12, p3

    const/4 v14, 0x0

    move v4, v10

    :goto_17
    if-eq v4, v12, :cond_21

    if-eqz v11, :cond_21

    const/4 v5, 0x1

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move/from16 v3, p3

    .line 21
    invoke-static/range {v0 .. v5}, Landroid/support/v4/app/aa;->a(Landroid/support/v4/app/O;Ljava/util/ArrayList;Ljava/util/ArrayList;IIZ)V

    iget v0, v6, Landroid/support/v4/app/O;->mCurState:I

    const/4 v1, 0x1

    invoke-virtual {v6, v0, v1}, Landroid/support/v4/app/O;->moveToState(IZ)V

    :cond_21
    :goto_18
    if-ge v12, v10, :cond_25

    invoke-virtual {v8, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v4/app/e;

    invoke-virtual {v9, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_22

    iget v1, v0, Landroid/support/v4/app/e;->mIndex:I

    if-ltz v1, :cond_22

    invoke-virtual {v6, v1}, Landroid/support/v4/app/O;->freeBackStackIndex(I)V

    iput v7, v0, Landroid/support/v4/app/e;->mIndex:I

    .line 22
    :cond_22
    iget-object v1, v0, Landroid/support/v4/app/e;->mCommitRunnables:Ljava/util/ArrayList;

    if-eqz v1, :cond_24

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    move v2, v14

    :goto_19
    if-ge v2, v1, :cond_23

    iget-object v3, v0, Landroid/support/v4/app/e;->mCommitRunnables:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Runnable;

    invoke-interface {v3}, Ljava/lang/Runnable;->run()V

    add-int/lit8 v2, v2, 0x1

    goto :goto_19

    :cond_23
    const/4 v2, 0x0

    iput-object v2, v0, Landroid/support/v4/app/e;->mCommitRunnables:Ljava/util/ArrayList;

    goto :goto_1a

    :cond_24
    const/4 v2, 0x0

    :goto_1a
    add-int/lit8 v12, v12, 0x1

    goto :goto_18

    :cond_25
    if-eqz v13, :cond_26

    .line 23
    iget-object v0, v6, Landroid/support/v4/app/O;->mBackStackChangeListeners:Ljava/util/ArrayList;

    if-eqz v0, :cond_26

    :goto_1b
    iget-object v0, v6, Landroid/support/v4/app/O;->mBackStackChangeListeners:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge v14, v0, :cond_26

    iget-object v0, v6, Landroid/support/v4/app/O;->mBackStackChangeListeners:Ljava/util/ArrayList;

    invoke-virtual {v0, v14}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v4/app/x;

    invoke-interface {v0}, Landroid/support/v4/app/x;->onBackStackChanged()V

    add-int/lit8 v14, v14, 0x1

    goto :goto_1b

    :cond_26
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x6
        :pswitch_2
        :pswitch_3
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method static synthetic b(Landroid/support/v4/app/O;)V
    .locals 0

    invoke-direct {p0}, Landroid/support/v4/app/O;->Tf()V

    return-void
.end method

.method private b(Ljava/util/ArrayList;Ljava/util/ArrayList;)Z
    .locals 4

    monitor-enter p0

    :try_start_0
    iget-object v0, p0, Landroid/support/v4/app/O;->mPendingActions:Ljava/util/ArrayList;

    const/4 v1, 0x0

    if-eqz v0, :cond_2

    iget-object v0, p0, Landroid/support/v4/app/O;->mPendingActions:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-nez v0, :cond_0

    goto :goto_1

    :cond_0
    iget-object v0, p0, Landroid/support/v4/app/O;->mPendingActions:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    move v2, v1

    :goto_0
    if-ge v1, v0, :cond_1

    iget-object v3, p0, Landroid/support/v4/app/O;->mPendingActions:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/support/v4/app/M;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    check-cast v3, Landroid/support/v4/app/e;

    :try_start_1
    invoke-virtual {v3, p1, p2}, Landroid/support/v4/app/e;->generateOps(Ljava/util/ArrayList;Ljava/util/ArrayList;)Z

    or-int/lit8 v2, v2, 0x1

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    iget-object p1, p0, Landroid/support/v4/app/O;->mPendingActions:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->clear()V

    iget-object p1, p0, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    invoke-virtual {p1}, Landroid/support/v4/app/u;->getHandler()Landroid/os/Handler;

    move-result-object p1

    iget-object p2, p0, Landroid/support/v4/app/O;->mExecCommit:Ljava/lang/Runnable;

    invoke-virtual {p1, p2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    monitor-exit p0

    return v2

    :cond_2
    :goto_1
    monitor-exit p0

    return v1

    :catchall_0
    move-exception p1

    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method private c(La/b/c/f/d;)V
    .locals 10

    iget v0, p0, Landroid/support/v4/app/O;->mCurState:I

    const/4 v1, 0x1

    if-ge v0, v1, :cond_0

    return-void

    :cond_0
    const/4 v1, 0x4

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v0

    iget-object v1, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v2, 0x0

    move v8, v2

    :goto_0
    if-ge v8, v1, :cond_2

    iget-object v2, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v2, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    move-object v9, v2

    check-cast v9, Landroid/support/v4/app/n;

    iget v2, v9, Landroid/support/v4/app/n;->mState:I

    if-ge v2, v0, :cond_1

    invoke-virtual {v9}, Landroid/support/v4/app/n;->getNextAnim()I

    move-result v5

    invoke-virtual {v9}, Landroid/support/v4/app/n;->getNextTransition()I

    move-result v6

    const/4 v7, 0x0

    move-object v2, p0

    move-object v3, v9

    move v4, v0

    invoke-virtual/range {v2 .. v7}, Landroid/support/v4/app/O;->a(Landroid/support/v4/app/n;IIIZ)V

    iget-object v2, v9, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    if-eqz v2, :cond_1

    iget-boolean v2, v9, Landroid/support/v4/app/n;->mHidden:Z

    if-nez v2, :cond_1

    iget-boolean v2, v9, Landroid/support/v4/app/n;->mIsNewlyAdded:Z

    if-eqz v2, :cond_1

    invoke-virtual {p1, v9}, La/b/c/f/d;->add(Ljava/lang/Object;)Z

    :cond_1
    add-int/lit8 v8, v8, 0x1

    goto :goto_0

    :cond_2
    return-void
.end method

.method private c(Ljava/util/ArrayList;Ljava/util/ArrayList;)V
    .locals 4

    if-eqz p1, :cond_7

    invoke-virtual {p1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_2

    :cond_0
    if-eqz p2, :cond_6

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v0

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ne v0, v1, :cond_6

    invoke-direct {p0, p1, p2}, Landroid/support/v4/app/O;->a(Ljava/util/ArrayList;Ljava/util/ArrayList;)V

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    if-ge v1, v0, :cond_4

    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/support/v4/app/e;

    iget-boolean v3, v3, Landroid/support/v4/app/e;->mReorderingAllowed:Z

    if-nez v3, :cond_3

    if-eq v2, v1, :cond_1

    invoke-direct {p0, p1, p2, v2, v1}, Landroid/support/v4/app/O;->a(Ljava/util/ArrayList;Ljava/util/ArrayList;II)V

    :cond_1
    add-int/lit8 v2, v1, 0x1

    invoke-virtual {p2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Boolean;

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    if-eqz v3, :cond_2

    :goto_1
    if-ge v2, v0, :cond_2

    invoke-virtual {p2, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Boolean;

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    if-eqz v3, :cond_2

    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/support/v4/app/e;

    iget-boolean v3, v3, Landroid/support/v4/app/e;->mReorderingAllowed:Z

    if-nez v3, :cond_2

    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_2
    invoke-direct {p0, p1, p2, v1, v2}, Landroid/support/v4/app/O;->a(Ljava/util/ArrayList;Ljava/util/ArrayList;II)V

    add-int/lit8 v1, v2, -0x1

    :cond_3
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_4
    if-eq v2, v0, :cond_5

    invoke-direct {p0, p1, p2, v2, v0}, Landroid/support/v4/app/O;->a(Ljava/util/ArrayList;Ljava/util/ArrayList;II)V

    :cond_5
    return-void

    :cond_6
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "Internal error with the back stack records"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_7
    :goto_2
    return-void
.end method

.method static modifiesAlpha(Landroid/animation/Animator;)Z
    .locals 5

    const/4 v0, 0x0

    if-nez p0, :cond_0

    return v0

    :cond_0
    instance-of v1, p0, Landroid/animation/ValueAnimator;

    const/4 v2, 0x1

    if-eqz v1, :cond_2

    check-cast p0, Landroid/animation/ValueAnimator;

    invoke-virtual {p0}, Landroid/animation/ValueAnimator;->getValues()[Landroid/animation/PropertyValuesHolder;

    move-result-object p0

    move v1, v0

    :goto_0
    array-length v3, p0

    if-ge v1, v3, :cond_4

    aget-object v3, p0, v1

    invoke-virtual {v3}, Landroid/animation/PropertyValuesHolder;->getPropertyName()Ljava/lang/String;

    move-result-object v3

    const-string v4, "alpha"

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1

    return v2

    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_2
    instance-of v1, p0, Landroid/animation/AnimatorSet;

    if-eqz v1, :cond_4

    check-cast p0, Landroid/animation/AnimatorSet;

    invoke-virtual {p0}, Landroid/animation/AnimatorSet;->getChildAnimations()Ljava/util/ArrayList;

    move-result-object p0

    move v1, v0

    :goto_1
    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v3

    if-ge v1, v3, :cond_4

    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/animation/Animator;

    invoke-static {v3}, Landroid/support/v4/app/O;->modifiesAlpha(Landroid/animation/Animator;)Z

    move-result v3

    if-eqz v3, :cond_3

    return v2

    :cond_3
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_4
    return v0
.end method

.method public static reverseTransit(I)I
    .locals 3

    const/16 v0, 0x2002

    const/16 v1, 0x1003

    const/16 v2, 0x1001

    if-eq p0, v2, :cond_2

    if-eq p0, v1, :cond_1

    if-eq p0, v0, :cond_0

    const/4 v0, 0x0

    goto :goto_0

    :cond_0
    move v0, v2

    goto :goto_0

    :cond_1
    move v0, v1

    :cond_2
    :goto_0
    return v0
.end method


# virtual methods
.method a(Landroid/support/v4/app/n;IZI)Landroid/support/v4/app/H;
    .locals 6

    invoke-virtual {p1}, Landroid/support/v4/app/n;->getNextAnim()I

    move-result p1

    const/4 v0, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz p1, :cond_3

    iget-object v3, p0, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    invoke-virtual {v3}, Landroid/support/v4/app/u;->getContext()Landroid/content/Context;

    move-result-object v3

    invoke-virtual {v3}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {v3, p1}, Landroid/content/res/Resources;->getResourceTypeName(I)Ljava/lang/String;

    move-result-object v3

    const-string v4, "anim"

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1

    :try_start_0
    iget-object v4, p0, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    invoke-virtual {v4}, Landroid/support/v4/app/u;->getContext()Landroid/content/Context;

    move-result-object v4

    invoke-static {v4, p1}, Landroid/view/animation/AnimationUtils;->loadAnimation(Landroid/content/Context;I)Landroid/view/animation/Animation;

    move-result-object v4

    if-eqz v4, :cond_0

    new-instance v5, Landroid/support/v4/app/H;

    invoke-direct {v5, v4, v0}, Landroid/support/v4/app/H;-><init>(Landroid/view/animation/Animation;Landroid/support/v4/app/z;)V
    :try_end_0
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_1

    return-object v5

    :cond_0
    move v4, v1

    goto :goto_0

    :catch_0
    move-exception p0

    throw p0

    :catch_1
    :cond_1
    move v4, v2

    :goto_0
    if-nez v4, :cond_3

    :try_start_1
    iget-object v4, p0, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    invoke-virtual {v4}, Landroid/support/v4/app/u;->getContext()Landroid/content/Context;

    move-result-object v4

    invoke-static {v4, p1}, Landroid/animation/AnimatorInflater;->loadAnimator(Landroid/content/Context;I)Landroid/animation/Animator;

    move-result-object v4

    if-eqz v4, :cond_3

    new-instance v5, Landroid/support/v4/app/H;

    invoke-direct {v5, v4, v0}, Landroid/support/v4/app/H;-><init>(Landroid/animation/Animator;Landroid/support/v4/app/z;)V
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_2

    return-object v5

    :catch_2
    move-exception v4

    if-nez v3, :cond_2

    iget-object v3, p0, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    invoke-virtual {v3}, Landroid/support/v4/app/u;->getContext()Landroid/content/Context;

    move-result-object v3

    invoke-static {v3, p1}, Landroid/view/animation/AnimationUtils;->loadAnimation(Landroid/content/Context;I)Landroid/view/animation/Animation;

    move-result-object p1

    if-eqz p1, :cond_3

    new-instance p0, Landroid/support/v4/app/H;

    invoke-direct {p0, p1, v0}, Landroid/support/v4/app/H;-><init>(Landroid/view/animation/Animation;Landroid/support/v4/app/z;)V

    return-object p0

    :cond_2
    throw v4

    :cond_3
    if-nez p2, :cond_4

    return-object v0

    :cond_4
    const/16 p1, 0x1001

    if-eq p2, p1, :cond_9

    const/16 p1, 0x1003

    if-eq p2, p1, :cond_7

    const/16 p1, 0x2002

    if-eq p2, p1, :cond_5

    const/4 p1, -0x1

    goto :goto_1

    :cond_5
    if-eqz p3, :cond_6

    const/4 p1, 0x3

    goto :goto_1

    :cond_6
    const/4 p1, 0x4

    goto :goto_1

    :cond_7
    if-eqz p3, :cond_8

    const/4 p1, 0x5

    goto :goto_1

    :cond_8
    const/4 p1, 0x6

    goto :goto_1

    :cond_9
    if-eqz p3, :cond_a

    move p1, v1

    goto :goto_1

    :cond_a
    const/4 p1, 0x2

    :goto_1
    if-gez p1, :cond_b

    return-object v0

    :cond_b
    const p2, 0x3f79999a    # 0.975f

    const/4 p3, 0x0

    const/high16 v3, 0x3f800000    # 1.0f

    const-wide/16 v4, 0xdc

    packed-switch p1, :pswitch_data_0

    if-nez p4, :cond_e

    iget-object p1, p0, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    goto :goto_2

    :pswitch_0
    iget-object p0, p0, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    invoke-virtual {p0}, Landroid/support/v4/app/u;->getContext()Landroid/content/Context;

    .line 24
    new-instance p0, Landroid/view/animation/AlphaAnimation;

    invoke-direct {p0, v3, p3}, Landroid/view/animation/AlphaAnimation;-><init>(FF)V

    sget-object p1, Landroid/support/v4/app/O;->Re:Landroid/view/animation/Interpolator;

    invoke-virtual {p0, p1}, Landroid/view/animation/AlphaAnimation;->setInterpolator(Landroid/view/animation/Interpolator;)V

    invoke-virtual {p0, v4, v5}, Landroid/view/animation/AlphaAnimation;->setDuration(J)V

    new-instance p1, Landroid/support/v4/app/H;

    invoke-direct {p1, p0, v0}, Landroid/support/v4/app/H;-><init>(Landroid/view/animation/Animation;Landroid/support/v4/app/z;)V

    return-object p1

    .line 25
    :pswitch_1
    iget-object p0, p0, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    invoke-virtual {p0}, Landroid/support/v4/app/u;->getContext()Landroid/content/Context;

    .line 26
    new-instance p0, Landroid/view/animation/AlphaAnimation;

    invoke-direct {p0, p3, v3}, Landroid/view/animation/AlphaAnimation;-><init>(FF)V

    sget-object p1, Landroid/support/v4/app/O;->Re:Landroid/view/animation/Interpolator;

    invoke-virtual {p0, p1}, Landroid/view/animation/AlphaAnimation;->setInterpolator(Landroid/view/animation/Interpolator;)V

    invoke-virtual {p0, v4, v5}, Landroid/view/animation/AlphaAnimation;->setDuration(J)V

    new-instance p1, Landroid/support/v4/app/H;

    invoke-direct {p1, p0, v0}, Landroid/support/v4/app/H;-><init>(Landroid/view/animation/Animation;Landroid/support/v4/app/z;)V

    return-object p1

    .line 27
    :pswitch_2
    iget-object p0, p0, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    invoke-virtual {p0}, Landroid/support/v4/app/u;->getContext()Landroid/content/Context;

    const p0, 0x3f89999a    # 1.075f

    invoke-static {v3, p0, v3, p3}, Landroid/support/v4/app/O;->a(FFFF)Landroid/support/v4/app/H;

    move-result-object p0

    return-object p0

    :pswitch_3
    iget-object p0, p0, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    invoke-virtual {p0}, Landroid/support/v4/app/u;->getContext()Landroid/content/Context;

    invoke-static {p2, v3, p3, v3}, Landroid/support/v4/app/O;->a(FFFF)Landroid/support/v4/app/H;

    move-result-object p0

    return-object p0

    :pswitch_4
    iget-object p0, p0, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    invoke-virtual {p0}, Landroid/support/v4/app/u;->getContext()Landroid/content/Context;

    invoke-static {v3, p2, v3, p3}, Landroid/support/v4/app/O;->a(FFFF)Landroid/support/v4/app/H;

    move-result-object p0

    return-object p0

    :pswitch_5
    iget-object p0, p0, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    invoke-virtual {p0}, Landroid/support/v4/app/u;->getContext()Landroid/content/Context;

    const/high16 p0, 0x3f900000    # 1.125f

    invoke-static {p0, v3, p3, v3}, Landroid/support/v4/app/O;->a(FFFF)Landroid/support/v4/app/H;

    move-result-object p0

    return-object p0

    :goto_2
    check-cast p1, Landroid/support/v4/app/p;

    .line 28
    iget-object p1, p1, Landroid/support/v4/app/p;->n:Landroid/support/v4/app/r;

    invoke-virtual {p1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p1

    if-eqz p1, :cond_c

    goto :goto_3

    :cond_c
    move v1, v2

    :goto_3
    if-eqz v1, :cond_e

    .line 29
    iget-object p0, p0, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    check-cast p0, Landroid/support/v4/app/p;

    .line 30
    iget-object p0, p0, Landroid/support/v4/app/p;->n:Landroid/support/v4/app/r;

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p0

    if-nez p0, :cond_d

    goto :goto_4

    :cond_d
    invoke-virtual {p0}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    move-result-object p0

    iget p0, p0, Landroid/view/WindowManager$LayoutParams;->windowAnimations:I

    :cond_e
    :goto_4
    return-object v0

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public a(ILandroid/support/v4/app/e;)V
    .locals 3

    monitor-enter p0

    :try_start_0
    iget-object v0, p0, Landroid/support/v4/app/O;->mBackStackIndices:Ljava/util/ArrayList;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroid/support/v4/app/O;->mBackStackIndices:Ljava/util/ArrayList;

    :cond_0
    iget-object v0, p0, Landroid/support/v4/app/O;->mBackStackIndices:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge p1, v0, :cond_1

    iget-object v0, p0, Landroid/support/v4/app/O;->mBackStackIndices:Ljava/util/ArrayList;

    invoke-virtual {v0, p1, p2}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    goto :goto_1

    :cond_1
    :goto_0
    if-ge v0, p1, :cond_3

    iget-object v1, p0, Landroid/support/v4/app/O;->mBackStackIndices:Ljava/util/ArrayList;

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v1, p0, Landroid/support/v4/app/O;->mAvailBackStackIndices:Ljava/util/ArrayList;

    if-nez v1, :cond_2

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, Landroid/support/v4/app/O;->mAvailBackStackIndices:Ljava/util/ArrayList;

    :cond_2
    iget-object v1, p0, Landroid/support/v4/app/O;->mAvailBackStackIndices:Ljava/util/ArrayList;

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_3
    iget-object p1, p0, Landroid/support/v4/app/O;->mBackStackIndices:Ljava/util/ArrayList;

    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_1
    monitor-exit p0

    return-void

    :catchall_0
    move-exception p1

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method

.method a(Landroid/os/Parcelable;Landroid/support/v4/app/P;)V
    .locals 13

    if-nez p1, :cond_0

    return-void

    :cond_0
    check-cast p1, Landroid/support/v4/app/FragmentManagerState;

    iget-object v0, p1, Landroid/support/v4/app/FragmentManagerState;->mActive:[Landroid/support/v4/app/FragmentState;

    if-nez v0, :cond_1

    return-void

    :cond_1
    const/4 v0, 0x0

    const/4 v1, 0x0

    if-eqz p2, :cond_6

    invoke-virtual {p2}, Landroid/support/v4/app/P;->getFragments()Ljava/util/List;

    move-result-object v2

    invoke-virtual {p2}, Landroid/support/v4/app/P;->getChildNonConfigs()Ljava/util/List;

    move-result-object v3

    invoke-virtual {p2}, Landroid/support/v4/app/P;->ta()Ljava/util/List;

    move-result-object v4

    if-eqz v2, :cond_2

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v5

    goto :goto_0

    :cond_2
    move v5, v1

    :goto_0
    move v6, v1

    :goto_1
    if-ge v6, v5, :cond_7

    invoke-interface {v2, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Landroid/support/v4/app/n;

    move v8, v1

    :goto_2
    iget-object v9, p1, Landroid/support/v4/app/FragmentManagerState;->mActive:[Landroid/support/v4/app/FragmentState;

    array-length v10, v9

    if-ge v8, v10, :cond_3

    aget-object v9, v9, v8

    iget v9, v9, Landroid/support/v4/app/FragmentState;->mIndex:I

    iget v10, v7, Landroid/support/v4/app/n;->mIndex:I

    if-eq v9, v10, :cond_3

    add-int/lit8 v8, v8, 0x1

    goto :goto_2

    :cond_3
    iget-object v9, p1, Landroid/support/v4/app/FragmentManagerState;->mActive:[Landroid/support/v4/app/FragmentState;

    array-length v10, v9

    if-eq v8, v10, :cond_5

    aget-object v8, v9, v8

    iput-object v7, v8, Landroid/support/v4/app/FragmentState;->mInstance:Landroid/support/v4/app/n;

    iput-object v0, v7, Landroid/support/v4/app/n;->mSavedViewState:Landroid/util/SparseArray;

    iput v1, v7, Landroid/support/v4/app/n;->mBackStackNesting:I

    iput-boolean v1, v7, Landroid/support/v4/app/n;->mInLayout:Z

    iput-boolean v1, v7, Landroid/support/v4/app/n;->mAdded:Z

    iput-object v0, v7, Landroid/support/v4/app/n;->mTarget:Landroid/support/v4/app/n;

    iget-object v9, v8, Landroid/support/v4/app/FragmentState;->mSavedFragmentState:Landroid/os/Bundle;

    if-eqz v9, :cond_4

    iget-object v10, p0, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    invoke-virtual {v10}, Landroid/support/v4/app/u;->getContext()Landroid/content/Context;

    move-result-object v10

    invoke-virtual {v10}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v10

    invoke-virtual {v9, v10}, Landroid/os/Bundle;->setClassLoader(Ljava/lang/ClassLoader;)V

    iget-object v9, v8, Landroid/support/v4/app/FragmentState;->mSavedFragmentState:Landroid/os/Bundle;

    const-string v10, "android:view_state"

    invoke-virtual {v9, v10}, Landroid/os/Bundle;->getSparseParcelableArray(Ljava/lang/String;)Landroid/util/SparseArray;

    move-result-object v9

    iput-object v9, v7, Landroid/support/v4/app/n;->mSavedViewState:Landroid/util/SparseArray;

    iget-object v8, v8, Landroid/support/v4/app/FragmentState;->mSavedFragmentState:Landroid/os/Bundle;

    iput-object v8, v7, Landroid/support/v4/app/n;->mSavedFragmentState:Landroid/os/Bundle;

    :cond_4
    add-int/lit8 v6, v6, 0x1

    goto :goto_1

    :cond_5
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "Could not find active fragment with index "

    invoke-static {p2}, Lb/a/a/a/a;->x(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    iget v1, v7, Landroid/support/v4/app/n;->mIndex:I

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    invoke-direct {p0, p1}, Landroid/support/v4/app/O;->a(Ljava/lang/RuntimeException;)V

    throw v0

    :cond_6
    move-object v3, v0

    move-object v4, v3

    :cond_7
    new-instance v2, Landroid/util/SparseArray;

    iget-object v5, p1, Landroid/support/v4/app/FragmentManagerState;->mActive:[Landroid/support/v4/app/FragmentState;

    array-length v5, v5

    invoke-direct {v2, v5}, Landroid/util/SparseArray;-><init>(I)V

    iput-object v2, p0, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    move v2, v1

    :goto_3
    iget-object v5, p1, Landroid/support/v4/app/FragmentManagerState;->mActive:[Landroid/support/v4/app/FragmentState;

    array-length v6, v5

    if-ge v2, v6, :cond_b

    aget-object v5, v5, v2

    if-eqz v5, :cond_a

    if-eqz v3, :cond_8

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v6

    if-ge v2, v6, :cond_8

    invoke-interface {v3, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroid/support/v4/app/P;

    move-object v11, v6

    goto :goto_4

    :cond_8
    move-object v11, v0

    :goto_4
    if-eqz v4, :cond_9

    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v6

    if-ge v2, v6, :cond_9

    invoke-interface {v4, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroid/arch/lifecycle/r;

    move-object v12, v6

    goto :goto_5

    :cond_9
    move-object v12, v0

    :goto_5
    iget-object v8, p0, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    iget-object v9, p0, Landroid/support/v4/app/O;->mContainer:Landroid/support/v4/app/s;

    iget-object v10, p0, Landroid/support/v4/app/O;->mParent:Landroid/support/v4/app/n;

    move-object v7, v5

    invoke-virtual/range {v7 .. v12}, Landroid/support/v4/app/FragmentState;->a(Landroid/support/v4/app/u;Landroid/support/v4/app/s;Landroid/support/v4/app/n;Landroid/support/v4/app/P;Landroid/arch/lifecycle/r;)Landroid/support/v4/app/n;

    move-result-object v6

    iget-object v7, p0, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    iget v8, v6, Landroid/support/v4/app/n;->mIndex:I

    invoke-virtual {v7, v8, v6}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    iput-object v0, v5, Landroid/support/v4/app/FragmentState;->mInstance:Landroid/support/v4/app/n;

    :cond_a
    add-int/lit8 v2, v2, 0x1

    goto :goto_3

    :cond_b
    if-eqz p2, :cond_e

    invoke-virtual {p2}, Landroid/support/v4/app/P;->getFragments()Ljava/util/List;

    move-result-object p2

    if-eqz p2, :cond_c

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v2

    goto :goto_6

    :cond_c
    move v2, v1

    :goto_6
    move v3, v1

    :goto_7
    if-ge v3, v2, :cond_e

    invoke-interface {p2, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/support/v4/app/n;

    iget v5, v4, Landroid/support/v4/app/n;->mTargetIndex:I

    if-ltz v5, :cond_d

    iget-object v6, p0, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    invoke-virtual {v6, v5}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/support/v4/app/n;

    iput-object v5, v4, Landroid/support/v4/app/n;->mTarget:Landroid/support/v4/app/n;

    iget-object v5, v4, Landroid/support/v4/app/n;->mTarget:Landroid/support/v4/app/n;

    if-nez v5, :cond_d

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "Re-attaching retained fragment "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v6, " target no longer exists: "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v4, v4, Landroid/support/v4/app/n;->mTargetIndex:I

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const-string v5, "FragmentManager"

    invoke-static {v5, v4}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    :cond_d
    add-int/lit8 v3, v3, 0x1

    goto :goto_7

    :cond_e
    iget-object p2, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {p2}, Ljava/util/ArrayList;->clear()V

    iget-object p2, p1, Landroid/support/v4/app/FragmentManagerState;->mAdded:[I

    if-eqz p2, :cond_11

    move p2, v1

    :goto_8
    iget-object v2, p1, Landroid/support/v4/app/FragmentManagerState;->mAdded:[I

    array-length v3, v2

    if-ge p2, v3, :cond_11

    iget-object v3, p0, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    aget v2, v2, p2

    invoke-virtual {v3, v2}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/support/v4/app/n;

    if-eqz v2, :cond_10

    const/4 v3, 0x1

    iput-boolean v3, v2, Landroid/support/v4/app/n;->mAdded:Z

    iget-object v3, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_f

    iget-object v3, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    monitor-enter v3

    :try_start_0
    iget-object v4, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    monitor-exit v3

    add-int/lit8 p2, p2, 0x1

    goto :goto_8

    :catchall_0
    move-exception p0

    monitor-exit v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p0

    :cond_f
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "Already added!"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_10
    new-instance v1, Ljava/lang/IllegalStateException;

    const-string v2, "No instantiated fragment for index #"

    invoke-static {v2}, Lb/a/a/a/a;->x(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object p1, p1, Landroid/support/v4/app/FragmentManagerState;->mAdded:[I

    aget p1, p1, p2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v1, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    invoke-direct {p0, v1}, Landroid/support/v4/app/O;->a(Ljava/lang/RuntimeException;)V

    throw v0

    :cond_11
    iget-object p2, p1, Landroid/support/v4/app/FragmentManagerState;->mBackStack:[Landroid/support/v4/app/BackStackState;

    if-eqz p2, :cond_13

    new-instance v0, Ljava/util/ArrayList;

    array-length p2, p2

    invoke-direct {v0, p2}, Ljava/util/ArrayList;-><init>(I)V

    iput-object v0, p0, Landroid/support/v4/app/O;->mBackStack:Ljava/util/ArrayList;

    :goto_9
    iget-object p2, p1, Landroid/support/v4/app/FragmentManagerState;->mBackStack:[Landroid/support/v4/app/BackStackState;

    array-length v0, p2

    if-ge v1, v0, :cond_14

    aget-object p2, p2, v1

    invoke-virtual {p2, p0}, Landroid/support/v4/app/BackStackState;->a(Landroid/support/v4/app/O;)Landroid/support/v4/app/e;

    move-result-object p2

    iget-object v0, p0, Landroid/support/v4/app/O;->mBackStack:Ljava/util/ArrayList;

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget v0, p2, Landroid/support/v4/app/e;->mIndex:I

    if-ltz v0, :cond_12

    invoke-virtual {p0, v0, p2}, Landroid/support/v4/app/O;->a(ILandroid/support/v4/app/e;)V

    :cond_12
    add-int/lit8 v1, v1, 0x1

    goto :goto_9

    :cond_13
    iput-object v0, p0, Landroid/support/v4/app/O;->mBackStack:Ljava/util/ArrayList;

    :cond_14
    iget p2, p1, Landroid/support/v4/app/FragmentManagerState;->mPrimaryNavActiveIndex:I

    if-ltz p2, :cond_15

    iget-object v0, p0, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    invoke-virtual {v0, p2}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Landroid/support/v4/app/n;

    iput-object p2, p0, Landroid/support/v4/app/O;->mPrimaryNav:Landroid/support/v4/app/n;

    :cond_15
    iget p1, p1, Landroid/support/v4/app/FragmentManagerState;->mNextFragmentIndex:I

    iput p1, p0, Landroid/support/v4/app/O;->mNextFragmentIndex:I

    return-void
.end method

.method a(Landroid/support/v4/app/n;IIIZ)V
    .locals 16

    move-object/from16 v6, p0

    move-object/from16 v7, p1

    iget-boolean v0, v7, Landroid/support/v4/app/n;->mAdded:Z

    const/4 v8, 0x1

    if-eqz v0, :cond_1

    iget-boolean v0, v7, Landroid/support/v4/app/n;->mDetached:Z

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    move/from16 v0, p2

    goto :goto_1

    :cond_1
    :goto_0
    move/from16 v0, p2

    if-le v0, v8, :cond_2

    move v0, v8

    :cond_2
    :goto_1
    iget-boolean v1, v7, Landroid/support/v4/app/n;->mRemoving:Z

    if-eqz v1, :cond_4

    iget v1, v7, Landroid/support/v4/app/n;->mState:I

    if-le v0, v1, :cond_4

    if-nez v1, :cond_3

    invoke-virtual/range {p1 .. p1}, Landroid/support/v4/app/n;->isInBackStack()Z

    move-result v0

    if-eqz v0, :cond_3

    move v0, v8

    goto :goto_2

    :cond_3
    iget v0, v7, Landroid/support/v4/app/n;->mState:I

    :cond_4
    :goto_2
    iget-boolean v1, v7, Landroid/support/v4/app/n;->mDeferStart:Z

    const/4 v9, 0x4

    const/4 v10, 0x3

    if-eqz v1, :cond_5

    iget v1, v7, Landroid/support/v4/app/n;->mState:I

    if-ge v1, v9, :cond_5

    if-le v0, v10, :cond_5

    move v11, v10

    goto :goto_3

    :cond_5
    move v11, v0

    :goto_3
    iget v0, v7, Landroid/support/v4/app/n;->mState:I

    const/4 v12, -0x1

    const-string v13, "Fragment "

    const/4 v14, 0x0

    const/4 v15, 0x2

    const/4 v1, 0x0

    if-gt v0, v11, :cond_34

    iget-boolean v0, v7, Landroid/support/v4/app/n;->mFromLayout:Z

    if-eqz v0, :cond_6

    iget-boolean v0, v7, Landroid/support/v4/app/n;->mInLayout:Z

    if-nez v0, :cond_6

    return-void

    :cond_6
    invoke-virtual/range {p1 .. p1}, Landroid/support/v4/app/n;->getAnimatingAway()Landroid/view/View;

    move-result-object v0

    if-nez v0, :cond_7

    invoke-virtual/range {p1 .. p1}, Landroid/support/v4/app/n;->getAnimator()Landroid/animation/Animator;

    move-result-object v0

    if-eqz v0, :cond_8

    :cond_7
    invoke-virtual {v7, v1}, Landroid/support/v4/app/n;->i(Landroid/view/View;)V

    invoke-virtual {v7, v1}, Landroid/support/v4/app/n;->a(Landroid/animation/Animator;)V

    invoke-virtual/range {p1 .. p1}, Landroid/support/v4/app/n;->getStateAfterAnimating()I

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual/range {v0 .. v5}, Landroid/support/v4/app/O;->a(Landroid/support/v4/app/n;IIIZ)V

    :cond_8
    iget v0, v7, Landroid/support/v4/app/n;->mState:I

    if-eqz v0, :cond_c

    if-eq v0, v8, :cond_1f

    if-eq v0, v15, :cond_b

    if-eq v0, v10, :cond_a

    if-eq v0, v9, :cond_9

    goto/16 :goto_1c

    :cond_9
    const/4 v0, 0x0

    goto/16 :goto_14

    :cond_a
    const/4 v0, 0x0

    goto/16 :goto_13

    :cond_b
    const/4 v0, 0x0

    goto/16 :goto_12

    :cond_c
    if-lez v11, :cond_1f

    iget-object v0, v7, Landroid/support/v4/app/n;->mSavedFragmentState:Landroid/os/Bundle;

    if-eqz v0, :cond_11

    iget-object v1, v6, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    invoke-virtual {v1}, Landroid/support/v4/app/u;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/os/Bundle;->setClassLoader(Ljava/lang/ClassLoader;)V

    iget-object v0, v7, Landroid/support/v4/app/n;->mSavedFragmentState:Landroid/os/Bundle;

    const-string v1, "android:view_state"

    invoke-virtual {v0, v1}, Landroid/os/Bundle;->getSparseParcelableArray(Ljava/lang/String;)Landroid/util/SparseArray;

    move-result-object v0

    iput-object v0, v7, Landroid/support/v4/app/n;->mSavedViewState:Landroid/util/SparseArray;

    iget-object v0, v7, Landroid/support/v4/app/n;->mSavedFragmentState:Landroid/os/Bundle;

    const-string v1, "android:target_state"

    .line 31
    invoke-virtual {v0, v1, v12}, Landroid/os/Bundle;->getInt(Ljava/lang/String;I)I

    move-result v0

    if-ne v0, v12, :cond_d

    const/4 v0, 0x0

    goto :goto_4

    :cond_d
    iget-object v2, v6, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    invoke-virtual {v2, v0}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/support/v4/app/n;

    if-eqz v2, :cond_10

    move-object v0, v2

    .line 32
    :goto_4
    iput-object v0, v7, Landroid/support/v4/app/n;->mTarget:Landroid/support/v4/app/n;

    iget-object v0, v7, Landroid/support/v4/app/n;->mTarget:Landroid/support/v4/app/n;

    if-eqz v0, :cond_e

    iget-object v0, v7, Landroid/support/v4/app/n;->mSavedFragmentState:Landroid/os/Bundle;

    const-string v1, "android:target_req_state"

    invoke-virtual {v0, v1, v14}, Landroid/os/Bundle;->getInt(Ljava/lang/String;I)I

    move-result v0

    iput v0, v7, Landroid/support/v4/app/n;->mTargetRequestCode:I

    :cond_e
    iget-object v0, v7, Landroid/support/v4/app/n;->Ge:Ljava/lang/Boolean;

    if-eqz v0, :cond_f

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    iput-boolean v0, v7, Landroid/support/v4/app/n;->mUserVisibleHint:Z

    const/4 v0, 0x0

    iput-object v0, v7, Landroid/support/v4/app/n;->Ge:Ljava/lang/Boolean;

    goto :goto_5

    :cond_f
    const/4 v0, 0x0

    iget-object v1, v7, Landroid/support/v4/app/n;->mSavedFragmentState:Landroid/os/Bundle;

    const-string v2, "android:user_visible_hint"

    invoke-virtual {v1, v2, v8}, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;Z)Z

    move-result v1

    iput-boolean v1, v7, Landroid/support/v4/app/n;->mUserVisibleHint:Z

    :goto_5
    iget-boolean v1, v7, Landroid/support/v4/app/n;->mUserVisibleHint:Z

    if-nez v1, :cond_12

    iput-boolean v8, v7, Landroid/support/v4/app/n;->mDeferStart:Z

    if-le v11, v10, :cond_12

    move-object v9, v0

    move v11, v10

    goto :goto_6

    :cond_10
    const/4 v2, 0x0

    .line 33
    new-instance v3, Ljava/lang/IllegalStateException;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Fragment no longer exists for key "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ": index "

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v3, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    invoke-direct {v6, v3}, Landroid/support/v4/app/O;->a(Ljava/lang/RuntimeException;)V

    throw v2

    :cond_11
    const/4 v0, 0x0

    :cond_12
    move-object v9, v0

    .line 34
    :goto_6
    iget-object v0, v6, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    iput-object v0, v7, Landroid/support/v4/app/n;->mHost:Landroid/support/v4/app/u;

    iget-object v1, v6, Landroid/support/v4/app/O;->mParent:Landroid/support/v4/app/n;

    iput-object v1, v7, Landroid/support/v4/app/n;->mParentFragment:Landroid/support/v4/app/n;

    if-eqz v1, :cond_13

    iget-object v0, v1, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    goto :goto_7

    .line 35
    :cond_13
    iget-object v0, v0, Landroid/support/v4/app/u;->mFragmentManager:Landroid/support/v4/app/O;

    .line 36
    :goto_7
    iput-object v0, v7, Landroid/support/v4/app/n;->mFragmentManager:Landroid/support/v4/app/O;

    iget-object v0, v7, Landroid/support/v4/app/n;->mTarget:Landroid/support/v4/app/n;

    if-eqz v0, :cond_15

    iget-object v1, v6, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    iget v0, v0, Landroid/support/v4/app/n;->mIndex:I

    invoke-virtual {v1, v0}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    iget-object v1, v7, Landroid/support/v4/app/n;->mTarget:Landroid/support/v4/app/n;

    if-ne v0, v1, :cond_14

    iget v0, v1, Landroid/support/v4/app/n;->mState:I

    if-ge v0, v8, :cond_15

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    move-object/from16 v0, p0

    invoke-virtual/range {v0 .. v5}, Landroid/support/v4/app/O;->a(Landroid/support/v4/app/n;IIIZ)V

    goto :goto_8

    :cond_14
    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v2, " declared target fragment "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, v7, Landroid/support/v4/app/n;->mTarget:Landroid/support/v4/app/n;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v2, " that does not belong to this FragmentManager!"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_15
    :goto_8
    iget-object v0, v6, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    invoke-virtual {v0}, Landroid/support/v4/app/u;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v6, v7, v0, v14}, Landroid/support/v4/app/O;->b(Landroid/support/v4/app/n;Landroid/content/Context;Z)V

    iput-boolean v14, v7, Landroid/support/v4/app/n;->mCalled:Z

    iget-object v0, v6, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    invoke-virtual {v0}, Landroid/support/v4/app/u;->getContext()Landroid/content/Context;

    .line 37
    iput-boolean v8, v7, Landroid/support/v4/app/n;->mCalled:Z

    iget-object v0, v7, Landroid/support/v4/app/n;->mHost:Landroid/support/v4/app/u;

    if-nez v0, :cond_16

    move-object v0, v9

    goto :goto_9

    :cond_16
    invoke-virtual {v0}, Landroid/support/v4/app/u;->getActivity()Landroid/app/Activity;

    move-result-object v0

    :goto_9
    if-eqz v0, :cond_17

    iput-boolean v14, v7, Landroid/support/v4/app/n;->mCalled:Z

    .line 38
    iput-boolean v8, v7, Landroid/support/v4/app/n;->mCalled:Z

    .line 39
    :cond_17
    iget-boolean v0, v7, Landroid/support/v4/app/n;->mCalled:Z

    if-eqz v0, :cond_1e

    iget-object v0, v7, Landroid/support/v4/app/n;->mParentFragment:Landroid/support/v4/app/n;

    if-nez v0, :cond_18

    iget-object v0, v6, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    check-cast v0, Landroid/support/v4/app/p;

    .line 40
    iget-object v0, v0, Landroid/support/v4/app/p;->n:Landroid/support/v4/app/r;

    invoke-virtual {v0, v7}, Landroid/support/v4/app/r;->a(Landroid/support/v4/app/n;)V

    .line 41
    :cond_18
    iget-object v0, v6, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    invoke-virtual {v0}, Landroid/support/v4/app/u;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v6, v7, v0, v14}, Landroid/support/v4/app/O;->a(Landroid/support/v4/app/n;Landroid/content/Context;Z)V

    iget-boolean v0, v7, Landroid/support/v4/app/n;->mIsCreated:Z

    if-nez v0, :cond_1d

    iget-object v0, v7, Landroid/support/v4/app/n;->mSavedFragmentState:Landroid/os/Bundle;

    invoke-virtual {v6, v7, v0, v14}, Landroid/support/v4/app/O;->c(Landroid/support/v4/app/n;Landroid/os/Bundle;Z)V

    iget-object v0, v7, Landroid/support/v4/app/n;->mSavedFragmentState:Landroid/os/Bundle;

    .line 42
    iget-object v1, v7, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    if-eqz v1, :cond_19

    invoke-virtual {v1}, Landroid/support/v4/app/O;->noteStateNotSaved()V

    :cond_19
    iput v8, v7, Landroid/support/v4/app/n;->mState:I

    iput-boolean v14, v7, Landroid/support/v4/app/n;->mCalled:Z

    .line 43
    iput-boolean v8, v7, Landroid/support/v4/app/n;->mCalled:Z

    invoke-virtual {v7, v0}, Landroid/support/v4/app/n;->a(Landroid/os/Bundle;)V

    iget-object v0, v7, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    if-eqz v0, :cond_1b

    .line 44
    iget v0, v0, Landroid/support/v4/app/O;->mCurState:I

    if-lt v0, v8, :cond_1a

    move v0, v8

    goto :goto_a

    :cond_1a
    move v0, v14

    :goto_a
    if-nez v0, :cond_1b

    .line 45
    iget-object v0, v7, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    invoke-virtual {v0}, Landroid/support/v4/app/O;->dispatchCreate()V

    .line 46
    :cond_1b
    iput-boolean v8, v7, Landroid/support/v4/app/n;->mIsCreated:Z

    iget-boolean v0, v7, Landroid/support/v4/app/n;->mCalled:Z

    if-eqz v0, :cond_1c

    iget-object v0, v7, Landroid/support/v4/app/n;->ad:Landroid/arch/lifecycle/g;

    sget-object v1, Landroid/arch/lifecycle/Lifecycle$Event;->ON_CREATE:Landroid/arch/lifecycle/Lifecycle$Event;

    invoke-virtual {v0, v1}, Landroid/arch/lifecycle/g;->b(Landroid/arch/lifecycle/Lifecycle$Event;)V

    .line 47
    iget-object v0, v7, Landroid/support/v4/app/n;->mSavedFragmentState:Landroid/os/Bundle;

    invoke-virtual {v6, v7, v0, v14}, Landroid/support/v4/app/O;->b(Landroid/support/v4/app/n;Landroid/os/Bundle;Z)V

    goto :goto_b

    .line 48
    :cond_1c
    new-instance v0, Landroid/support/v4/app/SuperNotCalledException;

    const-string v1, " did not call through to super.onCreate()"

    invoke-static {v13, v7, v1}, Lb/a/a/a/a;->a(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/support/v4/app/SuperNotCalledException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 49
    :cond_1d
    iget-object v0, v7, Landroid/support/v4/app/n;->mSavedFragmentState:Landroid/os/Bundle;

    invoke-virtual {v7, v0}, Landroid/support/v4/app/n;->a(Landroid/os/Bundle;)V

    iput v8, v7, Landroid/support/v4/app/n;->mState:I

    :goto_b
    iput-boolean v14, v7, Landroid/support/v4/app/n;->mRetaining:Z

    move-object v0, v9

    goto :goto_c

    :cond_1e
    new-instance v0, Landroid/support/v4/app/SuperNotCalledException;

    const-string v1, " did not call through to super.onAttach()"

    invoke-static {v13, v7, v1}, Lb/a/a/a/a;->a(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/support/v4/app/SuperNotCalledException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1f
    const/4 v0, 0x0

    .line 50
    :goto_c
    iget-boolean v1, v7, Landroid/support/v4/app/n;->mFromLayout:Z

    const/16 v2, 0x8

    if-eqz v1, :cond_22

    iget-boolean v1, v7, Landroid/support/v4/app/n;->mPerformedCreateView:Z

    if-nez v1, :cond_22

    iget-object v1, v7, Landroid/support/v4/app/n;->mSavedFragmentState:Landroid/os/Bundle;

    invoke-virtual {v7, v1}, Landroid/support/v4/app/n;->performGetLayoutInflater(Landroid/os/Bundle;)Landroid/view/LayoutInflater;

    move-result-object v1

    iget-object v3, v7, Landroid/support/v4/app/n;->mSavedFragmentState:Landroid/os/Bundle;

    invoke-virtual {v7, v1, v0, v3}, Landroid/support/v4/app/n;->performCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)V

    iget-object v1, v7, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    if-eqz v1, :cond_21

    iput-object v1, v7, Landroid/support/v4/app/n;->He:Landroid/view/View;

    invoke-virtual {v1, v14}, Landroid/view/View;->setSaveFromParentEnabled(Z)V

    iget-boolean v1, v7, Landroid/support/v4/app/n;->mHidden:Z

    if-eqz v1, :cond_20

    iget-object v1, v7, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    :cond_20
    iget-object v1, v7, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    iget-object v3, v7, Landroid/support/v4/app/n;->mSavedFragmentState:Landroid/os/Bundle;

    invoke-virtual {v6, v7, v1, v3, v14}, Landroid/support/v4/app/O;->a(Landroid/support/v4/app/n;Landroid/view/View;Landroid/os/Bundle;Z)V

    goto :goto_d

    :cond_21
    iput-object v0, v7, Landroid/support/v4/app/n;->He:Landroid/view/View;

    :cond_22
    :goto_d
    if-le v11, v8, :cond_31

    .line 51
    iget-boolean v1, v7, Landroid/support/v4/app/n;->mFromLayout:Z

    if-nez v1, :cond_2c

    iget v1, v7, Landroid/support/v4/app/n;->mContainerId:I

    if-eqz v1, :cond_26

    if-eq v1, v12, :cond_25

    iget-object v3, v6, Landroid/support/v4/app/O;->mContainer:Landroid/support/v4/app/s;

    invoke-virtual {v3, v1}, Landroid/support/v4/app/s;->onFindViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/view/ViewGroup;

    if-nez v1, :cond_27

    iget-boolean v3, v7, Landroid/support/v4/app/n;->mRestored:Z

    if-nez v3, :cond_27

    .line 52
    :try_start_0
    iget-object v1, v7, Landroid/support/v4/app/n;->mHost:Landroid/support/v4/app/u;

    if-nez v1, :cond_23

    move-object v1, v0

    goto :goto_e

    :cond_23
    invoke-virtual {v1}, Landroid/support/v4/app/u;->getContext()Landroid/content/Context;

    move-result-object v1

    :goto_e
    if-eqz v1, :cond_24

    .line 53
    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    .line 54
    iget v2, v7, Landroid/support/v4/app/n;->mContainerId:I

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getResourceName(I)Ljava/lang/String;

    move-result-object v1

    goto :goto_f

    .line 55
    :cond_24
    new-instance v1, Ljava/lang/IllegalStateException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v3, " not attached to a context."

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1
    :try_end_0
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const-string v1, "unknown"

    .line 56
    :goto_f
    new-instance v2, Ljava/lang/IllegalArgumentException;

    const-string v3, "No view found for id 0x"

    invoke-static {v3}, Lb/a/a/a/a;->x(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget v4, v7, Landroid/support/v4/app/n;->mContainerId:I

    invoke-static {v4}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, " ("

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ") for fragment "

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v2, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    invoke-direct {v6, v2}, Landroid/support/v4/app/O;->a(Ljava/lang/RuntimeException;)V

    throw v0

    :cond_25
    new-instance v1, Ljava/lang/IllegalArgumentException;

    const-string v2, "Cannot create fragment "

    const-string v3, " for a container view with no id"

    invoke-static {v2, v7, v3}, Lb/a/a/a/a;->a(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    invoke-direct {v6, v1}, Landroid/support/v4/app/O;->a(Ljava/lang/RuntimeException;)V

    throw v0

    :cond_26
    move-object v1, v0

    :cond_27
    iput-object v1, v7, Landroid/support/v4/app/n;->mContainer:Landroid/view/ViewGroup;

    iget-object v3, v7, Landroid/support/v4/app/n;->mSavedFragmentState:Landroid/os/Bundle;

    invoke-virtual {v7, v3}, Landroid/support/v4/app/n;->performGetLayoutInflater(Landroid/os/Bundle;)Landroid/view/LayoutInflater;

    move-result-object v3

    iget-object v4, v7, Landroid/support/v4/app/n;->mSavedFragmentState:Landroid/os/Bundle;

    invoke-virtual {v7, v3, v1, v4}, Landroid/support/v4/app/n;->performCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)V

    iget-object v3, v7, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    if-eqz v3, :cond_2b

    iput-object v3, v7, Landroid/support/v4/app/n;->He:Landroid/view/View;

    invoke-virtual {v3, v14}, Landroid/view/View;->setSaveFromParentEnabled(Z)V

    if-eqz v1, :cond_28

    iget-object v3, v7, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    invoke-virtual {v1, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    :cond_28
    iget-boolean v1, v7, Landroid/support/v4/app/n;->mHidden:Z

    if-eqz v1, :cond_29

    iget-object v1, v7, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    :cond_29
    iget-object v1, v7, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    iget-object v2, v7, Landroid/support/v4/app/n;->mSavedFragmentState:Landroid/os/Bundle;

    invoke-virtual {v6, v7, v1, v2, v14}, Landroid/support/v4/app/O;->a(Landroid/support/v4/app/n;Landroid/view/View;Landroid/os/Bundle;Z)V

    iget-object v1, v7, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    invoke-virtual {v1}, Landroid/view/View;->getVisibility()I

    move-result v1

    if-nez v1, :cond_2a

    iget-object v1, v7, Landroid/support/v4/app/n;->mContainer:Landroid/view/ViewGroup;

    if-eqz v1, :cond_2a

    move v1, v8

    goto :goto_10

    :cond_2a
    move v1, v14

    :goto_10
    iput-boolean v1, v7, Landroid/support/v4/app/n;->mIsNewlyAdded:Z

    goto :goto_11

    :cond_2b
    iput-object v0, v7, Landroid/support/v4/app/n;->He:Landroid/view/View;

    :cond_2c
    :goto_11
    iget-object v1, v7, Landroid/support/v4/app/n;->mSavedFragmentState:Landroid/os/Bundle;

    .line 57
    iget-object v1, v7, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    if-eqz v1, :cond_2d

    invoke-virtual {v1}, Landroid/support/v4/app/O;->noteStateNotSaved()V

    :cond_2d
    iput v15, v7, Landroid/support/v4/app/n;->mState:I

    iput-boolean v14, v7, Landroid/support/v4/app/n;->mCalled:Z

    .line 58
    iput-boolean v8, v7, Landroid/support/v4/app/n;->mCalled:Z

    .line 59
    iget-boolean v1, v7, Landroid/support/v4/app/n;->mCalled:Z

    if-eqz v1, :cond_30

    iget-object v1, v7, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    if-eqz v1, :cond_2e

    invoke-virtual {v1}, Landroid/support/v4/app/O;->dispatchActivityCreated()V

    .line 60
    :cond_2e
    iget-object v1, v7, Landroid/support/v4/app/n;->mSavedFragmentState:Landroid/os/Bundle;

    invoke-virtual {v6, v7, v1, v14}, Landroid/support/v4/app/O;->a(Landroid/support/v4/app/n;Landroid/os/Bundle;Z)V

    iget-object v1, v7, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    if-eqz v1, :cond_2f

    iget-object v1, v7, Landroid/support/v4/app/n;->mSavedFragmentState:Landroid/os/Bundle;

    invoke-virtual {v7, v1}, Landroid/support/v4/app/n;->restoreViewState(Landroid/os/Bundle;)V

    :cond_2f
    iput-object v0, v7, Landroid/support/v4/app/n;->mSavedFragmentState:Landroid/os/Bundle;

    goto :goto_12

    .line 61
    :cond_30
    new-instance v0, Landroid/support/v4/app/SuperNotCalledException;

    const-string v1, " did not call through to super.onActivityCreated()"

    invoke-static {v13, v7, v1}, Lb/a/a/a/a;->a(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/support/v4/app/SuperNotCalledException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_31
    :goto_12
    if-le v11, v15, :cond_32

    .line 62
    iput v10, v7, Landroid/support/v4/app/n;->mState:I

    :cond_32
    :goto_13
    if-le v11, v10, :cond_33

    invoke-virtual/range {p1 .. p1}, Landroid/support/v4/app/n;->performStart()V

    invoke-virtual {v6, v7, v14}, Landroid/support/v4/app/O;->f(Landroid/support/v4/app/n;Z)V

    :cond_33
    const/4 v9, 0x4

    :goto_14
    if-le v11, v9, :cond_4f

    invoke-virtual/range {p1 .. p1}, Landroid/support/v4/app/n;->performResume()V

    invoke-virtual {v6, v7, v14}, Landroid/support/v4/app/O;->e(Landroid/support/v4/app/n;Z)V

    iput-object v0, v7, Landroid/support/v4/app/n;->mSavedFragmentState:Landroid/os/Bundle;

    iput-object v0, v7, Landroid/support/v4/app/n;->mSavedViewState:Landroid/util/SparseArray;

    goto/16 :goto_1c

    :cond_34
    if-le v0, v11, :cond_4f

    if-eq v0, v8, :cond_41

    if-eq v0, v15, :cond_3b

    if-eq v0, v10, :cond_39

    const/4 v2, 0x4

    if-eq v0, v2, :cond_36

    const/4 v3, 0x5

    if-eq v0, v3, :cond_35

    goto/16 :goto_1c

    :cond_35
    if-ge v11, v3, :cond_36

    invoke-virtual/range {p1 .. p1}, Landroid/support/v4/app/n;->performPause()V

    invoke-virtual {v6, v7, v14}, Landroid/support/v4/app/O;->d(Landroid/support/v4/app/n;Z)V

    :cond_36
    if-ge v11, v2, :cond_39

    .line 63
    iget-object v0, v7, Landroid/support/v4/app/n;->ad:Landroid/arch/lifecycle/g;

    sget-object v2, Landroid/arch/lifecycle/Lifecycle$Event;->ON_STOP:Landroid/arch/lifecycle/Lifecycle$Event;

    invoke-virtual {v0, v2}, Landroid/arch/lifecycle/g;->b(Landroid/arch/lifecycle/Lifecycle$Event;)V

    iget-object v0, v7, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    if-eqz v0, :cond_37

    invoke-virtual {v0}, Landroid/support/v4/app/O;->dispatchStop()V

    :cond_37
    iput v10, v7, Landroid/support/v4/app/n;->mState:I

    iput-boolean v14, v7, Landroid/support/v4/app/n;->mCalled:Z

    .line 64
    iput-boolean v8, v7, Landroid/support/v4/app/n;->mCalled:Z

    .line 65
    iget-boolean v0, v7, Landroid/support/v4/app/n;->mCalled:Z

    if-eqz v0, :cond_38

    .line 66
    invoke-virtual {v6, v7, v14}, Landroid/support/v4/app/O;->g(Landroid/support/v4/app/n;Z)V

    goto :goto_15

    .line 67
    :cond_38
    new-instance v0, Landroid/support/v4/app/SuperNotCalledException;

    const-string v1, " did not call through to super.onStop()"

    invoke-static {v13, v7, v1}, Lb/a/a/a/a;->a(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/support/v4/app/SuperNotCalledException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_39
    :goto_15
    if-ge v11, v10, :cond_3b

    .line 68
    iget-object v0, v7, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    if-eqz v0, :cond_3a

    .line 69
    invoke-direct {v0, v15}, Landroid/support/v4/app/O;->La(I)V

    .line 70
    :cond_3a
    iput v15, v7, Landroid/support/v4/app/n;->mState:I

    :cond_3b
    if-ge v11, v15, :cond_41

    .line 71
    iget-object v0, v7, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    if-eqz v0, :cond_3c

    iget-object v0, v6, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    check-cast v0, Landroid/support/v4/app/p;

    .line 72
    iget-object v0, v0, Landroid/support/v4/app/p;->n:Landroid/support/v4/app/r;

    invoke-virtual {v0}, Landroid/app/Activity;->isFinishing()Z

    move-result v0

    xor-int/2addr v0, v8

    if-eqz v0, :cond_3c

    .line 73
    iget-object v0, v7, Landroid/support/v4/app/n;->mSavedViewState:Landroid/util/SparseArray;

    if-nez v0, :cond_3c

    invoke-virtual/range {p0 .. p1}, Landroid/support/v4/app/O;->k(Landroid/support/v4/app/n;)V

    :cond_3c
    invoke-virtual/range {p1 .. p1}, Landroid/support/v4/app/n;->performDestroyView()V

    invoke-virtual {v6, v7, v14}, Landroid/support/v4/app/O;->h(Landroid/support/v4/app/n;Z)V

    iget-object v0, v7, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    if-eqz v0, :cond_40

    iget-object v2, v7, Landroid/support/v4/app/n;->mContainer:Landroid/view/ViewGroup;

    if-eqz v2, :cond_40

    invoke-virtual {v2, v0}, Landroid/view/ViewGroup;->endViewTransition(Landroid/view/View;)V

    iget-object v0, v7, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->clearAnimation()V

    iget v0, v6, Landroid/support/v4/app/O;->mCurState:I

    const/4 v2, 0x0

    if-lez v0, :cond_3d

    iget-boolean v0, v6, Landroid/support/v4/app/O;->mDestroyed:Z

    if-nez v0, :cond_3d

    iget-object v0, v7, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    if-nez v0, :cond_3d

    iget v0, v7, Landroid/support/v4/app/n;->Ie:F

    cmpl-float v0, v0, v2

    if-ltz v0, :cond_3d

    move/from16 v0, p3

    move/from16 v3, p4

    invoke-virtual {v6, v7, v0, v14, v3}, Landroid/support/v4/app/O;->a(Landroid/support/v4/app/n;IZI)Landroid/support/v4/app/H;

    move-result-object v0

    goto :goto_16

    :cond_3d
    move-object v0, v1

    :goto_16
    iput v2, v7, Landroid/support/v4/app/n;->Ie:F

    if-eqz v0, :cond_3f

    .line 74
    iget-object v2, v7, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    iget-object v3, v7, Landroid/support/v4/app/n;->mContainer:Landroid/view/ViewGroup;

    invoke-virtual {v3, v2}, Landroid/view/ViewGroup;->startViewTransition(Landroid/view/View;)V

    invoke-virtual {v7, v11}, Landroid/support/v4/app/n;->setStateAfterAnimating(I)V

    iget-object v4, v0, Landroid/support/v4/app/H;->animation:Landroid/view/animation/Animation;

    if-eqz v4, :cond_3e

    new-instance v5, Landroid/support/v4/app/J;

    invoke-direct {v5, v4, v3, v2}, Landroid/support/v4/app/J;-><init>(Landroid/view/animation/Animation;Landroid/view/ViewGroup;Landroid/view/View;)V

    iget-object v4, v7, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    invoke-virtual {v7, v4}, Landroid/support/v4/app/n;->i(Landroid/view/View;)V

    invoke-static {v5}, Landroid/support/v4/app/O;->a(Landroid/view/animation/Animation;)Landroid/view/animation/Animation$AnimationListener;

    move-result-object v4

    new-instance v9, Landroid/support/v4/app/B;

    invoke-direct {v9, v6, v4, v3, v7}, Landroid/support/v4/app/B;-><init>(Landroid/support/v4/app/O;Landroid/view/animation/Animation$AnimationListener;Landroid/view/ViewGroup;Landroid/support/v4/app/n;)V

    invoke-virtual {v5, v9}, Landroid/view/animation/Animation;->setAnimationListener(Landroid/view/animation/Animation$AnimationListener;)V

    invoke-static {v2, v0}, Landroid/support/v4/app/O;->a(Landroid/view/View;Landroid/support/v4/app/H;)V

    iget-object v0, v7, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    invoke-virtual {v0, v5}, Landroid/view/View;->startAnimation(Landroid/view/animation/Animation;)V

    goto :goto_17

    :cond_3e
    iget-object v4, v0, Landroid/support/v4/app/H;->animator:Landroid/animation/Animator;

    invoke-virtual {v7, v4}, Landroid/support/v4/app/n;->a(Landroid/animation/Animator;)V

    new-instance v5, Landroid/support/v4/app/C;

    invoke-direct {v5, v6, v3, v2, v7}, Landroid/support/v4/app/C;-><init>(Landroid/support/v4/app/O;Landroid/view/ViewGroup;Landroid/view/View;Landroid/support/v4/app/n;)V

    invoke-virtual {v4, v5}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    iget-object v2, v7, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    invoke-virtual {v4, v2}, Landroid/animation/Animator;->setTarget(Ljava/lang/Object;)V

    iget-object v2, v7, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    invoke-static {v2, v0}, Landroid/support/v4/app/O;->a(Landroid/view/View;Landroid/support/v4/app/H;)V

    invoke-virtual {v4}, Landroid/animation/Animator;->start()V

    .line 75
    :cond_3f
    :goto_17
    iget-object v0, v7, Landroid/support/v4/app/n;->mContainer:Landroid/view/ViewGroup;

    iget-object v2, v7, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    invoke-virtual {v0, v2}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_40
    iput-object v1, v7, Landroid/support/v4/app/n;->mContainer:Landroid/view/ViewGroup;

    iput-object v1, v7, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    iput-object v1, v7, Landroid/support/v4/app/n;->Ke:Landroid/arch/lifecycle/e;

    iget-object v0, v7, Landroid/support/v4/app/n;->Le:Landroid/arch/lifecycle/l;

    invoke-virtual {v0, v1}, Landroid/arch/lifecycle/l;->setValue(Ljava/lang/Object;)V

    iput-object v1, v7, Landroid/support/v4/app/n;->He:Landroid/view/View;

    iput-boolean v14, v7, Landroid/support/v4/app/n;->mInLayout:Z

    :cond_41
    if-ge v11, v8, :cond_4f

    iget-boolean v0, v6, Landroid/support/v4/app/O;->mDestroyed:Z

    if-eqz v0, :cond_43

    invoke-virtual/range {p1 .. p1}, Landroid/support/v4/app/n;->getAnimatingAway()Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_42

    invoke-virtual/range {p1 .. p1}, Landroid/support/v4/app/n;->getAnimatingAway()Landroid/view/View;

    move-result-object v0

    invoke-virtual {v7, v1}, Landroid/support/v4/app/n;->i(Landroid/view/View;)V

    invoke-virtual {v0}, Landroid/view/View;->clearAnimation()V

    goto :goto_18

    :cond_42
    invoke-virtual/range {p1 .. p1}, Landroid/support/v4/app/n;->getAnimator()Landroid/animation/Animator;

    move-result-object v0

    if-eqz v0, :cond_43

    invoke-virtual/range {p1 .. p1}, Landroid/support/v4/app/n;->getAnimator()Landroid/animation/Animator;

    move-result-object v0

    invoke-virtual {v7, v1}, Landroid/support/v4/app/n;->a(Landroid/animation/Animator;)V

    invoke-virtual {v0}, Landroid/animation/Animator;->cancel()V

    :cond_43
    :goto_18
    invoke-virtual/range {p1 .. p1}, Landroid/support/v4/app/n;->getAnimatingAway()Landroid/view/View;

    move-result-object v0

    if-nez v0, :cond_4e

    invoke-virtual/range {p1 .. p1}, Landroid/support/v4/app/n;->getAnimator()Landroid/animation/Animator;

    move-result-object v0

    if-eqz v0, :cond_44

    goto/16 :goto_1b

    :cond_44
    iget-boolean v0, v7, Landroid/support/v4/app/n;->mRetaining:Z

    if-nez v0, :cond_48

    .line 76
    iget-object v0, v7, Landroid/support/v4/app/n;->ad:Landroid/arch/lifecycle/g;

    sget-object v2, Landroid/arch/lifecycle/Lifecycle$Event;->ON_DESTROY:Landroid/arch/lifecycle/Lifecycle$Event;

    invoke-virtual {v0, v2}, Landroid/arch/lifecycle/g;->b(Landroid/arch/lifecycle/Lifecycle$Event;)V

    iget-object v0, v7, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    if-eqz v0, :cond_45

    invoke-virtual {v0}, Landroid/support/v4/app/O;->dispatchDestroy()V

    :cond_45
    iput v14, v7, Landroid/support/v4/app/n;->mState:I

    iput-boolean v14, v7, Landroid/support/v4/app/n;->mCalled:Z

    iput-boolean v14, v7, Landroid/support/v4/app/n;->mIsCreated:Z

    .line 77
    iput-boolean v8, v7, Landroid/support/v4/app/n;->mCalled:Z

    iget-object v0, v7, Landroid/support/v4/app/n;->Gc:Landroid/arch/lifecycle/r;

    if-eqz v0, :cond_46

    iget-object v2, v7, Landroid/support/v4/app/n;->mHost:Landroid/support/v4/app/u;

    iget-object v2, v2, Landroid/support/v4/app/u;->mFragmentManager:Landroid/support/v4/app/O;

    iget-boolean v2, v2, Landroid/support/v4/app/O;->mStateSaved:Z

    if-nez v2, :cond_46

    invoke-virtual {v0}, Landroid/arch/lifecycle/r;->clear()V

    .line 78
    :cond_46
    iget-boolean v0, v7, Landroid/support/v4/app/n;->mCalled:Z

    if-eqz v0, :cond_47

    iput-object v1, v7, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    .line 79
    invoke-virtual {v6, v7, v14}, Landroid/support/v4/app/O;->b(Landroid/support/v4/app/n;Z)V

    goto :goto_19

    .line 80
    :cond_47
    new-instance v0, Landroid/support/v4/app/SuperNotCalledException;

    const-string v1, " did not call through to super.onDestroy()"

    invoke-static {v13, v7, v1}, Lb/a/a/a/a;->a(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/support/v4/app/SuperNotCalledException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 81
    :cond_48
    iput v14, v7, Landroid/support/v4/app/n;->mState:I

    .line 82
    :goto_19
    iput-boolean v14, v7, Landroid/support/v4/app/n;->mCalled:Z

    .line 83
    iput-boolean v8, v7, Landroid/support/v4/app/n;->mCalled:Z

    .line 84
    iput-object v1, v7, Landroid/support/v4/app/n;->mLayoutInflater:Landroid/view/LayoutInflater;

    iget-boolean v0, v7, Landroid/support/v4/app/n;->mCalled:Z

    if-eqz v0, :cond_4d

    iget-object v0, v7, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    if-eqz v0, :cond_4a

    iget-boolean v2, v7, Landroid/support/v4/app/n;->mRetaining:Z

    if-eqz v2, :cond_49

    invoke-virtual {v0}, Landroid/support/v4/app/O;->dispatchDestroy()V

    iput-object v1, v7, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    goto :goto_1a

    :cond_49
    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Child FragmentManager of "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v2, " was not "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, " destroyed and this fragment is not retaining instance"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 85
    :cond_4a
    :goto_1a
    invoke-virtual {v6, v7, v14}, Landroid/support/v4/app/O;->c(Landroid/support/v4/app/n;Z)V

    if-nez p5, :cond_4f

    iget-boolean v0, v7, Landroid/support/v4/app/n;->mRetaining:Z

    if-nez v0, :cond_4c

    .line 86
    iget v0, v7, Landroid/support/v4/app/n;->mIndex:I

    if-gez v0, :cond_4b

    goto :goto_1c

    :cond_4b
    iget-object v2, v6, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    invoke-virtual {v2, v0, v1}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 87
    iput v12, v7, Landroid/support/v4/app/n;->mIndex:I

    iput-object v1, v7, Landroid/support/v4/app/n;->mWho:Ljava/lang/String;

    iput-boolean v14, v7, Landroid/support/v4/app/n;->mAdded:Z

    iput-boolean v14, v7, Landroid/support/v4/app/n;->mRemoving:Z

    iput-boolean v14, v7, Landroid/support/v4/app/n;->mFromLayout:Z

    iput-boolean v14, v7, Landroid/support/v4/app/n;->mInLayout:Z

    iput-boolean v14, v7, Landroid/support/v4/app/n;->mRestored:Z

    iput v14, v7, Landroid/support/v4/app/n;->mBackStackNesting:I

    iput-object v1, v7, Landroid/support/v4/app/n;->mFragmentManager:Landroid/support/v4/app/O;

    iput-object v1, v7, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    iput-object v1, v7, Landroid/support/v4/app/n;->mHost:Landroid/support/v4/app/u;

    iput v14, v7, Landroid/support/v4/app/n;->mFragmentId:I

    iput v14, v7, Landroid/support/v4/app/n;->mContainerId:I

    iput-object v1, v7, Landroid/support/v4/app/n;->mTag:Ljava/lang/String;

    iput-boolean v14, v7, Landroid/support/v4/app/n;->mHidden:Z

    iput-boolean v14, v7, Landroid/support/v4/app/n;->mDetached:Z

    iput-boolean v14, v7, Landroid/support/v4/app/n;->mRetaining:Z

    goto :goto_1c

    .line 88
    :cond_4c
    iput-object v1, v7, Landroid/support/v4/app/n;->mHost:Landroid/support/v4/app/u;

    iput-object v1, v7, Landroid/support/v4/app/n;->mParentFragment:Landroid/support/v4/app/n;

    iput-object v1, v7, Landroid/support/v4/app/n;->mFragmentManager:Landroid/support/v4/app/O;

    goto :goto_1c

    .line 89
    :cond_4d
    new-instance v0, Landroid/support/v4/app/SuperNotCalledException;

    const-string v1, " did not call through to super.onDetach()"

    invoke-static {v13, v7, v1}, Lb/a/a/a/a;->a(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/support/v4/app/SuperNotCalledException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 90
    :cond_4e
    :goto_1b
    invoke-virtual {v7, v11}, Landroid/support/v4/app/n;->setStateAfterAnimating(I)V

    goto :goto_1d

    :cond_4f
    :goto_1c
    move v8, v11

    :goto_1d
    iget v0, v7, Landroid/support/v4/app/n;->mState:I

    if-eq v0, v8, :cond_50

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "moveToState: Fragment state for "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, " not updated inline; "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "expected state "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " found "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, v7, Landroid/support/v4/app/n;->mState:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "FragmentManager"

    invoke-static {v1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    iput v8, v7, Landroid/support/v4/app/n;->mState:I

    :cond_50
    return-void
.end method

.method a(Landroid/support/v4/app/n;Landroid/content/Context;Z)V
    .locals 2

    iget-object v0, p0, Landroid/support/v4/app/O;->mParent:Landroid/support/v4/app/n;

    if-eqz v0, :cond_0

    .line 5
    iget-object v0, v0, Landroid/support/v4/app/n;->mFragmentManager:Landroid/support/v4/app/O;

    .line 6
    instance-of v1, v0, Landroid/support/v4/app/O;

    if-eqz v1, :cond_0

    const/4 v1, 0x1

    invoke-virtual {v0, p1, p2, v1}, Landroid/support/v4/app/O;->a(Landroid/support/v4/app/n;Landroid/content/Context;Z)V

    :cond_0
    iget-object p0, p0, Landroid/support/v4/app/O;->mLifecycleCallbacks:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/support/v4/app/K;

    if-eqz p3, :cond_1

    iget-boolean p2, p1, Landroid/support/v4/app/K;->Se:Z

    if-nez p2, :cond_1

    goto :goto_0

    :cond_1
    iget-object p0, p1, Landroid/support/v4/app/K;->mCallback:Landroid/support/v4/app/w;

    const/4 p0, 0x0

    throw p0

    :cond_2
    return-void
.end method

.method a(Landroid/support/v4/app/n;Landroid/os/Bundle;Z)V
    .locals 2

    iget-object v0, p0, Landroid/support/v4/app/O;->mParent:Landroid/support/v4/app/n;

    if-eqz v0, :cond_0

    .line 3
    iget-object v0, v0, Landroid/support/v4/app/n;->mFragmentManager:Landroid/support/v4/app/O;

    .line 4
    instance-of v1, v0, Landroid/support/v4/app/O;

    if-eqz v1, :cond_0

    const/4 v1, 0x1

    invoke-virtual {v0, p1, p2, v1}, Landroid/support/v4/app/O;->a(Landroid/support/v4/app/n;Landroid/os/Bundle;Z)V

    :cond_0
    iget-object p0, p0, Landroid/support/v4/app/O;->mLifecycleCallbacks:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/support/v4/app/K;

    if-eqz p3, :cond_1

    iget-boolean p2, p1, Landroid/support/v4/app/K;->Se:Z

    if-nez p2, :cond_1

    goto :goto_0

    :cond_1
    iget-object p0, p1, Landroid/support/v4/app/K;->mCallback:Landroid/support/v4/app/w;

    const/4 p0, 0x0

    throw p0

    :cond_2
    return-void
.end method

.method a(Landroid/support/v4/app/n;Landroid/view/View;Landroid/os/Bundle;Z)V
    .locals 2

    iget-object v0, p0, Landroid/support/v4/app/O;->mParent:Landroid/support/v4/app/n;

    if-eqz v0, :cond_0

    .line 7
    iget-object v0, v0, Landroid/support/v4/app/n;->mFragmentManager:Landroid/support/v4/app/O;

    .line 8
    instance-of v1, v0, Landroid/support/v4/app/O;

    if-eqz v1, :cond_0

    const/4 v1, 0x1

    invoke-virtual {v0, p1, p2, p3, v1}, Landroid/support/v4/app/O;->a(Landroid/support/v4/app/n;Landroid/view/View;Landroid/os/Bundle;Z)V

    :cond_0
    iget-object p0, p0, Landroid/support/v4/app/O;->mLifecycleCallbacks:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/support/v4/app/K;

    if-eqz p4, :cond_1

    iget-boolean p2, p1, Landroid/support/v4/app/K;->Se:Z

    if-nez p2, :cond_1

    goto :goto_0

    :cond_1
    iget-object p0, p1, Landroid/support/v4/app/K;->mCallback:Landroid/support/v4/app/w;

    const/4 p0, 0x0

    throw p0

    :cond_2
    return-void
.end method

.method public a(Landroid/support/v4/app/n;Z)V
    .locals 8

    invoke-virtual {p0, p1}, Landroid/support/v4/app/O;->h(Landroid/support/v4/app/n;)V

    iget-boolean v0, p1, Landroid/support/v4/app/n;->mDetached:Z

    if-nez v0, :cond_3

    iget-object v0, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    iget-object v0, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v0, 0x1

    iput-boolean v0, p1, Landroid/support/v4/app/n;->mAdded:Z

    const/4 v1, 0x0

    iput-boolean v1, p1, Landroid/support/v4/app/n;->mRemoving:Z

    iget-object v2, p1, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    if-nez v2, :cond_0

    iput-boolean v1, p1, Landroid/support/v4/app/n;->mHiddenChanged:Z

    :cond_0
    iget-boolean v1, p1, Landroid/support/v4/app/n;->mHasMenu:Z

    if-eqz v1, :cond_1

    iget-boolean v1, p1, Landroid/support/v4/app/n;->mMenuVisible:Z

    if-eqz v1, :cond_1

    iput-boolean v0, p0, Landroid/support/v4/app/O;->mNeedMenuInvalidate:Z

    :cond_1
    if-eqz p2, :cond_3

    .line 1
    iget v4, p0, Landroid/support/v4/app/O;->mCurState:I

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    move-object v2, p0

    move-object v3, p1

    invoke-virtual/range {v2 .. v7}, Landroid/support/v4/app/O;->a(Landroid/support/v4/app/n;IIIZ)V

    goto :goto_0

    :catchall_0
    move-exception p0

    .line 2
    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p0

    :cond_2
    new-instance p0, Ljava/lang/IllegalStateException;

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "Fragment already added: "

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_3
    :goto_0
    return-void
.end method

.method b(Landroid/support/v4/app/n;Landroid/content/Context;Z)V
    .locals 2

    iget-object v0, p0, Landroid/support/v4/app/O;->mParent:Landroid/support/v4/app/n;

    if-eqz v0, :cond_0

    .line 5
    iget-object v0, v0, Landroid/support/v4/app/n;->mFragmentManager:Landroid/support/v4/app/O;

    .line 6
    instance-of v1, v0, Landroid/support/v4/app/O;

    if-eqz v1, :cond_0

    const/4 v1, 0x1

    invoke-virtual {v0, p1, p2, v1}, Landroid/support/v4/app/O;->b(Landroid/support/v4/app/n;Landroid/content/Context;Z)V

    :cond_0
    iget-object p0, p0, Landroid/support/v4/app/O;->mLifecycleCallbacks:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/support/v4/app/K;

    if-eqz p3, :cond_1

    iget-boolean p2, p1, Landroid/support/v4/app/K;->Se:Z

    if-nez p2, :cond_1

    goto :goto_0

    :cond_1
    iget-object p0, p1, Landroid/support/v4/app/K;->mCallback:Landroid/support/v4/app/w;

    const/4 p0, 0x0

    throw p0

    :cond_2
    return-void
.end method

.method b(Landroid/support/v4/app/n;Landroid/os/Bundle;Z)V
    .locals 2

    iget-object v0, p0, Landroid/support/v4/app/O;->mParent:Landroid/support/v4/app/n;

    if-eqz v0, :cond_0

    .line 1
    iget-object v0, v0, Landroid/support/v4/app/n;->mFragmentManager:Landroid/support/v4/app/O;

    .line 2
    instance-of v1, v0, Landroid/support/v4/app/O;

    if-eqz v1, :cond_0

    const/4 v1, 0x1

    invoke-virtual {v0, p1, p2, v1}, Landroid/support/v4/app/O;->b(Landroid/support/v4/app/n;Landroid/os/Bundle;Z)V

    :cond_0
    iget-object p0, p0, Landroid/support/v4/app/O;->mLifecycleCallbacks:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/support/v4/app/K;

    if-eqz p3, :cond_1

    iget-boolean p2, p1, Landroid/support/v4/app/K;->Se:Z

    if-nez p2, :cond_1

    goto :goto_0

    :cond_1
    iget-object p0, p1, Landroid/support/v4/app/K;->mCallback:Landroid/support/v4/app/w;

    const/4 p0, 0x0

    throw p0

    :cond_2
    return-void
.end method

.method b(Landroid/support/v4/app/n;Z)V
    .locals 2

    iget-object v0, p0, Landroid/support/v4/app/O;->mParent:Landroid/support/v4/app/n;

    if-eqz v0, :cond_0

    .line 3
    iget-object v0, v0, Landroid/support/v4/app/n;->mFragmentManager:Landroid/support/v4/app/O;

    .line 4
    instance-of v1, v0, Landroid/support/v4/app/O;

    if-eqz v1, :cond_0

    const/4 v1, 0x1

    invoke-virtual {v0, p1, v1}, Landroid/support/v4/app/O;->b(Landroid/support/v4/app/n;Z)V

    :cond_0
    iget-object p0, p0, Landroid/support/v4/app/O;->mLifecycleCallbacks:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/support/v4/app/K;

    if-eqz p2, :cond_1

    iget-boolean v0, p1, Landroid/support/v4/app/K;->Se:Z

    if-nez v0, :cond_1

    goto :goto_0

    :cond_1
    iget-object p0, p1, Landroid/support/v4/app/K;->mCallback:Landroid/support/v4/app/w;

    const/4 p0, 0x0

    throw p0

    :cond_2
    return-void
.end method

.method c(Landroid/support/v4/app/n;Landroid/os/Bundle;Z)V
    .locals 2

    iget-object v0, p0, Landroid/support/v4/app/O;->mParent:Landroid/support/v4/app/n;

    if-eqz v0, :cond_0

    .line 3
    iget-object v0, v0, Landroid/support/v4/app/n;->mFragmentManager:Landroid/support/v4/app/O;

    .line 4
    instance-of v1, v0, Landroid/support/v4/app/O;

    if-eqz v1, :cond_0

    const/4 v1, 0x1

    invoke-virtual {v0, p1, p2, v1}, Landroid/support/v4/app/O;->c(Landroid/support/v4/app/n;Landroid/os/Bundle;Z)V

    :cond_0
    iget-object p0, p0, Landroid/support/v4/app/O;->mLifecycleCallbacks:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/support/v4/app/K;

    if-eqz p3, :cond_1

    iget-boolean p2, p1, Landroid/support/v4/app/K;->Se:Z

    if-nez p2, :cond_1

    goto :goto_0

    :cond_1
    iget-object p0, p1, Landroid/support/v4/app/K;->mCallback:Landroid/support/v4/app/w;

    const/4 p0, 0x0

    throw p0

    :cond_2
    return-void
.end method

.method c(Landroid/support/v4/app/n;Z)V
    .locals 2

    iget-object v0, p0, Landroid/support/v4/app/O;->mParent:Landroid/support/v4/app/n;

    if-eqz v0, :cond_0

    .line 1
    iget-object v0, v0, Landroid/support/v4/app/n;->mFragmentManager:Landroid/support/v4/app/O;

    .line 2
    instance-of v1, v0, Landroid/support/v4/app/O;

    if-eqz v1, :cond_0

    const/4 v1, 0x1

    invoke-virtual {v0, p1, v1}, Landroid/support/v4/app/O;->c(Landroid/support/v4/app/n;Z)V

    :cond_0
    iget-object p0, p0, Landroid/support/v4/app/O;->mLifecycleCallbacks:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/support/v4/app/K;

    if-eqz p2, :cond_1

    iget-boolean v0, p1, Landroid/support/v4/app/K;->Se:Z

    if-nez v0, :cond_1

    goto :goto_0

    :cond_1
    iget-object p0, p1, Landroid/support/v4/app/K;->mCallback:Landroid/support/v4/app/w;

    const/4 p0, 0x0

    throw p0

    :cond_2
    return-void
.end method

.method d(Landroid/support/v4/app/n;Landroid/os/Bundle;Z)V
    .locals 2

    iget-object v0, p0, Landroid/support/v4/app/O;->mParent:Landroid/support/v4/app/n;

    if-eqz v0, :cond_0

    .line 3
    iget-object v0, v0, Landroid/support/v4/app/n;->mFragmentManager:Landroid/support/v4/app/O;

    .line 4
    instance-of v1, v0, Landroid/support/v4/app/O;

    if-eqz v1, :cond_0

    const/4 v1, 0x1

    invoke-virtual {v0, p1, p2, v1}, Landroid/support/v4/app/O;->d(Landroid/support/v4/app/n;Landroid/os/Bundle;Z)V

    :cond_0
    iget-object p0, p0, Landroid/support/v4/app/O;->mLifecycleCallbacks:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/support/v4/app/K;

    if-eqz p3, :cond_1

    iget-boolean p2, p1, Landroid/support/v4/app/K;->Se:Z

    if-nez p2, :cond_1

    goto :goto_0

    :cond_1
    iget-object p0, p1, Landroid/support/v4/app/K;->mCallback:Landroid/support/v4/app/w;

    const/4 p0, 0x0

    throw p0

    :cond_2
    return-void
.end method

.method d(Landroid/support/v4/app/n;Z)V
    .locals 2

    iget-object v0, p0, Landroid/support/v4/app/O;->mParent:Landroid/support/v4/app/n;

    if-eqz v0, :cond_0

    .line 1
    iget-object v0, v0, Landroid/support/v4/app/n;->mFragmentManager:Landroid/support/v4/app/O;

    .line 2
    instance-of v1, v0, Landroid/support/v4/app/O;

    if-eqz v1, :cond_0

    const/4 v1, 0x1

    invoke-virtual {v0, p1, v1}, Landroid/support/v4/app/O;->d(Landroid/support/v4/app/n;Z)V

    :cond_0
    iget-object p0, p0, Landroid/support/v4/app/O;->mLifecycleCallbacks:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/support/v4/app/K;

    if-eqz p2, :cond_1

    iget-boolean v0, p1, Landroid/support/v4/app/K;->Se:Z

    if-nez v0, :cond_1

    goto :goto_0

    :cond_1
    iget-object p0, p1, Landroid/support/v4/app/K;->mCallback:Landroid/support/v4/app/w;

    const/4 p0, 0x0

    throw p0

    :cond_2
    return-void
.end method

.method public dispatchActivityCreated()V
    .locals 1

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/support/v4/app/O;->mStateSaved:Z

    iput-boolean v0, p0, Landroid/support/v4/app/O;->mStopped:Z

    const/4 v0, 0x2

    invoke-direct {p0, v0}, Landroid/support/v4/app/O;->La(I)V

    return-void
.end method

.method public dispatchConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 2

    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    iget-object v1, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/support/v4/app/n;

    if-eqz v1, :cond_0

    invoke-virtual {v1, p1}, Landroid/support/v4/app/n;->performConfigurationChanged(Landroid/content/res/Configuration;)V

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method public dispatchContextItemSelected(Landroid/view/MenuItem;)Z
    .locals 4

    iget v0, p0, Landroid/support/v4/app/O;->mCurState:I

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-ge v0, v2, :cond_0

    return v1

    :cond_0
    move v0, v1

    :goto_0
    iget-object v3, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v0, v3, :cond_2

    iget-object v3, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/support/v4/app/n;

    if-eqz v3, :cond_1

    invoke-virtual {v3, p1}, Landroid/support/v4/app/n;->performContextItemSelected(Landroid/view/MenuItem;)Z

    move-result v3

    if-eqz v3, :cond_1

    return v2

    :cond_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_2
    return v1
.end method

.method public dispatchCreate()V
    .locals 1

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/support/v4/app/O;->mStateSaved:Z

    iput-boolean v0, p0, Landroid/support/v4/app/O;->mStopped:Z

    const/4 v0, 0x1

    invoke-direct {p0, v0}, Landroid/support/v4/app/O;->La(I)V

    return-void
.end method

.method public dispatchCreateOptionsMenu(Landroid/view/Menu;Landroid/view/MenuInflater;)Z
    .locals 7

    iget v0, p0, Landroid/support/v4/app/O;->mCurState:I

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-ge v0, v2, :cond_0

    return v1

    :cond_0
    const/4 v0, 0x0

    move-object v3, v0

    move v0, v1

    move v4, v0

    :goto_0
    iget-object v5, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v0, v5, :cond_3

    iget-object v5, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v5, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/support/v4/app/n;

    if-eqz v5, :cond_2

    invoke-virtual {v5, p1, p2}, Landroid/support/v4/app/n;->performCreateOptionsMenu(Landroid/view/Menu;Landroid/view/MenuInflater;)Z

    move-result v6

    if-eqz v6, :cond_2

    if-nez v3, :cond_1

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    :cond_1
    invoke-virtual {v3, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move v4, v2

    :cond_2
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_3
    iget-object p1, p0, Landroid/support/v4/app/O;->mCreatedMenus:Ljava/util/ArrayList;

    if-eqz p1, :cond_6

    :goto_1
    iget-object p1, p0, Landroid/support/v4/app/O;->mCreatedMenus:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-ge v1, p1, :cond_6

    iget-object p1, p0, Landroid/support/v4/app/O;->mCreatedMenus:Ljava/util/ArrayList;

    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/support/v4/app/n;

    if-eqz v3, :cond_4

    invoke-virtual {v3, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_5

    :cond_4
    invoke-virtual {p1}, Landroid/support/v4/app/n;->onDestroyOptionsMenu()V

    :cond_5
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_6
    iput-object v3, p0, Landroid/support/v4/app/O;->mCreatedMenus:Ljava/util/ArrayList;

    return v4
.end method

.method public dispatchDestroy()V
    .locals 1

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v4/app/O;->mDestroyed:Z

    invoke-virtual {p0}, Landroid/support/v4/app/O;->execPendingActions()Z

    const/4 v0, 0x0

    invoke-direct {p0, v0}, Landroid/support/v4/app/O;->La(I)V

    const/4 v0, 0x0

    iput-object v0, p0, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    iput-object v0, p0, Landroid/support/v4/app/O;->mContainer:Landroid/support/v4/app/s;

    iput-object v0, p0, Landroid/support/v4/app/O;->mParent:Landroid/support/v4/app/n;

    return-void
.end method

.method public dispatchDestroyView()V
    .locals 1

    const/4 v0, 0x1

    invoke-direct {p0, v0}, Landroid/support/v4/app/O;->La(I)V

    return-void
.end method

.method public dispatchLowMemory()V
    .locals 2

    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    iget-object v1, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/support/v4/app/n;

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Landroid/support/v4/app/n;->performLowMemory()V

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method public dispatchMultiWindowModeChanged(Z)V
    .locals 2

    iget-object v0, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    :goto_0
    if-ltz v0, :cond_1

    iget-object v1, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/support/v4/app/n;

    if-eqz v1, :cond_0

    invoke-virtual {v1, p1}, Landroid/support/v4/app/n;->performMultiWindowModeChanged(Z)V

    :cond_0
    add-int/lit8 v0, v0, -0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method public dispatchOptionsItemSelected(Landroid/view/MenuItem;)Z
    .locals 4

    iget v0, p0, Landroid/support/v4/app/O;->mCurState:I

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-ge v0, v2, :cond_0

    return v1

    :cond_0
    move v0, v1

    :goto_0
    iget-object v3, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v0, v3, :cond_2

    iget-object v3, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/support/v4/app/n;

    if-eqz v3, :cond_1

    invoke-virtual {v3, p1}, Landroid/support/v4/app/n;->performOptionsItemSelected(Landroid/view/MenuItem;)Z

    move-result v3

    if-eqz v3, :cond_1

    return v2

    :cond_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_2
    return v1
.end method

.method public dispatchOptionsMenuClosed(Landroid/view/Menu;)V
    .locals 2

    iget v0, p0, Landroid/support/v4/app/O;->mCurState:I

    const/4 v1, 0x1

    if-ge v0, v1, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_2

    iget-object v1, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/support/v4/app/n;

    if-eqz v1, :cond_1

    invoke-virtual {v1, p1}, Landroid/support/v4/app/n;->performOptionsMenuClosed(Landroid/view/Menu;)V

    :cond_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_2
    return-void
.end method

.method public dispatchPause()V
    .locals 1

    const/4 v0, 0x4

    invoke-direct {p0, v0}, Landroid/support/v4/app/O;->La(I)V

    return-void
.end method

.method public dispatchPictureInPictureModeChanged(Z)V
    .locals 2

    iget-object v0, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    :goto_0
    if-ltz v0, :cond_1

    iget-object v1, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/support/v4/app/n;

    if-eqz v1, :cond_0

    invoke-virtual {v1, p1}, Landroid/support/v4/app/n;->performPictureInPictureModeChanged(Z)V

    :cond_0
    add-int/lit8 v0, v0, -0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method public dispatchPrepareOptionsMenu(Landroid/view/Menu;)Z
    .locals 4

    iget v0, p0, Landroid/support/v4/app/O;->mCurState:I

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-ge v0, v2, :cond_0

    return v1

    :cond_0
    move v0, v1

    :goto_0
    iget-object v3, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v1, v3, :cond_2

    iget-object v3, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/support/v4/app/n;

    if-eqz v3, :cond_1

    invoke-virtual {v3, p1}, Landroid/support/v4/app/n;->performPrepareOptionsMenu(Landroid/view/Menu;)Z

    move-result v3

    if-eqz v3, :cond_1

    move v0, v2

    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_2
    return v0
.end method

.method public dispatchResume()V
    .locals 1

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/support/v4/app/O;->mStateSaved:Z

    iput-boolean v0, p0, Landroid/support/v4/app/O;->mStopped:Z

    const/4 v0, 0x5

    invoke-direct {p0, v0}, Landroid/support/v4/app/O;->La(I)V

    return-void
.end method

.method public dispatchStart()V
    .locals 1

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/support/v4/app/O;->mStateSaved:Z

    iput-boolean v0, p0, Landroid/support/v4/app/O;->mStopped:Z

    const/4 v0, 0x4

    invoke-direct {p0, v0}, Landroid/support/v4/app/O;->La(I)V

    return-void
.end method

.method public dispatchStop()V
    .locals 1

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v4/app/O;->mStopped:Z

    const/4 v0, 0x3

    invoke-direct {p0, v0}, Landroid/support/v4/app/O;->La(I)V

    return-void
.end method

.method doPendingDeferredStart()V
    .locals 1

    iget-boolean v0, p0, Landroid/support/v4/app/O;->mHavePendingDeferredStart:Z

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/support/v4/app/O;->mHavePendingDeferredStart:Z

    invoke-virtual {p0}, Landroid/support/v4/app/O;->startPendingDeferredFragments()V

    :cond_0
    return-void
.end method

.method public dump(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    .locals 7

    const-string v0, "    "

    invoke-static {p1, v0}, Lb/a/a/a/a;->k(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    const/4 v2, 0x0

    if-eqz v1, :cond_d

    invoke-virtual {v1}, Landroid/util/SparseArray;->size()I

    move-result v1

    if-lez v1, :cond_d

    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v3, "Active Fragments in "

    invoke-virtual {p3, v3}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p3, v3}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v3, ":"

    invoke-virtual {p3, v3}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    move v3, v2

    :goto_0
    if-ge v3, v1, :cond_d

    iget-object v4, p0, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    invoke-virtual {v4, v3}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/support/v4/app/n;

    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v5, "  #"

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    invoke-virtual {p3, v3}, Ljava/io/PrintWriter;->print(I)V

    const-string v5, ": "

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    invoke-virtual {p3, v4}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    if-eqz v4, :cond_c

    .line 1
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v5, "mFragmentId=#"

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget v5, v4, Landroid/support/v4/app/n;->mFragmentId:I

    invoke-static {v5}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v5, " mContainerId=#"

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget v5, v4, Landroid/support/v4/app/n;->mContainerId:I

    invoke-static {v5}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v5, " mTag="

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object v5, v4, Landroid/support/v4/app/n;->mTag:Ljava/lang/String;

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v5, "mState="

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget v5, v4, Landroid/support/v4/app/n;->mState:I

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(I)V

    const-string v5, " mIndex="

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget v5, v4, Landroid/support/v4/app/n;->mIndex:I

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(I)V

    const-string v5, " mWho="

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object v5, v4, Landroid/support/v4/app/n;->mWho:Ljava/lang/String;

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v5, " mBackStackNesting="

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget v5, v4, Landroid/support/v4/app/n;->mBackStackNesting:I

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->println(I)V

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v5, "mAdded="

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v5, v4, Landroid/support/v4/app/n;->mAdded:Z

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Z)V

    const-string v5, " mRemoving="

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v5, v4, Landroid/support/v4/app/n;->mRemoving:Z

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Z)V

    const-string v5, " mFromLayout="

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v5, v4, Landroid/support/v4/app/n;->mFromLayout:Z

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Z)V

    const-string v5, " mInLayout="

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v5, v4, Landroid/support/v4/app/n;->mInLayout:Z

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->println(Z)V

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v5, "mHidden="

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v5, v4, Landroid/support/v4/app/n;->mHidden:Z

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Z)V

    const-string v5, " mDetached="

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v5, v4, Landroid/support/v4/app/n;->mDetached:Z

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Z)V

    const-string v5, " mMenuVisible="

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v5, v4, Landroid/support/v4/app/n;->mMenuVisible:Z

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Z)V

    const-string v5, " mHasMenu="

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v5, v4, Landroid/support/v4/app/n;->mHasMenu:Z

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->println(Z)V

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v5, "mRetainInstance="

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v5, v4, Landroid/support/v4/app/n;->mRetainInstance:Z

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Z)V

    const-string v5, " mRetaining="

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v5, v4, Landroid/support/v4/app/n;->mRetaining:Z

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Z)V

    const-string v5, " mUserVisibleHint="

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v5, v4, Landroid/support/v4/app/n;->mUserVisibleHint:Z

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->println(Z)V

    iget-object v5, v4, Landroid/support/v4/app/n;->mFragmentManager:Landroid/support/v4/app/O;

    if-eqz v5, :cond_0

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v5, "mFragmentManager="

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object v5, v4, Landroid/support/v4/app/n;->mFragmentManager:Landroid/support/v4/app/O;

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    :cond_0
    iget-object v5, v4, Landroid/support/v4/app/n;->mHost:Landroid/support/v4/app/u;

    if-eqz v5, :cond_1

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v5, "mHost="

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object v5, v4, Landroid/support/v4/app/n;->mHost:Landroid/support/v4/app/u;

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    :cond_1
    iget-object v5, v4, Landroid/support/v4/app/n;->mParentFragment:Landroid/support/v4/app/n;

    if-eqz v5, :cond_2

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v5, "mParentFragment="

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object v5, v4, Landroid/support/v4/app/n;->mParentFragment:Landroid/support/v4/app/n;

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    :cond_2
    iget-object v5, v4, Landroid/support/v4/app/n;->mArguments:Landroid/os/Bundle;

    if-eqz v5, :cond_3

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v5, "mArguments="

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object v5, v4, Landroid/support/v4/app/n;->mArguments:Landroid/os/Bundle;

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    :cond_3
    iget-object v5, v4, Landroid/support/v4/app/n;->mSavedFragmentState:Landroid/os/Bundle;

    if-eqz v5, :cond_4

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v5, "mSavedFragmentState="

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object v5, v4, Landroid/support/v4/app/n;->mSavedFragmentState:Landroid/os/Bundle;

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    :cond_4
    iget-object v5, v4, Landroid/support/v4/app/n;->mSavedViewState:Landroid/util/SparseArray;

    if-eqz v5, :cond_5

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v5, "mSavedViewState="

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object v5, v4, Landroid/support/v4/app/n;->mSavedViewState:Landroid/util/SparseArray;

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    :cond_5
    iget-object v5, v4, Landroid/support/v4/app/n;->mTarget:Landroid/support/v4/app/n;

    if-eqz v5, :cond_6

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v5, "mTarget="

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object v5, v4, Landroid/support/v4/app/n;->mTarget:Landroid/support/v4/app/n;

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/Object;)V

    const-string v5, " mTargetRequestCode="

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget v5, v4, Landroid/support/v4/app/n;->mTargetRequestCode:I

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->println(I)V

    :cond_6
    invoke-virtual {v4}, Landroid/support/v4/app/n;->getNextAnim()I

    move-result v5

    if-eqz v5, :cond_7

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v5, "mNextAnim="

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    invoke-virtual {v4}, Landroid/support/v4/app/n;->getNextAnim()I

    move-result v5

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->println(I)V

    :cond_7
    iget-object v5, v4, Landroid/support/v4/app/n;->mContainer:Landroid/view/ViewGroup;

    if-eqz v5, :cond_8

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v5, "mContainer="

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object v5, v4, Landroid/support/v4/app/n;->mContainer:Landroid/view/ViewGroup;

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    :cond_8
    iget-object v5, v4, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    if-eqz v5, :cond_9

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v5, "mView="

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object v5, v4, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    :cond_9
    iget-object v5, v4, Landroid/support/v4/app/n;->He:Landroid/view/View;

    if-eqz v5, :cond_a

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v5, "mInnerView="

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object v5, v4, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    :cond_a
    invoke-virtual {v4}, Landroid/support/v4/app/n;->getAnimatingAway()Landroid/view/View;

    move-result-object v5

    if-eqz v5, :cond_b

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v5, "mAnimatingAway="

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    invoke-virtual {v4}, Landroid/support/v4/app/n;->getAnimatingAway()Landroid/view/View;

    move-result-object v5

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v5, "mStateAfterAnimating="

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    invoke-virtual {v4}, Landroid/support/v4/app/n;->getStateAfterAnimating()I

    move-result v5

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->println(I)V

    :cond_b
    invoke-static {v4}, Landroid/support/v4/app/ka;->g(Landroid/arch/lifecycle/e;)Landroid/support/v4/app/ka;

    move-result-object v5

    invoke-virtual {v5, v0, p2, p3, p4}, Landroid/support/v4/app/ka;->dump(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V

    iget-object v5, v4, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    if-eqz v5, :cond_c

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "Child "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v6, v4, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v6, ":"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {p3, v5}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    iget-object v4, v4, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    const-string v5, "  "

    invoke-static {v0, v5}, Lb/a/a/a/a;->k(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5, p2, p3, p4}, Landroid/support/v4/app/O;->dump(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V

    :cond_c
    add-int/lit8 v3, v3, 0x1

    goto/16 :goto_0

    .line 2
    :cond_d
    iget-object p2, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    if-lez p2, :cond_e

    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string p4, "Added Fragments:"

    invoke-virtual {p3, p4}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    move p4, v2

    :goto_1
    if-ge p4, p2, :cond_e

    iget-object v1, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v1, p4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/support/v4/app/n;

    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v3, "  #"

    invoke-virtual {p3, v3}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    invoke-virtual {p3, p4}, Ljava/io/PrintWriter;->print(I)V

    const-string v3, ": "

    invoke-virtual {p3, v3}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    invoke-virtual {v1}, Landroid/support/v4/app/n;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    add-int/lit8 p4, p4, 0x1

    goto :goto_1

    :cond_e
    iget-object p2, p0, Landroid/support/v4/app/O;->mCreatedMenus:Ljava/util/ArrayList;

    if-eqz p2, :cond_f

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    if-lez p2, :cond_f

    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string p4, "Fragments Created Menus:"

    invoke-virtual {p3, p4}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    move p4, v2

    :goto_2
    if-ge p4, p2, :cond_f

    iget-object v1, p0, Landroid/support/v4/app/O;->mCreatedMenus:Ljava/util/ArrayList;

    invoke-virtual {v1, p4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/support/v4/app/n;

    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v3, "  #"

    invoke-virtual {p3, v3}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    invoke-virtual {p3, p4}, Ljava/io/PrintWriter;->print(I)V

    const-string v3, ": "

    invoke-virtual {p3, v3}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    invoke-virtual {v1}, Landroid/support/v4/app/n;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    add-int/lit8 p4, p4, 0x1

    goto :goto_2

    :cond_f
    iget-object p2, p0, Landroid/support/v4/app/O;->mBackStack:Ljava/util/ArrayList;

    if-eqz p2, :cond_10

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    if-lez p2, :cond_10

    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string p4, "Back Stack:"

    invoke-virtual {p3, p4}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    move p4, v2

    :goto_3
    if-ge p4, p2, :cond_10

    iget-object v1, p0, Landroid/support/v4/app/O;->mBackStack:Ljava/util/ArrayList;

    invoke-virtual {v1, p4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/support/v4/app/e;

    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v3, "  #"

    invoke-virtual {p3, v3}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    invoke-virtual {p3, p4}, Ljava/io/PrintWriter;->print(I)V

    const-string v3, ": "

    invoke-virtual {p3, v3}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    invoke-virtual {v1}, Landroid/support/v4/app/e;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p3, v3}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    const/4 v3, 0x1

    .line 3
    invoke-virtual {v1, v0, p3, v3}, Landroid/support/v4/app/e;->dump(Ljava/lang/String;Ljava/io/PrintWriter;Z)V

    add-int/lit8 p4, p4, 0x1

    goto :goto_3

    .line 4
    :cond_10
    monitor-enter p0

    :try_start_0
    iget-object p2, p0, Landroid/support/v4/app/O;->mBackStackIndices:Ljava/util/ArrayList;

    if-eqz p2, :cond_11

    iget-object p2, p0, Landroid/support/v4/app/O;->mBackStackIndices:Ljava/util/ArrayList;

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    if-lez p2, :cond_11

    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string p4, "Back Stack Indices:"

    invoke-virtual {p3, p4}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    move p4, v2

    :goto_4
    if-ge p4, p2, :cond_11

    iget-object v0, p0, Landroid/support/v4/app/O;->mBackStackIndices:Ljava/util/ArrayList;

    invoke-virtual {v0, p4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v4/app/e;

    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v1, "  #"

    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    invoke-virtual {p3, p4}, Ljava/io/PrintWriter;->print(I)V

    const-string v1, ": "

    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    add-int/lit8 p4, p4, 0x1

    goto :goto_4

    :cond_11
    iget-object p2, p0, Landroid/support/v4/app/O;->mAvailBackStackIndices:Ljava/util/ArrayList;

    if-eqz p2, :cond_12

    iget-object p2, p0, Landroid/support/v4/app/O;->mAvailBackStackIndices:Ljava/util/ArrayList;

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    if-lez p2, :cond_12

    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string p2, "mAvailBackStackIndices: "

    invoke-virtual {p3, p2}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object p2, p0, Landroid/support/v4/app/O;->mAvailBackStackIndices:Ljava/util/ArrayList;

    invoke-virtual {p2}, Ljava/util/ArrayList;->toArray()[Ljava/lang/Object;

    move-result-object p2

    invoke-static {p2}, Ljava/util/Arrays;->toString([Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p3, p2}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    :cond_12
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object p2, p0, Landroid/support/v4/app/O;->mPendingActions:Ljava/util/ArrayList;

    if-eqz p2, :cond_13

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    if-lez p2, :cond_13

    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string p4, "Pending Actions:"

    invoke-virtual {p3, p4}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    :goto_5
    if-ge v2, p2, :cond_13

    iget-object p4, p0, Landroid/support/v4/app/O;->mPendingActions:Ljava/util/ArrayList;

    invoke-virtual {p4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p4

    check-cast p4, Landroid/support/v4/app/M;

    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "  #"

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    invoke-virtual {p3, v2}, Ljava/io/PrintWriter;->print(I)V

    const-string v0, ": "

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    invoke-virtual {p3, p4}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_5

    :cond_13
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string p2, "FragmentManager misc state:"

    invoke-virtual {p3, p2}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string p2, "  mHost="

    invoke-virtual {p3, p2}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object p2, p0, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    invoke-virtual {p3, p2}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string p2, "  mContainer="

    invoke-virtual {p3, p2}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object p2, p0, Landroid/support/v4/app/O;->mContainer:Landroid/support/v4/app/s;

    invoke-virtual {p3, p2}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    iget-object p2, p0, Landroid/support/v4/app/O;->mParent:Landroid/support/v4/app/n;

    if-eqz p2, :cond_14

    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string p2, "  mParent="

    invoke-virtual {p3, p2}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object p2, p0, Landroid/support/v4/app/O;->mParent:Landroid/support/v4/app/n;

    invoke-virtual {p3, p2}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    :cond_14
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string p2, "  mCurState="

    invoke-virtual {p3, p2}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget p2, p0, Landroid/support/v4/app/O;->mCurState:I

    invoke-virtual {p3, p2}, Ljava/io/PrintWriter;->print(I)V

    const-string p2, " mStateSaved="

    invoke-virtual {p3, p2}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean p2, p0, Landroid/support/v4/app/O;->mStateSaved:Z

    invoke-virtual {p3, p2}, Ljava/io/PrintWriter;->print(Z)V

    const-string p2, " mStopped="

    invoke-virtual {p3, p2}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean p2, p0, Landroid/support/v4/app/O;->mStopped:Z

    invoke-virtual {p3, p2}, Ljava/io/PrintWriter;->print(Z)V

    const-string p2, " mDestroyed="

    invoke-virtual {p3, p2}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean p2, p0, Landroid/support/v4/app/O;->mDestroyed:Z

    invoke-virtual {p3, p2}, Ljava/io/PrintWriter;->println(Z)V

    iget-boolean p2, p0, Landroid/support/v4/app/O;->mNeedMenuInvalidate:Z

    if-eqz p2, :cond_15

    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string p2, "  mNeedMenuInvalidate="

    invoke-virtual {p3, p2}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean p2, p0, Landroid/support/v4/app/O;->mNeedMenuInvalidate:Z

    invoke-virtual {p3, p2}, Ljava/io/PrintWriter;->println(Z)V

    :cond_15
    iget-object p2, p0, Landroid/support/v4/app/O;->mNoTransactionsBecause:Ljava/lang/String;

    if-eqz p2, :cond_16

    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string p1, "  mNoTransactionsBecause="

    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object p0, p0, Landroid/support/v4/app/O;->mNoTransactionsBecause:Ljava/lang/String;

    invoke-virtual {p3, p0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    :cond_16
    return-void

    :catchall_0
    move-exception p1

    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method public e(Landroid/support/v4/app/n;)V
    .locals 2

    iget-boolean v0, p1, Landroid/support/v4/app/n;->mDetached:Z

    if-eqz v0, :cond_1

    const/4 v0, 0x0

    iput-boolean v0, p1, Landroid/support/v4/app/n;->mDetached:Z

    iget-boolean v0, p1, Landroid/support/v4/app/n;->mAdded:Z

    if-nez v0, :cond_1

    iget-object v0, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v0, 0x1

    iput-boolean v0, p1, Landroid/support/v4/app/n;->mAdded:Z

    iget-boolean v1, p1, Landroid/support/v4/app/n;->mHasMenu:Z

    if-eqz v1, :cond_1

    iget-boolean p1, p1, Landroid/support/v4/app/n;->mMenuVisible:Z

    if-eqz p1, :cond_1

    iput-boolean v0, p0, Landroid/support/v4/app/O;->mNeedMenuInvalidate:Z

    goto :goto_0

    :catchall_0
    move-exception p0

    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p0

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Fragment already added: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    :goto_0
    return-void
.end method

.method e(Landroid/support/v4/app/n;Z)V
    .locals 2

    iget-object v0, p0, Landroid/support/v4/app/O;->mParent:Landroid/support/v4/app/n;

    if-eqz v0, :cond_0

    .line 1
    iget-object v0, v0, Landroid/support/v4/app/n;->mFragmentManager:Landroid/support/v4/app/O;

    .line 2
    instance-of v1, v0, Landroid/support/v4/app/O;

    if-eqz v1, :cond_0

    const/4 v1, 0x1

    invoke-virtual {v0, p1, v1}, Landroid/support/v4/app/O;->e(Landroid/support/v4/app/n;Z)V

    :cond_0
    iget-object p0, p0, Landroid/support/v4/app/O;->mLifecycleCallbacks:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/support/v4/app/K;

    if-eqz p2, :cond_1

    iget-boolean v0, p1, Landroid/support/v4/app/K;->Se:Z

    if-nez v0, :cond_1

    goto :goto_0

    :cond_1
    iget-object p0, p1, Landroid/support/v4/app/K;->mCallback:Landroid/support/v4/app/w;

    const/4 p0, 0x0

    throw p0

    :cond_2
    return-void
.end method

.method public execPendingActions()Z
    .locals 5

    const/4 v0, 0x1

    invoke-direct {p0, v0}, Landroid/support/v4/app/O;->W(Z)V

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    iget-object v3, p0, Landroid/support/v4/app/O;->mTmpRecords:Ljava/util/ArrayList;

    iget-object v4, p0, Landroid/support/v4/app/O;->mTmpIsPop:Ljava/util/ArrayList;

    invoke-direct {p0, v3, v4}, Landroid/support/v4/app/O;->b(Ljava/util/ArrayList;Ljava/util/ArrayList;)Z

    move-result v3

    if-eqz v3, :cond_0

    iput-boolean v0, p0, Landroid/support/v4/app/O;->mExecutingActions:Z

    :try_start_0
    iget-object v2, p0, Landroid/support/v4/app/O;->mTmpRecords:Ljava/util/ArrayList;

    iget-object v3, p0, Landroid/support/v4/app/O;->mTmpIsPop:Ljava/util/ArrayList;

    invoke-direct {p0, v2, v3}, Landroid/support/v4/app/O;->c(Ljava/util/ArrayList;Ljava/util/ArrayList;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-direct {p0}, Landroid/support/v4/app/O;->Sf()V

    move v2, v0

    goto :goto_0

    :catchall_0
    move-exception v0

    invoke-direct {p0}, Landroid/support/v4/app/O;->Sf()V

    throw v0

    .line 1
    :cond_0
    iget-boolean v0, p0, Landroid/support/v4/app/O;->mHavePendingDeferredStart:Z

    if-eqz v0, :cond_1

    iput-boolean v1, p0, Landroid/support/v4/app/O;->mHavePendingDeferredStart:Z

    invoke-virtual {p0}, Landroid/support/v4/app/O;->startPendingDeferredFragments()V

    .line 2
    :cond_1
    invoke-direct {p0}, Landroid/support/v4/app/O;->Qf()V

    return v2
.end method

.method public f(Landroid/support/v4/app/n;)V
    .locals 3

    iget-boolean v0, p1, Landroid/support/v4/app/n;->mDetached:Z

    if-nez v0, :cond_1

    const/4 v0, 0x1

    iput-boolean v0, p1, Landroid/support/v4/app/n;->mDetached:Z

    iget-boolean v1, p1, Landroid/support/v4/app/n;->mAdded:Z

    if-eqz v1, :cond_1

    iget-object v1, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    monitor-enter v1

    :try_start_0
    iget-object v2, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v2, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-boolean v1, p1, Landroid/support/v4/app/n;->mHasMenu:Z

    if-eqz v1, :cond_0

    iget-boolean v1, p1, Landroid/support/v4/app/n;->mMenuVisible:Z

    if-eqz v1, :cond_0

    iput-boolean v0, p0, Landroid/support/v4/app/O;->mNeedMenuInvalidate:Z

    :cond_0
    const/4 p0, 0x0

    iput-boolean p0, p1, Landroid/support/v4/app/n;->mAdded:Z

    goto :goto_0

    :catchall_0
    move-exception p0

    :try_start_1
    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p0

    :cond_1
    :goto_0
    return-void
.end method

.method f(Landroid/support/v4/app/n;Z)V
    .locals 2

    iget-object v0, p0, Landroid/support/v4/app/O;->mParent:Landroid/support/v4/app/n;

    if-eqz v0, :cond_0

    .line 1
    iget-object v0, v0, Landroid/support/v4/app/n;->mFragmentManager:Landroid/support/v4/app/O;

    .line 2
    instance-of v1, v0, Landroid/support/v4/app/O;

    if-eqz v1, :cond_0

    const/4 v1, 0x1

    invoke-virtual {v0, p1, v1}, Landroid/support/v4/app/O;->f(Landroid/support/v4/app/n;Z)V

    :cond_0
    iget-object p0, p0, Landroid/support/v4/app/O;->mLifecycleCallbacks:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/support/v4/app/K;

    if-eqz p2, :cond_1

    iget-boolean v0, p1, Landroid/support/v4/app/K;->Se:Z

    if-nez v0, :cond_1

    goto :goto_0

    :cond_1
    iget-object p0, p1, Landroid/support/v4/app/K;->mCallback:Landroid/support/v4/app/w;

    const/4 p0, 0x0

    throw p0

    :cond_2
    return-void
.end method

.method public findFragmentById(I)Landroid/support/v4/app/n;
    .locals 3

    iget-object v0, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    :goto_0
    if-ltz v0, :cond_1

    iget-object v1, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/support/v4/app/n;

    if-eqz v1, :cond_0

    iget v2, v1, Landroid/support/v4/app/n;->mFragmentId:I

    if-ne v2, p1, :cond_0

    return-object v1

    :cond_0
    add-int/lit8 v0, v0, -0x1

    goto :goto_0

    :cond_1
    iget-object v0, p0, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    if-eqz v0, :cond_3

    invoke-virtual {v0}, Landroid/util/SparseArray;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    :goto_1
    if-ltz v0, :cond_3

    iget-object v1, p0, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    invoke-virtual {v1, v0}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/support/v4/app/n;

    if-eqz v1, :cond_2

    iget v2, v1, Landroid/support/v4/app/n;->mFragmentId:I

    if-ne v2, p1, :cond_2

    return-object v1

    :cond_2
    add-int/lit8 v0, v0, -0x1

    goto :goto_1

    :cond_3
    const/4 p0, 0x0

    return-object p0
.end method

.method public findFragmentByWho(Ljava/lang/String;)Landroid/support/v4/app/n;
    .locals 2

    iget-object v0, p0, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    if-eqz v0, :cond_1

    if-eqz p1, :cond_1

    invoke-virtual {v0}, Landroid/util/SparseArray;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    :goto_0
    if-ltz v0, :cond_1

    iget-object v1, p0, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    invoke-virtual {v1, v0}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/support/v4/app/n;

    if-eqz v1, :cond_0

    invoke-virtual {v1, p1}, Landroid/support/v4/app/n;->findFragmentByWho(Ljava/lang/String;)Landroid/support/v4/app/n;

    move-result-object v1

    if-eqz v1, :cond_0

    return-object v1

    :cond_0
    add-int/lit8 v0, v0, -0x1

    goto :goto_0

    :cond_1
    const/4 p0, 0x0

    return-object p0
.end method

.method public freeBackStackIndex(I)V
    .locals 2

    monitor-enter p0

    :try_start_0
    iget-object v0, p0, Landroid/support/v4/app/O;->mBackStackIndices:Ljava/util/ArrayList;

    const/4 v1, 0x0

    invoke-virtual {v0, p1, v1}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    iget-object v0, p0, Landroid/support/v4/app/O;->mAvailBackStackIndices:Ljava/util/ArrayList;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroid/support/v4/app/O;->mAvailBackStackIndices:Ljava/util/ArrayList;

    :cond_0
    iget-object v0, p0, Landroid/support/v4/app/O;->mAvailBackStackIndices:Ljava/util/ArrayList;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    monitor-exit p0

    return-void

    :catchall_0
    move-exception p1

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method

.method public g(Landroid/support/v4/app/n;)V
    .locals 1

    iget-boolean p0, p1, Landroid/support/v4/app/n;->mHidden:Z

    if-nez p0, :cond_0

    const/4 p0, 0x1

    iput-boolean p0, p1, Landroid/support/v4/app/n;->mHidden:Z

    iget-boolean v0, p1, Landroid/support/v4/app/n;->mHiddenChanged:Z

    xor-int/2addr p0, v0

    iput-boolean p0, p1, Landroid/support/v4/app/n;->mHiddenChanged:Z

    :cond_0
    return-void
.end method

.method g(Landroid/support/v4/app/n;Z)V
    .locals 2

    iget-object v0, p0, Landroid/support/v4/app/O;->mParent:Landroid/support/v4/app/n;

    if-eqz v0, :cond_0

    .line 1
    iget-object v0, v0, Landroid/support/v4/app/n;->mFragmentManager:Landroid/support/v4/app/O;

    .line 2
    instance-of v1, v0, Landroid/support/v4/app/O;

    if-eqz v1, :cond_0

    const/4 v1, 0x1

    invoke-virtual {v0, p1, v1}, Landroid/support/v4/app/O;->g(Landroid/support/v4/app/n;Z)V

    :cond_0
    iget-object p0, p0, Landroid/support/v4/app/O;->mLifecycleCallbacks:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/support/v4/app/K;

    if-eqz p2, :cond_1

    iget-boolean v0, p1, Landroid/support/v4/app/K;->Se:Z

    if-nez v0, :cond_1

    goto :goto_0

    :cond_1
    iget-object p0, p1, Landroid/support/v4/app/K;->mCallback:Landroid/support/v4/app/w;

    const/4 p0, 0x0

    throw p0

    :cond_2
    return-void
.end method

.method public getFragments()Ljava/util/List;
    .locals 1

    iget-object v0, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    sget-object p0, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    return-object p0

    :cond_0
    iget-object v0, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    monitor-enter v0

    :try_start_0
    iget-object p0, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {p0}, Ljava/util/ArrayList;->clone()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/util/List;

    monitor-exit v0

    return-object p0

    :catchall_0
    move-exception p0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p0
.end method

.method getLayoutInflaterFactory()Landroid/view/LayoutInflater$Factory2;
    .locals 0

    return-object p0
.end method

.method h(Landroid/support/v4/app/n;)V
    .locals 2

    iget v0, p1, Landroid/support/v4/app/n;->mIndex:I

    if-ltz v0, :cond_0

    return-void

    :cond_0
    iget v0, p0, Landroid/support/v4/app/O;->mNextFragmentIndex:I

    add-int/lit8 v1, v0, 0x1

    iput v1, p0, Landroid/support/v4/app/O;->mNextFragmentIndex:I

    iget-object v1, p0, Landroid/support/v4/app/O;->mParent:Landroid/support/v4/app/n;

    invoke-virtual {p1, v0, v1}, Landroid/support/v4/app/n;->a(ILandroid/support/v4/app/n;)V

    iget-object v0, p0, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    if-nez v0, :cond_1

    new-instance v0, Landroid/util/SparseArray;

    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    iput-object v0, p0, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    :cond_1
    iget-object p0, p0, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    iget v0, p1, Landroid/support/v4/app/n;->mIndex:I

    invoke-virtual {p0, v0, p1}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    return-void
.end method

.method h(Landroid/support/v4/app/n;Z)V
    .locals 2

    iget-object v0, p0, Landroid/support/v4/app/O;->mParent:Landroid/support/v4/app/n;

    if-eqz v0, :cond_0

    .line 1
    iget-object v0, v0, Landroid/support/v4/app/n;->mFragmentManager:Landroid/support/v4/app/O;

    .line 2
    instance-of v1, v0, Landroid/support/v4/app/O;

    if-eqz v1, :cond_0

    const/4 v1, 0x1

    invoke-virtual {v0, p1, v1}, Landroid/support/v4/app/O;->h(Landroid/support/v4/app/n;Z)V

    :cond_0
    iget-object p0, p0, Landroid/support/v4/app/O;->mLifecycleCallbacks:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/support/v4/app/K;

    if-eqz p2, :cond_1

    iget-boolean v0, p1, Landroid/support/v4/app/K;->Se:Z

    if-nez v0, :cond_1

    goto :goto_0

    :cond_1
    iget-object p0, p1, Landroid/support/v4/app/K;->mCallback:Landroid/support/v4/app/w;

    const/4 p0, 0x0

    throw p0

    :cond_2
    return-void
.end method

.method i(Landroid/support/v4/app/n;)V
    .locals 10

    if-nez p1, :cond_0

    return-void

    :cond_0
    iget v0, p0, Landroid/support/v4/app/O;->mCurState:I

    iget-boolean v1, p1, Landroid/support/v4/app/n;->mRemoving:Z

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v1, :cond_2

    invoke-virtual {p1}, Landroid/support/v4/app/n;->isInBackStack()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-static {v0, v2}, Ljava/lang/Math;->min(II)I

    move-result v0

    goto :goto_0

    :cond_1
    invoke-static {v0, v3}, Ljava/lang/Math;->min(II)I

    move-result v0

    :cond_2
    :goto_0
    move v6, v0

    invoke-virtual {p1}, Landroid/support/v4/app/n;->getNextTransition()I

    move-result v7

    invoke-virtual {p1}, Landroid/support/v4/app/n;->getNextTransitionStyle()I

    move-result v8

    const/4 v9, 0x0

    move-object v4, p0

    move-object v5, p1

    invoke-virtual/range {v4 .. v9}, Landroid/support/v4/app/O;->a(Landroid/support/v4/app/n;IIIZ)V

    iget-object v0, p1, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    if-eqz v0, :cond_9

    .line 1
    iget-object v1, p1, Landroid/support/v4/app/n;->mContainer:Landroid/view/ViewGroup;

    const/4 v4, 0x0

    if-eqz v1, :cond_5

    if-nez v0, :cond_3

    goto :goto_1

    :cond_3
    iget-object v0, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->indexOf(Ljava/lang/Object;)I

    move-result v0

    :cond_4
    add-int/lit8 v0, v0, -0x1

    if-ltz v0, :cond_5

    iget-object v5, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v5, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/support/v4/app/n;

    iget-object v6, v5, Landroid/support/v4/app/n;->mContainer:Landroid/view/ViewGroup;

    if-ne v6, v1, :cond_4

    iget-object v6, v5, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    if-eqz v6, :cond_4

    move-object v4, v5

    :cond_5
    :goto_1
    if-eqz v4, :cond_6

    .line 2
    iget-object v0, v4, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    iget-object v1, p1, Landroid/support/v4/app/n;->mContainer:Landroid/view/ViewGroup;

    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    move-result v0

    iget-object v4, p1, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    invoke-virtual {v1, v4}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    move-result v4

    if-ge v4, v0, :cond_6

    invoke-virtual {v1, v4}, Landroid/view/ViewGroup;->removeViewAt(I)V

    iget-object v4, p1, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    invoke-virtual {v1, v4, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V

    :cond_6
    iget-boolean v0, p1, Landroid/support/v4/app/n;->mIsNewlyAdded:Z

    if-eqz v0, :cond_9

    iget-object v0, p1, Landroid/support/v4/app/n;->mContainer:Landroid/view/ViewGroup;

    if-eqz v0, :cond_9

    iget v0, p1, Landroid/support/v4/app/n;->Ie:F

    const/4 v1, 0x0

    cmpl-float v4, v0, v1

    if-lez v4, :cond_7

    iget-object v4, p1, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    invoke-virtual {v4, v0}, Landroid/view/View;->setAlpha(F)V

    :cond_7
    iput v1, p1, Landroid/support/v4/app/n;->Ie:F

    iput-boolean v3, p1, Landroid/support/v4/app/n;->mIsNewlyAdded:Z

    invoke-virtual {p1}, Landroid/support/v4/app/n;->getNextTransition()I

    move-result v0

    invoke-virtual {p1}, Landroid/support/v4/app/n;->getNextTransitionStyle()I

    move-result v1

    invoke-virtual {p0, p1, v0, v2, v1}, Landroid/support/v4/app/O;->a(Landroid/support/v4/app/n;IZI)Landroid/support/v4/app/H;

    move-result-object v0

    if-eqz v0, :cond_9

    iget-object v1, p1, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    invoke-static {v1, v0}, Landroid/support/v4/app/O;->a(Landroid/view/View;Landroid/support/v4/app/H;)V

    iget-object v1, v0, Landroid/support/v4/app/H;->animation:Landroid/view/animation/Animation;

    if-eqz v1, :cond_8

    iget-object v0, p1, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    invoke-virtual {v0, v1}, Landroid/view/View;->startAnimation(Landroid/view/animation/Animation;)V

    goto :goto_2

    :cond_8
    iget-object v1, v0, Landroid/support/v4/app/H;->animator:Landroid/animation/Animator;

    iget-object v4, p1, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    invoke-virtual {v1, v4}, Landroid/animation/Animator;->setTarget(Ljava/lang/Object;)V

    iget-object v0, v0, Landroid/support/v4/app/H;->animator:Landroid/animation/Animator;

    invoke-virtual {v0}, Landroid/animation/Animator;->start()V

    :cond_9
    :goto_2
    iget-boolean v0, p1, Landroid/support/v4/app/n;->mHiddenChanged:Z

    if-eqz v0, :cond_11

    .line 3
    iget-object v0, p1, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    if-eqz v0, :cond_f

    invoke-virtual {p1}, Landroid/support/v4/app/n;->getNextTransition()I

    move-result v0

    iget-boolean v1, p1, Landroid/support/v4/app/n;->mHidden:Z

    xor-int/2addr v1, v2

    invoke-virtual {p1}, Landroid/support/v4/app/n;->getNextTransitionStyle()I

    move-result v4

    invoke-virtual {p0, p1, v0, v1, v4}, Landroid/support/v4/app/O;->a(Landroid/support/v4/app/n;IZI)Landroid/support/v4/app/H;

    move-result-object v0

    if-eqz v0, :cond_c

    iget-object v1, v0, Landroid/support/v4/app/H;->animator:Landroid/animation/Animator;

    if-eqz v1, :cond_c

    iget-object v4, p1, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    invoke-virtual {v1, v4}, Landroid/animation/Animator;->setTarget(Ljava/lang/Object;)V

    iget-boolean v1, p1, Landroid/support/v4/app/n;->mHidden:Z

    if-eqz v1, :cond_b

    invoke-virtual {p1}, Landroid/support/v4/app/n;->isHideReplaced()Z

    move-result v1

    if-eqz v1, :cond_a

    invoke-virtual {p1, v3}, Landroid/support/v4/app/n;->setHideReplaced(Z)V

    goto :goto_3

    :cond_a
    iget-object v1, p1, Landroid/support/v4/app/n;->mContainer:Landroid/view/ViewGroup;

    iget-object v4, p1, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    invoke-virtual {v1, v4}, Landroid/view/ViewGroup;->startViewTransition(Landroid/view/View;)V

    iget-object v5, v0, Landroid/support/v4/app/H;->animator:Landroid/animation/Animator;

    new-instance v6, Landroid/support/v4/app/D;

    invoke-direct {v6, p0, v1, v4, p1}, Landroid/support/v4/app/D;-><init>(Landroid/support/v4/app/O;Landroid/view/ViewGroup;Landroid/view/View;Landroid/support/v4/app/n;)V

    invoke-virtual {v5, v6}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    goto :goto_3

    :cond_b
    iget-object v1, p1, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    invoke-virtual {v1, v3}, Landroid/view/View;->setVisibility(I)V

    :goto_3
    iget-object v1, p1, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    invoke-static {v1, v0}, Landroid/support/v4/app/O;->a(Landroid/view/View;Landroid/support/v4/app/H;)V

    iget-object v0, v0, Landroid/support/v4/app/H;->animator:Landroid/animation/Animator;

    invoke-virtual {v0}, Landroid/animation/Animator;->start()V

    goto :goto_5

    :cond_c
    if-eqz v0, :cond_d

    iget-object v1, p1, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    invoke-static {v1, v0}, Landroid/support/v4/app/O;->a(Landroid/view/View;Landroid/support/v4/app/H;)V

    iget-object v1, p1, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    iget-object v4, v0, Landroid/support/v4/app/H;->animation:Landroid/view/animation/Animation;

    invoke-virtual {v1, v4}, Landroid/view/View;->startAnimation(Landroid/view/animation/Animation;)V

    iget-object v0, v0, Landroid/support/v4/app/H;->animation:Landroid/view/animation/Animation;

    invoke-virtual {v0}, Landroid/view/animation/Animation;->start()V

    :cond_d
    iget-boolean v0, p1, Landroid/support/v4/app/n;->mHidden:Z

    if-eqz v0, :cond_e

    invoke-virtual {p1}, Landroid/support/v4/app/n;->isHideReplaced()Z

    move-result v0

    if-nez v0, :cond_e

    const/16 v0, 0x8

    goto :goto_4

    :cond_e
    move v0, v3

    :goto_4
    iget-object v1, p1, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    invoke-virtual {v1, v0}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {p1}, Landroid/support/v4/app/n;->isHideReplaced()Z

    move-result v0

    if-eqz v0, :cond_f

    invoke-virtual {p1, v3}, Landroid/support/v4/app/n;->setHideReplaced(Z)V

    :cond_f
    :goto_5
    iget-boolean v0, p1, Landroid/support/v4/app/n;->mAdded:Z

    if-eqz v0, :cond_10

    iget-boolean v0, p1, Landroid/support/v4/app/n;->mHasMenu:Z

    if-eqz v0, :cond_10

    iget-boolean v0, p1, Landroid/support/v4/app/n;->mMenuVisible:Z

    if-eqz v0, :cond_10

    iput-boolean v2, p0, Landroid/support/v4/app/O;->mNeedMenuInvalidate:Z

    :cond_10
    iput-boolean v3, p1, Landroid/support/v4/app/n;->mHiddenChanged:Z

    iget-boolean p0, p1, Landroid/support/v4/app/n;->mHidden:Z

    :cond_11
    return-void
.end method

.method public isStateSaved()Z
    .locals 1

    iget-boolean v0, p0, Landroid/support/v4/app/O;->mStateSaved:Z

    if-nez v0, :cond_1

    iget-boolean p0, p0, Landroid/support/v4/app/O;->mStopped:Z

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 p0, 0x1

    :goto_1
    return p0
.end method

.method public j(Landroid/support/v4/app/n;)V
    .locals 3

    invoke-virtual {p1}, Landroid/support/v4/app/n;->isInBackStack()Z

    move-result v0

    const/4 v1, 0x1

    xor-int/2addr v0, v1

    iget-boolean v2, p1, Landroid/support/v4/app/n;->mDetached:Z

    if-eqz v2, :cond_0

    if-eqz v0, :cond_2

    :cond_0
    iget-object v0, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    monitor-enter v0

    :try_start_0
    iget-object v2, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v2, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-boolean v0, p1, Landroid/support/v4/app/n;->mHasMenu:Z

    if-eqz v0, :cond_1

    iget-boolean v0, p1, Landroid/support/v4/app/n;->mMenuVisible:Z

    if-eqz v0, :cond_1

    iput-boolean v1, p0, Landroid/support/v4/app/O;->mNeedMenuInvalidate:Z

    :cond_1
    const/4 p0, 0x0

    iput-boolean p0, p1, Landroid/support/v4/app/n;->mAdded:Z

    iput-boolean v1, p1, Landroid/support/v4/app/n;->mRemoving:Z

    :cond_2
    return-void

    :catchall_0
    move-exception p0

    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p0
.end method

.method k(Landroid/support/v4/app/n;)V
    .locals 2

    iget-object v0, p1, Landroid/support/v4/app/n;->He:Landroid/view/View;

    if-nez v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Landroid/support/v4/app/O;->mStateArray:Landroid/util/SparseArray;

    if-nez v0, :cond_1

    new-instance v0, Landroid/util/SparseArray;

    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    iput-object v0, p0, Landroid/support/v4/app/O;->mStateArray:Landroid/util/SparseArray;

    goto :goto_0

    :cond_1
    invoke-virtual {v0}, Landroid/util/SparseArray;->clear()V

    :goto_0
    iget-object v0, p1, Landroid/support/v4/app/n;->He:Landroid/view/View;

    iget-object v1, p0, Landroid/support/v4/app/O;->mStateArray:Landroid/util/SparseArray;

    invoke-virtual {v0, v1}, Landroid/view/View;->saveHierarchyState(Landroid/util/SparseArray;)V

    iget-object v0, p0, Landroid/support/v4/app/O;->mStateArray:Landroid/util/SparseArray;

    invoke-virtual {v0}, Landroid/util/SparseArray;->size()I

    move-result v0

    if-lez v0, :cond_2

    iget-object v0, p0, Landroid/support/v4/app/O;->mStateArray:Landroid/util/SparseArray;

    iput-object v0, p1, Landroid/support/v4/app/n;->mSavedViewState:Landroid/util/SparseArray;

    const/4 p1, 0x0

    iput-object p1, p0, Landroid/support/v4/app/O;->mStateArray:Landroid/util/SparseArray;

    :cond_2
    return-void
.end method

.method public l(Landroid/support/v4/app/n;)V
    .locals 3

    if-eqz p1, :cond_1

    iget-object v0, p0, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    iget v1, p1, Landroid/support/v4/app/n;->mIndex:I

    invoke-virtual {v0, v1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    if-ne v0, p1, :cond_0

    iget-object v0, p1, Landroid/support/v4/app/n;->mHost:Landroid/support/v4/app/u;

    if-eqz v0, :cond_1

    .line 1
    iget-object v0, p1, Landroid/support/v4/app/n;->mFragmentManager:Landroid/support/v4/app/O;

    if-ne v0, p0, :cond_0

    goto :goto_0

    .line 2
    :cond_0
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Fragment "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p1, " is not an active fragment of FragmentManager "

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1
    :goto_0
    iput-object p1, p0, Landroid/support/v4/app/O;->mPrimaryNav:Landroid/support/v4/app/n;

    return-void
.end method

.method public m(Landroid/support/v4/app/n;)V
    .locals 0

    iget-boolean p0, p1, Landroid/support/v4/app/n;->mHidden:Z

    if-eqz p0, :cond_0

    const/4 p0, 0x0

    iput-boolean p0, p1, Landroid/support/v4/app/n;->mHidden:Z

    iget-boolean p0, p1, Landroid/support/v4/app/n;->mHiddenChanged:Z

    xor-int/lit8 p0, p0, 0x1

    iput-boolean p0, p1, Landroid/support/v4/app/n;->mHiddenChanged:Z

    :cond_0
    return-void
.end method

.method moveToState(IZ)V
    .locals 3

    iget-object v0, p0, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    if-nez v0, :cond_1

    if-nez p1, :cond_0

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "No activity"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    :goto_0
    if-nez p2, :cond_2

    iget p2, p0, Landroid/support/v4/app/O;->mCurState:I

    if-ne p1, p2, :cond_2

    return-void

    :cond_2
    iput p1, p0, Landroid/support/v4/app/O;->mCurState:I

    iget-object p1, p0, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    if-eqz p1, :cond_7

    iget-object p1, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    const/4 p2, 0x0

    move v0, p2

    :goto_1
    if-ge v0, p1, :cond_3

    iget-object v1, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/support/v4/app/n;

    invoke-virtual {p0, v1}, Landroid/support/v4/app/O;->i(Landroid/support/v4/app/n;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_3
    iget-object p1, p0, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    invoke-virtual {p1}, Landroid/util/SparseArray;->size()I

    move-result p1

    move v0, p2

    :goto_2
    if-ge v0, p1, :cond_6

    iget-object v1, p0, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    invoke-virtual {v1, v0}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/support/v4/app/n;

    if-eqz v1, :cond_5

    iget-boolean v2, v1, Landroid/support/v4/app/n;->mRemoving:Z

    if-nez v2, :cond_4

    iget-boolean v2, v1, Landroid/support/v4/app/n;->mDetached:Z

    if-eqz v2, :cond_5

    :cond_4
    iget-boolean v2, v1, Landroid/support/v4/app/n;->mIsNewlyAdded:Z

    if-nez v2, :cond_5

    invoke-virtual {p0, v1}, Landroid/support/v4/app/O;->i(Landroid/support/v4/app/n;)V

    :cond_5
    add-int/lit8 v0, v0, 0x1

    goto :goto_2

    :cond_6
    invoke-virtual {p0}, Landroid/support/v4/app/O;->startPendingDeferredFragments()V

    iget-boolean p1, p0, Landroid/support/v4/app/O;->mNeedMenuInvalidate:Z

    if-eqz p1, :cond_7

    iget-object p1, p0, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    if-eqz p1, :cond_7

    iget v0, p0, Landroid/support/v4/app/O;->mCurState:I

    const/4 v1, 0x5

    if-ne v0, v1, :cond_7

    check-cast p1, Landroid/support/v4/app/p;

    .line 1
    iget-object p1, p1, Landroid/support/v4/app/p;->n:Landroid/support/v4/app/r;

    invoke-virtual {p1}, Landroid/support/v4/app/r;->X()V

    .line 2
    iput-boolean p2, p0, Landroid/support/v4/app/O;->mNeedMenuInvalidate:Z

    :cond_7
    return-void
.end method

.method public noteStateNotSaved()V
    .locals 3

    const/4 v0, 0x0

    iput-object v0, p0, Landroid/support/v4/app/O;->mSavedNonConfig:Landroid/support/v4/app/P;

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/support/v4/app/O;->mStateSaved:Z

    iput-boolean v0, p0, Landroid/support/v4/app/O;->mStopped:Z

    iget-object v1, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    :goto_0
    if-ge v0, v1, :cond_1

    iget-object v2, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/support/v4/app/n;

    if-eqz v2, :cond_0

    .line 1
    iget-object v2, v2, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    if-eqz v2, :cond_0

    invoke-virtual {v2}, Landroid/support/v4/app/O;->noteStateNotSaved()V

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method public onCreateView(Landroid/view/View;Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;
    .locals 13

    move-object v0, p0

    move-object/from16 v1, p3

    move-object/from16 v2, p4

    const-string v3, "fragment"

    move-object v4, p2

    invoke-virtual {v3, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v4, 0x0

    if-nez v3, :cond_0

    return-object v4

    :cond_0
    const-string v3, "class"

    invoke-interface {v2, v4, v3}, Landroid/util/AttributeSet;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    sget-object v5, Landroid/support/v4/app/L;->Fragment:[I

    invoke-virtual {v1, v2, v5}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object v5

    const/4 v6, 0x0

    if-nez v3, :cond_1

    invoke-virtual {v5, v6}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v3

    :cond_1
    move-object v7, v3

    const/4 v3, 0x1

    const/4 v8, -0x1

    invoke-virtual {v5, v3, v8}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v9

    const/4 v10, 0x2

    invoke-virtual {v5, v10}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v5}, Landroid/content/res/TypedArray;->recycle()V

    iget-object v5, v0, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    invoke-virtual {v5}, Landroid/support/v4/app/u;->getContext()Landroid/content/Context;

    move-result-object v5

    invoke-static {v5, v7}, Landroid/support/v4/app/n;->b(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v5

    if-nez v5, :cond_2

    return-object v4

    :cond_2
    if-eqz p1, :cond_3

    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v6

    :cond_3
    if-ne v6, v8, :cond_5

    if-ne v9, v8, :cond_5

    if-eqz v10, :cond_4

    goto :goto_0

    :cond_4
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-interface/range {p4 .. p4}, Landroid/util/AttributeSet;->getPositionDescription()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ": Must specify unique android:id, android:tag, or have a parent with an id for "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_5
    :goto_0
    if-eq v9, v8, :cond_6

    invoke-virtual {p0, v9}, Landroid/support/v4/app/O;->findFragmentById(I)Landroid/support/v4/app/n;

    move-result-object v5

    goto :goto_1

    :cond_6
    move-object v5, v4

    :goto_1
    if-nez v5, :cond_b

    if-eqz v10, :cond_b

    .line 1
    iget-object v5, v0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    add-int/2addr v5, v8

    :goto_2
    if-ltz v5, :cond_8

    iget-object v11, v0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v11, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Landroid/support/v4/app/n;

    if-eqz v11, :cond_7

    iget-object v12, v11, Landroid/support/v4/app/n;->mTag:Ljava/lang/String;

    invoke-virtual {v10, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_7

    goto :goto_4

    :cond_7
    add-int/lit8 v5, v5, -0x1

    goto :goto_2

    :cond_8
    iget-object v5, v0, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    if-eqz v5, :cond_a

    invoke-virtual {v5}, Landroid/util/SparseArray;->size()I

    move-result v5

    add-int/2addr v5, v8

    :goto_3
    if-ltz v5, :cond_a

    iget-object v11, v0, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    invoke-virtual {v11, v5}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Landroid/support/v4/app/n;

    if-eqz v11, :cond_9

    iget-object v12, v11, Landroid/support/v4/app/n;->mTag:Ljava/lang/String;

    invoke-virtual {v10, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_9

    goto :goto_4

    :cond_9
    add-int/lit8 v5, v5, -0x1

    goto :goto_3

    :cond_a
    move-object v11, v4

    goto :goto_4

    :cond_b
    move-object v11, v5

    :goto_4
    if-nez v11, :cond_c

    if-eq v6, v8, :cond_c

    .line 2
    invoke-virtual {p0, v6}, Landroid/support/v4/app/O;->findFragmentById(I)Landroid/support/v4/app/n;

    move-result-object v11

    :cond_c
    if-nez v11, :cond_e

    iget-object v5, v0, Landroid/support/v4/app/O;->mContainer:Landroid/support/v4/app/s;

    invoke-virtual {v5, v1, v7, v4}, Landroid/support/v4/app/s;->instantiate(Landroid/content/Context;Ljava/lang/String;Landroid/os/Bundle;)Landroid/support/v4/app/n;

    move-result-object v1

    iput-boolean v3, v1, Landroid/support/v4/app/n;->mFromLayout:Z

    if-eqz v9, :cond_d

    move v4, v9

    goto :goto_5

    :cond_d
    move v4, v6

    :goto_5
    iput v4, v1, Landroid/support/v4/app/n;->mFragmentId:I

    iput v6, v1, Landroid/support/v4/app/n;->mContainerId:I

    iput-object v10, v1, Landroid/support/v4/app/n;->mTag:Ljava/lang/String;

    iput-boolean v3, v1, Landroid/support/v4/app/n;->mInLayout:Z

    iput-object v0, v1, Landroid/support/v4/app/n;->mFragmentManager:Landroid/support/v4/app/O;

    iget-object v4, v0, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    iput-object v4, v1, Landroid/support/v4/app/n;->mHost:Landroid/support/v4/app/u;

    invoke-virtual {v4}, Landroid/support/v4/app/u;->getContext()Landroid/content/Context;

    move-result-object v4

    iget-object v5, v1, Landroid/support/v4/app/n;->mSavedFragmentState:Landroid/os/Bundle;

    invoke-virtual {v1, v4, v2, v5}, Landroid/support/v4/app/n;->onInflate(Landroid/content/Context;Landroid/util/AttributeSet;Landroid/os/Bundle;)V

    invoke-virtual {p0, v1, v3}, Landroid/support/v4/app/O;->a(Landroid/support/v4/app/n;Z)V

    move-object v11, v1

    goto :goto_6

    :cond_e
    iget-boolean v1, v11, Landroid/support/v4/app/n;->mInLayout:Z

    if-nez v1, :cond_14

    iput-boolean v3, v11, Landroid/support/v4/app/n;->mInLayout:Z

    iget-object v1, v0, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    iput-object v1, v11, Landroid/support/v4/app/n;->mHost:Landroid/support/v4/app/u;

    iget-boolean v4, v11, Landroid/support/v4/app/n;->mRetaining:Z

    if-nez v4, :cond_f

    invoke-virtual {v1}, Landroid/support/v4/app/u;->getContext()Landroid/content/Context;

    move-result-object v1

    iget-object v4, v11, Landroid/support/v4/app/n;->mSavedFragmentState:Landroid/os/Bundle;

    invoke-virtual {v11, v1, v2, v4}, Landroid/support/v4/app/n;->onInflate(Landroid/content/Context;Landroid/util/AttributeSet;Landroid/os/Bundle;)V

    :cond_f
    :goto_6
    iget v1, v0, Landroid/support/v4/app/O;->mCurState:I

    if-ge v1, v3, :cond_10

    iget-boolean v1, v11, Landroid/support/v4/app/n;->mFromLayout:Z

    if-eqz v1, :cond_10

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    move-object v0, p0

    move-object v1, v11

    invoke-virtual/range {v0 .. v5}, Landroid/support/v4/app/O;->a(Landroid/support/v4/app/n;IIIZ)V

    goto :goto_7

    .line 3
    :cond_10
    iget v2, v0, Landroid/support/v4/app/O;->mCurState:I

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    move-object v0, p0

    move-object v1, v11

    invoke-virtual/range {v0 .. v5}, Landroid/support/v4/app/O;->a(Landroid/support/v4/app/n;IIIZ)V

    .line 4
    :goto_7
    iget-object v0, v11, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    if-eqz v0, :cond_13

    if-eqz v9, :cond_11

    invoke-virtual {v0, v9}, Landroid/view/View;->setId(I)V

    :cond_11
    iget-object v0, v11, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_12

    iget-object v0, v11, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    invoke-virtual {v0, v10}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    :cond_12
    iget-object v0, v11, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    return-object v0

    :cond_13
    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Fragment "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, " did not create a view."

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_14
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-interface/range {p4 .. p4}, Landroid/util/AttributeSet;->getPositionDescription()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ": Duplicate id 0x"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v9}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ", tag "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ", or parent id 0x"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v6}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, " with another fragment for "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public onCreateView(Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;
    .locals 1

    const/4 v0, 0x0

    invoke-virtual {p0, v0, p1, p2, p3}, Landroid/support/v4/app/O;->onCreateView(Landroid/view/View;Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;

    move-result-object p0

    return-object p0
.end method

.method public popBackStackImmediate()Z
    .locals 6

    invoke-direct {p0}, Landroid/support/v4/app/O;->Rf()V

    .line 1
    invoke-virtual {p0}, Landroid/support/v4/app/O;->execPendingActions()Z

    const/4 v0, 0x1

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    invoke-direct {p0, v0}, Landroid/support/v4/app/O;->W(Z)V

    iget-object v2, p0, Landroid/support/v4/app/O;->mPrimaryNav:Landroid/support/v4/app/n;

    if-eqz v2, :cond_0

    invoke-virtual {v2}, Landroid/support/v4/app/n;->ra()Landroid/support/v4/app/y;

    move-result-object v2

    if-eqz v2, :cond_0

    invoke-virtual {v2}, Landroid/support/v4/app/y;->popBackStackImmediate()Z

    move-result v2

    if-eqz v2, :cond_0

    goto :goto_2

    :cond_0
    iget-object v2, p0, Landroid/support/v4/app/O;->mTmpRecords:Ljava/util/ArrayList;

    iget-object v3, p0, Landroid/support/v4/app/O;->mTmpIsPop:Ljava/util/ArrayList;

    .line 2
    iget-object v4, p0, Landroid/support/v4/app/O;->mBackStack:Ljava/util/ArrayList;

    const/4 v5, 0x0

    if-nez v4, :cond_1

    goto :goto_0

    :cond_1
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    sub-int/2addr v4, v0

    if-gez v4, :cond_2

    goto :goto_0

    :cond_2
    iget-object v5, p0, Landroid/support/v4/app/O;->mBackStack:Ljava/util/ArrayList;

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move v5, v0

    :goto_0
    if-eqz v5, :cond_3

    .line 3
    iput-boolean v0, p0, Landroid/support/v4/app/O;->mExecutingActions:Z

    :try_start_0
    iget-object v0, p0, Landroid/support/v4/app/O;->mTmpRecords:Ljava/util/ArrayList;

    iget-object v1, p0, Landroid/support/v4/app/O;->mTmpIsPop:Ljava/util/ArrayList;

    invoke-direct {p0, v0, v1}, Landroid/support/v4/app/O;->c(Ljava/util/ArrayList;Ljava/util/ArrayList;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-direct {p0}, Landroid/support/v4/app/O;->Sf()V

    goto :goto_1

    :catchall_0
    move-exception v0

    invoke-direct {p0}, Landroid/support/v4/app/O;->Sf()V

    throw v0

    :cond_3
    :goto_1
    invoke-virtual {p0}, Landroid/support/v4/app/O;->doPendingDeferredStart()V

    invoke-direct {p0}, Landroid/support/v4/app/O;->Qf()V

    move v0, v5

    :goto_2
    return v0
.end method

.method retainNonConfig()Landroid/support/v4/app/P;
    .locals 1

    iget-object v0, p0, Landroid/support/v4/app/O;->mSavedNonConfig:Landroid/support/v4/app/P;

    invoke-static {v0}, Landroid/support/v4/app/O;->a(Landroid/support/v4/app/P;)V

    iget-object p0, p0, Landroid/support/v4/app/O;->mSavedNonConfig:Landroid/support/v4/app/P;

    return-object p0
.end method

.method public sa()V
    .locals 1

    const/4 v0, 0x2

    invoke-direct {p0, v0}, Landroid/support/v4/app/O;->La(I)V

    return-void
.end method

.method saveAllState()Landroid/os/Parcelable;
    .locals 11

    .line 1
    iget-object v0, p0, Landroid/support/v4/app/O;->mPostponedTransactions:Ljava/util/ArrayList;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    :goto_0
    iget-object v0, p0, Landroid/support/v4/app/O;->mPostponedTransactions:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Landroid/support/v4/app/O;->mPostponedTransactions:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v4/app/N;

    invoke-virtual {v0}, Landroid/support/v4/app/N;->completeTransaction()V

    goto :goto_0

    .line 2
    :cond_0
    iget-object v0, p0, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    if-nez v0, :cond_1

    move v0, v1

    move v2, v0

    goto :goto_1

    :cond_1
    invoke-virtual {v0}, Landroid/util/SparseArray;->size()I

    move-result v0

    move v2, v0

    move v0, v1

    :goto_1
    const/4 v3, 0x0

    if-ge v0, v2, :cond_5

    iget-object v4, p0, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    invoke-virtual {v4, v0}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v4

    move-object v6, v4

    check-cast v6, Landroid/support/v4/app/n;

    if-eqz v6, :cond_4

    invoke-virtual {v6}, Landroid/support/v4/app/n;->getAnimatingAway()Landroid/view/View;

    move-result-object v4

    if-eqz v4, :cond_3

    invoke-virtual {v6}, Landroid/support/v4/app/n;->getStateAfterAnimating()I

    move-result v7

    invoke-virtual {v6}, Landroid/support/v4/app/n;->getAnimatingAway()Landroid/view/View;

    move-result-object v4

    invoke-virtual {v4}, Landroid/view/View;->getAnimation()Landroid/view/animation/Animation;

    move-result-object v5

    if-eqz v5, :cond_2

    invoke-virtual {v5}, Landroid/view/animation/Animation;->cancel()V

    invoke-virtual {v4}, Landroid/view/View;->clearAnimation()V

    :cond_2
    invoke-virtual {v6, v3}, Landroid/support/v4/app/n;->i(Landroid/view/View;)V

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    move-object v5, p0

    invoke-virtual/range {v5 .. v10}, Landroid/support/v4/app/O;->a(Landroid/support/v4/app/n;IIIZ)V

    goto :goto_2

    :cond_3
    invoke-virtual {v6}, Landroid/support/v4/app/n;->getAnimator()Landroid/animation/Animator;

    move-result-object v3

    if-eqz v3, :cond_4

    invoke-virtual {v6}, Landroid/support/v4/app/n;->getAnimator()Landroid/animation/Animator;

    move-result-object v3

    invoke-virtual {v3}, Landroid/animation/Animator;->end()V

    :cond_4
    :goto_2
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    .line 3
    :cond_5
    invoke-virtual {p0}, Landroid/support/v4/app/O;->execPendingActions()Z

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v4/app/O;->mStateSaved:Z

    iput-object v3, p0, Landroid/support/v4/app/O;->mSavedNonConfig:Landroid/support/v4/app/P;

    iget-object v2, p0, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    if-eqz v2, :cond_1c

    invoke-virtual {v2}, Landroid/util/SparseArray;->size()I

    move-result v2

    if-gtz v2, :cond_6

    goto/16 :goto_9

    :cond_6
    iget-object v2, p0, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    invoke-virtual {v2}, Landroid/util/SparseArray;->size()I

    move-result v2

    new-array v4, v2, [Landroid/support/v4/app/FragmentState;

    move v5, v1

    move v6, v5

    :goto_3
    const-string v7, " has cleared index: "

    const-string v8, "Failure saving state: active "

    if-ge v5, v2, :cond_15

    iget-object v9, p0, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    invoke-virtual {v9, v5}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Landroid/support/v4/app/n;

    if-eqz v9, :cond_14

    iget v6, v9, Landroid/support/v4/app/n;->mIndex:I

    if-ltz v6, :cond_13

    new-instance v6, Landroid/support/v4/app/FragmentState;

    invoke-direct {v6, v9}, Landroid/support/v4/app/FragmentState;-><init>(Landroid/support/v4/app/n;)V

    aput-object v6, v4, v5

    iget v7, v9, Landroid/support/v4/app/n;->mState:I

    if-lez v7, :cond_11

    iget-object v7, v6, Landroid/support/v4/app/FragmentState;->mSavedFragmentState:Landroid/os/Bundle;

    if-nez v7, :cond_11

    .line 4
    iget-object v7, p0, Landroid/support/v4/app/O;->mStateBundle:Landroid/os/Bundle;

    if-nez v7, :cond_7

    new-instance v7, Landroid/os/Bundle;

    invoke-direct {v7}, Landroid/os/Bundle;-><init>()V

    iput-object v7, p0, Landroid/support/v4/app/O;->mStateBundle:Landroid/os/Bundle;

    :cond_7
    iget-object v7, p0, Landroid/support/v4/app/O;->mStateBundle:Landroid/os/Bundle;

    invoke-virtual {v9, v7}, Landroid/support/v4/app/n;->performSaveInstanceState(Landroid/os/Bundle;)V

    iget-object v7, p0, Landroid/support/v4/app/O;->mStateBundle:Landroid/os/Bundle;

    invoke-virtual {p0, v9, v7, v1}, Landroid/support/v4/app/O;->d(Landroid/support/v4/app/n;Landroid/os/Bundle;Z)V

    iget-object v7, p0, Landroid/support/v4/app/O;->mStateBundle:Landroid/os/Bundle;

    invoke-virtual {v7}, Landroid/os/Bundle;->isEmpty()Z

    move-result v7

    if-nez v7, :cond_8

    iget-object v7, p0, Landroid/support/v4/app/O;->mStateBundle:Landroid/os/Bundle;

    iput-object v3, p0, Landroid/support/v4/app/O;->mStateBundle:Landroid/os/Bundle;

    goto :goto_4

    :cond_8
    move-object v7, v3

    :goto_4
    iget-object v8, v9, Landroid/support/v4/app/n;->mView:Landroid/view/View;

    if-eqz v8, :cond_9

    invoke-virtual {p0, v9}, Landroid/support/v4/app/O;->k(Landroid/support/v4/app/n;)V

    :cond_9
    iget-object v8, v9, Landroid/support/v4/app/n;->mSavedViewState:Landroid/util/SparseArray;

    if-eqz v8, :cond_b

    if-nez v7, :cond_a

    new-instance v7, Landroid/os/Bundle;

    invoke-direct {v7}, Landroid/os/Bundle;-><init>()V

    :cond_a
    iget-object v8, v9, Landroid/support/v4/app/n;->mSavedViewState:Landroid/util/SparseArray;

    const-string v10, "android:view_state"

    invoke-virtual {v7, v10, v8}, Landroid/os/Bundle;->putSparseParcelableArray(Ljava/lang/String;Landroid/util/SparseArray;)V

    :cond_b
    iget-boolean v8, v9, Landroid/support/v4/app/n;->mUserVisibleHint:Z

    if-nez v8, :cond_d

    if-nez v7, :cond_c

    new-instance v7, Landroid/os/Bundle;

    invoke-direct {v7}, Landroid/os/Bundle;-><init>()V

    :cond_c
    iget-boolean v8, v9, Landroid/support/v4/app/n;->mUserVisibleHint:Z

    const-string v10, "android:user_visible_hint"

    invoke-virtual {v7, v10, v8}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 5
    :cond_d
    iput-object v7, v6, Landroid/support/v4/app/FragmentState;->mSavedFragmentState:Landroid/os/Bundle;

    iget-object v7, v9, Landroid/support/v4/app/n;->mTarget:Landroid/support/v4/app/n;

    if-eqz v7, :cond_12

    iget v7, v7, Landroid/support/v4/app/n;->mIndex:I

    if-ltz v7, :cond_10

    iget-object v7, v6, Landroid/support/v4/app/FragmentState;->mSavedFragmentState:Landroid/os/Bundle;

    if-nez v7, :cond_e

    new-instance v7, Landroid/os/Bundle;

    invoke-direct {v7}, Landroid/os/Bundle;-><init>()V

    iput-object v7, v6, Landroid/support/v4/app/FragmentState;->mSavedFragmentState:Landroid/os/Bundle;

    :cond_e
    iget-object v7, v6, Landroid/support/v4/app/FragmentState;->mSavedFragmentState:Landroid/os/Bundle;

    iget-object v8, v9, Landroid/support/v4/app/n;->mTarget:Landroid/support/v4/app/n;

    .line 6
    iget v10, v8, Landroid/support/v4/app/n;->mIndex:I

    if-ltz v10, :cond_f

    const-string v8, "android:target_state"

    invoke-virtual {v7, v8, v10}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    .line 7
    iget v7, v9, Landroid/support/v4/app/n;->mTargetRequestCode:I

    if-eqz v7, :cond_12

    iget-object v6, v6, Landroid/support/v4/app/FragmentState;->mSavedFragmentState:Landroid/os/Bundle;

    const-string v8, "android:target_req_state"

    invoke-virtual {v6, v8, v7}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    goto :goto_5

    .line 8
    :cond_f
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "Fragment "

    const-string v2, " is not currently in the FragmentManager"

    invoke-static {v1, v8, v2}, Lb/a/a/a/a;->a(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    invoke-direct {p0, v0}, Landroid/support/v4/app/O;->a(Ljava/lang/RuntimeException;)V

    throw v3

    .line 9
    :cond_10
    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Failure saving state: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v2, " has target not in fragment manager: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, v9, Landroid/support/v4/app/n;->mTarget:Landroid/support/v4/app/n;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    invoke-direct {p0, v0}, Landroid/support/v4/app/O;->a(Ljava/lang/RuntimeException;)V

    throw v3

    :cond_11
    iget-object v7, v9, Landroid/support/v4/app/n;->mSavedFragmentState:Landroid/os/Bundle;

    iput-object v7, v6, Landroid/support/v4/app/FragmentState;->mSavedFragmentState:Landroid/os/Bundle;

    :cond_12
    :goto_5
    move v6, v0

    goto :goto_6

    :cond_13
    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, v9, Landroid/support/v4/app/n;->mIndex:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    invoke-direct {p0, v0}, Landroid/support/v4/app/O;->a(Ljava/lang/RuntimeException;)V

    throw v3

    :cond_14
    :goto_6
    add-int/lit8 v5, v5, 0x1

    goto/16 :goto_3

    :cond_15
    if-nez v6, :cond_16

    return-object v3

    :cond_16
    iget-object v0, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_18

    new-array v2, v0, [I

    move v5, v1

    :goto_7
    if-ge v5, v0, :cond_19

    iget-object v6, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroid/support/v4/app/n;

    iget v6, v6, Landroid/support/v4/app/n;->mIndex:I

    aput v6, v2, v5

    aget v6, v2, v5

    if-ltz v6, :cond_17

    add-int/lit8 v5, v5, 0x1

    goto :goto_7

    :cond_17
    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-static {v8}, Lb/a/a/a/a;->x(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v4, p0, Landroid/support/v4/app/O;->mAdded:Ljava/util/ArrayList;

    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget v2, v2, v5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    invoke-direct {p0, v0}, Landroid/support/v4/app/O;->a(Ljava/lang/RuntimeException;)V

    throw v3

    :cond_18
    move-object v2, v3

    :cond_19
    iget-object v0, p0, Landroid/support/v4/app/O;->mBackStack:Ljava/util/ArrayList;

    if-eqz v0, :cond_1a

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_1a

    new-array v3, v0, [Landroid/support/v4/app/BackStackState;

    :goto_8
    if-ge v1, v0, :cond_1a

    new-instance v5, Landroid/support/v4/app/BackStackState;

    iget-object v6, p0, Landroid/support/v4/app/O;->mBackStack:Ljava/util/ArrayList;

    invoke-virtual {v6, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroid/support/v4/app/e;

    invoke-direct {v5, v6}, Landroid/support/v4/app/BackStackState;-><init>(Landroid/support/v4/app/e;)V

    aput-object v5, v3, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_8

    :cond_1a
    new-instance v0, Landroid/support/v4/app/FragmentManagerState;

    invoke-direct {v0}, Landroid/support/v4/app/FragmentManagerState;-><init>()V

    iput-object v4, v0, Landroid/support/v4/app/FragmentManagerState;->mActive:[Landroid/support/v4/app/FragmentState;

    iput-object v2, v0, Landroid/support/v4/app/FragmentManagerState;->mAdded:[I

    iput-object v3, v0, Landroid/support/v4/app/FragmentManagerState;->mBackStack:[Landroid/support/v4/app/BackStackState;

    iget-object v1, p0, Landroid/support/v4/app/O;->mPrimaryNav:Landroid/support/v4/app/n;

    if-eqz v1, :cond_1b

    iget v1, v1, Landroid/support/v4/app/n;->mIndex:I

    iput v1, v0, Landroid/support/v4/app/FragmentManagerState;->mPrimaryNavActiveIndex:I

    :cond_1b
    iget v1, p0, Landroid/support/v4/app/O;->mNextFragmentIndex:I

    iput v1, v0, Landroid/support/v4/app/FragmentManagerState;->mNextFragmentIndex:I

    invoke-virtual {p0}, Landroid/support/v4/app/O;->saveNonConfig()V

    return-object v0

    :cond_1c
    :goto_9
    return-object v3
.end method

.method saveNonConfig()V
    .locals 9

    iget-object v0, p0, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    const/4 v1, 0x0

    if-eqz v0, :cond_8

    const/4 v0, 0x0

    move v2, v0

    move-object v3, v1

    move-object v4, v3

    move-object v5, v4

    :goto_0
    iget-object v6, p0, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    invoke-virtual {v6}, Landroid/util/SparseArray;->size()I

    move-result v6

    if-ge v2, v6, :cond_9

    iget-object v6, p0, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    invoke-virtual {v6, v2}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroid/support/v4/app/n;

    if-eqz v6, :cond_7

    iget-boolean v7, v6, Landroid/support/v4/app/n;->mRetainInstance:Z

    if-eqz v7, :cond_2

    if-nez v3, :cond_0

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    :cond_0
    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v7, v6, Landroid/support/v4/app/n;->mTarget:Landroid/support/v4/app/n;

    if-eqz v7, :cond_1

    iget v7, v7, Landroid/support/v4/app/n;->mIndex:I

    goto :goto_1

    :cond_1
    const/4 v7, -0x1

    :goto_1
    iput v7, v6, Landroid/support/v4/app/n;->mTargetIndex:I

    :cond_2
    iget-object v7, v6, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    if-eqz v7, :cond_3

    invoke-virtual {v7}, Landroid/support/v4/app/O;->saveNonConfig()V

    iget-object v7, v6, Landroid/support/v4/app/n;->mChildFragmentManager:Landroid/support/v4/app/O;

    iget-object v7, v7, Landroid/support/v4/app/O;->mSavedNonConfig:Landroid/support/v4/app/P;

    goto :goto_2

    :cond_3
    iget-object v7, v6, Landroid/support/v4/app/n;->mChildNonConfig:Landroid/support/v4/app/P;

    :goto_2
    if-nez v4, :cond_4

    if-eqz v7, :cond_4

    new-instance v4, Ljava/util/ArrayList;

    iget-object v8, p0, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    invoke-virtual {v8}, Landroid/util/SparseArray;->size()I

    move-result v8

    invoke-direct {v4, v8}, Ljava/util/ArrayList;-><init>(I)V

    move v8, v0

    :goto_3
    if-ge v8, v2, :cond_4

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v8, v8, 0x1

    goto :goto_3

    :cond_4
    if-eqz v4, :cond_5

    invoke-virtual {v4, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_5
    if-nez v5, :cond_6

    iget-object v7, v6, Landroid/support/v4/app/n;->Gc:Landroid/arch/lifecycle/r;

    if-eqz v7, :cond_6

    new-instance v5, Ljava/util/ArrayList;

    iget-object v7, p0, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    invoke-virtual {v7}, Landroid/util/SparseArray;->size()I

    move-result v7

    invoke-direct {v5, v7}, Ljava/util/ArrayList;-><init>(I)V

    move v7, v0

    :goto_4
    if-ge v7, v2, :cond_6

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v7, v7, 0x1

    goto :goto_4

    :cond_6
    if-eqz v5, :cond_7

    iget-object v6, v6, Landroid/support/v4/app/n;->Gc:Landroid/arch/lifecycle/r;

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_7
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_8
    move-object v3, v1

    move-object v4, v3

    move-object v5, v4

    :cond_9
    if-nez v3, :cond_a

    if-nez v4, :cond_a

    if-nez v5, :cond_a

    iput-object v1, p0, Landroid/support/v4/app/O;->mSavedNonConfig:Landroid/support/v4/app/P;

    goto :goto_5

    :cond_a
    new-instance v0, Landroid/support/v4/app/P;

    invoke-direct {v0, v3, v4, v5}, Landroid/support/v4/app/P;-><init>(Ljava/util/List;Ljava/util/List;Ljava/util/List;)V

    iput-object v0, p0, Landroid/support/v4/app/O;->mSavedNonConfig:Landroid/support/v4/app/P;

    :goto_5
    return-void
.end method

.method startPendingDeferredFragments()V
    .locals 9

    iget-object v0, p0, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    if-nez v0, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x0

    move v1, v0

    :goto_0
    iget-object v2, p0, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    invoke-virtual {v2}, Landroid/util/SparseArray;->size()I

    move-result v2

    if-ge v1, v2, :cond_3

    iget-object v2, p0, Landroid/support/v4/app/O;->mActive:Landroid/util/SparseArray;

    invoke-virtual {v2, v1}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v2

    move-object v4, v2

    check-cast v4, Landroid/support/v4/app/n;

    if-eqz v4, :cond_2

    .line 1
    iget-boolean v2, v4, Landroid/support/v4/app/n;->mDeferStart:Z

    if-eqz v2, :cond_2

    iget-boolean v2, p0, Landroid/support/v4/app/O;->mExecutingActions:Z

    if-eqz v2, :cond_1

    const/4 v2, 0x1

    iput-boolean v2, p0, Landroid/support/v4/app/O;->mHavePendingDeferredStart:Z

    goto :goto_1

    :cond_1
    iput-boolean v0, v4, Landroid/support/v4/app/n;->mDeferStart:Z

    iget v5, p0, Landroid/support/v4/app/O;->mCurState:I

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    move-object v3, p0

    invoke-virtual/range {v3 .. v8}, Landroid/support/v4/app/O;->a(Landroid/support/v4/app/n;IIIZ)V

    :cond_2
    :goto_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_3
    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    const/16 v1, 0x80

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string v1, "FragmentManager{"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " in "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Landroid/support/v4/app/O;->mParent:Landroid/support/v4/app/n;

    if-eqz v1, :cond_0

    invoke-static {v1, v0}, La/b/a/a;->buildShortClassTag(Ljava/lang/Object;Ljava/lang/StringBuilder;)V

    goto :goto_0

    :cond_0
    iget-object p0, p0, Landroid/support/v4/app/O;->mHost:Landroid/support/v4/app/u;

    invoke-static {p0, v0}, La/b/a/a;->buildShortClassTag(Ljava/lang/Object;Ljava/lang/StringBuilder;)V

    :goto_0
    const-string p0, "}}"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
