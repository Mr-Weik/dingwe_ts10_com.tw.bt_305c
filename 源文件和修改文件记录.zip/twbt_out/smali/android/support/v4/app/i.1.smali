.class Landroid/support/v4/app/i;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic n:Landroid/support/v4/app/n;


# direct methods
.method constructor <init>(Landroid/support/v4/app/n;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v4/app/i;->n:Landroid/support/v4/app/n;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/i;->n:Landroid/support/v4/app/n;

    invoke-static {p0}, Landroid/support/v4/app/n;->b(Landroid/support/v4/app/n;)V

    return-void
.end method
