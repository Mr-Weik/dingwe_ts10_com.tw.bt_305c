.class Landroid/support/v4/app/k;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/arch/lifecycle/e;


# instance fields
.field final synthetic n:Landroid/support/v4/app/n;


# direct methods
.method constructor <init>(Landroid/support/v4/app/n;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v4/app/k;->n:Landroid/support/v4/app/n;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public y()Landroid/arch/lifecycle/c;
    .locals 3

    iget-object v0, p0, Landroid/support/v4/app/k;->n:Landroid/support/v4/app/n;

    invoke-static {v0}, Landroid/support/v4/app/n;->c(Landroid/support/v4/app/n;)Landroid/arch/lifecycle/g;

    move-result-object v0

    if-nez v0, :cond_0

    iget-object v0, p0, Landroid/support/v4/app/k;->n:Landroid/support/v4/app/n;

    new-instance v1, Landroid/arch/lifecycle/g;

    iget-object v2, v0, Landroid/support/v4/app/n;->Ke:Landroid/arch/lifecycle/e;

    invoke-direct {v1, v2}, Landroid/arch/lifecycle/g;-><init>(Landroid/arch/lifecycle/e;)V

    invoke-static {v0, v1}, Landroid/support/v4/app/n;->a(Landroid/support/v4/app/n;Landroid/arch/lifecycle/g;)Landroid/arch/lifecycle/g;

    :cond_0
    iget-object p0, p0, Landroid/support/v4/app/k;->n:Landroid/support/v4/app/n;

    invoke-static {p0}, Landroid/support/v4/app/n;->c(Landroid/support/v4/app/n;)Landroid/arch/lifecycle/g;

    move-result-object p0

    return-object p0
.end method
