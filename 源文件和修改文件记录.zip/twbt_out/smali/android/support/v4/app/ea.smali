.class Landroid/support/v4/app/ea;
.super Landroid/transition/Transition$EpicenterCallback;
.source ""


# instance fields
.field final synthetic jf:Landroid/graphics/Rect;


# direct methods
.method constructor <init>(Landroid/support/v4/app/fa;Landroid/graphics/Rect;)V
    .locals 0

    iput-object p2, p0, Landroid/support/v4/app/ea;->jf:Landroid/graphics/Rect;

    invoke-direct {p0}, Landroid/transition/Transition$EpicenterCallback;-><init>()V

    return-void
.end method


# virtual methods
.method public onGetEpicenter(Landroid/transition/Transition;)Landroid/graphics/Rect;
    .locals 0

    iget-object p1, p0, Landroid/support/v4/app/ea;->jf:Landroid/graphics/Rect;

    if-eqz p1, :cond_1

    invoke-virtual {p1}, Landroid/graphics/Rect;->isEmpty()Z

    move-result p1

    if-eqz p1, :cond_0

    goto :goto_0

    :cond_0
    iget-object p0, p0, Landroid/support/v4/app/ea;->jf:Landroid/graphics/Rect;

    return-object p0

    :cond_1
    :goto_0
    const/4 p0, 0x0

    return-object p0
.end method
