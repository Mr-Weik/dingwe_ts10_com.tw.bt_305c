.class Landroid/support/v4/app/B;
.super Landroid/support/v4/app/G;
.source ""


# instance fields
.field final synthetic j:Landroid/view/ViewGroup;

.field final synthetic m:Landroid/support/v4/app/n;

.field final synthetic n:Landroid/support/v4/app/O;


# direct methods
.method constructor <init>(Landroid/support/v4/app/O;Landroid/view/animation/Animation$AnimationListener;Landroid/view/ViewGroup;Landroid/support/v4/app/n;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v4/app/B;->n:Landroid/support/v4/app/O;

    iput-object p3, p0, Landroid/support/v4/app/B;->j:Landroid/view/ViewGroup;

    iput-object p4, p0, Landroid/support/v4/app/B;->m:Landroid/support/v4/app/n;

    const/4 p1, 0x0

    invoke-direct {p0, p2, p1}, Landroid/support/v4/app/G;-><init>(Landroid/view/animation/Animation$AnimationListener;Landroid/support/v4/app/z;)V

    return-void
.end method


# virtual methods
.method public onAnimationEnd(Landroid/view/animation/Animation;)V
    .locals 1

    invoke-super {p0, p1}, Landroid/support/v4/app/G;->onAnimationEnd(Landroid/view/animation/Animation;)V

    iget-object p1, p0, Landroid/support/v4/app/B;->j:Landroid/view/ViewGroup;

    new-instance v0, Landroid/support/v4/app/A;

    invoke-direct {v0, p0}, Landroid/support/v4/app/A;-><init>(Landroid/support/v4/app/B;)V

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->post(Ljava/lang/Runnable;)Z

    return-void
.end method
