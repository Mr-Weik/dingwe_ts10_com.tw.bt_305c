.class Landroid/support/v4/app/p;
.super Landroid/support/v4/app/u;
.source ""


# instance fields
.field final synthetic n:Landroid/support/v4/app/r;


# direct methods
.method public constructor <init>(Landroid/support/v4/app/r;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v4/app/p;->n:Landroid/support/v4/app/r;

    invoke-direct {p0, p1}, Landroid/support/v4/app/u;-><init>(Landroid/support/v4/app/r;)V

    return-void
.end method


# virtual methods
.method public onFindViewById(I)Landroid/view/View;
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/p;->n:Landroid/support/v4/app/r;

    invoke-virtual {p0, p1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object p0

    return-object p0
.end method

.method public onHasView()Z
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/p;->n:Landroid/support/v4/app/r;

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p0

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroid/view/Window;->peekDecorView()Landroid/view/View;

    move-result-object p0

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method
