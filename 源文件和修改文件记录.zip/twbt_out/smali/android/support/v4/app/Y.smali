.class final Landroid/support/v4/app/Y;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic Ze:Ljava/lang/Object;

.field final synthetic _e:Landroid/support/v4/app/ja;

.field final synthetic af:Landroid/view/View;

.field final synthetic bf:Landroid/support/v4/app/n;

.field final synthetic cf:Ljava/util/ArrayList;

.field final synthetic ff:Landroid/support/v4/app/n;

.field final synthetic gf:Z

.field final synthetic kf:La/b/c/f/b;

.field final synthetic lf:Ljava/lang/Object;

.field final synthetic mf:Landroid/support/v4/app/Z;

.field final synthetic nf:Ljava/util/ArrayList;

.field final synthetic of:Landroid/graphics/Rect;


# direct methods
.method constructor <init>(Landroid/support/v4/app/ja;La/b/c/f/b;Ljava/lang/Object;Landroid/support/v4/app/Z;Ljava/util/ArrayList;Landroid/view/View;Landroid/support/v4/app/n;Landroid/support/v4/app/n;ZLjava/util/ArrayList;Ljava/lang/Object;Landroid/graphics/Rect;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v4/app/Y;->_e:Landroid/support/v4/app/ja;

    iput-object p2, p0, Landroid/support/v4/app/Y;->kf:La/b/c/f/b;

    iput-object p3, p0, Landroid/support/v4/app/Y;->lf:Ljava/lang/Object;

    iput-object p4, p0, Landroid/support/v4/app/Y;->mf:Landroid/support/v4/app/Z;

    iput-object p5, p0, Landroid/support/v4/app/Y;->cf:Ljava/util/ArrayList;

    iput-object p6, p0, Landroid/support/v4/app/Y;->af:Landroid/view/View;

    iput-object p7, p0, Landroid/support/v4/app/Y;->bf:Landroid/support/v4/app/n;

    iput-object p8, p0, Landroid/support/v4/app/Y;->ff:Landroid/support/v4/app/n;

    iput-boolean p9, p0, Landroid/support/v4/app/Y;->gf:Z

    iput-object p10, p0, Landroid/support/v4/app/Y;->nf:Ljava/util/ArrayList;

    iput-object p11, p0, Landroid/support/v4/app/Y;->Ze:Ljava/lang/Object;

    iput-object p12, p0, Landroid/support/v4/app/Y;->of:Landroid/graphics/Rect;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    iget-object v0, p0, Landroid/support/v4/app/Y;->_e:Landroid/support/v4/app/ja;

    iget-object v1, p0, Landroid/support/v4/app/Y;->kf:La/b/c/f/b;

    iget-object v2, p0, Landroid/support/v4/app/Y;->lf:Ljava/lang/Object;

    iget-object v3, p0, Landroid/support/v4/app/Y;->mf:Landroid/support/v4/app/Z;

    invoke-static {v0, v1, v2, v3}, Landroid/support/v4/app/aa;->a(Landroid/support/v4/app/ja;La/b/c/f/b;Ljava/lang/Object;Landroid/support/v4/app/Z;)La/b/c/f/b;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-object v1, p0, Landroid/support/v4/app/Y;->cf:Ljava/util/ArrayList;

    invoke-virtual {v0}, La/b/c/f/b;->values()Ljava/util/Collection;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    iget-object v1, p0, Landroid/support/v4/app/Y;->cf:Ljava/util/ArrayList;

    iget-object v2, p0, Landroid/support/v4/app/Y;->af:Landroid/view/View;

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    iget-object v1, p0, Landroid/support/v4/app/Y;->bf:Landroid/support/v4/app/n;

    iget-object v2, p0, Landroid/support/v4/app/Y;->ff:Landroid/support/v4/app/n;

    iget-boolean v3, p0, Landroid/support/v4/app/Y;->gf:Z

    const/4 v4, 0x0

    invoke-static {v1, v2, v3, v0, v4}, Landroid/support/v4/app/aa;->a(Landroid/support/v4/app/n;Landroid/support/v4/app/n;ZLa/b/c/f/b;Z)V

    iget-object v1, p0, Landroid/support/v4/app/Y;->lf:Ljava/lang/Object;

    if-eqz v1, :cond_1

    iget-object v2, p0, Landroid/support/v4/app/Y;->_e:Landroid/support/v4/app/ja;

    iget-object v3, p0, Landroid/support/v4/app/Y;->nf:Ljava/util/ArrayList;

    iget-object v4, p0, Landroid/support/v4/app/Y;->cf:Ljava/util/ArrayList;

    invoke-virtual {v2, v1, v3, v4}, Landroid/support/v4/app/ja;->b(Ljava/lang/Object;Ljava/util/ArrayList;Ljava/util/ArrayList;)V

    iget-object v1, p0, Landroid/support/v4/app/Y;->mf:Landroid/support/v4/app/Z;

    iget-object v2, p0, Landroid/support/v4/app/Y;->Ze:Ljava/lang/Object;

    iget-boolean v3, p0, Landroid/support/v4/app/Y;->gf:Z

    invoke-static {v0, v1, v2, v3}, Landroid/support/v4/app/aa;->a(La/b/c/f/b;Landroid/support/v4/app/Z;Ljava/lang/Object;Z)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_1

    iget-object v1, p0, Landroid/support/v4/app/Y;->_e:Landroid/support/v4/app/ja;

    iget-object p0, p0, Landroid/support/v4/app/Y;->of:Landroid/graphics/Rect;

    invoke-virtual {v1, v0, p0}, Landroid/support/v4/app/ja;->a(Landroid/view/View;Landroid/graphics/Rect;)V

    :cond_1
    return-void
.end method
