.class Landroid/support/v4/app/o;
.super Landroid/os/Handler;
.source ""


# instance fields
.field final synthetic n:Landroid/support/v4/app/r;


# direct methods
.method constructor <init>(Landroid/support/v4/app/r;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v4/app/o;->n:Landroid/support/v4/app/r;

    invoke-direct {p0}, Landroid/os/Handler;-><init>()V

    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)V
    .locals 2

    iget v0, p1, Landroid/os/Message;->what:I

    const/4 v1, 0x1

    if-eq v0, v1, :cond_1

    const/4 v1, 0x2

    if-eq v0, v1, :cond_0

    invoke-super {p0, p1}, Landroid/os/Handler;->handleMessage(Landroid/os/Message;)V

    goto :goto_0

    :cond_0
    iget-object p1, p0, Landroid/support/v4/app/o;->n:Landroid/support/v4/app/r;

    invoke-virtual {p1}, Landroid/support/v4/app/r;->V()V

    iget-object p0, p0, Landroid/support/v4/app/o;->n:Landroid/support/v4/app/r;

    iget-object p0, p0, Landroid/support/v4/app/r;->mFragments:Landroid/support/v4/app/t;

    invoke-virtual {p0}, Landroid/support/v4/app/t;->execPendingActions()Z

    goto :goto_0

    :cond_1
    iget-object p0, p0, Landroid/support/v4/app/o;->n:Landroid/support/v4/app/r;

    iget-boolean p1, p0, Landroid/support/v4/app/r;->mStopped:Z

    if-eqz p1, :cond_2

    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Landroid/support/v4/app/r;->v(Z)V

    :cond_2
    :goto_0
    return-void
.end method
