.class public interface abstract Landroid/support/v4/app/h;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract getWrapper()Ljava/lang/Object;
.end method
