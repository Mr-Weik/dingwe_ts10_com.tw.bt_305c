.class public abstract Landroid/support/v4/app/u;
.super Landroid/support/v4/app/s;
.source ""


# instance fields
.field private final mActivity:Landroid/app/Activity;

.field private final mContext:Landroid/content/Context;

.field final mFragmentManager:Landroid/support/v4/app/O;

.field private final mHandler:Landroid/os/Handler;


# direct methods
.method constructor <init>(Landroid/support/v4/app/r;)V
    .locals 2

    iget-object v0, p1, Landroid/support/v4/app/r;->mHandler:Landroid/os/Handler;

    .line 1
    invoke-direct {p0}, Landroid/support/v4/app/s;-><init>()V

    new-instance v1, Landroid/support/v4/app/O;

    invoke-direct {v1}, Landroid/support/v4/app/O;-><init>()V

    iput-object v1, p0, Landroid/support/v4/app/u;->mFragmentManager:Landroid/support/v4/app/O;

    iput-object p1, p0, Landroid/support/v4/app/u;->mActivity:Landroid/app/Activity;

    const-string v1, "context == null"

    invoke-static {p1, v1}, La/b/a/a;->checkNotNull(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iput-object p1, p0, Landroid/support/v4/app/u;->mContext:Landroid/content/Context;

    const-string p1, "handler == null"

    invoke-static {v0, p1}, La/b/a/a;->checkNotNull(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iput-object v0, p0, Landroid/support/v4/app/u;->mHandler:Landroid/os/Handler;

    return-void
.end method


# virtual methods
.method getActivity()Landroid/app/Activity;
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/u;->mActivity:Landroid/app/Activity;

    return-object p0
.end method

.method getContext()Landroid/content/Context;
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/u;->mContext:Landroid/content/Context;

    return-object p0
.end method

.method getHandler()Landroid/os/Handler;
    .locals 0

    iget-object p0, p0, Landroid/support/v4/app/u;->mHandler:Landroid/os/Handler;

    return-object p0
.end method
