.class public final Landroid/support/v4/media/l;
.super Ljava/lang/Object;
.source ""


# instance fields
.field private Xf:Ljava/lang/String;

.field private Yf:Ljava/lang/CharSequence;

.field private Zf:Landroid/net/Uri;

.field private _f:Landroid/net/Uri;

.field private mDescription:Ljava/lang/CharSequence;

.field private mExtras:Landroid/os/Bundle;

.field private mIcon:Landroid/graphics/Bitmap;

.field private mTitle:Ljava/lang/CharSequence;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public build()Landroid/support/v4/media/MediaDescriptionCompat;
    .locals 10

    new-instance v9, Landroid/support/v4/media/MediaDescriptionCompat;

    iget-object v1, p0, Landroid/support/v4/media/l;->Xf:Ljava/lang/String;

    iget-object v2, p0, Landroid/support/v4/media/l;->mTitle:Ljava/lang/CharSequence;

    iget-object v3, p0, Landroid/support/v4/media/l;->Yf:Ljava/lang/CharSequence;

    iget-object v4, p0, Landroid/support/v4/media/l;->mDescription:Ljava/lang/CharSequence;

    iget-object v5, p0, Landroid/support/v4/media/l;->mIcon:Landroid/graphics/Bitmap;

    iget-object v6, p0, Landroid/support/v4/media/l;->Zf:Landroid/net/Uri;

    iget-object v7, p0, Landroid/support/v4/media/l;->mExtras:Landroid/os/Bundle;

    iget-object v8, p0, Landroid/support/v4/media/l;->_f:Landroid/net/Uri;

    move-object v0, v9

    invoke-direct/range {v0 .. v8}, Landroid/support/v4/media/MediaDescriptionCompat;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Landroid/graphics/Bitmap;Landroid/net/Uri;Landroid/os/Bundle;Landroid/net/Uri;)V

    return-object v9
.end method

.method public setDescription(Ljava/lang/CharSequence;)Landroid/support/v4/media/l;
    .locals 0

    iput-object p1, p0, Landroid/support/v4/media/l;->mDescription:Ljava/lang/CharSequence;

    return-object p0
.end method

.method public setExtras(Landroid/os/Bundle;)Landroid/support/v4/media/l;
    .locals 0

    iput-object p1, p0, Landroid/support/v4/media/l;->mExtras:Landroid/os/Bundle;

    return-object p0
.end method

.method public setIconBitmap(Landroid/graphics/Bitmap;)Landroid/support/v4/media/l;
    .locals 0

    iput-object p1, p0, Landroid/support/v4/media/l;->mIcon:Landroid/graphics/Bitmap;

    return-object p0
.end method

.method public setIconUri(Landroid/net/Uri;)Landroid/support/v4/media/l;
    .locals 0

    iput-object p1, p0, Landroid/support/v4/media/l;->Zf:Landroid/net/Uri;

    return-object p0
.end method

.method public setMediaId(Ljava/lang/String;)Landroid/support/v4/media/l;
    .locals 0

    iput-object p1, p0, Landroid/support/v4/media/l;->Xf:Ljava/lang/String;

    return-object p0
.end method

.method public setMediaUri(Landroid/net/Uri;)Landroid/support/v4/media/l;
    .locals 0

    iput-object p1, p0, Landroid/support/v4/media/l;->_f:Landroid/net/Uri;

    return-object p0
.end method

.method public setSubtitle(Ljava/lang/CharSequence;)Landroid/support/v4/media/l;
    .locals 0

    iput-object p1, p0, Landroid/support/v4/media/l;->Yf:Ljava/lang/CharSequence;

    return-object p0
.end method

.method public setTitle(Ljava/lang/CharSequence;)Landroid/support/v4/media/l;
    .locals 0

    iput-object p1, p0, Landroid/support/v4/media/l;->mTitle:Ljava/lang/CharSequence;

    return-object p0
.end method
