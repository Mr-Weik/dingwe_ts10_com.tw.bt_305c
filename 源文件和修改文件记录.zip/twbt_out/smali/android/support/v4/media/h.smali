.class Landroid/support/v4/media/h;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic Uf:Landroid/support/v4/media/MediaController2ImplLegacy$ControllerCompatCallback$1;


# direct methods
.method constructor <init>(Landroid/support/v4/media/MediaController2ImplLegacy$ControllerCompatCallback$1;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v4/media/h;->Uf:Landroid/support/v4/media/MediaController2ImplLegacy$ControllerCompatCallback$1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 0

    iget-object p0, p0, Landroid/support/v4/media/h;->Uf:Landroid/support/v4/media/MediaController2ImplLegacy$ControllerCompatCallback$1;

    iget-object p0, p0, Landroid/support/v4/media/MediaController2ImplLegacy$ControllerCompatCallback$1;->Hc:Landroid/support/v4/media/i;

    const/4 p0, 0x0

    throw p0
.end method
