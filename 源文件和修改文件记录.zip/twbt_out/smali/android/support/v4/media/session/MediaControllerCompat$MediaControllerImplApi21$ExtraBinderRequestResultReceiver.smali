.class Landroid/support/v4/media/session/MediaControllerCompat$MediaControllerImplApi21$ExtraBinderRequestResultReceiver;
.super Landroid/os/ResultReceiver;
.source ""


# instance fields
.field private we:Ljava/lang/ref/WeakReference;


# virtual methods
.method protected onReceiveResult(ILandroid/os/Bundle;)V
    .locals 1

    iget-object p0, p0, Landroid/support/v4/media/session/MediaControllerCompat$MediaControllerImplApi21$ExtraBinderRequestResultReceiver;->we:Ljava/lang/ref/WeakReference;

    invoke-virtual {p0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/support/v4/media/session/j;

    if-eqz p0, :cond_1

    if-nez p2, :cond_0

    goto :goto_0

    :cond_0
    invoke-static {p0}, Landroid/support/v4/media/session/j;->a(Landroid/support/v4/media/session/j;)Landroid/support/v4/media/session/MediaSessionCompat$Token;

    move-result-object p1

    const-string v0, "android.support.v4.media.session.EXTRA_BINDER"

    invoke-static {p2, v0}, Landroid/support/v4/app/g;->a(Landroid/os/Bundle;Ljava/lang/String;)Landroid/os/IBinder;

    move-result-object v0

    invoke-static {v0}, Landroid/support/v4/media/session/d;->asInterface(Landroid/os/IBinder;)Landroid/support/v4/media/session/e;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/support/v4/media/session/MediaSessionCompat$Token;->a(Landroid/support/v4/media/session/e;)V

    invoke-static {p0}, Landroid/support/v4/media/session/j;->a(Landroid/support/v4/media/session/j;)Landroid/support/v4/media/session/MediaSessionCompat$Token;

    move-result-object p1

    const-string v0, "android.support.v4.media.session.SESSION_TOKEN2"

    invoke-virtual {p2, v0}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object p2

    invoke-static {p2}, Landroid/support/v4/media/p;->fromBundle(Landroid/os/Bundle;)Landroid/support/v4/media/p;

    move-result-object p2

    invoke-virtual {p1, p2}, Landroid/support/v4/media/session/MediaSessionCompat$Token;->a(Landroid/support/v4/media/p;)V

    invoke-static {p0}, Landroid/support/v4/media/session/j;->b(Landroid/support/v4/media/session/j;)V

    :cond_1
    :goto_0
    return-void
.end method
