.class Landroid/support/v4/media/session/l;
.super Landroid/media/session/MediaController$Callback;
.source ""


# instance fields
.field protected final mCallback:Landroid/support/v4/media/session/k;


# direct methods
.method public constructor <init>(Landroid/support/v4/media/session/k;)V
    .locals 0

    invoke-direct {p0}, Landroid/media/session/MediaController$Callback;-><init>()V

    iput-object p1, p0, Landroid/support/v4/media/session/l;->mCallback:Landroid/support/v4/media/session/k;

    return-void
.end method


# virtual methods
.method public onAudioInfoChanged(Landroid/media/session/MediaController$PlaybackInfo;)V
    .locals 6

    iget-object p0, p0, Landroid/support/v4/media/session/l;->mCallback:Landroid/support/v4/media/session/k;

    invoke-virtual {p1}, Landroid/media/session/MediaController$PlaybackInfo;->getPlaybackType()I

    move-result v1

    .line 1
    invoke-virtual {p1}, Landroid/media/session/MediaController$PlaybackInfo;->getAudioAttributes()Landroid/media/AudioAttributes;

    move-result-object v0

    .line 2
    invoke-virtual {v0}, Landroid/media/AudioAttributes;->getFlags()I

    move-result v2

    const/4 v3, 0x1

    and-int/2addr v2, v3

    if-ne v2, v3, :cond_0

    const/4 v0, 0x7

    :goto_0
    move v2, v0

    goto :goto_1

    :cond_0
    invoke-virtual {v0}, Landroid/media/AudioAttributes;->getFlags()I

    move-result v2

    const/4 v4, 0x4

    and-int/2addr v2, v4

    if-ne v2, v4, :cond_1

    const/4 v0, 0x6

    goto :goto_0

    :cond_1
    invoke-virtual {v0}, Landroid/media/AudioAttributes;->getUsage()I

    move-result v0

    const/4 v2, 0x3

    packed-switch v0, :pswitch_data_0

    goto :goto_1

    :pswitch_0
    move v2, v3

    goto :goto_1

    :pswitch_1
    const/4 v0, 0x2

    goto :goto_0

    :pswitch_2
    const/4 v0, 0x5

    goto :goto_0

    :pswitch_3
    move v2, v4

    goto :goto_1

    :pswitch_4
    const/16 v0, 0x8

    goto :goto_0

    :pswitch_5
    const/4 v0, 0x0

    goto :goto_0

    .line 3
    :goto_1
    :pswitch_6
    invoke-virtual {p1}, Landroid/media/session/MediaController$PlaybackInfo;->getVolumeControl()I

    move-result v3

    invoke-virtual {p1}, Landroid/media/session/MediaController$PlaybackInfo;->getMaxVolume()I

    move-result v4

    invoke-virtual {p1}, Landroid/media/session/MediaController$PlaybackInfo;->getCurrentVolume()I

    move-result v5

    move-object v0, p0

    check-cast v0, Landroid/support/v4/media/session/f;

    invoke-virtual/range {v0 .. v5}, Landroid/support/v4/media/session/f;->b(IIIII)V

    return-void

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_2
        :pswitch_2
        :pswitch_2
        :pswitch_2
        :pswitch_6
        :pswitch_6
        :pswitch_0
        :pswitch_6
    .end packed-switch
.end method

.method public onExtrasChanged(Landroid/os/Bundle;)V
    .locals 0

    iget-object p0, p0, Landroid/support/v4/media/session/l;->mCallback:Landroid/support/v4/media/session/k;

    check-cast p0, Landroid/support/v4/media/session/f;

    invoke-virtual {p0, p1}, Landroid/support/v4/media/session/f;->onExtrasChanged(Landroid/os/Bundle;)V

    return-void
.end method

.method public onMetadataChanged(Landroid/media/MediaMetadata;)V
    .locals 0

    iget-object p0, p0, Landroid/support/v4/media/session/l;->mCallback:Landroid/support/v4/media/session/k;

    check-cast p0, Landroid/support/v4/media/session/f;

    invoke-virtual {p0, p1}, Landroid/support/v4/media/session/f;->k(Ljava/lang/Object;)V

    return-void
.end method

.method public onPlaybackStateChanged(Landroid/media/session/PlaybackState;)V
    .locals 0

    iget-object p0, p0, Landroid/support/v4/media/session/l;->mCallback:Landroid/support/v4/media/session/k;

    check-cast p0, Landroid/support/v4/media/session/f;

    invoke-virtual {p0, p1}, Landroid/support/v4/media/session/f;->l(Ljava/lang/Object;)V

    return-void
.end method

.method public onQueueChanged(Ljava/util/List;)V
    .locals 0

    iget-object p0, p0, Landroid/support/v4/media/session/l;->mCallback:Landroid/support/v4/media/session/k;

    check-cast p0, Landroid/support/v4/media/session/f;

    invoke-virtual {p0, p1}, Landroid/support/v4/media/session/f;->onQueueChanged(Ljava/util/List;)V

    return-void
.end method

.method public onQueueTitleChanged(Ljava/lang/CharSequence;)V
    .locals 0

    iget-object p0, p0, Landroid/support/v4/media/session/l;->mCallback:Landroid/support/v4/media/session/k;

    check-cast p0, Landroid/support/v4/media/session/f;

    invoke-virtual {p0, p1}, Landroid/support/v4/media/session/f;->onQueueTitleChanged(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public onSessionDestroyed()V
    .locals 0

    iget-object p0, p0, Landroid/support/v4/media/session/l;->mCallback:Landroid/support/v4/media/session/k;

    check-cast p0, Landroid/support/v4/media/session/f;

    invoke-virtual {p0}, Landroid/support/v4/media/session/f;->onSessionDestroyed()V

    return-void
.end method

.method public onSessionEvent(Ljava/lang/String;Landroid/os/Bundle;)V
    .locals 0

    iget-object p0, p0, Landroid/support/v4/media/session/l;->mCallback:Landroid/support/v4/media/session/k;

    check-cast p0, Landroid/support/v4/media/session/f;

    invoke-virtual {p0, p1, p2}, Landroid/support/v4/media/session/f;->onSessionEvent(Ljava/lang/String;Landroid/os/Bundle;)V

    return-void
.end method
