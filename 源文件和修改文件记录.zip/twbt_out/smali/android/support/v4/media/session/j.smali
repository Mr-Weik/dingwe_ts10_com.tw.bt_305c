.class Landroid/support/v4/media/session/j;
.super Ljava/lang/Object;
.source ""


# instance fields
.field private final hg:Ljava/util/List;

.field private ig:Ljava/util/HashMap;

.field private final jg:Landroid/support/v4/media/session/MediaSessionCompat$Token;


# direct methods
.method private Wf()V
    .locals 5

    iget-object v0, p0, Landroid/support/v4/media/session/j;->jg:Landroid/support/v4/media/session/MediaSessionCompat$Token;

    invoke-virtual {v0}, Landroid/support/v4/media/session/MediaSessionCompat$Token;->Aa()Landroid/support/v4/media/session/e;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Landroid/support/v4/media/session/j;->hg:Ljava/util/List;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, Landroid/support/v4/media/session/j;->hg:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/support/v4/media/session/h;

    new-instance v3, Landroid/support/v4/media/session/i;

    invoke-direct {v3, v2}, Landroid/support/v4/media/session/i;-><init>(Landroid/support/v4/media/session/h;)V

    iget-object v4, p0, Landroid/support/v4/media/session/j;->ig:Ljava/util/HashMap;

    invoke-virtual {v4, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iput-object v3, v2, Landroid/support/v4/media/session/h;->gg:Landroid/support/v4/media/session/b;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    iget-object v2, p0, Landroid/support/v4/media/session/j;->jg:Landroid/support/v4/media/session/MediaSessionCompat$Token;

    invoke-virtual {v2}, Landroid/support/v4/media/session/MediaSessionCompat$Token;->Aa()Landroid/support/v4/media/session/e;

    move-result-object v2
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    check-cast v2, Landroid/support/v4/media/session/c;

    :try_start_2
    invoke-virtual {v2, v3}, Landroid/support/v4/media/session/c;->a(Landroid/support/v4/media/session/b;)V
    :try_end_2
    .catch Landroid/os/RemoteException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    goto :goto_0

    :catch_0
    move-exception v1

    :try_start_3
    const-string v2, "MediaControllerCompat"

    const-string v3, "Dead object in registerCallback."

    invoke-static {v2, v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_1
    iget-object p0, p0, Landroid/support/v4/media/session/j;->hg:Ljava/util/List;

    invoke-interface {p0}, Ljava/util/List;->clear()V

    monitor-exit v0

    return-void

    :catchall_0
    move-exception p0

    monitor-exit v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    throw p0
.end method

.method static synthetic a(Landroid/support/v4/media/session/j;)Landroid/support/v4/media/session/MediaSessionCompat$Token;
    .locals 0

    iget-object p0, p0, Landroid/support/v4/media/session/j;->jg:Landroid/support/v4/media/session/MediaSessionCompat$Token;

    return-object p0
.end method

.method static synthetic b(Landroid/support/v4/media/session/j;)V
    .locals 0

    invoke-direct {p0}, Landroid/support/v4/media/session/j;->Wf()V

    return-void
.end method
