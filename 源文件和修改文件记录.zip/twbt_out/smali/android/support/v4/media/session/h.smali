.class public abstract Landroid/support/v4/media/session/h;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/os/IBinder$DeathRecipient;


# instance fields
.field gg:Landroid/support/v4/media/session/b;


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    new-instance v0, Landroid/support/v4/media/session/f;

    invoke-direct {v0, p0}, Landroid/support/v4/media/session/f;-><init>(Landroid/support/v4/media/session/h;)V

    .line 1
    new-instance p0, Landroid/support/v4/media/session/l;

    invoke-direct {p0, v0}, Landroid/support/v4/media/session/l;-><init>(Landroid/support/v4/media/session/k;)V

    return-void
.end method


# virtual methods
.method public binderDied()V
    .locals 0

    return-void
.end method
