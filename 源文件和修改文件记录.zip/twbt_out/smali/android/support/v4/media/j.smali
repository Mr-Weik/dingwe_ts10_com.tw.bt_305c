.class Landroid/support/v4/media/j;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/support/v4/media/f;


# annotations
.annotation build Landroid/annotation/TargetApi;
    value = 0x10
.end annotation


# static fields
.field static final Wf:Landroid/os/Bundle;


# instance fields
.field private final Vf:Landroid/os/HandlerThread;

.field private final mCallbackExecutor:Ljava/util/concurrent/Executor;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const-string v0, "MC2ImplLegacy"

    const/4 v1, 0x3

    invoke-static {v0, v1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    sput-object v0, Landroid/support/v4/media/j;->Wf:Landroid/os/Bundle;

    sget-object v0, Landroid/support/v4/media/j;->Wf:Landroid/os/Bundle;

    const-string v1, "android.support.v4.media.root_default_root"

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    return-void
.end method

.method static synthetic wa()V
    .locals 0

    return-void
.end method

.method static synthetic xa()Landroid/os/HandlerThread;
    .locals 1

    const/4 v0, 0x0

    iget-object v0, v0, Landroid/support/v4/media/j;->Vf:Landroid/os/HandlerThread;

    return-object v0
.end method

.method static synthetic ya()Ljava/util/concurrent/Executor;
    .locals 1

    const/4 v0, 0x0

    iget-object v0, v0, Landroid/support/v4/media/j;->mCallbackExecutor:Ljava/util/concurrent/Executor;

    return-object v0
.end method
