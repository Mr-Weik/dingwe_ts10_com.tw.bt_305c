.class Landroid/support/v4/media/MediaController2ImplLegacy$ControllerCompatCallback$1;
.super Landroid/os/ResultReceiver;
.source ""


# instance fields
.field final synthetic Hc:Landroid/support/v4/media/i;


# virtual methods
.method protected onReceiveResult(ILandroid/os/Bundle;)V
    .locals 1

    const/4 p2, 0x0

    iget-object v0, p2, Landroid/support/v4/media/i;->n:Landroid/support/v4/media/j;

    invoke-static {}, Landroid/support/v4/media/j;->xa()Landroid/os/HandlerThread;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/HandlerThread;->isAlive()Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    const/4 v0, -0x1

    if-eq p1, v0, :cond_2

    if-eqz p1, :cond_1

    return-void

    :cond_1
    iget-object p0, p2, Landroid/support/v4/media/i;->n:Landroid/support/v4/media/j;

    throw p2

    :cond_2
    iget-object p1, p2, Landroid/support/v4/media/i;->n:Landroid/support/v4/media/j;

    invoke-static {}, Landroid/support/v4/media/j;->ya()Ljava/util/concurrent/Executor;

    move-result-object p1

    new-instance v0, Landroid/support/v4/media/h;

    invoke-direct {v0, p0}, Landroid/support/v4/media/h;-><init>(Landroid/support/v4/media/MediaController2ImplLegacy$ControllerCompatCallback$1;)V

    invoke-interface {p1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    iget-object p0, p2, Landroid/support/v4/media/i;->n:Landroid/support/v4/media/j;

    throw p2
.end method
