.class Landroid/support/v4/media/g;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic Hc:Landroid/support/v4/media/MediaController2ImplLegacy$3;


# direct methods
.method constructor <init>(Landroid/support/v4/media/MediaController2ImplLegacy$3;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v4/media/g;->Hc:Landroid/support/v4/media/MediaController2ImplLegacy$3;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    iget-object v0, p0, Landroid/support/v4/media/g;->Hc:Landroid/support/v4/media/MediaController2ImplLegacy$3;

    iget-object v0, v0, Landroid/support/v4/media/MediaController2ImplLegacy$3;->n:Landroid/support/v4/media/j;

    invoke-static {}, Landroid/support/v4/media/j;->wa()V

    iget-object p0, p0, Landroid/support/v4/media/g;->Hc:Landroid/support/v4/media/MediaController2ImplLegacy$3;

    iget-object p0, p0, Landroid/support/v4/media/MediaController2ImplLegacy$3;->n:Landroid/support/v4/media/j;

    const/4 p0, 0x0

    throw p0
.end method
