.class public Landroid/support/v4/widget/f;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/view/View$OnTouchListener;


# static fields
.field private static final bi:I


# instance fields
.field private final Oh:Landroid/view/animation/Interpolator;

.field final Ph:Landroid/view/View;

.field private Qh:[F

.field private Rh:[F

.field private Sh:I

.field private Th:I

.field private Uh:[F

.field private Vh:[F

.field private Wh:[F

.field private Xh:Z

.field Yh:Z

.field Zh:Z

.field _h:Z

.field private ai:Z

.field private mEnabled:Z

.field private mRunnable:Ljava/lang/Runnable;

.field final mScroller:Landroid/support/v4/widget/a;

.field private final mTarget:Landroid/widget/ListView;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    invoke-static {}, Landroid/view/ViewConfiguration;->getTapTimeout()I

    move-result v0

    sput v0, Landroid/support/v4/widget/f;->bi:I

    return-void
.end method

.method public constructor <init>(Landroid/widget/ListView;)V
    .locals 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Landroid/support/v4/widget/a;

    invoke-direct {v0}, Landroid/support/v4/widget/a;-><init>()V

    iput-object v0, p0, Landroid/support/v4/widget/f;->mScroller:Landroid/support/v4/widget/a;

    new-instance v0, Landroid/view/animation/AccelerateInterpolator;

    invoke-direct {v0}, Landroid/view/animation/AccelerateInterpolator;-><init>()V

    iput-object v0, p0, Landroid/support/v4/widget/f;->Oh:Landroid/view/animation/Interpolator;

    const/4 v0, 0x2

    new-array v1, v0, [F

    fill-array-data v1, :array_0

    iput-object v1, p0, Landroid/support/v4/widget/f;->Qh:[F

    new-array v1, v0, [F

    fill-array-data v1, :array_1

    iput-object v1, p0, Landroid/support/v4/widget/f;->Rh:[F

    new-array v1, v0, [F

    fill-array-data v1, :array_2

    iput-object v1, p0, Landroid/support/v4/widget/f;->Uh:[F

    new-array v1, v0, [F

    fill-array-data v1, :array_3

    iput-object v1, p0, Landroid/support/v4/widget/f;->Vh:[F

    new-array v0, v0, [F

    fill-array-data v0, :array_4

    iput-object v0, p0, Landroid/support/v4/widget/f;->Wh:[F

    iput-object p1, p0, Landroid/support/v4/widget/f;->Ph:Landroid/view/View;

    invoke-static {}, Landroid/content/res/Resources;->getSystem()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    const v1, 0x44c4e000    # 1575.0f

    mul-float/2addr v1, v0

    const/high16 v2, 0x3f000000    # 0.5f

    add-float/2addr v1, v2

    float-to-int v1, v1

    const v3, 0x439d8000    # 315.0f

    mul-float/2addr v0, v3

    add-float/2addr v0, v2

    float-to-int v0, v0

    int-to-float v1, v1

    .line 2
    iget-object v2, p0, Landroid/support/v4/widget/f;->Wh:[F

    const/high16 v3, 0x447a0000    # 1000.0f

    div-float/2addr v1, v3

    const/4 v4, 0x0

    aput v1, v2, v4

    const/4 v5, 0x1

    aput v1, v2, v5

    int-to-float v0, v0

    .line 3
    iget-object v1, p0, Landroid/support/v4/widget/f;->Vh:[F

    div-float/2addr v0, v3

    aput v0, v1, v4

    aput v0, v1, v5

    .line 4
    iput v5, p0, Landroid/support/v4/widget/f;->Sh:I

    .line 5
    iget-object v0, p0, Landroid/support/v4/widget/f;->Rh:[F

    const v1, 0x7f7fffff    # Float.MAX_VALUE

    aput v1, v0, v4

    aput v1, v0, v5

    .line 6
    iget-object v0, p0, Landroid/support/v4/widget/f;->Qh:[F

    const v1, 0x3e4ccccd    # 0.2f

    aput v1, v0, v4

    aput v1, v0, v5

    .line 7
    iget-object v0, p0, Landroid/support/v4/widget/f;->Uh:[F

    const v1, 0x3a83126f    # 0.001f

    aput v1, v0, v4

    aput v1, v0, v5

    .line 8
    sget v0, Landroid/support/v4/widget/f;->bi:I

    .line 9
    iput v0, p0, Landroid/support/v4/widget/f;->Th:I

    .line 10
    iget-object v0, p0, Landroid/support/v4/widget/f;->mScroller:Landroid/support/v4/widget/a;

    const/16 v1, 0x1f4

    invoke-virtual {v0, v1}, Landroid/support/v4/widget/a;->setRampUpDuration(I)V

    .line 11
    iget-object v0, p0, Landroid/support/v4/widget/f;->mScroller:Landroid/support/v4/widget/a;

    invoke-virtual {v0, v1}, Landroid/support/v4/widget/a;->setRampDownDuration(I)V

    .line 12
    iput-object p1, p0, Landroid/support/v4/widget/f;->mTarget:Landroid/widget/ListView;

    return-void

    nop

    :array_0
    .array-data 4
        0x0
        0x0
    .end array-data

    :array_1
    .array-data 4
        0x7f7fffff    # Float.MAX_VALUE
        0x7f7fffff    # Float.MAX_VALUE
    .end array-data

    :array_2
    .array-data 4
        0x0
        0x0
    .end array-data

    :array_3
    .array-data 4
        0x0
        0x0
    .end array-data

    :array_4
    .array-data 4
        0x7f7fffff    # Float.MAX_VALUE
        0x7f7fffff    # Float.MAX_VALUE
    .end array-data
.end method

.method private a(FF)F
    .locals 4

    const/4 v0, 0x0

    cmpl-float v1, p2, v0

    if-nez v1, :cond_0

    return v0

    :cond_0
    iget v1, p0, Landroid/support/v4/widget/f;->Sh:I

    const/4 v2, 0x1

    if-eqz v1, :cond_2

    if-eq v1, v2, :cond_2

    const/4 p0, 0x2

    if-eq v1, p0, :cond_1

    goto :goto_0

    :cond_1
    cmpg-float p0, p1, v0

    if-gez p0, :cond_4

    neg-float p0, p2

    div-float/2addr p1, p0

    return p1

    :cond_2
    cmpg-float v1, p1, p2

    if-gez v1, :cond_4

    cmpl-float v1, p1, v0

    const/high16 v3, 0x3f800000    # 1.0f

    if-ltz v1, :cond_3

    div-float/2addr p1, p2

    sub-float/2addr v3, p1

    return v3

    :cond_3
    iget-boolean p1, p0, Landroid/support/v4/widget/f;->_h:Z

    if-eqz p1, :cond_4

    iget p0, p0, Landroid/support/v4/widget/f;->Sh:I

    if-ne p0, v2, :cond_4

    return v3

    :cond_4
    :goto_0
    return v0
.end method

.method private a(IFFF)F
    .locals 3

    iget-object v0, p0, Landroid/support/v4/widget/f;->Qh:[F

    aget v0, v0, p1

    iget-object v1, p0, Landroid/support/v4/widget/f;->Rh:[F

    aget v1, v1, p1

    mul-float/2addr v0, p3

    const/4 v2, 0x0

    .line 1
    invoke-static {v0, v2, v1}, Landroid/support/v4/widget/f;->constrain(FFF)F

    move-result v0

    invoke-direct {p0, p2, v0}, Landroid/support/v4/widget/f;->a(FF)F

    move-result v1

    sub-float/2addr p3, p2

    invoke-direct {p0, p3, v0}, Landroid/support/v4/widget/f;->a(FF)F

    move-result p2

    sub-float/2addr p2, v1

    cmpg-float p3, p2, v2

    if-gez p3, :cond_0

    iget-object p3, p0, Landroid/support/v4/widget/f;->Oh:Landroid/view/animation/Interpolator;

    neg-float p2, p2

    invoke-interface {p3, p2}, Landroid/view/animation/Interpolator;->getInterpolation(F)F

    move-result p2

    neg-float p2, p2

    goto :goto_0

    :cond_0
    cmpl-float p3, p2, v2

    if-lez p3, :cond_1

    iget-object p3, p0, Landroid/support/v4/widget/f;->Oh:Landroid/view/animation/Interpolator;

    invoke-interface {p3, p2}, Landroid/view/animation/Interpolator;->getInterpolation(F)F

    move-result p2

    :goto_0
    const/high16 p3, -0x40800000    # -1.0f

    const/high16 v0, 0x3f800000    # 1.0f

    invoke-static {p2, p3, v0}, Landroid/support/v4/widget/f;->constrain(FFF)F

    move-result p2

    goto :goto_1

    :cond_1
    move p2, v2

    :goto_1
    cmpl-float p3, p2, v2

    if-nez p3, :cond_2

    return v2

    .line 2
    :cond_2
    iget-object v0, p0, Landroid/support/v4/widget/f;->Uh:[F

    aget v0, v0, p1

    iget-object v1, p0, Landroid/support/v4/widget/f;->Vh:[F

    aget v1, v1, p1

    iget-object p0, p0, Landroid/support/v4/widget/f;->Wh:[F

    aget p0, p0, p1

    mul-float/2addr v0, p4

    if-lez p3, :cond_3

    mul-float/2addr p2, v0

    invoke-static {p2, v1, p0}, Landroid/support/v4/widget/f;->constrain(FFF)F

    move-result p0

    return p0

    :cond_3
    neg-float p1, p2

    mul-float/2addr p1, v0

    invoke-static {p1, v1, p0}, Landroid/support/v4/widget/f;->constrain(FFF)F

    move-result p0

    neg-float p0, p0

    return p0
.end method

.method static constrain(FFF)F
    .locals 1

    cmpl-float v0, p0, p2

    if-lez v0, :cond_0

    return p2

    :cond_0
    cmpg-float p2, p0, p1

    if-gez p2, :cond_1

    return p1

    :cond_1
    return p0
.end method

.method static constrain(III)I
    .locals 0

    if-le p0, p2, :cond_0

    return p2

    :cond_0
    if-ge p0, p1, :cond_1

    return p1

    :cond_1
    return p0
.end method

.method private requestStop()V
    .locals 1

    iget-boolean v0, p0, Landroid/support/v4/widget/f;->Yh:Z

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/support/v4/widget/f;->_h:Z

    goto :goto_0

    :cond_0
    iget-object p0, p0, Landroid/support/v4/widget/f;->mScroller:Landroid/support/v4/widget/a;

    invoke-virtual {p0}, Landroid/support/v4/widget/a;->requestStop()V

    :goto_0
    return-void
.end method


# virtual methods
.method Fa()V
    .locals 8

    .line 1
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v2

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    move-wide v0, v2

    invoke-static/range {v0 .. v7}, Landroid/view/MotionEvent;->obtain(JJIFFI)Landroid/view/MotionEvent;

    move-result-object v0

    iget-object p0, p0, Landroid/support/v4/widget/f;->Ph:Landroid/view/View;

    invoke-virtual {p0, v0}, Landroid/view/View;->onTouchEvent(Landroid/view/MotionEvent;)Z

    invoke-virtual {v0}, Landroid/view/MotionEvent;->recycle()V

    return-void
.end method

.method Ga()Z
    .locals 7

    .line 1
    iget-object v0, p0, Landroid/support/v4/widget/f;->mScroller:Landroid/support/v4/widget/a;

    invoke-virtual {v0}, Landroid/support/v4/widget/a;->getVerticalDirection()I

    move-result v1

    invoke-virtual {v0}, Landroid/support/v4/widget/a;->getHorizontalDirection()I

    const/4 v0, 0x1

    const/4 v2, 0x0

    if-eqz v1, :cond_4

    .line 2
    iget-object p0, p0, Landroid/support/v4/widget/f;->mTarget:Landroid/widget/ListView;

    invoke-virtual {p0}, Landroid/widget/ListView;->getCount()I

    move-result v3

    if-nez v3, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Landroid/widget/ListView;->getChildCount()I

    move-result v4

    invoke-virtual {p0}, Landroid/widget/ListView;->getFirstVisiblePosition()I

    move-result v5

    add-int v6, v5, v4

    if-lez v1, :cond_1

    if-lt v6, v3, :cond_2

    sub-int/2addr v4, v0

    invoke-virtual {p0, v4}, Landroid/widget/ListView;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/View;->getBottom()I

    move-result v1

    invoke-virtual {p0}, Landroid/widget/ListView;->getHeight()I

    move-result p0

    if-gt v1, p0, :cond_2

    goto :goto_0

    :cond_1
    if-gez v1, :cond_3

    if-gtz v5, :cond_2

    invoke-virtual {p0, v2}, Landroid/widget/ListView;->getChildAt(I)Landroid/view/View;

    move-result-object p0

    invoke-virtual {p0}, Landroid/view/View;->getTop()I

    move-result p0

    if-ltz p0, :cond_2

    goto :goto_0

    :cond_2
    move p0, v0

    goto :goto_1

    :cond_3
    :goto_0
    move p0, v2

    :goto_1
    if-nez p0, :cond_5

    :cond_4
    move v0, v2

    :cond_5
    return v0
.end method

.method public onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 5

    .line 1
    iget-boolean v0, p0, Landroid/support/v4/widget/f;->mEnabled:Z

    const/4 v1, 0x0

    if-nez v0, :cond_0

    goto/16 :goto_2

    :cond_0
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v0

    const/4 v2, 0x1

    if-eqz v0, :cond_2

    if-eq v0, v2, :cond_1

    const/4 v3, 0x2

    if-eq v0, v3, :cond_3

    const/4 p1, 0x3

    if-eq v0, p1, :cond_1

    goto :goto_1

    :cond_1
    invoke-direct {p0}, Landroid/support/v4/widget/f;->requestStop()V

    goto :goto_1

    :cond_2
    iput-boolean v2, p0, Landroid/support/v4/widget/f;->Zh:Z

    iput-boolean v1, p0, Landroid/support/v4/widget/f;->Xh:Z

    :cond_3
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getX()F

    move-result v0

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result v3

    int-to-float v3, v3

    iget-object v4, p0, Landroid/support/v4/widget/f;->Ph:Landroid/view/View;

    invoke-virtual {v4}, Landroid/view/View;->getWidth()I

    move-result v4

    int-to-float v4, v4

    invoke-direct {p0, v1, v0, v3, v4}, Landroid/support/v4/widget/f;->a(IFFF)F

    move-result v0

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getY()F

    move-result p2

    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result p1

    int-to-float p1, p1

    iget-object v3, p0, Landroid/support/v4/widget/f;->Ph:Landroid/view/View;

    invoke-virtual {v3}, Landroid/view/View;->getHeight()I

    move-result v3

    int-to-float v3, v3

    invoke-direct {p0, v2, p2, p1, v3}, Landroid/support/v4/widget/f;->a(IFFF)F

    move-result p1

    iget-object p2, p0, Landroid/support/v4/widget/f;->mScroller:Landroid/support/v4/widget/a;

    invoke-virtual {p2, v0, p1}, Landroid/support/v4/widget/a;->setTargetVelocity(FF)V

    iget-boolean p1, p0, Landroid/support/v4/widget/f;->_h:Z

    if-nez p1, :cond_6

    invoke-virtual {p0}, Landroid/support/v4/widget/f;->Ga()Z

    move-result p1

    if-eqz p1, :cond_6

    .line 2
    iget-object p1, p0, Landroid/support/v4/widget/f;->mRunnable:Ljava/lang/Runnable;

    if-nez p1, :cond_4

    new-instance p1, Landroid/support/v4/widget/b;

    invoke-direct {p1, p0}, Landroid/support/v4/widget/b;-><init>(Landroid/support/v4/widget/f;)V

    iput-object p1, p0, Landroid/support/v4/widget/f;->mRunnable:Ljava/lang/Runnable;

    :cond_4
    iput-boolean v2, p0, Landroid/support/v4/widget/f;->_h:Z

    iput-boolean v2, p0, Landroid/support/v4/widget/f;->Yh:Z

    iget-boolean p1, p0, Landroid/support/v4/widget/f;->Xh:Z

    if-nez p1, :cond_5

    iget p1, p0, Landroid/support/v4/widget/f;->Th:I

    if-lez p1, :cond_5

    iget-object p2, p0, Landroid/support/v4/widget/f;->Ph:Landroid/view/View;

    iget-object v0, p0, Landroid/support/v4/widget/f;->mRunnable:Ljava/lang/Runnable;

    int-to-long v3, p1

    invoke-static {p2, v0, v3, v4}, Landroid/support/v4/view/r;->a(Landroid/view/View;Ljava/lang/Runnable;J)V

    goto :goto_0

    :cond_5
    iget-object p1, p0, Landroid/support/v4/widget/f;->mRunnable:Ljava/lang/Runnable;

    invoke-interface {p1}, Ljava/lang/Runnable;->run()V

    :goto_0
    iput-boolean v2, p0, Landroid/support/v4/widget/f;->Xh:Z

    .line 3
    :cond_6
    :goto_1
    iget-boolean p1, p0, Landroid/support/v4/widget/f;->ai:Z

    if-eqz p1, :cond_7

    iget-boolean p0, p0, Landroid/support/v4/widget/f;->_h:Z

    if-eqz p0, :cond_7

    move v1, v2

    :cond_7
    :goto_2
    return v1
.end method

.method public scrollTargetBy(II)V
    .locals 0

    iget-object p0, p0, Landroid/support/v4/widget/f;->mTarget:Landroid/widget/ListView;

    .line 1
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-virtual {p0, p2}, Landroid/widget/ListView;->scrollListBy(I)V

    return-void
.end method

.method public setEnabled(Z)Landroid/support/v4/widget/f;
    .locals 1

    .line 1
    iget-boolean v0, p0, Landroid/support/v4/widget/f;->mEnabled:Z

    if-eqz v0, :cond_0

    if-nez p1, :cond_0

    invoke-direct {p0}, Landroid/support/v4/widget/f;->requestStop()V

    :cond_0
    iput-boolean p1, p0, Landroid/support/v4/widget/f;->mEnabled:Z

    return-object p0
.end method
