.class Landroid/support/v4/widget/b;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic n:Landroid/support/v4/widget/f;


# direct methods
.method constructor <init>(Landroid/support/v4/widget/f;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v4/widget/b;->n:Landroid/support/v4/widget/f;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    iget-object v0, p0, Landroid/support/v4/widget/b;->n:Landroid/support/v4/widget/f;

    iget-boolean v1, v0, Landroid/support/v4/widget/f;->_h:Z

    if-nez v1, :cond_0

    return-void

    :cond_0
    iget-boolean v1, v0, Landroid/support/v4/widget/f;->Yh:Z

    const/4 v2, 0x0

    if-eqz v1, :cond_1

    iput-boolean v2, v0, Landroid/support/v4/widget/f;->Yh:Z

    iget-object v0, v0, Landroid/support/v4/widget/f;->mScroller:Landroid/support/v4/widget/a;

    invoke-virtual {v0}, Landroid/support/v4/widget/a;->start()V

    :cond_1
    iget-object v0, p0, Landroid/support/v4/widget/b;->n:Landroid/support/v4/widget/f;

    iget-object v0, v0, Landroid/support/v4/widget/f;->mScroller:Landroid/support/v4/widget/a;

    invoke-virtual {v0}, Landroid/support/v4/widget/a;->isFinished()Z

    move-result v1

    if-nez v1, :cond_4

    iget-object v1, p0, Landroid/support/v4/widget/b;->n:Landroid/support/v4/widget/f;

    invoke-virtual {v1}, Landroid/support/v4/widget/f;->Ga()Z

    move-result v1

    if-nez v1, :cond_2

    goto :goto_0

    :cond_2
    iget-object v1, p0, Landroid/support/v4/widget/b;->n:Landroid/support/v4/widget/f;

    iget-boolean v3, v1, Landroid/support/v4/widget/f;->Zh:Z

    if-eqz v3, :cond_3

    iput-boolean v2, v1, Landroid/support/v4/widget/f;->Zh:Z

    invoke-virtual {v1}, Landroid/support/v4/widget/f;->Fa()V

    :cond_3
    invoke-virtual {v0}, Landroid/support/v4/widget/a;->computeScrollDelta()V

    invoke-virtual {v0}, Landroid/support/v4/widget/a;->getDeltaX()I

    move-result v1

    invoke-virtual {v0}, Landroid/support/v4/widget/a;->getDeltaY()I

    move-result v0

    iget-object v2, p0, Landroid/support/v4/widget/b;->n:Landroid/support/v4/widget/f;

    invoke-virtual {v2, v1, v0}, Landroid/support/v4/widget/f;->scrollTargetBy(II)V

    iget-object v0, p0, Landroid/support/v4/widget/b;->n:Landroid/support/v4/widget/f;

    iget-object v0, v0, Landroid/support/v4/widget/f;->Ph:Landroid/view/View;

    invoke-static {v0, p0}, Landroid/support/v4/view/r;->a(Landroid/view/View;Ljava/lang/Runnable;)V

    return-void

    :cond_4
    :goto_0
    iget-object p0, p0, Landroid/support/v4/widget/b;->n:Landroid/support/v4/widget/f;

    iput-boolean v2, p0, Landroid/support/v4/widget/f;->_h:Z

    return-void
.end method
