.class public interface abstract Landroid/support/v4/widget/c;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final zE:Z


# direct methods
.method static constructor <clinit>()V
    .locals 1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v0, 0x1

    sput-boolean v0, Landroid/support/v4/widget/c;->zE:Z

    return-void
.end method
