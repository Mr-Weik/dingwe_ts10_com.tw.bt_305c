.class public interface abstract Landroid/support/v4/widget/h;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract a(Landroid/support/v4/widget/NestedScrollView;IIII)V
.end method
