.class public final Landroid/support/v4/view/g;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static a(Landroid/view/LayoutInflater;Landroid/view/LayoutInflater$Factory2;)V
    .locals 0

    invoke-virtual {p0, p1}, Landroid/view/LayoutInflater;->setFactory2(Landroid/view/LayoutInflater$Factory2;)V

    sget p0, Landroid/os/Build$VERSION;->SDK_INT:I

    return-void
.end method
