.class final Landroid/support/v4/view/q;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/view/View$OnApplyWindowInsetsListener;


# instance fields
.field final synthetic p:Landroid/support/v4/view/n;


# direct methods
.method constructor <init>(Landroid/support/v4/view/n;)V
    .locals 0

    iput-object p1, p0, Landroid/support/v4/view/q;->p:Landroid/support/v4/view/n;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onApplyWindowInsets(Landroid/view/View;Landroid/view/WindowInsets;)Landroid/view/WindowInsets;
    .locals 0

    invoke-static {p2}, Landroid/support/v4/view/A;->wrap(Ljava/lang/Object;)Landroid/support/v4/view/A;

    move-result-object p2

    iget-object p0, p0, Landroid/support/v4/view/q;->p:Landroid/support/v4/view/n;

    invoke-interface {p0, p1, p2}, Landroid/support/v4/view/n;->a(Landroid/view/View;Landroid/support/v4/view/A;)Landroid/support/v4/view/A;

    move-result-object p0

    invoke-static {p0}, Landroid/support/v4/view/A;->a(Landroid/support/v4/view/A;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/view/WindowInsets;

    return-object p0
.end method
