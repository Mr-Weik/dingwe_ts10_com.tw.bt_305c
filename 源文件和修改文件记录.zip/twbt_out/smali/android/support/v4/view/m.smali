.class public Landroid/support/v4/view/m;
.super Ljava/lang/Object;
.source ""


# instance fields
.field private vh:I


# direct methods
.method public constructor <init>(Landroid/view/ViewGroup;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Landroid/view/View;I)V
    .locals 0

    const/4 p1, 0x0

    iput p1, p0, Landroid/support/v4/view/m;->vh:I

    return-void
.end method

.method public a(Landroid/view/View;Landroid/view/View;II)V
    .locals 0

    iput p3, p0, Landroid/support/v4/view/m;->vh:I

    return-void
.end method

.method public getNestedScrollAxes()I
    .locals 0

    iget p0, p0, Landroid/support/v4/view/m;->vh:I

    return p0
.end method
