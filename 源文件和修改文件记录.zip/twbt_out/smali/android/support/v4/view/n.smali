.class public interface abstract Landroid/support/v4/view/n;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract a(Landroid/view/View;Landroid/support/v4/view/A;)Landroid/support/v4/view/A;
.end method
