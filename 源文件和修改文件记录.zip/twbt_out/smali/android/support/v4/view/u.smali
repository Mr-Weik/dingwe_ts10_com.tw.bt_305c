.class Landroid/support/v4/view/u;
.super Landroid/animation/AnimatorListenerAdapter;
.source ""


# instance fields
.field final synthetic p:Landroid/support/v4/view/x;

.field final synthetic q:Landroid/view/View;


# direct methods
.method constructor <init>(Landroid/support/v4/view/w;Landroid/support/v4/view/x;Landroid/view/View;)V
    .locals 0

    iput-object p2, p0, Landroid/support/v4/view/u;->p:Landroid/support/v4/view/x;

    iput-object p3, p0, Landroid/support/v4/view/u;->q:Landroid/view/View;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public onAnimationCancel(Landroid/animation/Animator;)V
    .locals 0

    iget-object p1, p0, Landroid/support/v4/view/u;->p:Landroid/support/v4/view/x;

    iget-object p0, p0, Landroid/support/v4/view/u;->q:Landroid/view/View;

    invoke-interface {p1, p0}, Landroid/support/v4/view/x;->b(Landroid/view/View;)V

    return-void
.end method

.method public onAnimationEnd(Landroid/animation/Animator;)V
    .locals 0

    iget-object p1, p0, Landroid/support/v4/view/u;->p:Landroid/support/v4/view/x;

    iget-object p0, p0, Landroid/support/v4/view/u;->q:Landroid/view/View;

    invoke-interface {p1, p0}, Landroid/support/v4/view/x;->d(Landroid/view/View;)V

    return-void
.end method

.method public onAnimationStart(Landroid/animation/Animator;)V
    .locals 0

    iget-object p1, p0, Landroid/support/v4/view/u;->p:Landroid/support/v4/view/x;

    iget-object p0, p0, Landroid/support/v4/view/u;->q:Landroid/view/View;

    invoke-interface {p1, p0}, Landroid/support/v4/view/x;->f(Landroid/view/View;)V

    return-void
.end method
