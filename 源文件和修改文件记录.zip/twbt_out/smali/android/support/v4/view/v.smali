.class Landroid/support/v4/view/v;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/animation/ValueAnimator$AnimatorUpdateListener;


# instance fields
.field final synthetic p:Landroid/support/v4/view/z;

.field final synthetic q:Landroid/view/View;


# direct methods
.method constructor <init>(Landroid/support/v4/view/w;Landroid/support/v4/view/z;Landroid/view/View;)V
    .locals 0

    iput-object p2, p0, Landroid/support/v4/view/v;->p:Landroid/support/v4/view/z;

    iput-object p3, p0, Landroid/support/v4/view/v;->q:Landroid/view/View;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onAnimationUpdate(Landroid/animation/ValueAnimator;)V
    .locals 0

    iget-object p1, p0, Landroid/support/v4/view/v;->p:Landroid/support/v4/view/z;

    iget-object p0, p0, Landroid/support/v4/view/v;->q:Landroid/view/View;

    invoke-interface {p1, p0}, Landroid/support/v4/view/z;->c(Landroid/view/View;)V

    return-void
.end method
