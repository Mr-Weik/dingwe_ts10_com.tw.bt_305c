.class public Landroid/support/v4/view/a/b;
.super Ljava/lang/Object;
.source ""


# instance fields
.field final mInfo:Ljava/lang/Object;


# direct methods
.method constructor <init>(Ljava/lang/Object;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroid/support/v4/view/a/b;->mInfo:Ljava/lang/Object;

    return-void
.end method

.method public static obtain(IIIIZZ)Landroid/support/v4/view/a/b;
    .locals 1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    new-instance v0, Landroid/support/v4/view/a/b;

    invoke-static/range {p0 .. p5}, Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo;->obtain(IIIIZZ)Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo;

    move-result-object p0

    invoke-direct {v0, p0}, Landroid/support/v4/view/a/b;-><init>(Ljava/lang/Object;)V

    return-object v0
.end method
