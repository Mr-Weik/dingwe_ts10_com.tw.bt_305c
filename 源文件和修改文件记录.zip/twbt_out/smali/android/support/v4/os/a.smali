.class Landroid/support/v4/os/a;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/support/v4/os/c;


# instance fields
.field private mRemote:Landroid/os/IBinder;


# direct methods
.method constructor <init>(Landroid/os/IBinder;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroid/support/v4/os/a;->mRemote:Landroid/os/IBinder;

    return-void
.end method


# virtual methods
.method public asBinder()Landroid/os/IBinder;
    .locals 0

    iget-object p0, p0, Landroid/support/v4/os/a;->mRemote:Landroid/os/IBinder;

    return-object p0
.end method
