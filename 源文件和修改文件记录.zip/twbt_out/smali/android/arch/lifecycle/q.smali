.class public Landroid/arch/lifecycle/q;
.super Ljava/lang/Object;
.source ""


# instance fields
.field private final Gc:Landroid/arch/lifecycle/r;

.field private final mFactory:Landroid/arch/lifecycle/p;


# direct methods
.method public constructor <init>(Landroid/arch/lifecycle/r;Landroid/arch/lifecycle/p;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Landroid/arch/lifecycle/q;->mFactory:Landroid/arch/lifecycle/p;

    iput-object p1, p0, Landroid/arch/lifecycle/q;->Gc:Landroid/arch/lifecycle/r;

    return-void
.end method


# virtual methods
.method public b(Ljava/lang/Class;)Landroid/arch/lifecycle/o;
    .locals 3

    invoke-virtual {p1}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_1

    const-string v1, "android.arch.lifecycle.ViewModelProvider.DefaultKey:"

    invoke-static {v1, v0}, Lb/a/a/a/a;->k(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 1
    iget-object v1, p0, Landroid/arch/lifecycle/q;->Gc:Landroid/arch/lifecycle/r;

    invoke-virtual {v1, v0}, Landroid/arch/lifecycle/r;->get(Ljava/lang/String;)Landroid/arch/lifecycle/o;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    goto :goto_0

    :cond_0
    iget-object v1, p0, Landroid/arch/lifecycle/q;->mFactory:Landroid/arch/lifecycle/p;

    invoke-interface {v1, p1}, Landroid/arch/lifecycle/p;->a(Ljava/lang/Class;)Landroid/arch/lifecycle/o;

    move-result-object v1

    iget-object p0, p0, Landroid/arch/lifecycle/q;->Gc:Landroid/arch/lifecycle/r;

    invoke-virtual {p0, v0, v1}, Landroid/arch/lifecycle/r;->a(Ljava/lang/String;Landroid/arch/lifecycle/o;)V

    :goto_0
    return-object v1

    .line 2
    :cond_1
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "Local and anonymous classes can not be ViewModels"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method
