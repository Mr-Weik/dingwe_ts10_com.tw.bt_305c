.class public interface abstract Landroid/arch/lifecycle/s;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract j()Landroid/arch/lifecycle/r;
.end method
