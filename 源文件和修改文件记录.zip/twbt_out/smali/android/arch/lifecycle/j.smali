.class abstract Landroid/arch/lifecycle/j;
.super Ljava/lang/Object;
.source ""


# instance fields
.field mActive:Z

.field final mObserver:Landroid/arch/lifecycle/m;

.field final synthetic n:Landroid/arch/lifecycle/l;

.field zc:I


# virtual methods
.method I()V
    .locals 0

    return-void
.end method

.method abstract J()Z
.end method

.method t(Z)V
    .locals 4

    iget-boolean v0, p0, Landroid/arch/lifecycle/j;->mActive:Z

    if-ne p1, v0, :cond_0

    return-void

    :cond_0
    iput-boolean p1, p0, Landroid/arch/lifecycle/j;->mActive:Z

    iget-object p1, p0, Landroid/arch/lifecycle/j;->n:Landroid/arch/lifecycle/l;

    invoke-static {p1}, Landroid/arch/lifecycle/l;->c(Landroid/arch/lifecycle/l;)I

    move-result p1

    const/4 v0, 0x1

    if-nez p1, :cond_1

    move p1, v0

    goto :goto_0

    :cond_1
    const/4 p1, 0x0

    :goto_0
    iget-object v1, p0, Landroid/arch/lifecycle/j;->n:Landroid/arch/lifecycle/l;

    invoke-static {v1}, Landroid/arch/lifecycle/l;->c(Landroid/arch/lifecycle/l;)I

    move-result v2

    iget-boolean v3, p0, Landroid/arch/lifecycle/j;->mActive:Z

    if-eqz v3, :cond_2

    goto :goto_1

    :cond_2
    const/4 v0, -0x1

    :goto_1
    add-int/2addr v2, v0

    invoke-static {v1, v2}, Landroid/arch/lifecycle/l;->a(Landroid/arch/lifecycle/l;I)I

    if-eqz p1, :cond_3

    iget-boolean p1, p0, Landroid/arch/lifecycle/j;->mActive:Z

    if-eqz p1, :cond_3

    iget-object p1, p0, Landroid/arch/lifecycle/j;->n:Landroid/arch/lifecycle/l;

    invoke-virtual {p1}, Landroid/arch/lifecycle/l;->onActive()V

    :cond_3
    iget-object p1, p0, Landroid/arch/lifecycle/j;->n:Landroid/arch/lifecycle/l;

    invoke-static {p1}, Landroid/arch/lifecycle/l;->c(Landroid/arch/lifecycle/l;)I

    move-result p1

    if-nez p1, :cond_4

    iget-boolean p1, p0, Landroid/arch/lifecycle/j;->mActive:Z

    if-nez p1, :cond_4

    iget-object p1, p0, Landroid/arch/lifecycle/j;->n:Landroid/arch/lifecycle/l;

    invoke-virtual {p1}, Landroid/arch/lifecycle/l;->L()V

    :cond_4
    iget-boolean p1, p0, Landroid/arch/lifecycle/j;->mActive:Z

    if-eqz p1, :cond_5

    iget-object p1, p0, Landroid/arch/lifecycle/j;->n:Landroid/arch/lifecycle/l;

    invoke-static {p1, p0}, Landroid/arch/lifecycle/l;->a(Landroid/arch/lifecycle/l;Landroid/arch/lifecycle/j;)V

    :cond_5
    return-void
.end method
