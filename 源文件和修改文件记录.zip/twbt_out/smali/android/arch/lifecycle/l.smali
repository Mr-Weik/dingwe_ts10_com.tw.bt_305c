.class public Landroid/arch/lifecycle/l;
.super Ljava/lang/Object;
.source ""


# static fields
.field private static final NOT_SET:Ljava/lang/Object;


# instance fields
.field private final Ac:Ljava/lang/Object;

.field private volatile Bc:Ljava/lang/Object;

.field private Cc:Z

.field private Dc:Z

.field private mActiveCount:I

.field private volatile mData:Ljava/lang/Object;

.field private mObservers:La/a/a/b/i;

.field private mVersion:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Landroid/arch/lifecycle/l;->NOT_SET:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Landroid/arch/lifecycle/l;->Ac:Ljava/lang/Object;

    new-instance v0, La/a/a/b/i;

    invoke-direct {v0}, La/a/a/b/i;-><init>()V

    iput-object v0, p0, Landroid/arch/lifecycle/l;->mObservers:La/a/a/b/i;

    const/4 v0, 0x0

    iput v0, p0, Landroid/arch/lifecycle/l;->mActiveCount:I

    sget-object v0, Landroid/arch/lifecycle/l;->NOT_SET:Ljava/lang/Object;

    iput-object v0, p0, Landroid/arch/lifecycle/l;->mData:Ljava/lang/Object;

    iput-object v0, p0, Landroid/arch/lifecycle/l;->Bc:Ljava/lang/Object;

    const/4 v0, -0x1

    iput v0, p0, Landroid/arch/lifecycle/l;->mVersion:I

    new-instance v0, Landroid/arch/lifecycle/i;

    invoke-direct {v0, p0}, Landroid/arch/lifecycle/i;-><init>(Landroid/arch/lifecycle/l;)V

    return-void
.end method

.method static synthetic K()Ljava/lang/Object;
    .locals 1

    sget-object v0, Landroid/arch/lifecycle/l;->NOT_SET:Ljava/lang/Object;

    return-object v0
.end method

.method static synthetic a(Landroid/arch/lifecycle/l;I)I
    .locals 0

    iput p1, p0, Landroid/arch/lifecycle/l;->mActiveCount:I

    return p1
.end method

.method static synthetic a(Landroid/arch/lifecycle/l;)Ljava/lang/Object;
    .locals 0

    iget-object p0, p0, Landroid/arch/lifecycle/l;->Ac:Ljava/lang/Object;

    return-object p0
.end method

.method static synthetic a(Landroid/arch/lifecycle/l;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    iput-object p1, p0, Landroid/arch/lifecycle/l;->Bc:Ljava/lang/Object;

    return-object p1
.end method

.method private a(Landroid/arch/lifecycle/j;)V
    .locals 2

    iget-boolean v0, p1, Landroid/arch/lifecycle/j;->mActive:Z

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {p1}, Landroid/arch/lifecycle/j;->J()Z

    move-result v0

    if-nez v0, :cond_1

    const/4 p0, 0x0

    invoke-virtual {p1, p0}, Landroid/arch/lifecycle/j;->t(Z)V

    return-void

    :cond_1
    iget v0, p1, Landroid/arch/lifecycle/j;->zc:I

    iget v1, p0, Landroid/arch/lifecycle/l;->mVersion:I

    if-lt v0, v1, :cond_2

    return-void

    :cond_2
    iput v1, p1, Landroid/arch/lifecycle/j;->zc:I

    iget-object p1, p1, Landroid/arch/lifecycle/j;->mObserver:Landroid/arch/lifecycle/m;

    iget-object p0, p0, Landroid/arch/lifecycle/l;->mData:Ljava/lang/Object;

    invoke-interface {p1, p0}, Landroid/arch/lifecycle/m;->d(Ljava/lang/Object;)V

    return-void
.end method

.method static synthetic a(Landroid/arch/lifecycle/l;Landroid/arch/lifecycle/j;)V
    .locals 0

    invoke-direct {p0, p1}, Landroid/arch/lifecycle/l;->b(Landroid/arch/lifecycle/j;)V

    return-void
.end method

.method static synthetic b(Landroid/arch/lifecycle/l;)Ljava/lang/Object;
    .locals 0

    iget-object p0, p0, Landroid/arch/lifecycle/l;->Bc:Ljava/lang/Object;

    return-object p0
.end method

.method private b(Landroid/arch/lifecycle/j;)V
    .locals 3

    iget-boolean v0, p0, Landroid/arch/lifecycle/l;->Cc:Z

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    iput-boolean v1, p0, Landroid/arch/lifecycle/l;->Dc:Z

    return-void

    :cond_0
    iput-boolean v1, p0, Landroid/arch/lifecycle/l;->Cc:Z

    :cond_1
    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/arch/lifecycle/l;->Dc:Z

    if-eqz p1, :cond_2

    invoke-direct {p0, p1}, Landroid/arch/lifecycle/l;->a(Landroid/arch/lifecycle/j;)V

    const/4 p1, 0x0

    goto :goto_0

    :cond_2
    iget-object v1, p0, Landroid/arch/lifecycle/l;->mObservers:La/a/a/b/i;

    invoke-virtual {v1}, La/a/a/b/i;->G()La/a/a/b/f;

    move-result-object v1

    :cond_3
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_4

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map$Entry;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/arch/lifecycle/j;

    invoke-direct {p0, v2}, Landroid/arch/lifecycle/l;->a(Landroid/arch/lifecycle/j;)V

    iget-boolean v2, p0, Landroid/arch/lifecycle/l;->Dc:Z

    if-eqz v2, :cond_3

    :cond_4
    :goto_0
    iget-boolean v1, p0, Landroid/arch/lifecycle/l;->Dc:Z

    if-nez v1, :cond_1

    iput-boolean v0, p0, Landroid/arch/lifecycle/l;->Cc:Z

    return-void
.end method

.method static synthetic c(Landroid/arch/lifecycle/l;)I
    .locals 0

    iget p0, p0, Landroid/arch/lifecycle/l;->mActiveCount:I

    return p0
.end method

.method private static ea(Ljava/lang/String;)V
    .locals 3

    invoke-static {}, La/a/a/a/c;->getInstance()La/a/a/a/c;

    move-result-object v0

    invoke-virtual {v0}, La/a/a/a/c;->F()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Cannot invoke "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, " on a background"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, " thread"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method


# virtual methods
.method protected L()V
    .locals 0

    return-void
.end method

.method public a(Landroid/arch/lifecycle/m;)V
    .locals 0

    const-string p1, "removeObserver"

    .line 1
    invoke-static {p1}, Landroid/arch/lifecycle/l;->ea(Ljava/lang/String;)V

    iget-object p0, p0, Landroid/arch/lifecycle/l;->mObservers:La/a/a/b/i;

    const/4 p1, 0x0

    invoke-virtual {p0, p1}, La/a/a/b/i;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/arch/lifecycle/j;

    if-nez p0, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Landroid/arch/lifecycle/j;->I()V

    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Landroid/arch/lifecycle/j;->t(Z)V

    :goto_0
    return-void
.end method

.method protected onActive()V
    .locals 0

    return-void
.end method

.method public setValue(Ljava/lang/Object;)V
    .locals 1

    const-string v0, "setValue"

    .line 1
    invoke-static {v0}, Landroid/arch/lifecycle/l;->ea(Ljava/lang/String;)V

    iget v0, p0, Landroid/arch/lifecycle/l;->mVersion:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Landroid/arch/lifecycle/l;->mVersion:I

    iput-object p1, p0, Landroid/arch/lifecycle/l;->mData:Ljava/lang/Object;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Landroid/arch/lifecycle/l;->b(Landroid/arch/lifecycle/j;)V

    return-void
.end method
