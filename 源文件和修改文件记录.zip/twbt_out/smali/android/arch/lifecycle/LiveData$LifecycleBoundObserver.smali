.class Landroid/arch/lifecycle/LiveData$LifecycleBoundObserver;
.super Landroid/arch/lifecycle/j;
.source ""

# interfaces
.implements Landroid/arch/lifecycle/GenericLifecycleObserver;


# instance fields
.field final mOwner:Landroid/arch/lifecycle/e;

.field final synthetic n:Landroid/arch/lifecycle/l;


# virtual methods
.method I()V
    .locals 1

    iget-object v0, p0, Landroid/arch/lifecycle/LiveData$LifecycleBoundObserver;->mOwner:Landroid/arch/lifecycle/e;

    invoke-interface {v0}, Landroid/arch/lifecycle/e;->y()Landroid/arch/lifecycle/c;

    move-result-object v0

    invoke-virtual {v0, p0}, Landroid/arch/lifecycle/c;->a(Landroid/arch/lifecycle/d;)V

    return-void
.end method

.method J()Z
    .locals 1

    iget-object p0, p0, Landroid/arch/lifecycle/LiveData$LifecycleBoundObserver;->mOwner:Landroid/arch/lifecycle/e;

    invoke-interface {p0}, Landroid/arch/lifecycle/e;->y()Landroid/arch/lifecycle/c;

    move-result-object p0

    invoke-virtual {p0}, Landroid/arch/lifecycle/c;->getCurrentState()Landroid/arch/lifecycle/Lifecycle$State;

    move-result-object p0

    sget-object v0, Landroid/arch/lifecycle/Lifecycle$State;->STARTED:Landroid/arch/lifecycle/Lifecycle$State;

    .line 1
    invoke-virtual {p0, v0}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    move-result p0

    if-ltz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public a(Landroid/arch/lifecycle/e;Landroid/arch/lifecycle/Lifecycle$Event;)V
    .locals 0

    iget-object p1, p0, Landroid/arch/lifecycle/LiveData$LifecycleBoundObserver;->mOwner:Landroid/arch/lifecycle/e;

    invoke-interface {p1}, Landroid/arch/lifecycle/e;->y()Landroid/arch/lifecycle/c;

    move-result-object p1

    invoke-virtual {p1}, Landroid/arch/lifecycle/c;->getCurrentState()Landroid/arch/lifecycle/Lifecycle$State;

    move-result-object p1

    sget-object p2, Landroid/arch/lifecycle/Lifecycle$State;->DESTROYED:Landroid/arch/lifecycle/Lifecycle$State;

    if-ne p1, p2, :cond_0

    iget-object p0, p0, Landroid/arch/lifecycle/LiveData$LifecycleBoundObserver;->n:Landroid/arch/lifecycle/l;

    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Landroid/arch/lifecycle/l;->a(Landroid/arch/lifecycle/m;)V

    return-void

    :cond_0
    invoke-virtual {p0}, Landroid/arch/lifecycle/LiveData$LifecycleBoundObserver;->J()Z

    move-result p1

    invoke-virtual {p0, p1}, Landroid/arch/lifecycle/j;->t(Z)V

    return-void
.end method
