.class public interface abstract Landroid/arch/lifecycle/h;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/arch/lifecycle/e;


# annotations
.annotation runtime Ljava/lang/Deprecated;
.end annotation


# virtual methods
.method public abstract y()Landroid/arch/lifecycle/g;
.end method
