.class public interface abstract Landroid/arch/lifecycle/p;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract a(Ljava/lang/Class;)Landroid/arch/lifecycle/o;
.end method
