.class public interface abstract Landroid/arch/lifecycle/m;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract d(Ljava/lang/Object;)V
.end method
