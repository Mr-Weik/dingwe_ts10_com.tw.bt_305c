.class public interface abstract Landroid/arch/lifecycle/b;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract a(Landroid/arch/lifecycle/e;Landroid/arch/lifecycle/Lifecycle$Event;ZLandroid/arch/lifecycle/k;)V
.end method
