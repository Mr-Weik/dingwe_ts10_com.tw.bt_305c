.class Landroid/arch/lifecycle/i;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic n:Landroid/arch/lifecycle/l;


# direct methods
.method constructor <init>(Landroid/arch/lifecycle/l;)V
    .locals 0

    iput-object p1, p0, Landroid/arch/lifecycle/i;->n:Landroid/arch/lifecycle/l;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    iget-object v0, p0, Landroid/arch/lifecycle/i;->n:Landroid/arch/lifecycle/l;

    invoke-static {v0}, Landroid/arch/lifecycle/l;->a(Landroid/arch/lifecycle/l;)Ljava/lang/Object;

    move-result-object v0

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, Landroid/arch/lifecycle/i;->n:Landroid/arch/lifecycle/l;

    invoke-static {v1}, Landroid/arch/lifecycle/l;->b(Landroid/arch/lifecycle/l;)Ljava/lang/Object;

    move-result-object v1

    iget-object v2, p0, Landroid/arch/lifecycle/i;->n:Landroid/arch/lifecycle/l;

    invoke-static {}, Landroid/arch/lifecycle/l;->K()Ljava/lang/Object;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/arch/lifecycle/l;->a(Landroid/arch/lifecycle/l;Ljava/lang/Object;)Ljava/lang/Object;

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object p0, p0, Landroid/arch/lifecycle/i;->n:Landroid/arch/lifecycle/l;

    invoke-virtual {p0, v1}, Landroid/arch/lifecycle/l;->setValue(Ljava/lang/Object;)V

    return-void

    :catchall_0
    move-exception p0

    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p0
.end method
