.class final La/a/a/a/b;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/util/concurrent/Executor;


# direct methods
.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public execute(Ljava/lang/Runnable;)V
    .locals 0

    invoke-static {}, La/a/a/a/c;->getInstance()La/a/a/a/c;

    move-result-object p0

    invoke-virtual {p0, p1}, La/a/a/a/c;->a(Ljava/lang/Runnable;)V

    return-void
.end method
