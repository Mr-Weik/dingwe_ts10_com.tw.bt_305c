.class public abstract La/a/a/a/e;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public abstract F()Z
.end method

.method public abstract a(Ljava/lang/Runnable;)V
.end method

.method public abstract b(Ljava/lang/Runnable;)V
.end method
