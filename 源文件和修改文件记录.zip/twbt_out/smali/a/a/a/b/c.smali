.class La/a/a/b/c;
.super La/a/a/b/g;
.source ""


# direct methods
.method constructor <init>(La/a/a/b/e;La/a/a/b/e;)V
    .locals 0

    invoke-direct {p0, p1, p2}, La/a/a/b/g;-><init>(La/a/a/b/e;La/a/a/b/e;)V

    return-void
.end method


# virtual methods
.method b(La/a/a/b/e;)La/a/a/b/e;
    .locals 0

    iget-object p0, p1, La/a/a/b/e;->lc:La/a/a/b/e;

    return-object p0
.end method

.method c(La/a/a/b/e;)La/a/a/b/e;
    .locals 0

    iget-object p0, p1, La/a/a/b/e;->mNext:La/a/a/b/e;

    return-object p0
.end method
