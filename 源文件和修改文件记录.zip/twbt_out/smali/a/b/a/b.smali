.class public final La/b/a/b;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final FontFamily:[I

.field public static final FontFamilyFont:[I

.field public static final FontFamily_fontProviderAuthority:I

.field public static final xe:I


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v0, 0x1

    new-array v1, v0, [I

    const/4 v2, 0x0

    const v3, 0x10100b3

    aput v3, v1, v2

    new-array v1, v0, [I

    const v3, 0x101013f

    aput v3, v1, v2

    new-array v1, v0, [I

    const v3, 0x7f030026

    aput v3, v1, v2

    const/4 v1, 0x6

    new-array v1, v1, [I

    fill-array-data v1, :array_0

    sput-object v1, La/b/a/b;->FontFamily:[I

    const/16 v1, 0xa

    new-array v1, v1, [I

    fill-array-data v1, :array_1

    sput-object v1, La/b/a/b;->FontFamilyFont:[I

    new-array v0, v0, [I

    const v1, 0x7f0300e4

    aput v1, v0, v2

    return-void

    :array_0
    .array-data 4
        0x7f03007c
        0x7f03007d
        0x7f03007e
        0x7f03007f
        0x7f030080
        0x7f030081
    .end array-data

    :array_1
    .array-data 4
        0x1010532
        0x1010533
        0x101053f
        0x101056f
        0x1010570
        0x7f03007a
        0x7f030082
        0x7f030083
        0x7f030084
        0x7f030118
    .end array-data
.end method
