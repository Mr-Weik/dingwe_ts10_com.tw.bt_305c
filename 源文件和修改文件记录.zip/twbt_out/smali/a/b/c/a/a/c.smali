.class public final La/b/c/a/a/c;
.super Ljava/lang/Object;
.source ""


# instance fields
.field private final Af:Ljava/lang/String;

.field private Bf:I

.field private Cf:Z

.field private Df:Ljava/lang/String;

.field private Ef:I

.field private Ff:I


# direct methods
.method public constructor <init>(Ljava/lang/String;IZLjava/lang/String;II)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La/b/c/a/a/c;->Af:Ljava/lang/String;

    iput p2, p0, La/b/c/a/a/c;->Bf:I

    iput-boolean p3, p0, La/b/c/a/a/c;->Cf:Z

    iput-object p4, p0, La/b/c/a/a/c;->Df:Ljava/lang/String;

    iput p5, p0, La/b/c/a/a/c;->Ef:I

    iput p6, p0, La/b/c/a/a/c;->Ff:I

    return-void
.end method


# virtual methods
.method public getFileName()Ljava/lang/String;
    .locals 0

    iget-object p0, p0, La/b/c/a/a/c;->Af:Ljava/lang/String;

    return-object p0
.end method

.method public getResourceId()I
    .locals 0

    iget p0, p0, La/b/c/a/a/c;->Ff:I

    return p0
.end method

.method public getTtcIndex()I
    .locals 0

    iget p0, p0, La/b/c/a/a/c;->Ef:I

    return p0
.end method

.method public getVariationSettings()Ljava/lang/String;
    .locals 0

    iget-object p0, p0, La/b/c/a/a/c;->Df:Ljava/lang/String;

    return-object p0
.end method

.method public getWeight()I
    .locals 0

    iget p0, p0, La/b/c/a/a/c;->Bf:I

    return p0
.end method

.method public isItalic()Z
    .locals 0

    iget-boolean p0, p0, La/b/c/a/a/c;->Cf:Z

    return p0
.end method
