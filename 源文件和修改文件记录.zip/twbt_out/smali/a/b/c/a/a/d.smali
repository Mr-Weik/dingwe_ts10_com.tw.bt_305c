.class public final La/b/c/a/a/d;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements La/b/c/a/a/a;


# instance fields
.field private final Gf:I

.field private final Hf:I

.field private final mRequest:La/b/c/d/a;


# direct methods
.method public constructor <init>(La/b/c/d/a;II)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La/b/c/a/a/d;->mRequest:La/b/c/d/a;

    iput p2, p0, La/b/c/a/a/d;->Hf:I

    iput p3, p0, La/b/c/a/a/d;->Gf:I

    return-void
.end method


# virtual methods
.method public getRequest()La/b/c/d/a;
    .locals 0

    iget-object p0, p0, La/b/c/a/a/d;->mRequest:La/b/c/d/a;

    return-object p0
.end method

.method public getTimeout()I
    .locals 0

    iget p0, p0, La/b/c/a/a/d;->Gf:I

    return p0
.end method

.method public va()I
    .locals 0

    iget p0, p0, La/b/c/a/a/d;->Hf:I

    return p0
.end method
