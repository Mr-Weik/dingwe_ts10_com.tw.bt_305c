.class La/b/c/a/a/g;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic Jf:I

.field final synthetic n:La/b/c/a/a/h;


# direct methods
.method constructor <init>(La/b/c/a/a/h;I)V
    .locals 0

    iput-object p1, p0, La/b/c/a/a/g;->n:La/b/c/a/a/h;

    iput p2, p0, La/b/c/a/a/g;->Jf:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    iget-object v0, p0, La/b/c/a/a/g;->n:La/b/c/a/a/h;

    iget p0, p0, La/b/c/a/a/g;->Jf:I

    invoke-virtual {v0, p0}, La/b/c/a/a/h;->K(I)V

    return-void
.end method
