.class public final La/b/c/a/a/b;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements La/b/c/a/a/a;


# instance fields
.field private final mEntries:[La/b/c/a/a/c;


# direct methods
.method public constructor <init>([La/b/c/a/a/c;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La/b/c/a/a/b;->mEntries:[La/b/c/a/a/c;

    return-void
.end method


# virtual methods
.method public getEntries()[La/b/c/a/a/c;
    .locals 0

    iget-object p0, p0, La/b/c/a/a/b;->mEntries:[La/b/c/a/a/c;

    return-object p0
.end method
