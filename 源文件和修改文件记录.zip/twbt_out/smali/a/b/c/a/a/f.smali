.class La/b/c/a/a/f;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic If:Landroid/graphics/Typeface;

.field final synthetic n:La/b/c/a/a/h;


# direct methods
.method constructor <init>(La/b/c/a/a/h;Landroid/graphics/Typeface;)V
    .locals 0

    iput-object p1, p0, La/b/c/a/a/f;->n:La/b/c/a/a/h;

    iput-object p2, p0, La/b/c/a/a/f;->If:Landroid/graphics/Typeface;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    iget-object v0, p0, La/b/c/a/a/f;->n:La/b/c/a/a/h;

    iget-object p0, p0, La/b/c/a/a/f;->If:Landroid/graphics/Typeface;

    invoke-virtual {v0, p0}, La/b/c/a/a/h;->a(Landroid/graphics/Typeface;)V

    return-void
.end method
