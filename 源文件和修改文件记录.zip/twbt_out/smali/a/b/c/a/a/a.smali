.class public interface abstract La/b/c/a/a/a;
.super Ljava/lang/Object;
.source ""
