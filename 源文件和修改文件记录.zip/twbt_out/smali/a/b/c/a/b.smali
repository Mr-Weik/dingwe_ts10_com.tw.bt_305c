.class public interface abstract La/b/c/a/b;
.super Ljava/lang/Object;
.source ""
