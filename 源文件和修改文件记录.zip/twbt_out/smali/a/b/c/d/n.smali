.class public interface abstract La/b/c/d/n;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract a(Ljava/lang/Object;)V
.end method
