.class La/b/c/d/l;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic Ng:Ljava/util/concurrent/Callable;

.field final synthetic Og:Landroid/os/Handler;

.field final synthetic Pg:La/b/c/d/n;


# direct methods
.method constructor <init>(La/b/c/d/o;Ljava/util/concurrent/Callable;Landroid/os/Handler;La/b/c/d/n;)V
    .locals 0

    iput-object p2, p0, La/b/c/d/l;->Ng:Ljava/util/concurrent/Callable;

    iput-object p3, p0, La/b/c/d/l;->Og:Landroid/os/Handler;

    iput-object p4, p0, La/b/c/d/l;->Pg:La/b/c/d/n;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    :try_start_0
    iget-object v0, p0, La/b/c/d/l;->Ng:Ljava/util/concurrent/Callable;

    invoke-interface {v0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, La/b/c/d/l;->Og:Landroid/os/Handler;

    new-instance v2, La/b/c/d/k;

    invoke-direct {v2, p0, v0}, La/b/c/d/k;-><init>(La/b/c/d/l;Ljava/lang/Object;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method
