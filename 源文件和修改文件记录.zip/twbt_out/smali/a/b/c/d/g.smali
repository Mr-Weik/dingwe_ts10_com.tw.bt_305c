.class public La/b/c/d/g;
.super Ljava/lang/Object;
.source ""


# instance fields
.field private final Bf:I

.field private final Cf:Z

.field private final Ef:I

.field private final mResultCode:I

.field private final mUri:Landroid/net/Uri;


# direct methods
.method public constructor <init>(Landroid/net/Uri;IIZI)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    if-eqz p1, :cond_0

    iput-object p1, p0, La/b/c/d/g;->mUri:Landroid/net/Uri;

    iput p2, p0, La/b/c/d/g;->Ef:I

    iput p3, p0, La/b/c/d/g;->Bf:I

    iput-boolean p4, p0, La/b/c/d/g;->Cf:Z

    iput p5, p0, La/b/c/d/g;->mResultCode:I

    return-void

    .line 1
    :cond_0
    new-instance p0, Ljava/lang/NullPointerException;

    invoke-direct {p0}, Ljava/lang/NullPointerException;-><init>()V

    throw p0
.end method


# virtual methods
.method public getResultCode()I
    .locals 0

    iget p0, p0, La/b/c/d/g;->mResultCode:I

    return p0
.end method

.method public getTtcIndex()I
    .locals 0

    iget p0, p0, La/b/c/d/g;->Ef:I

    return p0
.end method

.method public getUri()Landroid/net/Uri;
    .locals 0

    iget-object p0, p0, La/b/c/d/g;->mUri:Landroid/net/Uri;

    return-object p0
.end method

.method public getWeight()I
    .locals 0

    iget p0, p0, La/b/c/d/g;->Bf:I

    return p0
.end method

.method public isItalic()Z
    .locals 0

    iget-boolean p0, p0, La/b/c/d/g;->Cf:Z

    return p0
.end method
