.class final La/b/c/d/b;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/util/concurrent/Callable;


# instance fields
.field final synthetic Bg:Landroid/content/Context;

.field final synthetic Cg:La/b/c/d/a;

.field final synthetic Dg:I

.field final synthetic Eg:Ljava/lang/String;


# direct methods
.method constructor <init>(Landroid/content/Context;La/b/c/d/a;ILjava/lang/String;)V
    .locals 0

    iput-object p1, p0, La/b/c/d/b;->Bg:Landroid/content/Context;

    iput-object p2, p0, La/b/c/d/b;->Cg:La/b/c/d/a;

    iput p3, p0, La/b/c/d/b;->Dg:I

    iput-object p4, p0, La/b/c/d/b;->Eg:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public call()Ljava/lang/Object;
    .locals 3

    .line 1
    iget-object v0, p0, La/b/c/d/b;->Bg:Landroid/content/Context;

    iget-object v1, p0, La/b/c/d/b;->Cg:La/b/c/d/a;

    iget v2, p0, La/b/c/d/b;->Dg:I

    invoke-static {v0, v1, v2}, La/b/c/d/i;->a(Landroid/content/Context;La/b/c/d/a;I)La/b/c/d/h;

    move-result-object v0

    iget-object v1, v0, La/b/c/d/h;->Ig:Landroid/graphics/Typeface;

    if-eqz v1, :cond_0

    sget-object v2, La/b/c/d/i;->Nf:La/b/c/f/h;

    iget-object p0, p0, La/b/c/d/b;->Eg:Ljava/lang/String;

    invoke-virtual {v2, p0, v1}, La/b/c/f/h;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    return-object v0
.end method
