.class La/b/c/d/k;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic Hc:La/b/c/d/l;

.field final synthetic Mg:Ljava/lang/Object;


# direct methods
.method constructor <init>(La/b/c/d/l;Ljava/lang/Object;)V
    .locals 0

    iput-object p1, p0, La/b/c/d/k;->Hc:La/b/c/d/l;

    iput-object p2, p0, La/b/c/d/k;->Mg:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    iget-object v0, p0, La/b/c/d/k;->Hc:La/b/c/d/l;

    iget-object v0, v0, La/b/c/d/l;->Pg:La/b/c/d/n;

    iget-object p0, p0, La/b/c/d/k;->Mg:Ljava/lang/Object;

    invoke-interface {v0, p0}, La/b/c/d/n;->a(Ljava/lang/Object;)V

    return-void
.end method
