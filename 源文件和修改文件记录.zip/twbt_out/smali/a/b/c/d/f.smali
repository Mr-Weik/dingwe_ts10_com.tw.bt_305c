.class public La/b/c/d/f;
.super Ljava/lang/Object;
.source ""


# instance fields
.field private final Hg:[La/b/c/d/g;

.field private final mStatusCode:I


# direct methods
.method public constructor <init>(I[La/b/c/d/g;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, La/b/c/d/f;->mStatusCode:I

    iput-object p2, p0, La/b/c/d/f;->Hg:[La/b/c/d/g;

    return-void
.end method


# virtual methods
.method public getFonts()[La/b/c/d/g;
    .locals 0

    iget-object p0, p0, La/b/c/d/f;->Hg:[La/b/c/d/g;

    return-object p0
.end method

.method public getStatusCode()I
    .locals 0

    iget p0, p0, La/b/c/d/f;->mStatusCode:I

    return p0
.end method
