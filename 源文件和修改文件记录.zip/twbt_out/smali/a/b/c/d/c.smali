.class final La/b/c/d/c;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements La/b/c/d/n;


# instance fields
.field final synthetic Fg:La/b/c/a/a/h;

.field final synthetic Gg:Landroid/os/Handler;


# direct methods
.method constructor <init>(La/b/c/a/a/h;Landroid/os/Handler;)V
    .locals 0

    iput-object p1, p0, La/b/c/d/c;->Fg:La/b/c/a/a/h;

    iput-object p2, p0, La/b/c/d/c;->Gg:Landroid/os/Handler;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Ljava/lang/Object;)V
    .locals 1

    check-cast p1, La/b/c/d/h;

    if-nez p1, :cond_0

    .line 1
    iget-object p1, p0, La/b/c/d/c;->Fg:La/b/c/a/a/h;

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    iget v0, p1, La/b/c/d/h;->mResult:I

    if-nez v0, :cond_1

    iget-object v0, p0, La/b/c/d/c;->Fg:La/b/c/a/a/h;

    iget-object p1, p1, La/b/c/d/h;->Ig:Landroid/graphics/Typeface;

    iget-object p0, p0, La/b/c/d/c;->Gg:Landroid/os/Handler;

    invoke-virtual {v0, p1, p0}, La/b/c/a/a/h;->a(Landroid/graphics/Typeface;Landroid/os/Handler;)V

    goto :goto_1

    :cond_1
    iget-object p1, p0, La/b/c/d/c;->Fg:La/b/c/a/a/h;

    :goto_0
    iget-object p0, p0, La/b/c/d/c;->Gg:Landroid/os/Handler;

    invoke-virtual {p1, v0, p0}, La/b/c/a/a/h;->a(ILandroid/os/Handler;)V

    :goto_1
    return-void
.end method
