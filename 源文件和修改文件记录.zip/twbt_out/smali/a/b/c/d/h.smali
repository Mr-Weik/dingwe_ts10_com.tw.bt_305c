.class final La/b/c/d/h;
.super Ljava/lang/Object;
.source ""


# instance fields
.field final Ig:Landroid/graphics/Typeface;

.field final mResult:I


# direct methods
.method constructor <init>(Landroid/graphics/Typeface;I)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La/b/c/d/h;->Ig:Landroid/graphics/Typeface;

    iput p2, p0, La/b/c/d/h;->mResult:I

    return-void
.end method
