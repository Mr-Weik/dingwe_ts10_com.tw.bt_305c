.class La/b/c/b/g;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements La/b/c/b/h;


# direct methods
.method constructor <init>(La/b/c/b/i;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public b(Ljava/lang/Object;)Z
    .locals 0

    check-cast p1, La/b/c/d/g;

    .line 1
    invoke-virtual {p1}, La/b/c/d/g;->isItalic()Z

    move-result p0

    return p0
.end method

.method public c(Ljava/lang/Object;)I
    .locals 0

    check-cast p1, La/b/c/d/g;

    .line 1
    invoke-virtual {p1}, La/b/c/d/g;->getWeight()I

    move-result p0

    return p0
.end method
