.class interface abstract La/b/c/b/h;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract b(Ljava/lang/Object;)Z
.end method

.method public abstract c(Ljava/lang/Object;)I
.end method
