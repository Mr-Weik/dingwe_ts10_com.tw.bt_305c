.class public interface abstract La/b/c/b/a/b;
.super Ljava/lang/Object;
.source ""
