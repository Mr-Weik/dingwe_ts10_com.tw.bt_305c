.class public interface abstract La/b/c/b/a/c;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract a(Landroid/graphics/drawable/Drawable;)V
.end method

.method public abstract n()Landroid/graphics/drawable/Drawable;
.end method
