.class public La/b/c/b/e;
.super La/b/c/b/d;
.source ""


# instance fields
.field protected final Of:Ljava/lang/reflect/Constructor;

.field protected final Pf:Ljava/lang/reflect/Method;

.field protected final Qf:Ljava/lang/reflect/Method;

.field protected final Rf:Ljava/lang/reflect/Method;

.field protected final Sf:Ljava/lang/reflect/Method;

.field protected final Tf:Ljava/lang/reflect/Method;

.field protected final mFontFamily:Ljava/lang/Class;


# direct methods
.method public constructor <init>()V
    .locals 9

    invoke-direct {p0}, La/b/c/b/d;-><init>()V

    const-string v0, "android.graphics.FontFamily"

    const/4 v1, 0x0

    .line 1
    :try_start_0
    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const/4 v2, 0x0

    new-array v3, v2, [Ljava/lang/Class;

    .line 2
    invoke-virtual {v0, v3}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object v3

    .line 3
    invoke-virtual {p0, v0}, La/b/c/b/e;->c(Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v4

    invoke-virtual {p0, v0}, La/b/c/b/e;->d(Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v5

    new-array v6, v2, [Ljava/lang/Class;

    const-string v7, "freeze"

    .line 4
    invoke-virtual {v0, v7, v6}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v6

    new-array v2, v2, [Ljava/lang/Class;

    const-string v7, "abortCreation"

    .line 5
    invoke-virtual {v0, v7, v2}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v2

    .line 6
    invoke-virtual {p0, v0}, La/b/c/b/e;->e(Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_0

    move-object v8, v3

    move-object v3, v1

    move-object v1, v8

    goto :goto_0

    :catch_0
    move-exception v0

    const-string v2, "Unable to collect necessary methods for class "

    invoke-static {v2}, Lb/a/a/a/a;->x(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v3, "TypefaceCompatApi26Impl"

    invoke-static {v3, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    move-object v0, v1

    move-object v2, v0

    move-object v3, v2

    move-object v4, v3

    move-object v5, v4

    move-object v6, v5

    :goto_0
    iput-object v0, p0, La/b/c/b/e;->mFontFamily:Ljava/lang/Class;

    iput-object v1, p0, La/b/c/b/e;->Of:Ljava/lang/reflect/Constructor;

    iput-object v4, p0, La/b/c/b/e;->Pf:Ljava/lang/reflect/Method;

    iput-object v5, p0, La/b/c/b/e;->Qf:Ljava/lang/reflect/Method;

    iput-object v6, p0, La/b/c/b/e;->Rf:Ljava/lang/reflect/Method;

    iput-object v2, p0, La/b/c/b/e;->Sf:Ljava/lang/reflect/Method;

    iput-object v3, p0, La/b/c/b/e;->Tf:Ljava/lang/reflect/Method;

    return-void
.end method

.method private Uf()Z
    .locals 2

    iget-object v0, p0, La/b/c/b/e;->Pf:Ljava/lang/reflect/Method;

    if-nez v0, :cond_0

    const-string v0, "TypefaceCompatApi26Impl"

    const-string v1, "Unable to collect necessary private methods. Fallback to legacy implementation."

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    iget-object p0, p0, La/b/c/b/e;->Pf:Ljava/lang/reflect/Method;

    if-eqz p0, :cond_1

    const/4 p0, 0x1

    goto :goto_0

    :cond_1
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method private Vf()Ljava/lang/Object;
    .locals 1

    :try_start_0
    iget-object p0, p0, La/b/c/b/e;->Of:Ljava/lang/reflect/Constructor;

    const/4 v0, 0x0

    new-array v0, v0, [Ljava/lang/Object;

    invoke-virtual {p0, v0}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/InstantiationException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    move-exception p0

    new-instance v0, Ljava/lang/RuntimeException;

    invoke-direct {v0, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    throw v0
.end method

.method private a(Landroid/content/Context;Ljava/lang/Object;Ljava/lang/String;III[Landroid/graphics/fonts/FontVariationAxis;)Z
    .locals 2

    :try_start_0
    iget-object p0, p0, La/b/c/b/e;->Pf:Ljava/lang/reflect/Method;

    const/16 v0, 0x8

    new-array v0, v0, [Ljava/lang/Object;

    invoke-virtual {p1}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object p1

    const/4 v1, 0x0

    aput-object p1, v0, v1

    const/4 p1, 0x1

    aput-object p3, v0, p1

    const/4 p1, 0x2

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p3

    aput-object p3, v0, p1

    const/4 p1, 0x3

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p3

    aput-object p3, v0, p1

    const/4 p1, 0x4

    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p3

    aput-object p3, v0, p1

    const/4 p1, 0x5

    invoke-static {p5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p3

    aput-object p3, v0, p1

    const/4 p1, 0x6

    invoke-static {p6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p3

    aput-object p3, v0, p1

    const/4 p1, 0x7

    aput-object p7, v0, p1

    invoke-virtual {p0, p2, v0}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0
    :try_end_0
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0

    return p0

    :catch_0
    move-exception p0

    new-instance p1, Ljava/lang/RuntimeException;

    invoke-direct {p1, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    throw p1
.end method

.method private u(Ljava/lang/Object;)V
    .locals 1

    :try_start_0
    iget-object p0, p0, La/b/c/b/e;->Sf:Ljava/lang/reflect/Method;

    const/4 v0, 0x0

    new-array v0, v0, [Ljava/lang/Object;

    invoke-virtual {p0, p1, v0}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception p0

    new-instance p1, Ljava/lang/RuntimeException;

    invoke-direct {p1, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    throw p1
.end method

.method private v(Ljava/lang/Object;)Z
    .locals 1

    :try_start_0
    iget-object p0, p0, La/b/c/b/e;->Rf:Ljava/lang/reflect/Method;

    const/4 v0, 0x0

    new-array v0, v0, [Ljava/lang/Object;

    invoke-virtual {p0, p1, v0}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0
    :try_end_0
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0

    return p0

    :catch_0
    move-exception p0

    new-instance p1, Ljava/lang/RuntimeException;

    invoke-direct {p1, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    throw p1
.end method


# virtual methods
.method public a(Landroid/content/Context;La/b/c/a/a/b;Landroid/content/res/Resources;I)Landroid/graphics/Typeface;
    .locals 11

    invoke-direct {p0}, La/b/c/b/e;->Uf()Z

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-nez v0, :cond_7

    .line 1
    invoke-virtual {p2}, La/b/c/a/a/b;->getEntries()[La/b/c/a/a/c;

    move-result-object p0

    and-int/lit8 p2, p4, 0x1

    if-nez p2, :cond_0

    const/16 p2, 0x190

    goto :goto_0

    :cond_0
    const/16 p2, 0x2bc

    :goto_0
    and-int/lit8 v0, p4, 0x2

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    move v0, v3

    goto :goto_1

    :cond_1
    move v0, v1

    :goto_1
    const v4, 0x7fffffff

    .line 2
    array-length v5, p0

    move-object v6, v2

    move v7, v4

    move v4, v1

    :goto_2
    if-ge v4, v5, :cond_5

    aget-object v8, p0, v4

    .line 3
    invoke-virtual {v8}, La/b/c/a/a/c;->getWeight()I

    move-result v9

    sub-int/2addr v9, p2

    .line 4
    invoke-static {v9}, Ljava/lang/Math;->abs(I)I

    move-result v9

    mul-int/lit8 v9, v9, 0x2

    .line 5
    invoke-virtual {v8}, La/b/c/a/a/c;->isItalic()Z

    move-result v10

    if-ne v10, v0, :cond_2

    move v10, v1

    goto :goto_3

    :cond_2
    move v10, v3

    :goto_3
    add-int/2addr v9, v10

    if-eqz v6, :cond_3

    if-le v7, v9, :cond_4

    :cond_3
    move-object v6, v8

    move v7, v9

    :cond_4
    add-int/lit8 v4, v4, 0x1

    goto :goto_2

    :cond_5
    if-nez v6, :cond_6

    goto :goto_4

    .line 6
    :cond_6
    invoke-virtual {v6}, La/b/c/a/a/c;->getResourceId()I

    move-result p0

    invoke-virtual {v6}, La/b/c/a/a/c;->getFileName()Ljava/lang/String;

    move-result-object p2

    invoke-static {p1, p3, p0, p2, p4}, La/b/c/b/c;->a(Landroid/content/Context;Landroid/content/res/Resources;ILjava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v2

    :goto_4
    return-object v2

    .line 7
    :cond_7
    invoke-direct {p0}, La/b/c/b/e;->Vf()Ljava/lang/Object;

    move-result-object p3

    invoke-virtual {p2}, La/b/c/a/a/b;->getEntries()[La/b/c/a/a/c;

    move-result-object p2

    array-length p4, p2

    :goto_5
    if-ge v1, p4, :cond_9

    aget-object v0, p2, v1

    invoke-virtual {v0}, La/b/c/a/a/c;->getFileName()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v0}, La/b/c/a/a/c;->getTtcIndex()I

    move-result v7

    invoke-virtual {v0}, La/b/c/a/a/c;->getWeight()I

    move-result v8

    invoke-virtual {v0}, La/b/c/a/a/c;->isItalic()Z

    move-result v9

    invoke-virtual {v0}, La/b/c/a/a/c;->getVariationSettings()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/graphics/fonts/FontVariationAxis;->fromFontVariationSettings(Ljava/lang/String;)[Landroid/graphics/fonts/FontVariationAxis;

    move-result-object v10

    move-object v3, p0

    move-object v4, p1

    move-object v5, p3

    invoke-direct/range {v3 .. v10}, La/b/c/b/e;->a(Landroid/content/Context;Ljava/lang/Object;Ljava/lang/String;III[Landroid/graphics/fonts/FontVariationAxis;)Z

    move-result v0

    if-nez v0, :cond_8

    invoke-direct {p0, p3}, La/b/c/b/e;->u(Ljava/lang/Object;)V

    return-object v2

    :cond_8
    add-int/lit8 v1, v1, 0x1

    goto :goto_5

    :cond_9
    invoke-direct {p0, p3}, La/b/c/b/e;->v(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_a

    return-object v2

    :cond_a
    invoke-virtual {p0, p3}, La/b/c/b/e;->h(Ljava/lang/Object;)Landroid/graphics/Typeface;

    move-result-object p0

    return-object p0
.end method

.method public a(Landroid/content/Context;Landroid/content/res/Resources;ILjava/lang/String;I)Landroid/graphics/Typeface;
    .locals 9

    invoke-direct {p0}, La/b/c/b/e;->Uf()Z

    move-result p5

    const/4 v0, 0x0

    if-nez p5, :cond_2

    .line 12
    invoke-static {p1}, La/b/c/b/b;->c(Landroid/content/Context;)Ljava/io/File;

    move-result-object p0

    if-nez p0, :cond_0

    goto :goto_1

    :cond_0
    :try_start_0
    invoke-static {p0, p2, p3}, La/b/c/b/b;->a(Ljava/io/File;Landroid/content/res/Resources;I)Z

    move-result p1

    if-nez p1, :cond_1

    goto :goto_0

    :cond_1
    invoke-virtual {p0}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Landroid/graphics/Typeface;->createFromFile(Ljava/lang/String;)Landroid/graphics/Typeface;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p1

    invoke-virtual {p0}, Ljava/io/File;->delete()Z

    throw p1

    :catch_0
    :goto_0
    invoke-virtual {p0}, Ljava/io/File;->delete()Z

    :goto_1
    return-object v0

    .line 13
    :cond_2
    invoke-direct {p0}, La/b/c/b/e;->Vf()Ljava/lang/Object;

    move-result-object p2

    const/4 v5, 0x0

    const/4 v6, -0x1

    const/4 v7, -0x1

    const/4 v8, 0x0

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move-object v4, p4

    invoke-direct/range {v1 .. v8}, La/b/c/b/e;->a(Landroid/content/Context;Ljava/lang/Object;Ljava/lang/String;III[Landroid/graphics/fonts/FontVariationAxis;)Z

    move-result p1

    if-nez p1, :cond_3

    invoke-direct {p0, p2}, La/b/c/b/e;->u(Ljava/lang/Object;)V

    return-object v0

    :cond_3
    invoke-direct {p0, p2}, La/b/c/b/e;->v(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_4

    return-object v0

    :cond_4
    invoke-virtual {p0, p2}, La/b/c/b/e;->h(Ljava/lang/Object;)Landroid/graphics/Typeface;

    move-result-object p0

    return-object p0
.end method

.method public a(Landroid/content/Context;Landroid/os/CancellationSignal;[La/b/c/d/g;I)Landroid/graphics/Typeface;
    .locals 11

    array-length v0, p3

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-ge v0, v1, :cond_0

    return-object v2

    :cond_0
    invoke-direct {p0}, La/b/c/b/e;->Uf()Z

    move-result v0

    if-nez v0, :cond_3

    invoke-virtual {p0, p3, p4}, La/b/c/b/i;->a([La/b/c/d/g;I)La/b/c/d/g;

    move-result-object p0

    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p1

    :try_start_0
    invoke-virtual {p0}, La/b/c/d/g;->getUri()Landroid/net/Uri;

    move-result-object p3

    const-string p4, "r"

    invoke-virtual {p1, p3, p4, p2}, Landroid/content/ContentResolver;->openFileDescriptor(Landroid/net/Uri;Ljava/lang/String;Landroid/os/CancellationSignal;)Landroid/os/ParcelFileDescriptor;

    move-result-object p1

    if-nez p1, :cond_2

    if-eqz p1, :cond_1

    invoke-virtual {p1}, Landroid/os/ParcelFileDescriptor;->close()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :cond_1
    return-object v2

    :cond_2
    :try_start_1
    new-instance p2, Landroid/graphics/Typeface$Builder;

    invoke-virtual {p1}, Landroid/os/ParcelFileDescriptor;->getFileDescriptor()Ljava/io/FileDescriptor;

    move-result-object p3

    invoke-direct {p2, p3}, Landroid/graphics/Typeface$Builder;-><init>(Ljava/io/FileDescriptor;)V

    invoke-virtual {p0}, La/b/c/d/g;->getWeight()I

    move-result p3

    invoke-virtual {p2, p3}, Landroid/graphics/Typeface$Builder;->setWeight(I)Landroid/graphics/Typeface$Builder;

    move-result-object p2

    invoke-virtual {p0}, La/b/c/d/g;->isItalic()Z

    move-result p0

    invoke-virtual {p2, p0}, Landroid/graphics/Typeface$Builder;->setItalic(Z)Landroid/graphics/Typeface$Builder;

    move-result-object p0

    invoke-virtual {p0}, Landroid/graphics/Typeface$Builder;->build()Landroid/graphics/Typeface;

    move-result-object p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    invoke-virtual {p1}, Landroid/os/ParcelFileDescriptor;->close()V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0

    return-object p0

    :catchall_0
    move-exception p0

    :try_start_3
    throw p0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :catchall_1
    move-exception p2

    :try_start_4
    invoke-virtual {p1}, Landroid/os/ParcelFileDescriptor;->close()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    goto :goto_0

    :catchall_2
    move-exception p1

    :try_start_5
    invoke-virtual {p0, p1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_0
    throw p2
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_0

    :catch_0
    return-object v2

    :cond_3
    invoke-static {p1, p3, p2}, La/b/c/d/i;->a(Landroid/content/Context;[La/b/c/d/g;Landroid/os/CancellationSignal;)Ljava/util/Map;

    move-result-object p1

    invoke-direct {p0}, La/b/c/b/e;->Vf()Ljava/lang/Object;

    move-result-object p2

    array-length v0, p3

    const/4 v3, 0x0

    move v4, v3

    move v5, v4

    :goto_1
    if-ge v4, v0, :cond_6

    aget-object v6, p3, v4

    invoke-virtual {v6}, La/b/c/d/g;->getUri()Landroid/net/Uri;

    move-result-object v7

    invoke-interface {p1, v7}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/nio/ByteBuffer;

    if-nez v7, :cond_4

    goto :goto_2

    :cond_4
    invoke-virtual {v6}, La/b/c/d/g;->getTtcIndex()I

    move-result v5

    invoke-virtual {v6}, La/b/c/d/g;->getWeight()I

    move-result v8

    invoke-virtual {v6}, La/b/c/d/g;->isItalic()Z

    move-result v6

    .line 8
    :try_start_6
    iget-object v9, p0, La/b/c/b/e;->Qf:Ljava/lang/reflect/Method;

    const/4 v10, 0x5

    new-array v10, v10, [Ljava/lang/Object;

    aput-object v7, v10, v3

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v10, v1

    const/4 v5, 0x2

    aput-object v2, v10, v5

    const/4 v5, 0x3

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    aput-object v7, v10, v5

    const/4 v5, 0x4

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    aput-object v6, v10, v5

    invoke-virtual {v9, p2, v10}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5
    :try_end_6
    .catch Ljava/lang/IllegalAccessException; {:try_start_6 .. :try_end_6} :catch_1
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_6 .. :try_end_6} :catch_1

    if-nez v5, :cond_5

    .line 9
    invoke-direct {p0, p2}, La/b/c/b/e;->u(Ljava/lang/Object;)V

    return-object v2

    :cond_5
    move v5, v1

    :goto_2
    add-int/lit8 v4, v4, 0x1

    goto :goto_1

    :catch_1
    move-exception p0

    .line 10
    new-instance p1, Ljava/lang/RuntimeException;

    invoke-direct {p1, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    throw p1

    :cond_6
    if-nez v5, :cond_7

    .line 11
    invoke-direct {p0, p2}, La/b/c/b/e;->u(Ljava/lang/Object;)V

    return-object v2

    :cond_7
    invoke-direct {p0, p2}, La/b/c/b/e;->v(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_8

    return-object v2

    :cond_8
    invoke-virtual {p0, p2}, La/b/c/b/e;->h(Ljava/lang/Object;)Landroid/graphics/Typeface;

    move-result-object p0

    invoke-static {p0, p4}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    move-result-object p0

    return-object p0
.end method

.method protected c(Ljava/lang/Class;)Ljava/lang/reflect/Method;
    .locals 2

    const/16 p0, 0x8

    new-array p0, p0, [Ljava/lang/Class;

    const-class v0, Landroid/content/res/AssetManager;

    const/4 v1, 0x0

    aput-object v0, p0, v1

    const-class v0, Ljava/lang/String;

    const/4 v1, 0x1

    aput-object v0, p0, v1

    sget-object v0, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v1, 0x2

    aput-object v0, p0, v1

    sget-object v0, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    const/4 v1, 0x3

    aput-object v0, p0, v1

    sget-object v0, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v1, 0x4

    aput-object v0, p0, v1

    const/4 v1, 0x5

    aput-object v0, p0, v1

    const/4 v1, 0x6

    aput-object v0, p0, v1

    const-class v0, [Landroid/graphics/fonts/FontVariationAxis;

    const/4 v1, 0x7

    aput-object v0, p0, v1

    const-string v0, "addFontFromAssetManager"

    invoke-virtual {p1, v0, p0}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object p0

    return-object p0
.end method

.method protected d(Ljava/lang/Class;)Ljava/lang/reflect/Method;
    .locals 3

    const/4 p0, 0x5

    new-array p0, p0, [Ljava/lang/Class;

    const-class v0, Ljava/nio/ByteBuffer;

    const/4 v1, 0x0

    aput-object v0, p0, v1

    sget-object v0, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v1, 0x1

    aput-object v0, p0, v1

    const-class v1, [Landroid/graphics/fonts/FontVariationAxis;

    const/4 v2, 0x2

    aput-object v1, p0, v2

    const/4 v1, 0x3

    aput-object v0, p0, v1

    const/4 v1, 0x4

    aput-object v0, p0, v1

    const-string v0, "addFontFromBuffer"

    invoke-virtual {p1, v0, p0}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object p0

    return-object p0
.end method

.method protected e(Ljava/lang/Class;)Ljava/lang/reflect/Method;
    .locals 0

    const p0, 0x0

    throw p0
.end method

.method protected h(Ljava/lang/Object;)Landroid/graphics/Typeface;
    .locals 0

    const p0, 0x0

    throw p0
.end method
