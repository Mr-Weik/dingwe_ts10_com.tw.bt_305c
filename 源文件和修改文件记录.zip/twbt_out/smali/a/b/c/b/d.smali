.class La/b/c/b/d;
.super La/b/c/b/i;
.source ""


# direct methods
.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, La/b/c/b/i;-><init>()V

    return-void
.end method
