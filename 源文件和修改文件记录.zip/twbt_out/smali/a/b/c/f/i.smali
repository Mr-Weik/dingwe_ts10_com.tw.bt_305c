.class final La/b/c/f/i;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/util/Iterator;


# instance fields
.field mCanRemove:Z

.field mIndex:I

.field final mOffset:I

.field mSize:I

.field final synthetic n:La/b/c/f/n;


# direct methods
.method constructor <init>(La/b/c/f/n;I)V
    .locals 1

    iput-object p1, p0, La/b/c/f/i;->n:La/b/c/f/n;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, La/b/c/f/i;->mCanRemove:Z

    iput p2, p0, La/b/c/f/i;->mOffset:I

    invoke-virtual {p1}, La/b/c/f/n;->colGetSize()I

    move-result p1

    iput p1, p0, La/b/c/f/i;->mSize:I

    return-void
.end method


# virtual methods
.method public hasNext()Z
    .locals 1

    iget v0, p0, La/b/c/f/i;->mIndex:I

    iget p0, p0, La/b/c/f/i;->mSize:I

    if-ge v0, p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public next()Ljava/lang/Object;
    .locals 4

    .line 1
    iget v0, p0, La/b/c/f/i;->mIndex:I

    iget v1, p0, La/b/c/f/i;->mSize:I

    const/4 v2, 0x1

    if-ge v0, v1, :cond_0

    move v0, v2

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    if-eqz v0, :cond_1

    .line 2
    iget-object v0, p0, La/b/c/f/i;->n:La/b/c/f/n;

    iget v1, p0, La/b/c/f/i;->mIndex:I

    iget v3, p0, La/b/c/f/i;->mOffset:I

    invoke-virtual {v0, v1, v3}, La/b/c/f/n;->colGetEntry(II)Ljava/lang/Object;

    move-result-object v0

    iget v1, p0, La/b/c/f/i;->mIndex:I

    add-int/2addr v1, v2

    iput v1, p0, La/b/c/f/i;->mIndex:I

    iput-boolean v2, p0, La/b/c/f/i;->mCanRemove:Z

    return-object v0

    :cond_1
    new-instance p0, Ljava/util/NoSuchElementException;

    invoke-direct {p0}, Ljava/util/NoSuchElementException;-><init>()V

    throw p0
.end method

.method public remove()V
    .locals 1

    iget-boolean v0, p0, La/b/c/f/i;->mCanRemove:Z

    if-eqz v0, :cond_0

    iget v0, p0, La/b/c/f/i;->mIndex:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, La/b/c/f/i;->mIndex:I

    iget v0, p0, La/b/c/f/i;->mSize:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, La/b/c/f/i;->mSize:I

    const/4 v0, 0x0

    iput-boolean v0, p0, La/b/c/f/i;->mCanRemove:Z

    iget-object v0, p0, La/b/c/f/i;->n:La/b/c/f/n;

    iget p0, p0, La/b/c/f/i;->mIndex:I

    invoke-virtual {v0, p0}, La/b/c/f/n;->colRemoveAt(I)V

    return-void

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    invoke-direct {p0}, Ljava/lang/IllegalStateException;-><init>()V

    throw p0
.end method
