.class La/b/c/f/c;
.super La/b/c/f/n;
.source ""


# instance fields
.field final synthetic n:La/b/c/f/d;


# direct methods
.method constructor <init>(La/b/c/f/d;)V
    .locals 0

    iput-object p1, p0, La/b/c/f/c;->n:La/b/c/f/d;

    invoke-direct {p0}, La/b/c/f/n;-><init>()V

    return-void
.end method


# virtual methods
.method protected colClear()V
    .locals 0

    iget-object p0, p0, La/b/c/f/c;->n:La/b/c/f/d;

    invoke-virtual {p0}, La/b/c/f/d;->clear()V

    return-void
.end method

.method protected colGetEntry(II)Ljava/lang/Object;
    .locals 0

    iget-object p0, p0, La/b/c/f/c;->n:La/b/c/f/d;

    invoke-static {p0}, La/b/c/f/d;->b(La/b/c/f/d;)[Ljava/lang/Object;

    move-result-object p0

    aget-object p0, p0, p1

    return-object p0
.end method

.method protected colGetMap()Ljava/util/Map;
    .locals 1

    new-instance p0, Ljava/lang/UnsupportedOperationException;

    const-string v0, "not a map"

    invoke-direct {p0, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method protected colGetSize()I
    .locals 0

    iget-object p0, p0, La/b/c/f/c;->n:La/b/c/f/d;

    invoke-static {p0}, La/b/c/f/d;->a(La/b/c/f/d;)I

    move-result p0

    return p0
.end method

.method protected colIndexOfKey(Ljava/lang/Object;)I
    .locals 0

    iget-object p0, p0, La/b/c/f/c;->n:La/b/c/f/d;

    invoke-virtual {p0, p1}, La/b/c/f/d;->indexOf(Ljava/lang/Object;)I

    move-result p0

    return p0
.end method

.method protected colIndexOfValue(Ljava/lang/Object;)I
    .locals 0

    iget-object p0, p0, La/b/c/f/c;->n:La/b/c/f/d;

    invoke-virtual {p0, p1}, La/b/c/f/d;->indexOf(Ljava/lang/Object;)I

    move-result p0

    return p0
.end method

.method protected colPut(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 0

    iget-object p0, p0, La/b/c/f/c;->n:La/b/c/f/d;

    invoke-virtual {p0, p1}, La/b/c/f/d;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method protected colRemoveAt(I)V
    .locals 0

    iget-object p0, p0, La/b/c/f/c;->n:La/b/c/f/d;

    invoke-virtual {p0, p1}, La/b/c/f/d;->removeAt(I)Ljava/lang/Object;

    return-void
.end method

.method protected colSetValue(ILjava/lang/Object;)Ljava/lang/Object;
    .locals 0

    new-instance p0, Ljava/lang/UnsupportedOperationException;

    const-string p1, "not a map"

    invoke-direct {p0, p1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p0
.end method
