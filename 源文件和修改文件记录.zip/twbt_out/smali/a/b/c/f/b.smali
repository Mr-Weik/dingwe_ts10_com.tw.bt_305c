.class public La/b/c/f/b;
.super La/b/c/f/p;
.source ""

# interfaces
.implements Ljava/util/Map;


# instance fields
.field mCollections:La/b/c/f/n;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La/b/c/f/p;-><init>()V

    return-void
.end method

.method private getCollection()La/b/c/f/n;
    .locals 1

    iget-object v0, p0, La/b/c/f/b;->mCollections:La/b/c/f/n;

    if-nez v0, :cond_0

    new-instance v0, La/b/c/f/a;

    invoke-direct {v0, p0}, La/b/c/f/a;-><init>(La/b/c/f/b;)V

    iput-object v0, p0, La/b/c/f/b;->mCollections:La/b/c/f/n;

    :cond_0
    iget-object p0, p0, La/b/c/f/b;->mCollections:La/b/c/f/n;

    return-object p0
.end method


# virtual methods
.method public entrySet()Ljava/util/Set;
    .locals 1

    invoke-direct {p0}, La/b/c/f/b;->getCollection()La/b/c/f/n;

    move-result-object p0

    .line 1
    iget-object v0, p0, La/b/c/f/n;->mEntrySet:La/b/c/f/j;

    if-nez v0, :cond_0

    new-instance v0, La/b/c/f/j;

    invoke-direct {v0, p0}, La/b/c/f/j;-><init>(La/b/c/f/n;)V

    iput-object v0, p0, La/b/c/f/n;->mEntrySet:La/b/c/f/j;

    :cond_0
    iget-object p0, p0, La/b/c/f/n;->mEntrySet:La/b/c/f/j;

    return-object p0
.end method

.method public keySet()Ljava/util/Set;
    .locals 1

    invoke-direct {p0}, La/b/c/f/b;->getCollection()La/b/c/f/n;

    move-result-object p0

    .line 1
    iget-object v0, p0, La/b/c/f/n;->mKeySet:La/b/c/f/k;

    if-nez v0, :cond_0

    new-instance v0, La/b/c/f/k;

    invoke-direct {v0, p0}, La/b/c/f/k;-><init>(La/b/c/f/n;)V

    iput-object v0, p0, La/b/c/f/n;->mKeySet:La/b/c/f/k;

    :cond_0
    iget-object p0, p0, La/b/c/f/n;->mKeySet:La/b/c/f/k;

    return-object p0
.end method

.method public putAll(Ljava/util/Map;)V
    .locals 2

    iget v0, p0, La/b/c/f/p;->mSize:I

    invoke-interface {p1}, Ljava/util/Map;->size()I

    move-result v1

    add-int/2addr v1, v0

    invoke-virtual {p0, v1}, La/b/c/f/p;->ensureCapacity(I)V

    invoke-interface {p1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map$Entry;

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p0, v1, v0}, La/b/c/f/p;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_0

    :cond_0
    return-void
.end method

.method public retainAll(Ljava/util/Collection;)Z
    .locals 0

    invoke-static {p0, p1}, La/b/c/f/n;->retainAllHelper(Ljava/util/Map;Ljava/util/Collection;)Z

    move-result p0

    return p0
.end method

.method public values()Ljava/util/Collection;
    .locals 1

    invoke-direct {p0}, La/b/c/f/b;->getCollection()La/b/c/f/n;

    move-result-object p0

    .line 1
    iget-object v0, p0, La/b/c/f/n;->mValues:La/b/c/f/m;

    if-nez v0, :cond_0

    new-instance v0, La/b/c/f/m;

    invoke-direct {v0, p0}, La/b/c/f/m;-><init>(La/b/c/f/n;)V

    iput-object v0, p0, La/b/c/f/n;->mValues:La/b/c/f/m;

    :cond_0
    iget-object p0, p0, La/b/c/f/n;->mValues:La/b/c/f/m;

    return-object p0
.end method
