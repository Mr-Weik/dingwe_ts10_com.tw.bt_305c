.class La/b/c/f/a;
.super La/b/c/f/n;
.source ""


# instance fields
.field final synthetic n:La/b/c/f/b;


# direct methods
.method constructor <init>(La/b/c/f/b;)V
    .locals 0

    iput-object p1, p0, La/b/c/f/a;->n:La/b/c/f/b;

    invoke-direct {p0}, La/b/c/f/n;-><init>()V

    return-void
.end method


# virtual methods
.method protected colClear()V
    .locals 0

    iget-object p0, p0, La/b/c/f/a;->n:La/b/c/f/b;

    invoke-virtual {p0}, La/b/c/f/p;->clear()V

    return-void
.end method

.method protected colGetEntry(II)Ljava/lang/Object;
    .locals 0

    iget-object p0, p0, La/b/c/f/a;->n:La/b/c/f/b;

    iget-object p0, p0, La/b/c/f/p;->mArray:[Ljava/lang/Object;

    shl-int/lit8 p1, p1, 0x1

    add-int/2addr p1, p2

    aget-object p0, p0, p1

    return-object p0
.end method

.method protected colGetMap()Ljava/util/Map;
    .locals 0

    iget-object p0, p0, La/b/c/f/a;->n:La/b/c/f/b;

    return-object p0
.end method

.method protected colGetSize()I
    .locals 0

    iget-object p0, p0, La/b/c/f/a;->n:La/b/c/f/b;

    iget p0, p0, La/b/c/f/p;->mSize:I

    return p0
.end method

.method protected colIndexOfKey(Ljava/lang/Object;)I
    .locals 0

    iget-object p0, p0, La/b/c/f/a;->n:La/b/c/f/b;

    invoke-virtual {p0, p1}, La/b/c/f/p;->indexOfKey(Ljava/lang/Object;)I

    move-result p0

    return p0
.end method

.method protected colIndexOfValue(Ljava/lang/Object;)I
    .locals 0

    iget-object p0, p0, La/b/c/f/a;->n:La/b/c/f/b;

    invoke-virtual {p0, p1}, La/b/c/f/p;->indexOfValue(Ljava/lang/Object;)I

    move-result p0

    return p0
.end method

.method protected colPut(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 0

    iget-object p0, p0, La/b/c/f/a;->n:La/b/c/f/b;

    invoke-virtual {p0, p1, p2}, La/b/c/f/p;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method protected colRemoveAt(I)V
    .locals 0

    iget-object p0, p0, La/b/c/f/a;->n:La/b/c/f/b;

    invoke-virtual {p0, p1}, La/b/c/f/p;->removeAt(I)Ljava/lang/Object;

    return-void
.end method

.method protected colSetValue(ILjava/lang/Object;)Ljava/lang/Object;
    .locals 1

    iget-object p0, p0, La/b/c/f/a;->n:La/b/c/f/b;

    shl-int/lit8 p1, p1, 0x1

    add-int/lit8 p1, p1, 0x1

    .line 1
    iget-object p0, p0, La/b/c/f/p;->mArray:[Ljava/lang/Object;

    aget-object v0, p0, p1

    aput-object p2, p0, p1

    return-object v0
.end method
