.class abstract La/b/b/a/a;
.super Landroid/graphics/drawable/Drawable;
.source ""

# interfaces
.implements La/b/c/b/a/b;
