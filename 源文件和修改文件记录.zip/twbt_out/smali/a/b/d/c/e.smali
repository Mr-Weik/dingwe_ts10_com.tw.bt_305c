.class La/b/d/c/e;
.super Landroid/os/AsyncTask;
.source ""


# instance fields
.field final synthetic n:La/b/d/c/f;

.field final synthetic p:La/b/d/c/h;


# direct methods
.method constructor <init>(La/b/d/c/f;La/b/d/c/h;)V
    .locals 0

    iput-object p1, p0, La/b/d/c/e;->n:La/b/d/c/f;

    iput-object p2, p0, La/b/d/c/e;->p:La/b/d/c/h;

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    return-void
.end method


# virtual methods
.method protected doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    check-cast p1, [Landroid/graphics/Bitmap;

    .line 1
    :try_start_0
    iget-object p0, p0, La/b/d/c/e;->n:La/b/d/c/f;

    invoke-virtual {p0}, La/b/d/c/f;->generate()La/b/d/c/j;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p0

    const-string p1, "Palette"

    const-string v0, "Exception thrown during async generate"

    invoke-static {p1, v0, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 p0, 0x0

    :goto_0
    return-object p0
.end method

.method protected onPostExecute(Ljava/lang/Object;)V
    .locals 0

    check-cast p1, La/b/d/c/j;

    .line 1
    iget-object p0, p0, La/b/d/c/e;->p:La/b/d/c/h;

    invoke-interface {p0, p1}, La/b/d/c/h;->a(La/b/d/c/j;)V

    return-void
.end method
