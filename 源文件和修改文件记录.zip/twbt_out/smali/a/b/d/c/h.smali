.class public interface abstract La/b/d/c/h;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract a(La/b/d/c/j;)V
.end method
