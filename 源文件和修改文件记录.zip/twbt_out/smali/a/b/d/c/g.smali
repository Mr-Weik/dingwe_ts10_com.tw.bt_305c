.class public interface abstract La/b/d/c/g;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract isAllowed(I[F)Z
.end method
