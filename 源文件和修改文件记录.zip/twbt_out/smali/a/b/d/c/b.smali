.class La/b/d/c/b;
.super Ljava/lang/Object;
.source ""


# instance fields
.field private Kk:I

.field private Lk:I

.field private Mk:I

.field private Nk:I

.field private Ok:I

.field private Pk:I

.field private Qk:I

.field private Rk:I

.field private Sk:I

.field final synthetic n:La/b/d/c/c;


# direct methods
.method constructor <init>(La/b/d/c/c;II)V
    .locals 0

    iput-object p1, p0, La/b/d/c/b;->n:La/b/d/c/c;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p2, p0, La/b/d/c/b;->Kk:I

    iput p3, p0, La/b/d/c/b;->Lk:I

    invoke-virtual {p0}, La/b/d/c/b;->fitBox()V

    return-void
.end method


# virtual methods
.method final canSplit()Z
    .locals 2

    .line 1
    iget v0, p0, La/b/d/c/b;->Lk:I

    const/4 v1, 0x1

    add-int/2addr v0, v1

    iget p0, p0, La/b/d/c/b;->Kk:I

    sub-int/2addr v0, p0

    if-le v0, v1, :cond_0

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    return v1
.end method

.method final fitBox()V
    .locals 13

    iget-object v0, p0, La/b/d/c/b;->n:La/b/d/c/c;

    iget-object v1, v0, La/b/d/c/c;->mColors:[I

    iget-object v0, v0, La/b/d/c/c;->mHistogram:[I

    iget v2, p0, La/b/d/c/b;->Kk:I

    const v3, 0x7fffffff

    const/high16 v4, -0x80000000

    const/4 v5, 0x0

    move v7, v3

    move v6, v4

    move v8, v6

    move v9, v5

    move v5, v7

    :goto_0
    iget v10, p0, La/b/d/c/b;->Lk:I

    if-gt v2, v10, :cond_6

    aget v10, v1, v2

    aget v11, v0, v10

    add-int/2addr v9, v11

    shr-int/lit8 v11, v10, 0xa

    and-int/lit8 v11, v11, 0x1f

    shr-int/lit8 v12, v10, 0x5

    and-int/lit8 v12, v12, 0x1f

    and-int/lit8 v10, v10, 0x1f

    if-le v11, v4, :cond_0

    move v4, v11

    :cond_0
    if-ge v11, v3, :cond_1

    move v3, v11

    :cond_1
    if-le v12, v6, :cond_2

    move v6, v12

    :cond_2
    if-ge v12, v5, :cond_3

    move v5, v12

    :cond_3
    if-le v10, v8, :cond_4

    move v8, v10

    :cond_4
    if-ge v10, v7, :cond_5

    move v7, v10

    :cond_5
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_6
    iput v3, p0, La/b/d/c/b;->Nk:I

    iput v4, p0, La/b/d/c/b;->Ok:I

    iput v5, p0, La/b/d/c/b;->Pk:I

    iput v6, p0, La/b/d/c/b;->Qk:I

    iput v7, p0, La/b/d/c/b;->Rk:I

    iput v8, p0, La/b/d/c/b;->Sk:I

    iput v9, p0, La/b/d/c/b;->Mk:I

    return-void
.end method

.method final getAverageColor()La/b/d/c/i;
    .locals 10

    iget-object v0, p0, La/b/d/c/b;->n:La/b/d/c/c;

    iget-object v1, v0, La/b/d/c/c;->mColors:[I

    iget-object v0, v0, La/b/d/c/c;->mHistogram:[I

    iget v2, p0, La/b/d/c/b;->Kk:I

    const/4 v3, 0x0

    move v4, v3

    move v5, v4

    move v6, v5

    :goto_0
    iget v7, p0, La/b/d/c/b;->Lk:I

    if-gt v2, v7, :cond_0

    aget v7, v1, v2

    aget v8, v0, v7

    add-int/2addr v4, v8

    shr-int/lit8 v9, v7, 0xa

    and-int/lit8 v9, v9, 0x1f

    mul-int/2addr v9, v8

    add-int/2addr v3, v9

    shr-int/lit8 v9, v7, 0x5

    and-int/lit8 v9, v9, 0x1f

    mul-int/2addr v9, v8

    add-int/2addr v5, v9

    and-int/lit8 v7, v7, 0x1f

    mul-int/2addr v8, v7

    add-int/2addr v6, v8

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    int-to-float p0, v3

    int-to-float v0, v4

    div-float/2addr p0, v0

    invoke-static {p0}, Ljava/lang/Math;->round(F)I

    move-result p0

    int-to-float v1, v5

    div-float/2addr v1, v0

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    int-to-float v2, v6

    div-float/2addr v2, v0

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v0

    new-instance v2, La/b/d/c/i;

    invoke-static {p0, v1, v0}, La/b/d/c/c;->approximateToRgb888(III)I

    move-result p0

    invoke-direct {v2, p0, v4}, La/b/d/c/i;-><init>(II)V

    return-object v2
.end method

.method final getVolume()I
    .locals 3

    iget v0, p0, La/b/d/c/b;->Ok:I

    iget v1, p0, La/b/d/c/b;->Nk:I

    sub-int/2addr v0, v1

    add-int/lit8 v0, v0, 0x1

    iget v1, p0, La/b/d/c/b;->Qk:I

    iget v2, p0, La/b/d/c/b;->Pk:I

    sub-int/2addr v1, v2

    add-int/lit8 v1, v1, 0x1

    mul-int/2addr v1, v0

    iget v0, p0, La/b/d/c/b;->Sk:I

    iget p0, p0, La/b/d/c/b;->Rk:I

    sub-int/2addr v0, p0

    add-int/lit8 v0, v0, 0x1

    mul-int/2addr v0, v1

    return v0
.end method

.method final splitBox()La/b/d/c/b;
    .locals 8

    invoke-virtual {p0}, La/b/d/c/b;->canSplit()Z

    move-result v0

    if-eqz v0, :cond_4

    .line 1
    iget v0, p0, La/b/d/c/b;->Ok:I

    iget v1, p0, La/b/d/c/b;->Nk:I

    sub-int/2addr v0, v1

    iget v1, p0, La/b/d/c/b;->Qk:I

    iget v2, p0, La/b/d/c/b;->Pk:I

    sub-int/2addr v1, v2

    iget v2, p0, La/b/d/c/b;->Sk:I

    iget v3, p0, La/b/d/c/b;->Rk:I

    sub-int/2addr v2, v3

    const/4 v3, -0x1

    if-lt v0, v1, :cond_0

    if-lt v0, v2, :cond_0

    const/4 v0, -0x3

    goto :goto_0

    :cond_0
    if-lt v1, v0, :cond_1

    if-lt v1, v2, :cond_1

    const/4 v0, -0x2

    goto :goto_0

    :cond_1
    move v0, v3

    .line 2
    :goto_0
    iget-object v1, p0, La/b/d/c/b;->n:La/b/d/c/c;

    iget-object v2, v1, La/b/d/c/c;->mColors:[I

    iget-object v1, v1, La/b/d/c/c;->mHistogram:[I

    iget v4, p0, La/b/d/c/b;->Kk:I

    iget v5, p0, La/b/d/c/b;->Lk:I

    invoke-static {v2, v0, v4, v5}, La/b/d/c/c;->modifySignificantOctet([IIII)V

    iget v4, p0, La/b/d/c/b;->Kk:I

    iget v5, p0, La/b/d/c/b;->Lk:I

    add-int/lit8 v5, v5, 0x1

    invoke-static {v2, v4, v5}, Ljava/util/Arrays;->sort([III)V

    iget v4, p0, La/b/d/c/b;->Kk:I

    iget v5, p0, La/b/d/c/b;->Lk:I

    invoke-static {v2, v0, v4, v5}, La/b/d/c/c;->modifySignificantOctet([IIII)V

    iget v0, p0, La/b/d/c/b;->Mk:I

    div-int/lit8 v0, v0, 0x2

    iget v4, p0, La/b/d/c/b;->Kk:I

    const/4 v5, 0x0

    :goto_1
    iget v6, p0, La/b/d/c/b;->Lk:I

    if-gt v4, v6, :cond_3

    aget v7, v2, v4

    aget v7, v1, v7

    add-int/2addr v5, v7

    if-lt v5, v0, :cond_2

    add-int/2addr v6, v3

    invoke-static {v6, v4}, Ljava/lang/Math;->min(II)I

    move-result v0

    goto :goto_2

    :cond_2
    add-int/lit8 v4, v4, 0x1

    goto :goto_1

    :cond_3
    iget v0, p0, La/b/d/c/b;->Kk:I

    .line 3
    :goto_2
    new-instance v1, La/b/d/c/b;

    iget-object v2, p0, La/b/d/c/b;->n:La/b/d/c/c;

    add-int/lit8 v3, v0, 0x1

    iget v4, p0, La/b/d/c/b;->Lk:I

    invoke-direct {v1, v2, v3, v4}, La/b/d/c/b;-><init>(La/b/d/c/c;II)V

    iput v0, p0, La/b/d/c/b;->Lk:I

    invoke-virtual {p0}, La/b/d/c/b;->fitBox()V

    return-object v1

    :cond_4
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string v0, "Can not split a box with only 1 color"

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method
