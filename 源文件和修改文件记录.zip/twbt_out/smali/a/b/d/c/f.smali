.class public final La/b/d/c/f;
.super Ljava/lang/Object;
.source ""


# instance fields
.field private final Vk:Ljava/util/List;

.field private Wk:I

.field private Xk:I

.field private Yk:I

.field private final mBitmap:Landroid/graphics/Bitmap;

.field private final mFilters:Ljava/util/List;

.field private mRegion:Landroid/graphics/Rect;

.field private final mTargets:Ljava/util/List;


# direct methods
.method public constructor <init>(Landroid/graphics/Bitmap;)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/b/d/c/f;->mTargets:Ljava/util/List;

    const/16 v0, 0x10

    iput v0, p0, La/b/d/c/f;->Wk:I

    const/16 v0, 0x3100

    iput v0, p0, La/b/d/c/f;->Xk:I

    const/4 v0, -0x1

    iput v0, p0, La/b/d/c/f;->Yk:I

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/b/d/c/f;->mFilters:Ljava/util/List;

    if-eqz p1, :cond_0

    invoke-virtual {p1}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, La/b/d/c/f;->mFilters:Ljava/util/List;

    sget-object v1, La/b/d/c/j;->DEFAULT_FILTER:La/b/d/c/g;

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    iput-object p1, p0, La/b/d/c/f;->mBitmap:Landroid/graphics/Bitmap;

    const/4 p1, 0x0

    iput-object p1, p0, La/b/d/c/f;->Vk:Ljava/util/List;

    iget-object p1, p0, La/b/d/c/f;->mTargets:Ljava/util/List;

    sget-object v0, La/b/d/c/k;->LIGHT_VIBRANT:La/b/d/c/k;

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    iget-object p1, p0, La/b/d/c/f;->mTargets:Ljava/util/List;

    sget-object v0, La/b/d/c/k;->VIBRANT:La/b/d/c/k;

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    iget-object p1, p0, La/b/d/c/f;->mTargets:Ljava/util/List;

    sget-object v0, La/b/d/c/k;->DARK_VIBRANT:La/b/d/c/k;

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    iget-object p1, p0, La/b/d/c/f;->mTargets:Ljava/util/List;

    sget-object v0, La/b/d/c/k;->LIGHT_MUTED:La/b/d/c/k;

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    iget-object p1, p0, La/b/d/c/f;->mTargets:Ljava/util/List;

    sget-object v0, La/b/d/c/k;->MUTED:La/b/d/c/k;

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    iget-object p0, p0, La/b/d/c/f;->mTargets:Ljava/util/List;

    sget-object p1, La/b/d/c/k;->DARK_MUTED:La/b/d/c/k;

    invoke-interface {p0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    return-void

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "Bitmap is not valid"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method


# virtual methods
.method public a(La/b/d/c/h;)Landroid/os/AsyncTask;
    .locals 3

    if-eqz p1, :cond_0

    new-instance v0, La/b/d/c/e;

    invoke-direct {v0, p0, p1}, La/b/d/c/e;-><init>(La/b/d/c/f;La/b/d/c/h;)V

    sget-object p1, Landroid/os/AsyncTask;->THREAD_POOL_EXECUTOR:Ljava/util/concurrent/Executor;

    const/4 v1, 0x1

    new-array v1, v1, [Landroid/graphics/Bitmap;

    const/4 v2, 0x0

    iget-object p0, p0, La/b/d/c/f;->mBitmap:Landroid/graphics/Bitmap;

    aput-object p0, v1, v2

    invoke-virtual {v0, p1, v1}, Landroid/os/AsyncTask;->executeOnExecutor(Ljava/util/concurrent/Executor;[Ljava/lang/Object;)Landroid/os/AsyncTask;

    move-result-object p0

    return-object p0

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "listener can not be null"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public clearFilters()La/b/d/c/f;
    .locals 1

    iget-object v0, p0, La/b/d/c/f;->mFilters:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    return-object p0
.end method

.method public generate()La/b/d/c/j;
    .locals 13

    iget-object v0, p0, La/b/d/c/f;->mBitmap:Landroid/graphics/Bitmap;

    if-eqz v0, :cond_8

    .line 1
    iget v1, p0, La/b/d/c/f;->Xk:I

    const-wide/high16 v2, -0x4010000000000000L    # -1.0

    if-lez v1, :cond_0

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v1

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v4

    mul-int/2addr v4, v1

    iget v1, p0, La/b/d/c/f;->Xk:I

    if-le v4, v1, :cond_1

    int-to-double v1, v1

    int-to-double v3, v4

    div-double/2addr v1, v3

    invoke-static {v1, v2}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v2

    goto :goto_0

    :cond_0
    iget v1, p0, La/b/d/c/f;->Yk:I

    if-lez v1, :cond_1

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v1

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v4

    invoke-static {v1, v4}, Ljava/lang/Math;->max(II)I

    move-result v1

    iget v4, p0, La/b/d/c/f;->Yk:I

    if-le v1, v4, :cond_1

    int-to-double v2, v4

    int-to-double v4, v1

    div-double/2addr v2, v4

    :cond_1
    :goto_0
    const-wide/16 v4, 0x0

    cmpg-double v1, v2, v4

    const/4 v4, 0x0

    if-gtz v1, :cond_2

    goto :goto_1

    :cond_2
    invoke-virtual {v0}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v1

    int-to-double v5, v1

    mul-double/2addr v5, v2

    invoke-static {v5, v6}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v5

    double-to-int v1, v5

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v5

    int-to-double v5, v5

    mul-double/2addr v5, v2

    invoke-static {v5, v6}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v2

    double-to-int v2, v2

    invoke-static {v0, v1, v2, v4}, Landroid/graphics/Bitmap;->createScaledBitmap(Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;

    move-result-object v0

    .line 2
    :goto_1
    iget-object v1, p0, La/b/d/c/f;->mRegion:Landroid/graphics/Rect;

    iget-object v2, p0, La/b/d/c/f;->mBitmap:Landroid/graphics/Bitmap;

    if-eq v0, v2, :cond_3

    if-eqz v1, :cond_3

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v2

    int-to-double v2, v2

    iget-object v5, p0, La/b/d/c/f;->mBitmap:Landroid/graphics/Bitmap;

    invoke-virtual {v5}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v5

    int-to-double v5, v5

    div-double/2addr v2, v5

    iget v5, v1, Landroid/graphics/Rect;->left:I

    int-to-double v5, v5

    mul-double/2addr v5, v2

    invoke-static {v5, v6}, Ljava/lang/Math;->floor(D)D

    move-result-wide v5

    double-to-int v5, v5

    iput v5, v1, Landroid/graphics/Rect;->left:I

    iget v5, v1, Landroid/graphics/Rect;->top:I

    int-to-double v5, v5

    mul-double/2addr v5, v2

    invoke-static {v5, v6}, Ljava/lang/Math;->floor(D)D

    move-result-wide v5

    double-to-int v5, v5

    iput v5, v1, Landroid/graphics/Rect;->top:I

    iget v5, v1, Landroid/graphics/Rect;->right:I

    int-to-double v5, v5

    mul-double/2addr v5, v2

    invoke-static {v5, v6}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v5

    double-to-int v5, v5

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v6

    invoke-static {v5, v6}, Ljava/lang/Math;->min(II)I

    move-result v5

    iput v5, v1, Landroid/graphics/Rect;->right:I

    iget v5, v1, Landroid/graphics/Rect;->bottom:I

    int-to-double v5, v5

    mul-double/2addr v5, v2

    invoke-static {v5, v6}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v2

    double-to-int v2, v2

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v3

    invoke-static {v2, v3}, Ljava/lang/Math;->min(II)I

    move-result v2

    iput v2, v1, Landroid/graphics/Rect;->bottom:I

    :cond_3
    new-instance v1, La/b/d/c/c;

    .line 3
    invoke-virtual {v0}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v2

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v12

    mul-int v3, v2, v12

    new-array v3, v3, [I

    const/4 v7, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    move-object v5, v0

    move-object v6, v3

    move v8, v2

    move v11, v2

    invoke-virtual/range {v5 .. v12}, Landroid/graphics/Bitmap;->getPixels([IIIIIII)V

    iget-object v5, p0, La/b/d/c/f;->mRegion:Landroid/graphics/Rect;

    if-nez v5, :cond_4

    goto :goto_3

    :cond_4
    invoke-virtual {v5}, Landroid/graphics/Rect;->width()I

    move-result v5

    iget-object v6, p0, La/b/d/c/f;->mRegion:Landroid/graphics/Rect;

    invoke-virtual {v6}, Landroid/graphics/Rect;->height()I

    move-result v6

    mul-int v7, v5, v6

    new-array v7, v7, [I

    :goto_2
    if-ge v4, v6, :cond_5

    iget-object v8, p0, La/b/d/c/f;->mRegion:Landroid/graphics/Rect;

    iget v9, v8, Landroid/graphics/Rect;->top:I

    add-int/2addr v9, v4

    mul-int/2addr v9, v2

    iget v8, v8, Landroid/graphics/Rect;->left:I

    add-int/2addr v9, v8

    mul-int v8, v4, v5

    invoke-static {v3, v9, v7, v8, v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    add-int/lit8 v4, v4, 0x1

    goto :goto_2

    :cond_5
    move-object v3, v7

    .line 4
    :goto_3
    iget v2, p0, La/b/d/c/f;->Wk:I

    iget-object v4, p0, La/b/d/c/f;->mFilters:Ljava/util/List;

    invoke-interface {v4}, Ljava/util/List;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_6

    const/4 v4, 0x0

    goto :goto_4

    :cond_6
    iget-object v4, p0, La/b/d/c/f;->mFilters:Ljava/util/List;

    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v5

    new-array v5, v5, [La/b/d/c/g;

    invoke-interface {v4, v5}, Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v4

    check-cast v4, [La/b/d/c/g;

    :goto_4
    invoke-direct {v1, v3, v2, v4}, La/b/d/c/c;-><init>([II[La/b/d/c/g;)V

    iget-object v2, p0, La/b/d/c/f;->mBitmap:Landroid/graphics/Bitmap;

    if-eq v0, v2, :cond_7

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->recycle()V

    .line 5
    :cond_7
    iget-object v0, v1, La/b/d/c/c;->mQuantizedColors:Ljava/util/List;

    goto :goto_5

    .line 6
    :cond_8
    iget-object v0, p0, La/b/d/c/f;->Vk:Ljava/util/List;

    if-eqz v0, :cond_9

    :goto_5
    new-instance v1, La/b/d/c/j;

    iget-object p0, p0, La/b/d/c/f;->mTargets:Ljava/util/List;

    invoke-direct {v1, v0, p0}, La/b/d/c/j;-><init>(Ljava/util/List;Ljava/util/List;)V

    invoke-virtual {v1}, La/b/d/c/j;->generate()V

    return-object v1

    :cond_9
    new-instance p0, Ljava/lang/AssertionError;

    invoke-direct {p0}, Ljava/lang/AssertionError;-><init>()V

    throw p0
.end method
