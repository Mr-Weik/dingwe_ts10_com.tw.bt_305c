.class final La/b/d/c/a;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/util/Comparator;


# direct methods
.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 0

    check-cast p1, La/b/d/c/b;

    check-cast p2, La/b/d/c/b;

    .line 1
    invoke-virtual {p2}, La/b/d/c/b;->getVolume()I

    move-result p0

    invoke-virtual {p1}, La/b/d/c/b;->getVolume()I

    move-result p1

    sub-int/2addr p0, p1

    return p0
.end method
