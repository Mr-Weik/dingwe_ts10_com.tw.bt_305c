.class public final La/b/d/c/j;
.super Ljava/lang/Object;
.source ""


# static fields
.field static final DEFAULT_FILTER:La/b/d/c/g;


# instance fields
.field private final Vk:Ljava/util/List;

.field private final fl:Ljava/util/Map;

.field private final gl:Landroid/util/SparseBooleanArray;

.field private final hl:La/b/d/c/i;

.field private final mTargets:Ljava/util/List;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, La/b/d/c/d;

    invoke-direct {v0}, La/b/d/c/d;-><init>()V

    sput-object v0, La/b/d/c/j;->DEFAULT_FILTER:La/b/d/c/g;

    return-void
.end method

.method constructor <init>(Ljava/util/List;Ljava/util/List;)V
    .locals 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La/b/d/c/j;->Vk:Ljava/util/List;

    iput-object p2, p0, La/b/d/c/j;->mTargets:Ljava/util/List;

    new-instance p1, Landroid/util/SparseBooleanArray;

    invoke-direct {p1}, Landroid/util/SparseBooleanArray;-><init>()V

    iput-object p1, p0, La/b/d/c/j;->gl:Landroid/util/SparseBooleanArray;

    new-instance p1, La/b/c/f/b;

    invoke-direct {p1}, La/b/c/f/b;-><init>()V

    iput-object p1, p0, La/b/d/c/j;->fl:Ljava/util/Map;

    .line 1
    iget-object p1, p0, La/b/d/c/j;->Vk:Ljava/util/List;

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p1

    const/high16 p2, -0x80000000

    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    if-ge v1, p1, :cond_1

    iget-object v2, p0, La/b/d/c/j;->Vk:Ljava/util/List;

    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/b/d/c/i;

    invoke-virtual {v2}, La/b/d/c/i;->getPopulation()I

    move-result v3

    if-le v3, p2, :cond_0

    invoke-virtual {v2}, La/b/d/c/i;->getPopulation()I

    move-result p2

    move-object v0, v2

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 2
    :cond_1
    iput-object v0, p0, La/b/d/c/j;->hl:La/b/d/c/i;

    return-void
.end method

.method public static from(Landroid/graphics/Bitmap;)La/b/d/c/f;
    .locals 1

    new-instance v0, La/b/d/c/f;

    invoke-direct {v0, p0}, La/b/d/c/f;-><init>(Landroid/graphics/Bitmap;)V

    return-object v0
.end method


# virtual methods
.method generate()V
    .locals 19

    move-object/from16 v0, p0

    iget-object v1, v0, La/b/d/c/j;->mTargets:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    const/4 v2, 0x0

    move v3, v2

    :goto_0
    if-ge v3, v1, :cond_e

    iget-object v4, v0, La/b/d/c/j;->mTargets:Ljava/util/List;

    invoke-interface {v4, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/b/d/c/k;

    .line 1
    iget-object v5, v4, La/b/d/c/k;->mWeights:[F

    array-length v5, v5

    const/4 v6, 0x0

    move v7, v2

    move v8, v6

    :goto_1
    if-ge v7, v5, :cond_1

    iget-object v9, v4, La/b/d/c/k;->mWeights:[F

    aget v9, v9, v7

    cmpl-float v10, v9, v6

    if-lez v10, :cond_0

    add-float/2addr v8, v9

    :cond_0
    add-int/lit8 v7, v7, 0x1

    goto :goto_1

    :cond_1
    cmpl-float v5, v8, v6

    if-eqz v5, :cond_3

    iget-object v5, v4, La/b/d/c/k;->mWeights:[F

    array-length v5, v5

    move v7, v2

    :goto_2
    if-ge v7, v5, :cond_3

    iget-object v9, v4, La/b/d/c/k;->mWeights:[F

    aget v10, v9, v7

    cmpl-float v10, v10, v6

    if-lez v10, :cond_2

    aget v10, v9, v7

    div-float/2addr v10, v8

    aput v10, v9, v7

    :cond_2
    add-int/lit8 v7, v7, 0x1

    goto :goto_2

    .line 2
    :cond_3
    iget-object v5, v0, La/b/d/c/j;->fl:Ljava/util/Map;

    .line 3
    iget-object v7, v0, La/b/d/c/j;->Vk:Ljava/util/List;

    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v7

    const/4 v8, 0x0

    move v10, v6

    move-object v9, v8

    move v8, v2

    :goto_3
    const/4 v11, 0x1

    if-ge v8, v7, :cond_c

    iget-object v12, v0, La/b/d/c/j;->Vk:Ljava/util/List;

    invoke-interface {v12, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, La/b/d/c/i;

    .line 4
    invoke-virtual {v12}, La/b/d/c/i;->getHsl()[F

    move-result-object v13

    aget v14, v13, v11

    .line 5
    iget-object v15, v4, La/b/d/c/k;->mSaturationTargets:[F

    aget v16, v15, v2

    cmpl-float v14, v14, v16

    const/16 v16, 0x2

    if-ltz v14, :cond_4

    .line 6
    aget v14, v13, v11

    .line 7
    aget v15, v15, v16

    cmpg-float v14, v14, v15

    if-gtz v14, :cond_4

    .line 8
    aget v14, v13, v16

    .line 9
    iget-object v15, v4, La/b/d/c/k;->mLightnessTargets:[F

    aget v17, v15, v2

    cmpl-float v14, v14, v17

    if-ltz v14, :cond_4

    .line 10
    aget v13, v13, v16

    .line 11
    aget v14, v15, v16

    cmpg-float v13, v13, v14

    if-gtz v13, :cond_4

    .line 12
    iget-object v13, v0, La/b/d/c/j;->gl:Landroid/util/SparseBooleanArray;

    invoke-virtual {v12}, La/b/d/c/i;->getRgb()I

    move-result v14

    invoke-virtual {v13, v14}, Landroid/util/SparseBooleanArray;->get(I)Z

    move-result v13

    if-nez v13, :cond_4

    move v13, v11

    goto :goto_4

    :cond_4
    move v13, v2

    :goto_4
    if-eqz v13, :cond_a

    .line 13
    invoke-virtual {v12}, La/b/d/c/i;->getHsl()[F

    move-result-object v13

    iget-object v14, v0, La/b/d/c/j;->hl:La/b/d/c/i;

    if-eqz v14, :cond_5

    invoke-virtual {v14}, La/b/d/c/i;->getPopulation()I

    move-result v14

    goto :goto_5

    :cond_5
    move v14, v11

    :goto_5
    invoke-virtual {v4}, La/b/d/c/k;->getSaturationWeight()F

    move-result v15

    cmpl-float v15, v15, v6

    const/high16 v17, 0x3f800000    # 1.0f

    if-lez v15, :cond_6

    invoke-virtual {v4}, La/b/d/c/k;->getSaturationWeight()F

    move-result v15

    aget v18, v13, v11

    .line 14
    iget-object v2, v4, La/b/d/c/k;->mSaturationTargets:[F

    aget v2, v2, v11

    sub-float v18, v18, v2

    .line 15
    invoke-static/range {v18 .. v18}, Ljava/lang/Math;->abs(F)F

    move-result v2

    sub-float v2, v17, v2

    mul-float/2addr v2, v15

    goto :goto_6

    :cond_6
    move v2, v6

    :goto_6
    invoke-virtual {v4}, La/b/d/c/k;->getLightnessWeight()F

    move-result v15

    cmpl-float v15, v15, v6

    if-lez v15, :cond_7

    invoke-virtual {v4}, La/b/d/c/k;->getLightnessWeight()F

    move-result v15

    aget v13, v13, v16

    .line 16
    iget-object v6, v4, La/b/d/c/k;->mLightnessTargets:[F

    aget v6, v6, v11

    sub-float/2addr v13, v6

    .line 17
    invoke-static {v13}, Ljava/lang/Math;->abs(F)F

    move-result v6

    sub-float v17, v17, v6

    mul-float v6, v17, v15

    goto :goto_7

    :cond_7
    const/4 v6, 0x0

    :goto_7
    invoke-virtual {v4}, La/b/d/c/k;->getPopulationWeight()F

    move-result v11

    const/4 v13, 0x0

    cmpl-float v11, v11, v13

    if-lez v11, :cond_8

    invoke-virtual {v4}, La/b/d/c/k;->getPopulationWeight()F

    move-result v11

    invoke-virtual {v12}, La/b/d/c/i;->getPopulation()I

    move-result v15

    int-to-float v15, v15

    int-to-float v14, v14

    div-float/2addr v15, v14

    mul-float/2addr v11, v15

    goto :goto_8

    :cond_8
    move v11, v13

    :goto_8
    add-float/2addr v2, v6

    add-float/2addr v2, v11

    if-eqz v9, :cond_9

    cmpl-float v6, v2, v10

    if-lez v6, :cond_b

    :cond_9
    move v10, v2

    move-object v9, v12

    goto :goto_9

    :cond_a
    move v13, v6

    :cond_b
    :goto_9
    add-int/lit8 v8, v8, 0x1

    move v6, v13

    const/4 v2, 0x0

    goto/16 :goto_3

    :cond_c
    if-eqz v9, :cond_d

    .line 18
    iget-boolean v2, v4, La/b/d/c/k;->mIsExclusive:Z

    if-eqz v2, :cond_d

    .line 19
    iget-object v2, v0, La/b/d/c/j;->gl:Landroid/util/SparseBooleanArray;

    invoke-virtual {v9}, La/b/d/c/i;->getRgb()I

    move-result v6

    invoke-virtual {v2, v6, v11}, Landroid/util/SparseBooleanArray;->append(IZ)V

    .line 20
    :cond_d
    invoke-interface {v5, v4, v9}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    add-int/lit8 v3, v3, 0x1

    const/4 v2, 0x0

    goto/16 :goto_0

    :cond_e
    iget-object v0, v0, La/b/d/c/j;->gl:Landroid/util/SparseBooleanArray;

    invoke-virtual {v0}, Landroid/util/SparseBooleanArray;->clear()V

    return-void
.end method

.method public getDominantColor(I)I
    .locals 0

    iget-object p0, p0, La/b/d/c/j;->hl:La/b/d/c/i;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, La/b/d/c/i;->getRgb()I

    move-result p1

    :cond_0
    return p1
.end method

.method public getDominantSwatch()La/b/d/c/i;
    .locals 0

    iget-object p0, p0, La/b/d/c/j;->hl:La/b/d/c/i;

    return-object p0
.end method
