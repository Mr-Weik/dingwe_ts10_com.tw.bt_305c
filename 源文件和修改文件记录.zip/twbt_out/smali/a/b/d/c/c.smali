.class final La/b/d/c/c;
.super Ljava/lang/Object;
.source ""


# static fields
.field private static final Uk:Ljava/util/Comparator;


# instance fields
.field private final Tk:[F

.field final mColors:[I

.field final mFilters:[La/b/d/c/g;

.field final mHistogram:[I

.field final mQuantizedColors:Ljava/util/List;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, La/b/d/c/a;

    invoke-direct {v0}, La/b/d/c/a;-><init>()V

    sput-object v0, La/b/d/c/c;->Uk:Ljava/util/Comparator;

    return-void
.end method

.method constructor <init>([II[La/b/d/c/g;)V
    .locals 7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x3

    new-array v0, v0, [F

    iput-object v0, p0, La/b/d/c/c;->Tk:[F

    iput-object p3, p0, La/b/d/c/c;->mFilters:[La/b/d/c/g;

    const p3, 0x8000

    new-array p3, p3, [I

    iput-object p3, p0, La/b/d/c/c;->mHistogram:[I

    const/4 v0, 0x0

    move v1, v0

    :goto_0
    array-length v2, p1

    if-ge v1, v2, :cond_0

    aget v2, p1, v1

    .line 1
    invoke-static {v2}, Landroid/graphics/Color;->red(I)I

    move-result v3

    const/16 v4, 0x8

    const/4 v5, 0x5

    invoke-static {v3, v4, v5}, La/b/d/c/c;->a(III)I

    move-result v3

    invoke-static {v2}, Landroid/graphics/Color;->green(I)I

    move-result v6

    invoke-static {v6, v4, v5}, La/b/d/c/c;->a(III)I

    move-result v6

    invoke-static {v2}, Landroid/graphics/Color;->blue(I)I

    move-result v2

    invoke-static {v2, v4, v5}, La/b/d/c/c;->a(III)I

    move-result v2

    shl-int/lit8 v3, v3, 0xa

    shl-int/lit8 v4, v6, 0x5

    or-int/2addr v3, v4

    or-int/2addr v2, v3

    .line 2
    aput v2, p1, v1

    aget v3, p3, v2

    add-int/lit8 v3, v3, 0x1

    aput v3, p3, v2

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    move p1, v0

    move v1, p1

    :goto_1
    array-length v2, p3

    if-ge p1, v2, :cond_3

    aget v2, p3, p1

    if-lez v2, :cond_1

    shr-int/lit8 v2, p1, 0xa

    and-int/lit8 v2, v2, 0x1f

    shr-int/lit8 v3, p1, 0x5

    and-int/lit8 v3, v3, 0x1f

    and-int/lit8 v4, p1, 0x1f

    .line 3
    invoke-static {v2, v3, v4}, La/b/d/c/c;->approximateToRgb888(III)I

    move-result v2

    .line 4
    iget-object v3, p0, La/b/d/c/c;->Tk:[F

    invoke-static {v2, v3}, La/b/c/b/a;->colorToHSL(I[F)V

    iget-object v3, p0, La/b/d/c/c;->Tk:[F

    invoke-direct {p0, v2, v3}, La/b/d/c/c;->a(I[F)Z

    move-result v2

    if-eqz v2, :cond_1

    .line 5
    aput v0, p3, p1

    :cond_1
    aget v2, p3, p1

    if-lez v2, :cond_2

    add-int/lit8 v1, v1, 0x1

    :cond_2
    add-int/lit8 p1, p1, 0x1

    goto :goto_1

    :cond_3
    new-array p1, v1, [I

    iput-object p1, p0, La/b/d/c/c;->mColors:[I

    move v2, v0

    move v3, v2

    :goto_2
    array-length v4, p3

    if-ge v2, v4, :cond_5

    aget v4, p3, v2

    if-lez v4, :cond_4

    add-int/lit8 v4, v3, 0x1

    aput v2, p1, v3

    move v3, v4

    :cond_4
    add-int/lit8 v2, v2, 0x1

    goto :goto_2

    :cond_5
    if-gt v1, p2, :cond_6

    new-instance p2, Ljava/util/ArrayList;

    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    iput-object p2, p0, La/b/d/c/c;->mQuantizedColors:Ljava/util/List;

    array-length p2, p1

    :goto_3
    if-ge v0, p2, :cond_a

    aget v1, p1, v0

    iget-object v2, p0, La/b/d/c/c;->mQuantizedColors:Ljava/util/List;

    new-instance v3, La/b/d/c/i;

    shr-int/lit8 v4, v1, 0xa

    and-int/lit8 v4, v4, 0x1f

    shr-int/lit8 v5, v1, 0x5

    and-int/lit8 v5, v5, 0x1f

    and-int/lit8 v6, v1, 0x1f

    .line 6
    invoke-static {v4, v5, v6}, La/b/d/c/c;->approximateToRgb888(III)I

    move-result v4

    .line 7
    aget v1, p3, v1

    invoke-direct {v3, v4, v1}, La/b/d/c/i;-><init>(II)V

    invoke-interface {v2, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, 0x1

    goto :goto_3

    .line 8
    :cond_6
    new-instance p1, Ljava/util/PriorityQueue;

    sget-object p3, La/b/d/c/c;->Uk:Ljava/util/Comparator;

    invoke-direct {p1, p2, p3}, Ljava/util/PriorityQueue;-><init>(ILjava/util/Comparator;)V

    new-instance p3, La/b/d/c/b;

    iget-object v1, p0, La/b/d/c/c;->mColors:[I

    array-length v1, v1

    add-int/lit8 v1, v1, -0x1

    invoke-direct {p3, p0, v0, v1}, La/b/d/c/b;-><init>(La/b/d/c/c;II)V

    invoke-virtual {p1, p3}, Ljava/util/PriorityQueue;->offer(Ljava/lang/Object;)Z

    .line 9
    :goto_4
    invoke-virtual {p1}, Ljava/util/PriorityQueue;->size()I

    move-result p3

    if-ge p3, p2, :cond_7

    invoke-virtual {p1}, Ljava/util/PriorityQueue;->poll()Ljava/lang/Object;

    move-result-object p3

    check-cast p3, La/b/d/c/b;

    if-eqz p3, :cond_7

    invoke-virtual {p3}, La/b/d/c/b;->canSplit()Z

    move-result v0

    if-eqz v0, :cond_7

    invoke-virtual {p3}, La/b/d/c/b;->splitBox()La/b/d/c/b;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/util/PriorityQueue;->offer(Ljava/lang/Object;)Z

    invoke-virtual {p1, p3}, Ljava/util/PriorityQueue;->offer(Ljava/lang/Object;)Z

    goto :goto_4

    .line 10
    :cond_7
    new-instance p2, Ljava/util/ArrayList;

    invoke-interface {p1}, Ljava/util/Collection;->size()I

    move-result p3

    invoke-direct {p2, p3}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {p1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_8
    :goto_5
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p3

    if-eqz p3, :cond_9

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p3

    check-cast p3, La/b/d/c/b;

    invoke-virtual {p3}, La/b/d/c/b;->getAverageColor()La/b/d/c/i;

    move-result-object p3

    .line 11
    invoke-virtual {p3}, La/b/d/c/i;->getRgb()I

    move-result v0

    invoke-virtual {p3}, La/b/d/c/i;->getHsl()[F

    move-result-object v1

    invoke-direct {p0, v0, v1}, La/b/d/c/c;->a(I[F)Z

    move-result v0

    if-nez v0, :cond_8

    .line 12
    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_5

    .line 13
    :cond_9
    iput-object p2, p0, La/b/d/c/c;->mQuantizedColors:Ljava/util/List;

    :cond_a
    return-void
.end method

.method private static a(III)I
    .locals 0

    if-le p2, p1, :cond_0

    sub-int p1, p2, p1

    shl-int/2addr p0, p1

    goto :goto_0

    :cond_0
    sub-int/2addr p1, p2

    shr-int/2addr p0, p1

    :goto_0
    const/4 p1, 0x1

    shl-int p2, p1, p2

    sub-int/2addr p2, p1

    and-int/2addr p0, p2

    return p0
.end method

.method private a(I[F)Z
    .locals 4

    iget-object v0, p0, La/b/d/c/c;->mFilters:[La/b/d/c/g;

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    array-length v2, v0

    if-lez v2, :cond_1

    array-length v0, v0

    move v2, v1

    :goto_0
    if-ge v2, v0, :cond_1

    iget-object v3, p0, La/b/d/c/c;->mFilters:[La/b/d/c/g;

    aget-object v3, v3, v2

    invoke-interface {v3, p1, p2}, La/b/d/c/g;->isAllowed(I[F)Z

    move-result v3

    if-nez v3, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    return v1
.end method

.method static approximateToRgb888(III)I
    .locals 2

    const/16 v0, 0x8

    const/4 v1, 0x5

    invoke-static {p0, v1, v0}, La/b/d/c/c;->a(III)I

    move-result p0

    invoke-static {p1, v1, v0}, La/b/d/c/c;->a(III)I

    move-result p1

    invoke-static {p2, v1, v0}, La/b/d/c/c;->a(III)I

    move-result p2

    invoke-static {p0, p1, p2}, Landroid/graphics/Color;->rgb(III)I

    move-result p0

    return p0
.end method

.method static modifySignificantOctet([IIII)V
    .locals 2

    const/4 v0, -0x3

    if-eq p1, v0, :cond_2

    const/4 v0, -0x2

    if-eq p1, v0, :cond_1

    const/4 v0, -0x1

    if-eq p1, v0, :cond_0

    goto :goto_2

    :cond_0
    :goto_0
    if-gt p2, p3, :cond_2

    aget p1, p0, p2

    and-int/lit8 v0, p1, 0x1f

    shl-int/lit8 v0, v0, 0xa

    shr-int/lit8 v1, p1, 0x5

    and-int/lit8 v1, v1, 0x1f

    shl-int/lit8 v1, v1, 0x5

    or-int/2addr v0, v1

    shr-int/lit8 p1, p1, 0xa

    and-int/lit8 p1, p1, 0x1f

    or-int/2addr p1, v0

    aput p1, p0, p2

    add-int/lit8 p2, p2, 0x1

    goto :goto_0

    :cond_1
    :goto_1
    if-gt p2, p3, :cond_2

    aget p1, p0, p2

    shr-int/lit8 v0, p1, 0x5

    and-int/lit8 v0, v0, 0x1f

    shl-int/lit8 v0, v0, 0xa

    shr-int/lit8 v1, p1, 0xa

    and-int/lit8 v1, v1, 0x1f

    shl-int/lit8 v1, v1, 0x5

    or-int/2addr v0, v1

    and-int/lit8 p1, p1, 0x1f

    or-int/2addr p1, v0

    aput p1, p0, p2

    add-int/lit8 p2, p2, 0x1

    goto :goto_1

    :cond_2
    :goto_2
    return-void
.end method
