.class final La/b/d/c/d;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements La/b/d/c/g;


# direct methods
.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public isAllowed(I[F)Z
    .locals 2

    const/4 p0, 0x2

    .line 1
    aget p1, p2, p0

    const v0, 0x3f733333    # 0.95f

    cmpl-float p1, p1, v0

    const/4 v0, 0x1

    const/4 v1, 0x0

    if-ltz p1, :cond_0

    move p1, v0

    goto :goto_0

    :cond_0
    move p1, v1

    :goto_0
    if-nez p1, :cond_3

    .line 2
    aget p0, p2, p0

    const p1, 0x3d4ccccd    # 0.05f

    cmpg-float p0, p0, p1

    if-gtz p0, :cond_1

    move p0, v0

    goto :goto_1

    :cond_1
    move p0, v1

    :goto_1
    if-nez p0, :cond_3

    .line 3
    aget p0, p2, v1

    const/high16 p1, 0x41200000    # 10.0f

    cmpl-float p0, p0, p1

    if-ltz p0, :cond_2

    aget p0, p2, v1

    const/high16 p1, 0x42140000    # 37.0f

    cmpg-float p0, p0, p1

    if-gtz p0, :cond_2

    aget p0, p2, v0

    const p1, 0x3f51eb85    # 0.82f

    cmpg-float p0, p0, p1

    if-gtz p0, :cond_2

    move p0, v0

    goto :goto_2

    :cond_2
    move p0, v1

    :goto_2
    if-nez p0, :cond_3

    goto :goto_3

    :cond_3
    move v0, v1

    :goto_3
    return v0
.end method
