.class public final La/b/d/c/i;
.super Ljava/lang/Object;
.source ""


# instance fields
.field private final Mk:I

.field private final Zk:I

.field private final _k:I

.field private final al:I

.field private bl:Z

.field private cl:I

.field private dl:I

.field private el:[F

.field private final mRgb:I


# direct methods
.method public constructor <init>(II)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {p1}, Landroid/graphics/Color;->red(I)I

    move-result v0

    iput v0, p0, La/b/d/c/i;->Zk:I

    invoke-static {p1}, Landroid/graphics/Color;->green(I)I

    move-result v0

    iput v0, p0, La/b/d/c/i;->_k:I

    invoke-static {p1}, Landroid/graphics/Color;->blue(I)I

    move-result v0

    iput v0, p0, La/b/d/c/i;->al:I

    iput p1, p0, La/b/d/c/i;->mRgb:I

    iput p2, p0, La/b/d/c/i;->Mk:I

    return-void
.end method

.method private ag()V
    .locals 8

    iget-boolean v0, p0, La/b/d/c/i;->bl:Z

    if-nez v0, :cond_4

    iget v0, p0, La/b/d/c/i;->mRgb:I

    const/high16 v1, 0x40900000    # 4.5f

    const/4 v2, -0x1

    invoke-static {v2, v0, v1}, La/b/c/b/a;->calculateMinimumAlpha(IIF)I

    move-result v0

    iget v3, p0, La/b/d/c/i;->mRgb:I

    const/high16 v4, 0x40400000    # 3.0f

    invoke-static {v2, v3, v4}, La/b/c/b/a;->calculateMinimumAlpha(IIF)I

    move-result v3

    const/4 v5, 0x1

    if-eq v0, v2, :cond_0

    if-eq v3, v2, :cond_0

    invoke-static {v2, v0}, La/b/c/b/a;->setAlphaComponent(II)I

    move-result v0

    iput v0, p0, La/b/d/c/i;->dl:I

    invoke-static {v2, v3}, La/b/c/b/a;->setAlphaComponent(II)I

    move-result v0

    :goto_0
    iput v0, p0, La/b/d/c/i;->cl:I

    iput-boolean v5, p0, La/b/d/c/i;->bl:Z

    return-void

    :cond_0
    iget v6, p0, La/b/d/c/i;->mRgb:I

    const/high16 v7, -0x1000000

    invoke-static {v7, v6, v1}, La/b/c/b/a;->calculateMinimumAlpha(IIF)I

    move-result v1

    iget v6, p0, La/b/d/c/i;->mRgb:I

    invoke-static {v7, v6, v4}, La/b/c/b/a;->calculateMinimumAlpha(IIF)I

    move-result v4

    if-eq v1, v2, :cond_1

    if-eq v4, v2, :cond_1

    invoke-static {v7, v1}, La/b/c/b/a;->setAlphaComponent(II)I

    move-result v0

    iput v0, p0, La/b/d/c/i;->dl:I

    invoke-static {v7, v4}, La/b/c/b/a;->setAlphaComponent(II)I

    move-result v0

    goto :goto_0

    :cond_1
    if-eq v0, v2, :cond_2

    invoke-static {v2, v0}, La/b/c/b/a;->setAlphaComponent(II)I

    move-result v0

    goto :goto_1

    :cond_2
    invoke-static {v7, v1}, La/b/c/b/a;->setAlphaComponent(II)I

    move-result v0

    :goto_1
    iput v0, p0, La/b/d/c/i;->dl:I

    if-eq v3, v2, :cond_3

    invoke-static {v2, v3}, La/b/c/b/a;->setAlphaComponent(II)I

    move-result v0

    goto :goto_2

    :cond_3
    invoke-static {v7, v4}, La/b/c/b/a;->setAlphaComponent(II)I

    move-result v0

    :goto_2
    iput v0, p0, La/b/d/c/i;->cl:I

    iput-boolean v5, p0, La/b/d/c/i;->bl:Z

    :cond_4
    return-void
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .locals 4

    const/4 v0, 0x1

    if-ne p0, p1, :cond_0

    return v0

    :cond_0
    const/4 v1, 0x0

    if-eqz p1, :cond_3

    const-class v2, La/b/d/c/i;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v3

    if-eq v2, v3, :cond_1

    goto :goto_1

    :cond_1
    check-cast p1, La/b/d/c/i;

    iget v2, p0, La/b/d/c/i;->Mk:I

    iget v3, p1, La/b/d/c/i;->Mk:I

    if-ne v2, v3, :cond_2

    iget p0, p0, La/b/d/c/i;->mRgb:I

    iget p1, p1, La/b/d/c/i;->mRgb:I

    if-ne p0, p1, :cond_2

    goto :goto_0

    :cond_2
    move v0, v1

    :goto_0
    return v0

    :cond_3
    :goto_1
    return v1
.end method

.method public getHsl()[F
    .locals 4

    iget-object v0, p0, La/b/d/c/i;->el:[F

    if-nez v0, :cond_0

    const/4 v0, 0x3

    new-array v0, v0, [F

    iput-object v0, p0, La/b/d/c/i;->el:[F

    :cond_0
    iget v0, p0, La/b/d/c/i;->Zk:I

    iget v1, p0, La/b/d/c/i;->_k:I

    iget v2, p0, La/b/d/c/i;->al:I

    iget-object v3, p0, La/b/d/c/i;->el:[F

    invoke-static {v0, v1, v2, v3}, La/b/c/b/a;->RGBToHSL(III[F)V

    iget-object p0, p0, La/b/d/c/i;->el:[F

    return-object p0
.end method

.method public getPopulation()I
    .locals 0

    iget p0, p0, La/b/d/c/i;->Mk:I

    return p0
.end method

.method public getRgb()I
    .locals 0

    iget p0, p0, La/b/d/c/i;->mRgb:I

    return p0
.end method

.method public hashCode()I
    .locals 1

    iget v0, p0, La/b/d/c/i;->mRgb:I

    mul-int/lit8 v0, v0, 0x1f

    iget p0, p0, La/b/d/c/i;->Mk:I

    add-int/2addr v0, p0

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-class v1, La/b/d/c/i;

    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v1, " [RGB: #"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1
    iget v1, p0, La/b/d/c/i;->mRgb:I

    .line 2
    invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v1, 0x5d

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const-string v2, " [HSL: "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, La/b/d/c/i;->getHsl()[F

    move-result-object v2

    invoke-static {v2}, Ljava/util/Arrays;->toString([F)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const-string v2, " [Population: "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, p0, La/b/d/c/i;->Mk:I

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const-string v2, " [Title Text: #"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 3
    invoke-direct {p0}, La/b/d/c/i;->ag()V

    iget v2, p0, La/b/d/c/i;->cl:I

    .line 4
    invoke-static {v2}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const-string v2, " [Body Text: #"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 5
    invoke-direct {p0}, La/b/d/c/i;->ag()V

    iget p0, p0, La/b/d/c/i;->dl:I

    .line 6
    invoke-static {p0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
