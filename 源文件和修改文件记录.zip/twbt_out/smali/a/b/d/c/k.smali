.class public final La/b/d/c/k;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final DARK_MUTED:La/b/d/c/k;

.field public static final DARK_VIBRANT:La/b/d/c/k;

.field public static final LIGHT_MUTED:La/b/d/c/k;

.field public static final LIGHT_VIBRANT:La/b/d/c/k;

.field public static final MUTED:La/b/d/c/k;

.field public static final VIBRANT:La/b/d/c/k;


# instance fields
.field mIsExclusive:Z

.field final mLightnessTargets:[F

.field final mSaturationTargets:[F

.field final mWeights:[F


# direct methods
.method static constructor <clinit>()V
    .locals 9

    new-instance v0, La/b/d/c/k;

    invoke-direct {v0}, La/b/d/c/k;-><init>()V

    sput-object v0, La/b/d/c/k;->LIGHT_VIBRANT:La/b/d/c/k;

    sget-object v0, La/b/d/c/k;->LIGHT_VIBRANT:La/b/d/c/k;

    .line 1
    iget-object v1, v0, La/b/d/c/k;->mLightnessTargets:[F

    const v2, 0x3f0ccccd    # 0.55f

    const/4 v3, 0x0

    aput v2, v1, v3

    const v4, 0x3f3d70a4    # 0.74f

    const/4 v5, 0x1

    aput v4, v1, v5

    .line 2
    invoke-static {v0}, La/b/d/c/k;->c(La/b/d/c/k;)V

    new-instance v0, La/b/d/c/k;

    invoke-direct {v0}, La/b/d/c/k;-><init>()V

    sput-object v0, La/b/d/c/k;->VIBRANT:La/b/d/c/k;

    sget-object v0, La/b/d/c/k;->VIBRANT:La/b/d/c/k;

    invoke-static {v0}, La/b/d/c/k;->b(La/b/d/c/k;)V

    sget-object v0, La/b/d/c/k;->VIBRANT:La/b/d/c/k;

    invoke-static {v0}, La/b/d/c/k;->c(La/b/d/c/k;)V

    new-instance v0, La/b/d/c/k;

    invoke-direct {v0}, La/b/d/c/k;-><init>()V

    sput-object v0, La/b/d/c/k;->DARK_VIBRANT:La/b/d/c/k;

    sget-object v0, La/b/d/c/k;->DARK_VIBRANT:La/b/d/c/k;

    .line 3
    iget-object v1, v0, La/b/d/c/k;->mLightnessTargets:[F

    const v6, 0x3e851eb8    # 0.26f

    aput v6, v1, v5

    const v7, 0x3ee66666    # 0.45f

    const/4 v8, 0x2

    aput v7, v1, v8

    .line 4
    invoke-static {v0}, La/b/d/c/k;->c(La/b/d/c/k;)V

    new-instance v0, La/b/d/c/k;

    invoke-direct {v0}, La/b/d/c/k;-><init>()V

    sput-object v0, La/b/d/c/k;->LIGHT_MUTED:La/b/d/c/k;

    sget-object v0, La/b/d/c/k;->LIGHT_MUTED:La/b/d/c/k;

    .line 5
    iget-object v1, v0, La/b/d/c/k;->mLightnessTargets:[F

    aput v2, v1, v3

    aput v4, v1, v5

    .line 6
    invoke-static {v0}, La/b/d/c/k;->a(La/b/d/c/k;)V

    new-instance v0, La/b/d/c/k;

    invoke-direct {v0}, La/b/d/c/k;-><init>()V

    sput-object v0, La/b/d/c/k;->MUTED:La/b/d/c/k;

    sget-object v0, La/b/d/c/k;->MUTED:La/b/d/c/k;

    invoke-static {v0}, La/b/d/c/k;->b(La/b/d/c/k;)V

    sget-object v0, La/b/d/c/k;->MUTED:La/b/d/c/k;

    invoke-static {v0}, La/b/d/c/k;->a(La/b/d/c/k;)V

    new-instance v0, La/b/d/c/k;

    invoke-direct {v0}, La/b/d/c/k;-><init>()V

    sput-object v0, La/b/d/c/k;->DARK_MUTED:La/b/d/c/k;

    sget-object v0, La/b/d/c/k;->DARK_MUTED:La/b/d/c/k;

    .line 7
    iget-object v1, v0, La/b/d/c/k;->mLightnessTargets:[F

    aput v6, v1, v5

    aput v7, v1, v8

    .line 8
    invoke-static {v0}, La/b/d/c/k;->a(La/b/d/c/k;)V

    return-void
.end method

.method constructor <init>()V
    .locals 7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x3

    new-array v1, v0, [F

    iput-object v1, p0, La/b/d/c/k;->mSaturationTargets:[F

    new-array v1, v0, [F

    iput-object v1, p0, La/b/d/c/k;->mLightnessTargets:[F

    new-array v0, v0, [F

    iput-object v0, p0, La/b/d/c/k;->mWeights:[F

    const/4 v0, 0x1

    iput-boolean v0, p0, La/b/d/c/k;->mIsExclusive:Z

    iget-object v1, p0, La/b/d/c/k;->mSaturationTargets:[F

    const/4 v2, 0x0

    const/4 v3, 0x0

    .line 1
    aput v2, v1, v3

    const/high16 v4, 0x3f000000    # 0.5f

    aput v4, v1, v0

    const/high16 v5, 0x3f800000    # 1.0f

    const/4 v6, 0x2

    aput v5, v1, v6

    .line 2
    iget-object v1, p0, La/b/d/c/k;->mLightnessTargets:[F

    .line 3
    aput v2, v1, v3

    aput v4, v1, v0

    aput v5, v1, v6

    .line 4
    iget-object p0, p0, La/b/d/c/k;->mWeights:[F

    const v1, 0x3e75c28f    # 0.24f

    aput v1, p0, v3

    const v2, 0x3f051eb8    # 0.52f

    aput v2, p0, v0

    aput v1, p0, v6

    return-void
.end method

.method private static a(La/b/d/c/k;)V
    .locals 2

    iget-object p0, p0, La/b/d/c/k;->mSaturationTargets:[F

    const/4 v0, 0x1

    const v1, 0x3e99999a    # 0.3f

    aput v1, p0, v0

    const/4 v0, 0x2

    const v1, 0x3ecccccd    # 0.4f

    aput v1, p0, v0

    return-void
.end method

.method private static b(La/b/d/c/k;)V
    .locals 2

    iget-object p0, p0, La/b/d/c/k;->mLightnessTargets:[F

    const/4 v0, 0x0

    const v1, 0x3e99999a    # 0.3f

    aput v1, p0, v0

    const/4 v0, 0x1

    const/high16 v1, 0x3f000000    # 0.5f

    aput v1, p0, v0

    const/4 v0, 0x2

    const v1, 0x3f333333    # 0.7f

    aput v1, p0, v0

    return-void
.end method

.method private static c(La/b/d/c/k;)V
    .locals 2

    iget-object p0, p0, La/b/d/c/k;->mSaturationTargets:[F

    const/4 v0, 0x0

    const v1, 0x3eb33333    # 0.35f

    aput v1, p0, v0

    const/4 v0, 0x1

    const/high16 v1, 0x3f800000    # 1.0f

    aput v1, p0, v0

    return-void
.end method


# virtual methods
.method public getLightnessWeight()F
    .locals 1

    iget-object p0, p0, La/b/d/c/k;->mWeights:[F

    const/4 v0, 0x1

    aget p0, p0, v0

    return p0
.end method

.method public getPopulationWeight()F
    .locals 1

    iget-object p0, p0, La/b/d/c/k;->mWeights:[F

    const/4 v0, 0x2

    aget p0, p0, v0

    return p0
.end method

.method public getSaturationWeight()F
    .locals 1

    iget-object p0, p0, La/b/d/c/k;->mWeights:[F

    const/4 v0, 0x0

    aget p0, p0, v0

    return p0
.end method
