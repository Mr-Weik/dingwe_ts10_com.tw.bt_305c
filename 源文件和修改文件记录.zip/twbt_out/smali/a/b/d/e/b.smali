.class public interface abstract La/b/d/e/b;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract a(La/b/d/e/c;Landroid/view/Menu;)Z
.end method

.method public abstract a(La/b/d/e/c;Landroid/view/MenuItem;)Z
.end method

.method public abstract b(La/b/d/e/c;Landroid/view/Menu;)Z
.end method

.method public abstract c(La/b/d/e/c;)V
.end method
