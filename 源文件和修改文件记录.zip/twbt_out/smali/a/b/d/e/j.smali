.class La/b/d/e/j;
.super Ljava/lang/Object;
.source ""


# instance fields
.field private Al:Ljava/lang/CharSequence;

.field private Bl:I

.field private Cl:C

.field private Dl:I

.field private El:C

.field private Fl:I

.field private Gl:I

.field private Hl:Z

.field private Il:Z

.field private Jl:Z

.field private Kl:I

.field private Ll:I

.field private Ml:Ljava/lang/String;

.field private Nl:Ljava/lang/String;

.field private Ol:Ljava/lang/String;

.field Pl:Landroid/support/v4/view/f;

.field private Ql:Ljava/lang/CharSequence;

.field private Rl:Ljava/lang/CharSequence;

.field private Sl:Landroid/content/res/ColorStateList;

.field private Tl:Landroid/graphics/PorterDuff$Mode;

.field private itemId:I

.field private menu:Landroid/view/Menu;

.field final synthetic n:La/b/d/e/k;

.field private rl:I

.field private sl:I

.field private tl:I

.field private ul:I

.field private vl:Z

.field private wl:Z

.field private xl:Z

.field private yl:I

.field private zl:Ljava/lang/CharSequence;


# direct methods
.method public constructor <init>(La/b/d/e/k;Landroid/view/Menu;)V
    .locals 0

    iput-object p1, p0, La/b/d/e/j;->n:La/b/d/e/k;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 p1, 0x0

    iput-object p1, p0, La/b/d/e/j;->Sl:Landroid/content/res/ColorStateList;

    iput-object p1, p0, La/b/d/e/j;->Tl:Landroid/graphics/PorterDuff$Mode;

    iput-object p2, p0, La/b/d/e/j;->menu:Landroid/view/Menu;

    invoke-virtual {p0}, La/b/d/e/j;->resetGroup()V

    return-void
.end method

.method private a(Ljava/lang/String;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    :try_start_0
    iget-object p0, p0, La/b/d/e/j;->n:La/b/d/e/k;

    iget-object p0, p0, La/b/d/e/k;->mContext:Landroid/content/Context;

    invoke-virtual {p0}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object p0

    invoke-virtual {p0, p1}, Ljava/lang/ClassLoader;->loadClass(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object p0

    invoke-virtual {p0, p2}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object p0

    const/4 p2, 0x1

    invoke-virtual {p0, p2}, Ljava/lang/reflect/Constructor;->setAccessible(Z)V

    invoke-virtual {p0, p3}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    move-exception p0

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const-string p3, "Cannot instantiate class: "

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string p2, "SupportMenuInflater"

    invoke-static {p2, p1, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 p0, 0x0

    return-object p0
.end method

.method private b(Landroid/view/MenuItem;)V
    .locals 5

    iget-boolean v0, p0, La/b/d/e/j;->Hl:Z

    invoke-interface {p1, v0}, Landroid/view/MenuItem;->setChecked(Z)Landroid/view/MenuItem;

    move-result-object v0

    iget-boolean v1, p0, La/b/d/e/j;->Il:Z

    invoke-interface {v0, v1}, Landroid/view/MenuItem;->setVisible(Z)Landroid/view/MenuItem;

    move-result-object v0

    iget-boolean v1, p0, La/b/d/e/j;->Jl:Z

    invoke-interface {v0, v1}, Landroid/view/MenuItem;->setEnabled(Z)Landroid/view/MenuItem;

    move-result-object v0

    iget v1, p0, La/b/d/e/j;->Gl:I

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-lt v1, v3, :cond_0

    move v1, v3

    goto :goto_0

    :cond_0
    move v1, v2

    :goto_0
    invoke-interface {v0, v1}, Landroid/view/MenuItem;->setCheckable(Z)Landroid/view/MenuItem;

    move-result-object v0

    iget-object v1, p0, La/b/d/e/j;->Al:Ljava/lang/CharSequence;

    invoke-interface {v0, v1}, Landroid/view/MenuItem;->setTitleCondensed(Ljava/lang/CharSequence;)Landroid/view/MenuItem;

    move-result-object v0

    iget v1, p0, La/b/d/e/j;->Bl:I

    invoke-interface {v0, v1}, Landroid/view/MenuItem;->setIcon(I)Landroid/view/MenuItem;

    iget v0, p0, La/b/d/e/j;->Kl:I

    if-ltz v0, :cond_1

    invoke-interface {p1, v0}, Landroid/view/MenuItem;->setShowAsAction(I)V

    :cond_1
    iget-object v0, p0, La/b/d/e/j;->Ol:Ljava/lang/String;

    if-eqz v0, :cond_3

    iget-object v0, p0, La/b/d/e/j;->n:La/b/d/e/k;

    iget-object v0, v0, La/b/d/e/k;->mContext:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->isRestricted()Z

    move-result v0

    if-nez v0, :cond_2

    new-instance v0, La/b/d/e/i;

    iget-object v1, p0, La/b/d/e/j;->n:La/b/d/e/k;

    invoke-virtual {v1}, La/b/d/e/k;->yb()Ljava/lang/Object;

    move-result-object v1

    iget-object v4, p0, La/b/d/e/j;->Ol:Ljava/lang/String;

    invoke-direct {v0, v1, v4}, La/b/d/e/i;-><init>(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {p1, v0}, Landroid/view/MenuItem;->setOnMenuItemClickListener(Landroid/view/MenuItem$OnMenuItemClickListener;)Landroid/view/MenuItem;

    goto :goto_1

    :cond_2
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "The android:onClick attribute cannot be used within a restricted context"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_3
    :goto_1
    instance-of v0, p1, Landroid/support/v7/view/menu/u;

    if-eqz v0, :cond_4

    move-object v1, p1

    check-cast v1, Landroid/support/v7/view/menu/u;

    :cond_4
    iget v1, p0, La/b/d/e/j;->Gl:I

    const/4 v4, 0x2

    if-lt v1, v4, :cond_6

    if-eqz v0, :cond_5

    move-object v0, p1

    check-cast v0, Landroid/support/v7/view/menu/u;

    invoke-virtual {v0, v3}, Landroid/support/v7/view/menu/u;->setExclusiveCheckable(Z)V

    goto :goto_2

    :cond_5
    instance-of v0, p1, Landroid/support/v7/view/menu/z;

    if-eqz v0, :cond_6

    move-object v0, p1

    check-cast v0, Landroid/support/v7/view/menu/z;

    invoke-virtual {v0, v3}, Landroid/support/v7/view/menu/z;->setExclusiveCheckable(Z)V

    :cond_6
    :goto_2
    iget-object v0, p0, La/b/d/e/j;->Ml:Ljava/lang/String;

    if-eqz v0, :cond_7

    sget-object v1, La/b/d/e/k;->gt:[Ljava/lang/Class;

    iget-object v2, p0, La/b/d/e/j;->n:La/b/d/e/k;

    iget-object v2, v2, La/b/d/e/k;->et:[Ljava/lang/Object;

    invoke-direct {p0, v0, v1, v2}, La/b/d/e/j;->a(Ljava/lang/String;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    invoke-interface {p1, v0}, Landroid/view/MenuItem;->setActionView(Landroid/view/View;)Landroid/view/MenuItem;

    move v2, v3

    :cond_7
    iget v0, p0, La/b/d/e/j;->Ll:I

    if-lez v0, :cond_9

    if-nez v2, :cond_8

    invoke-interface {p1, v0}, Landroid/view/MenuItem;->setActionView(I)Landroid/view/MenuItem;

    goto :goto_3

    :cond_8
    const-string v0, "SupportMenuInflater"

    const-string v1, "Ignoring attribute \'itemActionViewLayout\'. Action view already specified."

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    :cond_9
    :goto_3
    iget-object v0, p0, La/b/d/e/j;->Pl:Landroid/support/v4/view/f;

    if-eqz v0, :cond_b

    .line 1
    instance-of v1, p1, La/b/c/c/a/b;

    if-eqz v1, :cond_a

    move-object v1, p1

    check-cast v1, La/b/c/c/a/b;

    invoke-interface {v1, v0}, La/b/c/c/a/b;->a(Landroid/support/v4/view/f;)La/b/c/c/a/b;

    goto :goto_4

    :cond_a
    const-string v0, "MenuItemCompat"

    const-string v1, "setActionProvider: item does not implement SupportMenuItem; ignoring"

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 2
    :cond_b
    :goto_4
    iget-object v0, p0, La/b/d/e/j;->Ql:Ljava/lang/CharSequence;

    .line 3
    instance-of v1, p1, La/b/c/c/a/b;

    if-eqz v1, :cond_c

    move-object v2, p1

    check-cast v2, La/b/c/c/a/b;

    invoke-interface {v2, v0}, La/b/c/c/a/b;->setContentDescription(Ljava/lang/CharSequence;)La/b/c/c/a/b;

    goto :goto_5

    :cond_c
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-interface {p1, v0}, Landroid/view/MenuItem;->setContentDescription(Ljava/lang/CharSequence;)Landroid/view/MenuItem;

    .line 4
    :goto_5
    iget-object v0, p0, La/b/d/e/j;->Rl:Ljava/lang/CharSequence;

    if-eqz v1, :cond_d

    .line 5
    move-object v2, p1

    check-cast v2, La/b/c/c/a/b;

    invoke-interface {v2, v0}, La/b/c/c/a/b;->setTooltipText(Ljava/lang/CharSequence;)La/b/c/c/a/b;

    goto :goto_6

    :cond_d
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-interface {p1, v0}, Landroid/view/MenuItem;->setTooltipText(Ljava/lang/CharSequence;)Landroid/view/MenuItem;

    .line 6
    :goto_6
    iget-char v0, p0, La/b/d/e/j;->Cl:C

    iget v2, p0, La/b/d/e/j;->Dl:I

    if-eqz v1, :cond_e

    .line 7
    move-object v3, p1

    check-cast v3, La/b/c/c/a/b;

    invoke-interface {v3, v0, v2}, La/b/c/c/a/b;->setAlphabeticShortcut(CI)Landroid/view/MenuItem;

    goto :goto_7

    :cond_e
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-interface {p1, v0, v2}, Landroid/view/MenuItem;->setAlphabeticShortcut(CI)Landroid/view/MenuItem;

    .line 8
    :goto_7
    iget-char v0, p0, La/b/d/e/j;->El:C

    iget v2, p0, La/b/d/e/j;->Fl:I

    if-eqz v1, :cond_f

    .line 9
    move-object v3, p1

    check-cast v3, La/b/c/c/a/b;

    invoke-interface {v3, v0, v2}, La/b/c/c/a/b;->setNumericShortcut(CI)Landroid/view/MenuItem;

    goto :goto_8

    :cond_f
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-interface {p1, v0, v2}, Landroid/view/MenuItem;->setNumericShortcut(CI)Landroid/view/MenuItem;

    .line 10
    :goto_8
    iget-object v0, p0, La/b/d/e/j;->Tl:Landroid/graphics/PorterDuff$Mode;

    if-eqz v0, :cond_11

    if-eqz v1, :cond_10

    .line 11
    move-object v2, p1

    check-cast v2, La/b/c/c/a/b;

    invoke-interface {v2, v0}, La/b/c/c/a/b;->setIconTintMode(Landroid/graphics/PorterDuff$Mode;)Landroid/view/MenuItem;

    goto :goto_9

    :cond_10
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-interface {p1, v0}, Landroid/view/MenuItem;->setIconTintMode(Landroid/graphics/PorterDuff$Mode;)Landroid/view/MenuItem;

    .line 12
    :cond_11
    :goto_9
    iget-object p0, p0, La/b/d/e/j;->Sl:Landroid/content/res/ColorStateList;

    if-eqz p0, :cond_13

    if-eqz v1, :cond_12

    .line 13
    check-cast p1, La/b/c/c/a/b;

    invoke-interface {p1, p0}, La/b/c/c/a/b;->setIconTintList(Landroid/content/res/ColorStateList;)Landroid/view/MenuItem;

    goto :goto_a

    :cond_12
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-interface {p1, p0}, Landroid/view/MenuItem;->setIconTintList(Landroid/content/res/ColorStateList;)Landroid/view/MenuItem;

    :cond_13
    :goto_a
    return-void
.end method


# virtual methods
.method public addItem()V
    .locals 5

    const/4 v0, 0x1

    iput-boolean v0, p0, La/b/d/e/j;->xl:Z

    iget-object v0, p0, La/b/d/e/j;->menu:Landroid/view/Menu;

    iget v1, p0, La/b/d/e/j;->rl:I

    iget v2, p0, La/b/d/e/j;->itemId:I

    iget v3, p0, La/b/d/e/j;->yl:I

    iget-object v4, p0, La/b/d/e/j;->zl:Ljava/lang/CharSequence;

    invoke-interface {v0, v1, v2, v3, v4}, Landroid/view/Menu;->add(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    move-result-object v0

    invoke-direct {p0, v0}, La/b/d/e/j;->b(Landroid/view/MenuItem;)V

    return-void
.end method

.method public addSubMenuItem()Landroid/view/SubMenu;
    .locals 5

    const/4 v0, 0x1

    iput-boolean v0, p0, La/b/d/e/j;->xl:Z

    iget-object v0, p0, La/b/d/e/j;->menu:Landroid/view/Menu;

    iget v1, p0, La/b/d/e/j;->rl:I

    iget v2, p0, La/b/d/e/j;->itemId:I

    iget v3, p0, La/b/d/e/j;->yl:I

    iget-object v4, p0, La/b/d/e/j;->zl:Ljava/lang/CharSequence;

    invoke-interface {v0, v1, v2, v3, v4}, Landroid/view/Menu;->addSubMenu(IIILjava/lang/CharSequence;)Landroid/view/SubMenu;

    move-result-object v0

    invoke-interface {v0}, Landroid/view/SubMenu;->getItem()Landroid/view/MenuItem;

    move-result-object v1

    invoke-direct {p0, v1}, La/b/d/e/j;->b(Landroid/view/MenuItem;)V

    return-object v0
.end method

.method public hasAddedItem()Z
    .locals 0

    iget-boolean p0, p0, La/b/d/e/j;->xl:Z

    return p0
.end method

.method public readGroup(Landroid/util/AttributeSet;)V
    .locals 3

    iget-object v0, p0, La/b/d/e/j;->n:La/b/d/e/k;

    iget-object v0, v0, La/b/d/e/k;->mContext:Landroid/content/Context;

    sget-object v1, La/b/d/a/b;->MenuGroup:[I

    invoke-virtual {v0, p1, v1}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object p1

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-virtual {p1, v0, v1}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v2

    iput v2, p0, La/b/d/e/j;->rl:I

    const/4 v2, 0x3

    invoke-virtual {p1, v2, v1}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v2

    iput v2, p0, La/b/d/e/j;->sl:I

    const/4 v2, 0x4

    invoke-virtual {p1, v2, v1}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v2

    iput v2, p0, La/b/d/e/j;->tl:I

    const/4 v2, 0x5

    invoke-virtual {p1, v2, v1}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v1

    iput v1, p0, La/b/d/e/j;->ul:I

    const/4 v1, 0x2

    invoke-virtual {p1, v1, v0}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v1

    iput-boolean v1, p0, La/b/d/e/j;->vl:Z

    sget v1, La/b/d/a/b;->wk:I

    invoke-virtual {p1, v1, v0}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v0

    iput-boolean v0, p0, La/b/d/e/j;->wl:Z

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    return-void
.end method

.method public readItem(Landroid/util/AttributeSet;)V
    .locals 6

    iget-object v0, p0, La/b/d/e/j;->n:La/b/d/e/k;

    iget-object v0, v0, La/b/d/e/k;->mContext:Landroid/content/Context;

    sget-object v1, La/b/d/a/b;->MenuItem:[I

    invoke-virtual {v0, p1, v1}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object p1

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-virtual {p1, v1, v0}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v1

    iput v1, p0, La/b/d/e/j;->itemId:I

    iget v1, p0, La/b/d/e/j;->sl:I

    const/4 v2, 0x5

    invoke-virtual {p1, v2, v1}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v1

    iget v2, p0, La/b/d/e/j;->tl:I

    const/4 v3, 0x6

    invoke-virtual {p1, v3, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v2

    const/high16 v3, -0x10000

    and-int/2addr v1, v3

    const v3, 0xffff

    and-int/2addr v2, v3

    or-int/2addr v1, v2

    iput v1, p0, La/b/d/e/j;->yl:I

    const/4 v1, 0x7

    invoke-virtual {p1, v1}, Landroid/content/res/TypedArray;->getText(I)Ljava/lang/CharSequence;

    move-result-object v1

    iput-object v1, p0, La/b/d/e/j;->zl:Ljava/lang/CharSequence;

    const/16 v1, 0x8

    invoke-virtual {p1, v1}, Landroid/content/res/TypedArray;->getText(I)Ljava/lang/CharSequence;

    move-result-object v1

    iput-object v1, p0, La/b/d/e/j;->Al:Ljava/lang/CharSequence;

    sget v1, La/b/d/a/b;->xk:I

    invoke-virtual {p1, v1, v0}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v1

    iput v1, p0, La/b/d/e/j;->Bl:I

    const/16 v1, 0x9

    invoke-virtual {p1, v1}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_0

    move v1, v0

    goto :goto_0

    .line 1
    :cond_0
    invoke-virtual {v1, v0}, Ljava/lang/String;->charAt(I)C

    move-result v1

    .line 2
    :goto_0
    iput-char v1, p0, La/b/d/e/j;->Cl:C

    const/16 v1, 0x1000

    const/16 v2, 0x10

    invoke-virtual {p1, v2, v1}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v2

    iput v2, p0, La/b/d/e/j;->Dl:I

    const/16 v2, 0xa

    invoke-virtual {p1, v2}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v2

    if-nez v2, :cond_1

    move v2, v0

    goto :goto_1

    .line 3
    :cond_1
    invoke-virtual {v2, v0}, Ljava/lang/String;->charAt(I)C

    move-result v2

    .line 4
    :goto_1
    iput-char v2, p0, La/b/d/e/j;->El:C

    const/16 v2, 0x14

    invoke-virtual {p1, v2, v1}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v1

    iput v1, p0, La/b/d/e/j;->Fl:I

    const/16 v1, 0xb

    invoke-virtual {p1, v1}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-virtual {p1, v1, v0}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v1

    goto :goto_2

    :cond_2
    iget v1, p0, La/b/d/e/j;->ul:I

    :goto_2
    iput v1, p0, La/b/d/e/j;->Gl:I

    const/4 v1, 0x3

    invoke-virtual {p1, v1, v0}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v1

    iput-boolean v1, p0, La/b/d/e/j;->Hl:Z

    const/4 v1, 0x4

    iget-boolean v2, p0, La/b/d/e/j;->vl:Z

    invoke-virtual {p1, v1, v2}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v1

    iput-boolean v1, p0, La/b/d/e/j;->Il:Z

    iget-boolean v1, p0, La/b/d/e/j;->wl:Z

    const/4 v2, 0x1

    invoke-virtual {p1, v2, v1}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v1

    iput-boolean v1, p0, La/b/d/e/j;->Jl:Z

    const/16 v1, 0x15

    const/4 v3, -0x1

    invoke-virtual {p1, v1, v3}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v1

    iput v1, p0, La/b/d/e/j;->Kl:I

    const/16 v1, 0xc

    invoke-virtual {p1, v1}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, La/b/d/e/j;->Ol:Ljava/lang/String;

    const/16 v1, 0xd

    invoke-virtual {p1, v1, v0}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v1

    iput v1, p0, La/b/d/e/j;->Ll:I

    const/16 v1, 0xf

    invoke-virtual {p1, v1}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, La/b/d/e/j;->Ml:Ljava/lang/String;

    const/16 v1, 0xe

    invoke-virtual {p1, v1}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, La/b/d/e/j;->Nl:Ljava/lang/String;

    iget-object v1, p0, La/b/d/e/j;->Nl:Ljava/lang/String;

    if-eqz v1, :cond_3

    goto :goto_3

    :cond_3
    move v2, v0

    :goto_3
    const/4 v1, 0x0

    if-eqz v2, :cond_4

    iget v4, p0, La/b/d/e/j;->Ll:I

    if-nez v4, :cond_4

    iget-object v4, p0, La/b/d/e/j;->Ml:Ljava/lang/String;

    if-nez v4, :cond_4

    iget-object v2, p0, La/b/d/e/j;->Nl:Ljava/lang/String;

    sget-object v4, La/b/d/e/k;->ht:[Ljava/lang/Class;

    iget-object v5, p0, La/b/d/e/j;->n:La/b/d/e/k;

    iget-object v5, v5, La/b/d/e/k;->ft:[Ljava/lang/Object;

    invoke-direct {p0, v2, v4, v5}, La/b/d/e/j;->a(Ljava/lang/String;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/support/v4/view/f;

    iput-object v2, p0, La/b/d/e/j;->Pl:Landroid/support/v4/view/f;

    goto :goto_4

    :cond_4
    if-eqz v2, :cond_5

    const-string v2, "SupportMenuInflater"

    const-string v4, "Ignoring attribute \'actionProviderClass\'. Action view already specified."

    invoke-static {v2, v4}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    :cond_5
    iput-object v1, p0, La/b/d/e/j;->Pl:Landroid/support/v4/view/f;

    :goto_4
    const/16 v2, 0x11

    invoke-virtual {p1, v2}, Landroid/content/res/TypedArray;->getText(I)Ljava/lang/CharSequence;

    move-result-object v2

    iput-object v2, p0, La/b/d/e/j;->Ql:Ljava/lang/CharSequence;

    const/16 v2, 0x16

    invoke-virtual {p1, v2}, Landroid/content/res/TypedArray;->getText(I)Ljava/lang/CharSequence;

    move-result-object v2

    iput-object v2, p0, La/b/d/e/j;->Rl:Ljava/lang/CharSequence;

    const/16 v2, 0x13

    invoke-virtual {p1, v2}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v4

    if-eqz v4, :cond_6

    invoke-virtual {p1, v2, v3}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v2

    iget-object v3, p0, La/b/d/e/j;->Tl:Landroid/graphics/PorterDuff$Mode;

    invoke-static {v2, v3}, Landroid/support/v7/widget/ta;->parseTintMode(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;

    move-result-object v2

    iput-object v2, p0, La/b/d/e/j;->Tl:Landroid/graphics/PorterDuff$Mode;

    goto :goto_5

    :cond_6
    iput-object v1, p0, La/b/d/e/j;->Tl:Landroid/graphics/PorterDuff$Mode;

    :goto_5
    const/16 v2, 0x12

    invoke-virtual {p1, v2}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v3

    if-eqz v3, :cond_7

    invoke-virtual {p1, v2}, Landroid/content/res/TypedArray;->getColorStateList(I)Landroid/content/res/ColorStateList;

    move-result-object v1

    :cond_7
    iput-object v1, p0, La/b/d/e/j;->Sl:Landroid/content/res/ColorStateList;

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    iput-boolean v0, p0, La/b/d/e/j;->xl:Z

    return-void
.end method

.method public resetGroup()V
    .locals 1

    const/4 v0, 0x0

    iput v0, p0, La/b/d/e/j;->rl:I

    iput v0, p0, La/b/d/e/j;->sl:I

    iput v0, p0, La/b/d/e/j;->tl:I

    iput v0, p0, La/b/d/e/j;->ul:I

    const/4 v0, 0x1

    iput-boolean v0, p0, La/b/d/e/j;->vl:Z

    iput-boolean v0, p0, La/b/d/e/j;->wl:Z

    return-void
.end method
