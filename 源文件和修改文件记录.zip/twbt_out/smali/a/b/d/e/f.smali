.class public La/b/d/e/f;
.super La/b/d/e/c;
.source ""

# interfaces
.implements Landroid/support/v7/view/menu/p;


# instance fields
.field private hi:Landroid/support/v7/widget/ActionBarContextView;

.field private ll:Ljava/lang/ref/WeakReference;

.field private mCallback:La/b/d/e/b;

.field private mContext:Landroid/content/Context;

.field private mFinished:Z

.field private mMenu:Landroid/support/v7/view/menu/r;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/support/v7/widget/ActionBarContextView;La/b/d/e/b;Z)V
    .locals 0

    invoke-direct {p0}, La/b/d/e/c;-><init>()V

    iput-object p1, p0, La/b/d/e/f;->mContext:Landroid/content/Context;

    iput-object p2, p0, La/b/d/e/f;->hi:Landroid/support/v7/widget/ActionBarContextView;

    iput-object p3, p0, La/b/d/e/f;->mCallback:La/b/d/e/b;

    new-instance p1, Landroid/support/v7/view/menu/r;

    invoke-virtual {p2}, Landroid/view/ViewGroup;->getContext()Landroid/content/Context;

    move-result-object p2

    invoke-direct {p1, p2}, Landroid/support/v7/view/menu/r;-><init>(Landroid/content/Context;)V

    const/4 p2, 0x1

    invoke-virtual {p1, p2}, Landroid/support/v7/view/menu/r;->setDefaultShowAsAction(I)Landroid/support/v7/view/menu/r;

    iput-object p1, p0, La/b/d/e/f;->mMenu:Landroid/support/v7/view/menu/r;

    iget-object p1, p0, La/b/d/e/f;->mMenu:Landroid/support/v7/view/menu/r;

    invoke-virtual {p1, p0}, Landroid/support/v7/view/menu/r;->a(Landroid/support/v7/view/menu/p;)V

    return-void
.end method


# virtual methods
.method public b(Landroid/support/v7/view/menu/r;)V
    .locals 1

    .line 1
    iget-object p1, p0, La/b/d/e/f;->mCallback:La/b/d/e/b;

    iget-object v0, p0, La/b/d/e/f;->mMenu:Landroid/support/v7/view/menu/r;

    invoke-interface {p1, p0, v0}, La/b/d/e/b;->b(La/b/d/e/c;Landroid/view/Menu;)Z

    .line 2
    iget-object p0, p0, La/b/d/e/f;->hi:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {p0}, Landroid/support/v7/widget/ActionBarContextView;->showOverflowMenu()Z

    return-void
.end method

.method public c(Landroid/support/v7/view/menu/r;Landroid/view/MenuItem;)Z
    .locals 0

    iget-object p1, p0, La/b/d/e/f;->mCallback:La/b/d/e/b;

    invoke-interface {p1, p0, p2}, La/b/d/e/b;->a(La/b/d/e/c;Landroid/view/MenuItem;)Z

    move-result p0

    return p0
.end method

.method public finish()V
    .locals 2

    iget-boolean v0, p0, La/b/d/e/f;->mFinished:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, La/b/d/e/f;->mFinished:Z

    iget-object v0, p0, La/b/d/e/f;->hi:Landroid/support/v7/widget/ActionBarContextView;

    const/16 v1, 0x20

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->sendAccessibilityEvent(I)V

    iget-object v0, p0, La/b/d/e/f;->mCallback:La/b/d/e/b;

    invoke-interface {v0, p0}, La/b/d/e/b;->c(La/b/d/e/c;)V

    return-void
.end method

.method public getCustomView()Landroid/view/View;
    .locals 0

    iget-object p0, p0, La/b/d/e/f;->ll:Ljava/lang/ref/WeakReference;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/view/View;

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return-object p0
.end method

.method public getMenu()Landroid/view/Menu;
    .locals 0

    iget-object p0, p0, La/b/d/e/f;->mMenu:Landroid/support/v7/view/menu/r;

    return-object p0
.end method

.method public getMenuInflater()Landroid/view/MenuInflater;
    .locals 1

    new-instance v0, La/b/d/e/k;

    iget-object p0, p0, La/b/d/e/f;->hi:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getContext()Landroid/content/Context;

    move-result-object p0

    invoke-direct {v0, p0}, La/b/d/e/k;-><init>(Landroid/content/Context;)V

    return-object v0
.end method

.method public getSubtitle()Ljava/lang/CharSequence;
    .locals 0

    iget-object p0, p0, La/b/d/e/f;->hi:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {p0}, Landroid/support/v7/widget/ActionBarContextView;->getSubtitle()Ljava/lang/CharSequence;

    move-result-object p0

    return-object p0
.end method

.method public getTitle()Ljava/lang/CharSequence;
    .locals 0

    iget-object p0, p0, La/b/d/e/f;->hi:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {p0}, Landroid/support/v7/widget/ActionBarContextView;->getTitle()Ljava/lang/CharSequence;

    move-result-object p0

    return-object p0
.end method

.method public invalidate()V
    .locals 2

    iget-object v0, p0, La/b/d/e/f;->mCallback:La/b/d/e/b;

    iget-object v1, p0, La/b/d/e/f;->mMenu:Landroid/support/v7/view/menu/r;

    invoke-interface {v0, p0, v1}, La/b/d/e/b;->b(La/b/d/e/c;Landroid/view/Menu;)Z

    return-void
.end method

.method public isTitleOptional()Z
    .locals 0

    iget-object p0, p0, La/b/d/e/f;->hi:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {p0}, Landroid/support/v7/widget/ActionBarContextView;->isTitleOptional()Z

    move-result p0

    return p0
.end method

.method public setCustomView(Landroid/view/View;)V
    .locals 1

    iget-object v0, p0, La/b/d/e/f;->hi:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {v0, p1}, Landroid/support/v7/widget/ActionBarContextView;->setCustomView(Landroid/view/View;)V

    if-eqz p1, :cond_0

    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    iput-object v0, p0, La/b/d/e/f;->ll:Ljava/lang/ref/WeakReference;

    return-void
.end method

.method public setSubtitle(I)V
    .locals 1

    iget-object v0, p0, La/b/d/e/f;->mContext:Landroid/content/Context;

    invoke-virtual {v0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p1

    .line 1
    iget-object p0, p0, La/b/d/e/f;->hi:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/ActionBarContextView;->setSubtitle(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public setSubtitle(Ljava/lang/CharSequence;)V
    .locals 0

    iget-object p0, p0, La/b/d/e/f;->hi:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/ActionBarContextView;->setSubtitle(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public setTitle(I)V
    .locals 1

    iget-object v0, p0, La/b/d/e/f;->mContext:Landroid/content/Context;

    invoke-virtual {v0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p1

    .line 1
    iget-object p0, p0, La/b/d/e/f;->hi:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/ActionBarContextView;->setTitle(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public setTitle(Ljava/lang/CharSequence;)V
    .locals 0

    iget-object p0, p0, La/b/d/e/f;->hi:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/ActionBarContextView;->setTitle(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public setTitleOptionalHint(Z)V
    .locals 0

    invoke-super {p0, p1}, La/b/d/e/c;->setTitleOptionalHint(Z)V

    iget-object p0, p0, La/b/d/e/f;->hi:Landroid/support/v7/widget/ActionBarContextView;

    invoke-virtual {p0, p1}, Landroid/support/v7/widget/ActionBarContextView;->setTitleOptional(Z)V

    return-void
.end method
