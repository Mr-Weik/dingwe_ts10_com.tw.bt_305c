.class public La/b/d/e/h;
.super Landroid/view/ActionMode;
.source ""


# instance fields
.field final Am:La/b/d/e/c;

.field final mContext:Landroid/content/Context;


# direct methods
.method public constructor <init>(Landroid/content/Context;La/b/d/e/c;)V
    .locals 0

    invoke-direct {p0}, Landroid/view/ActionMode;-><init>()V

    iput-object p1, p0, La/b/d/e/h;->mContext:Landroid/content/Context;

    iput-object p2, p0, La/b/d/e/h;->Am:La/b/d/e/c;

    return-void
.end method


# virtual methods
.method public finish()V
    .locals 0

    iget-object p0, p0, La/b/d/e/h;->Am:La/b/d/e/c;

    invoke-virtual {p0}, La/b/d/e/c;->finish()V

    return-void
.end method

.method public getCustomView()Landroid/view/View;
    .locals 0

    iget-object p0, p0, La/b/d/e/h;->Am:La/b/d/e/c;

    invoke-virtual {p0}, La/b/d/e/c;->getCustomView()Landroid/view/View;

    move-result-object p0

    return-object p0
.end method

.method public getMenu()Landroid/view/Menu;
    .locals 1

    iget-object v0, p0, La/b/d/e/h;->mContext:Landroid/content/Context;

    iget-object p0, p0, La/b/d/e/h;->Am:La/b/d/e/c;

    invoke-virtual {p0}, La/b/d/e/c;->getMenu()Landroid/view/Menu;

    move-result-object p0

    check-cast p0, La/b/c/c/a/a;

    invoke-static {v0, p0}, Landroid/support/v7/view/menu/J;->a(Landroid/content/Context;La/b/c/c/a/a;)Landroid/view/Menu;

    move-result-object p0

    return-object p0
.end method

.method public getMenuInflater()Landroid/view/MenuInflater;
    .locals 0

    iget-object p0, p0, La/b/d/e/h;->Am:La/b/d/e/c;

    invoke-virtual {p0}, La/b/d/e/c;->getMenuInflater()Landroid/view/MenuInflater;

    move-result-object p0

    return-object p0
.end method

.method public getSubtitle()Ljava/lang/CharSequence;
    .locals 0

    iget-object p0, p0, La/b/d/e/h;->Am:La/b/d/e/c;

    invoke-virtual {p0}, La/b/d/e/c;->getSubtitle()Ljava/lang/CharSequence;

    move-result-object p0

    return-object p0
.end method

.method public getTag()Ljava/lang/Object;
    .locals 0

    iget-object p0, p0, La/b/d/e/h;->Am:La/b/d/e/c;

    invoke-virtual {p0}, La/b/d/e/c;->getTag()Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public getTitle()Ljava/lang/CharSequence;
    .locals 0

    iget-object p0, p0, La/b/d/e/h;->Am:La/b/d/e/c;

    invoke-virtual {p0}, La/b/d/e/c;->getTitle()Ljava/lang/CharSequence;

    move-result-object p0

    return-object p0
.end method

.method public getTitleOptionalHint()Z
    .locals 0

    iget-object p0, p0, La/b/d/e/h;->Am:La/b/d/e/c;

    invoke-virtual {p0}, La/b/d/e/c;->getTitleOptionalHint()Z

    move-result p0

    return p0
.end method

.method public invalidate()V
    .locals 0

    iget-object p0, p0, La/b/d/e/h;->Am:La/b/d/e/c;

    invoke-virtual {p0}, La/b/d/e/c;->invalidate()V

    return-void
.end method

.method public isTitleOptional()Z
    .locals 0

    iget-object p0, p0, La/b/d/e/h;->Am:La/b/d/e/c;

    invoke-virtual {p0}, La/b/d/e/c;->isTitleOptional()Z

    move-result p0

    return p0
.end method

.method public setCustomView(Landroid/view/View;)V
    .locals 0

    iget-object p0, p0, La/b/d/e/h;->Am:La/b/d/e/c;

    invoke-virtual {p0, p1}, La/b/d/e/c;->setCustomView(Landroid/view/View;)V

    return-void
.end method

.method public setSubtitle(I)V
    .locals 0

    iget-object p0, p0, La/b/d/e/h;->Am:La/b/d/e/c;

    invoke-virtual {p0, p1}, La/b/d/e/c;->setSubtitle(I)V

    return-void
.end method

.method public setSubtitle(Ljava/lang/CharSequence;)V
    .locals 0

    iget-object p0, p0, La/b/d/e/h;->Am:La/b/d/e/c;

    invoke-virtual {p0, p1}, La/b/d/e/c;->setSubtitle(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public setTag(Ljava/lang/Object;)V
    .locals 0

    iget-object p0, p0, La/b/d/e/h;->Am:La/b/d/e/c;

    invoke-virtual {p0, p1}, La/b/d/e/c;->setTag(Ljava/lang/Object;)V

    return-void
.end method

.method public setTitle(I)V
    .locals 0

    iget-object p0, p0, La/b/d/e/h;->Am:La/b/d/e/c;

    invoke-virtual {p0, p1}, La/b/d/e/c;->setTitle(I)V

    return-void
.end method

.method public setTitle(Ljava/lang/CharSequence;)V
    .locals 0

    iget-object p0, p0, La/b/d/e/h;->Am:La/b/d/e/c;

    invoke-virtual {p0, p1}, La/b/d/e/c;->setTitle(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public setTitleOptionalHint(Z)V
    .locals 0

    iget-object p0, p0, La/b/d/e/h;->Am:La/b/d/e/c;

    invoke-virtual {p0, p1}, La/b/d/e/c;->setTitleOptionalHint(Z)V

    return-void
.end method
