.class public La/b/d/e/g;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements La/b/d/e/b;


# instance fields
.field final mContext:Landroid/content/Context;

.field final ml:Landroid/view/ActionMode$Callback;

.field final nl:Ljava/util/ArrayList;

.field final ol:La/b/c/f/p;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/view/ActionMode$Callback;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La/b/d/e/g;->mContext:Landroid/content/Context;

    iput-object p2, p0, La/b/d/e/g;->ml:Landroid/view/ActionMode$Callback;

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, La/b/d/e/g;->nl:Ljava/util/ArrayList;

    new-instance p1, La/b/c/f/p;

    invoke-direct {p1}, La/b/c/f/p;-><init>()V

    iput-object p1, p0, La/b/d/e/g;->ol:La/b/c/f/p;

    return-void
.end method

.method private a(Landroid/view/Menu;)Landroid/view/Menu;
    .locals 2

    iget-object v0, p0, La/b/d/e/g;->ol:La/b/c/f/p;

    invoke-virtual {v0, p1}, La/b/c/f/p;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/Menu;

    if-nez v0, :cond_0

    iget-object v0, p0, La/b/d/e/g;->mContext:Landroid/content/Context;

    move-object v1, p1

    check-cast v1, La/b/c/c/a/a;

    invoke-static {v0, v1}, Landroid/support/v7/view/menu/J;->a(Landroid/content/Context;La/b/c/c/a/a;)Landroid/view/Menu;

    move-result-object v0

    iget-object p0, p0, La/b/d/e/g;->ol:La/b/c/f/p;

    invoke-virtual {p0, p1, v0}, La/b/c/f/p;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    return-object v0
.end method


# virtual methods
.method public a(La/b/d/e/c;Landroid/view/Menu;)Z
    .locals 1

    iget-object v0, p0, La/b/d/e/g;->ml:Landroid/view/ActionMode$Callback;

    invoke-virtual {p0, p1}, La/b/d/e/g;->d(La/b/d/e/c;)Landroid/view/ActionMode;

    move-result-object p1

    invoke-direct {p0, p2}, La/b/d/e/g;->a(Landroid/view/Menu;)Landroid/view/Menu;

    move-result-object p0

    invoke-interface {v0, p1, p0}, Landroid/view/ActionMode$Callback;->onCreateActionMode(Landroid/view/ActionMode;Landroid/view/Menu;)Z

    move-result p0

    return p0
.end method

.method public a(La/b/d/e/c;Landroid/view/MenuItem;)Z
    .locals 1

    iget-object v0, p0, La/b/d/e/g;->ml:Landroid/view/ActionMode$Callback;

    invoke-virtual {p0, p1}, La/b/d/e/g;->d(La/b/d/e/c;)Landroid/view/ActionMode;

    move-result-object p1

    iget-object p0, p0, La/b/d/e/g;->mContext:Landroid/content/Context;

    check-cast p2, La/b/c/c/a/b;

    invoke-static {p0, p2}, Landroid/support/v7/view/menu/J;->a(Landroid/content/Context;La/b/c/c/a/b;)Landroid/view/MenuItem;

    move-result-object p0

    invoke-interface {v0, p1, p0}, Landroid/view/ActionMode$Callback;->onActionItemClicked(Landroid/view/ActionMode;Landroid/view/MenuItem;)Z

    move-result p0

    return p0
.end method

.method public b(La/b/d/e/c;Landroid/view/Menu;)Z
    .locals 1

    iget-object v0, p0, La/b/d/e/g;->ml:Landroid/view/ActionMode$Callback;

    invoke-virtual {p0, p1}, La/b/d/e/g;->d(La/b/d/e/c;)Landroid/view/ActionMode;

    move-result-object p1

    invoke-direct {p0, p2}, La/b/d/e/g;->a(Landroid/view/Menu;)Landroid/view/Menu;

    move-result-object p0

    invoke-interface {v0, p1, p0}, Landroid/view/ActionMode$Callback;->onPrepareActionMode(Landroid/view/ActionMode;Landroid/view/Menu;)Z

    move-result p0

    return p0
.end method

.method public c(La/b/d/e/c;)V
    .locals 1

    iget-object v0, p0, La/b/d/e/g;->ml:Landroid/view/ActionMode$Callback;

    invoke-virtual {p0, p1}, La/b/d/e/g;->d(La/b/d/e/c;)Landroid/view/ActionMode;

    move-result-object p0

    invoke-interface {v0, p0}, Landroid/view/ActionMode$Callback;->onDestroyActionMode(Landroid/view/ActionMode;)V

    return-void
.end method

.method public d(La/b/d/e/c;)Landroid/view/ActionMode;
    .locals 4

    iget-object v0, p0, La/b/d/e/g;->nl:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_1

    iget-object v2, p0, La/b/d/e/g;->nl:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, La/b/d/e/h;

    if-eqz v2, :cond_0

    iget-object v3, v2, La/b/d/e/h;->Am:La/b/d/e/c;

    if-ne v3, p1, :cond_0

    return-object v2

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    new-instance v0, La/b/d/e/h;

    iget-object v1, p0, La/b/d/e/g;->mContext:Landroid/content/Context;

    invoke-direct {v0, v1, p1}, La/b/d/e/h;-><init>(Landroid/content/Context;La/b/d/e/c;)V

    iget-object p0, p0, La/b/d/e/g;->nl:Ljava/util/ArrayList;

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-object v0
.end method
