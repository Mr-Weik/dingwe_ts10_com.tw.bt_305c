.class public La/b/d/e/m;
.super Ljava/lang/Object;
.source ""


# instance fields
.field private Ul:Z

.field private final Vl:Landroid/support/v4/view/y;

.field final mAnimators:Ljava/util/ArrayList;

.field private mDuration:J

.field private mInterpolator:Landroid/view/animation/Interpolator;

.field mListener:Landroid/support/v4/view/x;


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-wide/16 v0, -0x1

    iput-wide v0, p0, La/b/d/e/m;->mDuration:J

    new-instance v0, La/b/d/e/l;

    invoke-direct {v0, p0}, La/b/d/e/l;-><init>(La/b/d/e/m;)V

    iput-object v0, p0, La/b/d/e/m;->Vl:Landroid/support/v4/view/y;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/b/d/e/m;->mAnimators:Ljava/util/ArrayList;

    return-void
.end method


# virtual methods
.method Sa()V
    .locals 1

    const/4 v0, 0x0

    iput-boolean v0, p0, La/b/d/e/m;->Ul:Z

    return-void
.end method

.method public a(Landroid/support/v4/view/w;)La/b/d/e/m;
    .locals 1

    iget-boolean v0, p0, La/b/d/e/m;->Ul:Z

    if-nez v0, :cond_0

    iget-object v0, p0, La/b/d/e/m;->mAnimators:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    return-object p0
.end method

.method public a(Landroid/support/v4/view/w;Landroid/support/v4/view/w;)La/b/d/e/m;
    .locals 2

    iget-object v0, p0, La/b/d/e/m;->mAnimators:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {p1}, Landroid/support/v4/view/w;->getDuration()J

    move-result-wide v0

    invoke-virtual {p2, v0, v1}, Landroid/support/v4/view/w;->setStartDelay(J)Landroid/support/v4/view/w;

    iget-object p1, p0, La/b/d/e/m;->mAnimators:Ljava/util/ArrayList;

    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-object p0
.end method

.method public a(Landroid/support/v4/view/x;)La/b/d/e/m;
    .locals 1

    iget-boolean v0, p0, La/b/d/e/m;->Ul:Z

    if-nez v0, :cond_0

    iput-object p1, p0, La/b/d/e/m;->mListener:Landroid/support/v4/view/x;

    :cond_0
    return-object p0
.end method

.method public cancel()V
    .locals 2

    iget-boolean v0, p0, La/b/d/e/m;->Ul:Z

    if-nez v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, La/b/d/e/m;->mAnimators:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/support/v4/view/w;

    invoke-virtual {v1}, Landroid/support/v4/view/w;->cancel()V

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    iput-boolean v0, p0, La/b/d/e/m;->Ul:Z

    return-void
.end method

.method public setDuration(J)La/b/d/e/m;
    .locals 1

    iget-boolean v0, p0, La/b/d/e/m;->Ul:Z

    if-nez v0, :cond_0

    iput-wide p1, p0, La/b/d/e/m;->mDuration:J

    :cond_0
    return-object p0
.end method

.method public setInterpolator(Landroid/view/animation/Interpolator;)La/b/d/e/m;
    .locals 1

    iget-boolean v0, p0, La/b/d/e/m;->Ul:Z

    if-nez v0, :cond_0

    iput-object p1, p0, La/b/d/e/m;->mInterpolator:Landroid/view/animation/Interpolator;

    :cond_0
    return-object p0
.end method

.method public start()V
    .locals 6

    iget-boolean v0, p0, La/b/d/e/m;->Ul:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, La/b/d/e/m;->mAnimators:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/support/v4/view/w;

    iget-wide v2, p0, La/b/d/e/m;->mDuration:J

    const-wide/16 v4, 0x0

    cmp-long v4, v2, v4

    if-ltz v4, :cond_1

    invoke-virtual {v1, v2, v3}, Landroid/support/v4/view/w;->setDuration(J)Landroid/support/v4/view/w;

    :cond_1
    iget-object v2, p0, La/b/d/e/m;->mInterpolator:Landroid/view/animation/Interpolator;

    if-eqz v2, :cond_2

    invoke-virtual {v1, v2}, Landroid/support/v4/view/w;->setInterpolator(Landroid/view/animation/Interpolator;)Landroid/support/v4/view/w;

    :cond_2
    iget-object v2, p0, La/b/d/e/m;->mListener:Landroid/support/v4/view/x;

    if-eqz v2, :cond_3

    iget-object v2, p0, La/b/d/e/m;->Vl:Landroid/support/v4/view/y;

    invoke-virtual {v1, v2}, Landroid/support/v4/view/w;->a(Landroid/support/v4/view/x;)Landroid/support/v4/view/w;

    :cond_3
    invoke-virtual {v1}, Landroid/support/v4/view/w;->start()V

    goto :goto_0

    :cond_4
    const/4 v0, 0x1

    iput-boolean v0, p0, La/b/d/e/m;->Ul:Z

    return-void
.end method
