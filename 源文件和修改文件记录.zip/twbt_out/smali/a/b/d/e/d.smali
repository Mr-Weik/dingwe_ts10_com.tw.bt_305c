.class public interface abstract La/b/d/e/d;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract onActionViewCollapsed()V
.end method

.method public abstract onActionViewExpanded()V
.end method
