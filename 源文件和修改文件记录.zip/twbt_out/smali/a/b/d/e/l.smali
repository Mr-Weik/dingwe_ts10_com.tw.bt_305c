.class La/b/d/e/l;
.super Landroid/support/v4/view/y;
.source ""


# instance fields
.field private Ch:Z

.field private Dh:I

.field final synthetic n:La/b/d/e/m;


# direct methods
.method constructor <init>(La/b/d/e/m;)V
    .locals 0

    iput-object p1, p0, La/b/d/e/l;->n:La/b/d/e/m;

    invoke-direct {p0}, Landroid/support/v4/view/y;-><init>()V

    const/4 p1, 0x0

    iput-boolean p1, p0, La/b/d/e/l;->Ch:Z

    iput p1, p0, La/b/d/e/l;->Dh:I

    return-void
.end method


# virtual methods
.method public d(Landroid/view/View;)V
    .locals 1

    iget p1, p0, La/b/d/e/l;->Dh:I

    add-int/lit8 p1, p1, 0x1

    iput p1, p0, La/b/d/e/l;->Dh:I

    iget-object v0, p0, La/b/d/e/l;->n:La/b/d/e/m;

    iget-object v0, v0, La/b/d/e/m;->mAnimators:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ne p1, v0, :cond_1

    iget-object p1, p0, La/b/d/e/l;->n:La/b/d/e/m;

    iget-object p1, p1, La/b/d/e/m;->mListener:Landroid/support/v4/view/x;

    if-eqz p1, :cond_0

    const/4 v0, 0x0

    invoke-interface {p1, v0}, Landroid/support/v4/view/x;->d(Landroid/view/View;)V

    :cond_0
    const/4 p1, 0x0

    .line 1
    iput p1, p0, La/b/d/e/l;->Dh:I

    iput-boolean p1, p0, La/b/d/e/l;->Ch:Z

    iget-object p0, p0, La/b/d/e/l;->n:La/b/d/e/m;

    invoke-virtual {p0}, La/b/d/e/m;->Sa()V

    :cond_1
    return-void
.end method

.method public f(Landroid/view/View;)V
    .locals 0

    iget-boolean p1, p0, La/b/d/e/l;->Ch:Z

    if-eqz p1, :cond_0

    return-void

    :cond_0
    const/4 p1, 0x1

    iput-boolean p1, p0, La/b/d/e/l;->Ch:Z

    iget-object p0, p0, La/b/d/e/l;->n:La/b/d/e/m;

    iget-object p0, p0, La/b/d/e/m;->mListener:Landroid/support/v4/view/x;

    if-eqz p0, :cond_1

    const/4 p1, 0x0

    invoke-interface {p0, p1}, Landroid/support/v4/view/x;->f(Landroid/view/View;)V

    :cond_1
    return-void
.end method
