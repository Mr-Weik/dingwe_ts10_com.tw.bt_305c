.class public final La/b/d/d/a;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final RecyclerView:[I

.field public static final il:I


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v0, 0x1

    new-array v1, v0, [I

    const/4 v2, 0x0

    const v3, 0x10100b3

    aput v3, v1, v2

    new-array v1, v0, [I

    const v3, 0x101013f

    aput v3, v1, v2

    new-array v1, v0, [I

    const v3, 0x7f030026

    aput v3, v1, v2

    new-array v0, v0, [I

    const v1, 0x7f0300e4

    aput v1, v0, v2

    const/16 v0, 0xb

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    sput-object v0, La/b/d/d/a;->RecyclerView:[I

    return-void

    :array_0
    .array-data 4
        0x10100c4
        0x10100f1
        0x7f030074
        0x7f030075
        0x7f030076
        0x7f030077
        0x7f030078
        0x7f030097
        0x7f0300d0
        0x7f0300dd
        0x7f0300e3
    .end array-data
.end method
